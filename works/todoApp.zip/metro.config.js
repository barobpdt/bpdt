const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// Add any custom configurations here
config.resolver.sourceExts = ['jsx', 'js', 'ts', 'tsx', 'json'];
config.resolver.assetExts = [
  'png', 'jpg', 'jpeg', 'gif', 'webp',
  'ttf', 'otf', 'woff', 'woff2', 'eot'
];

// Add vector icons to the asset extensions
config.resolver.assetExts.push('ttf');

module.exports = config; 