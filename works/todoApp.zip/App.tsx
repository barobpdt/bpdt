import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import { useEffect, useState } from 'react';
import { Alert, FlatList, KeyboardAvoidingView, Modal, Platform, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { Calendar } from 'react-native-calendars';
import 'react-native-gesture-handler';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import AppointmentScreen from './src/pages/AppointmentScreen';
import { selectGrobalData, useGlobalStore } from './src/store/global';

// Type definitions
type Category = {
  id: string;
  name: string;
};

type SortOption = {
  id: string;
  name: string;
};

type Todo = {
  id: string;
  text: string;
  completed: boolean;
  category: string;
  priority: 'high' | 'medium' | 'low';
  createdAt: string;
};

type HomeScreenProps = {
  navigation: any;
};

type DrawerIconProps = {
  color: string;
  size: number;
};

const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

// 카테고리 목록
const CATEGORIES: Category[] = [
  { id: 'all', name: '전체' },
  { id: 'work', name: '업무' },
  { id: 'personal', name: '개인' },
  { id: 'shopping', name: '쇼핑' },
  { id: 'health', name: '건강' },
];

// 정렬 옵션
const SORT_OPTIONS: SortOption[] = [
  { id: 'date', name: '날짜순' },
  { id: 'priority', name: '우선순위순' },
  { id: 'alphabet', name: '알파벳순' },
];

// 홈 스크린 컴포넌트
function HomeScreen({ navigation }: HomeScreenProps) {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [text, setText] = useState<string>('');
  const [category, setCategory] = useState<string>('all');
  const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [sortBy, setSortBy] = useState<string>('date');
  const [editModalVisible, setEditModalVisible] = useState<boolean>(false);
  const [editTodo, setEditTodo] = useState<Todo | null>(null);
  const [editText, setEditText] = useState<string>('');
  const [editCategory, setEditCategory] = useState<string>('');
  const [editPriority, setEditPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [categoryModalVisible, setCategoryModalVisible] = useState<boolean>(false);
  const [sortModalVisible, setSortModalVisible] = useState<boolean>(false);

  const global = useGlobalStore();

  const initPage = async () => {
    loadTodos();
    await selectGrobalData();
    await global.getVersion();
    await global.getMainData();
  }
  // 앱 시작 시 저장된 데이터 로드
  useEffect(() => { initPage() }, []);

  // AsyncStorage에서 데이터 로드
  const loadTodos = async () => {
    try {
      const storedTodos = await AsyncStorage.getItem('todos');
      if (storedTodos !== null) {
        setTodos(JSON.parse(storedTodos));
      }
    } catch (error) {
      console.error('데이터 로드 중 오류 발생:', error);
    }
  };

  // AsyncStorage에 데이터 저장
  const saveTodos = async (updatedTodos: Todo[]) => {
    try {
      await AsyncStorage.setItem('todos', JSON.stringify(updatedTodos));
    } catch (error) {
      console.error('데이터 저장 중 오류 발생:', error);
    }
  };

  // Todo 항목 추가
  const addTodo = () => {
    if (text.trim().length === 0) {
      Alert.alert('오류', '할 일을 입력해주세요.');
      return;
    }
    
    const newTodo: Todo = {
      id: Date.now().toString(),
      text,
      completed: false,
      category,
      priority,
      createdAt: new Date().toISOString(),
    };
    
    const updatedTodos = [...todos, newTodo];
    setTodos(updatedTodos);
    saveTodos(updatedTodos);
    setText('');
  };

  // Todo 항목 삭제
  const deleteTodo = (id: string) => {
    Alert.alert(
      '삭제 확인',
      '이 할 일을 삭제하시겠습니까?',
      [
        { text: '취소', style: 'cancel' },
        { 
          text: '삭제', 
          style: 'destructive',
          onPress: () => {
            const updatedTodos = todos.filter(todo => todo.id !== id);
            setTodos(updatedTodos);
            saveTodos(updatedTodos);
          }
        }
      ]
    );
  };

  // Todo 항목 완료 상태 토글
  const toggleTodo = (id: string) => {
    const updatedTodos = todos.map(todo => 
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    );
    setTodos(updatedTodos);
    saveTodos(updatedTodos);
  };

  // Todo 항목 수정 모달 열기
  const openEditModal = (todo: Todo) => {
    setEditTodo(todo);
    setEditText(todo.text);
    setEditCategory(todo.category);
    setEditPriority(todo.priority);
    setEditModalVisible(true);
  };

  // Todo 항목 수정 저장
  const saveEdit = () => {
    if (editText.trim().length === 0) {
      Alert.alert('오류', '할 일을 입력해주세요.');
      return;
    }
    
    const updatedTodos = todos.map(todo => 
      todo.id === editTodo?.id 
        ? { ...todo, text: editText, category: editCategory, priority: editPriority } 
        : todo
    );
    
    setTodos(updatedTodos);
    saveTodos(updatedTodos);
    setEditModalVisible(false);
  };

  // 정렬된 Todo 목록 가져오기
  const getSortedTodos = () => {
    let sortedTodos = [...todos];
    
    // 카테고리 필터링
    if (category !== 'all') {
      sortedTodos = sortedTodos.filter(todo => todo.category === category);
    }
    
    // 정렬
    switch (sortBy) {
      case 'date':
        sortedTodos.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        break;
      case 'priority':
        const priorityOrder = { high: 0, medium: 1, low: 2 };
        sortedTodos.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
        break;
      case 'alphabet':
        sortedTodos.sort((a, b) => a.text.localeCompare(b.text));
        break;
      default:
        break;
    }
    
    return sortedTodos;
  };

  // 우선순위 색상 가져오기
  const getPriorityColor = (priority: 'high' | 'medium' | 'low') => {
    switch (priority) {
      case 'high': return '#ff6b6b';
      case 'medium': return '#ffd166';
      case 'low': return '#06d6a0';
      default: return '#ffd166';
    }
  };

  // 카테고리 이름 가져오기
  const getCategoryName = (categoryId: string) => {
    const category = CATEGORIES.find(cat => cat.id === categoryId);
    return category ? category.name : '기타';
  };

  // Todo 항목 렌더링
  const renderItem = ({ item }: { item: Todo }) => {
    return (
      <View style={styles.todoItem}>
        <TouchableOpacity 
          style={styles.todoTextContainer} 
          onPress={() => toggleTodo(item.id)}
        >
          <View style={styles.todoHeader}>
            <Text style={[
              styles.todoText,
              item.completed && styles.completedTodo
            ]}>
              {item.text}
            </Text>
            <View style={[styles.priorityIndicator, { backgroundColor: getPriorityColor(item.priority) }]} />
          </View>
          <View style={styles.todoMeta}>
            <Text style={styles.categoryText}>{getCategoryName(item.category)}</Text>
            <Text style={styles.dateText}>
              {new Date(item.createdAt).toLocaleDateString()}
            </Text>
          </View>
        </TouchableOpacity>
        <View style={styles.todoActions}>
          <TouchableOpacity 
            style={styles.editButton}
            onPress={() => openEditModal(item)}
          >
            <Text style={styles.editButtonText}>수정</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.deleteButton}
            onPress={() => deleteTodo(item.id)}
          >
            <Text style={styles.deleteButtonText}>삭제</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  // 수정 모달
  const renderEditModal = () => (
    <Modal
      animationType="slide"
      transparent={true}
      visible={editModalVisible}
      onRequestClose={() => setEditModalVisible(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>할 일 수정</Text>
          
          <TextInput
            style={styles.modalInput}
            placeholder="할 일을 입력하세요"
            value={editText}
            onChangeText={setEditText}
          />
          
          <Text style={styles.modalLabel}>카테고리</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
            {CATEGORIES.map(cat => (
              <TouchableOpacity
                key={cat.id}
                style={[
                  styles.categoryOption,
                  editCategory === cat.id && styles.selectedCategory
                ]}
                onPress={() => setEditCategory(cat.id)}
              >
                <Text style={[
                  styles.categoryOptionText,
                  editCategory === cat.id && styles.selectedCategoryText
                ]}>
                  {cat.name}
                </Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
          
          <Text style={styles.modalLabel}>우선순위</Text>
          <View style={styles.priorityOptions}>
            <TouchableOpacity
              style={[
                styles.priorityOption,
                editPriority === 'low' && styles.selectedPriority
              ]}
              onPress={() => setEditPriority('low')}
            >
              <Text style={styles.priorityOptionText}>낮음</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.priorityOption,
                editPriority === 'medium' && styles.selectedPriority
              ]}
              onPress={() => setEditPriority('medium')}
            >
              <Text style={styles.priorityOptionText}>중간</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.priorityOption,
                editPriority === 'high' && styles.selectedPriority
              ]}
              onPress={() => setEditPriority('high')}
            >
              <Text style={styles.priorityOptionText}>높음</Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.modalButtons}>
            <TouchableOpacity 
              style={[styles.modalButton, styles.cancelButton]}
              onPress={() => setEditModalVisible(false)}
            >
              <Text style={styles.modalButtonText}>취소</Text>
            </TouchableOpacity>
            <TouchableOpacity 
              style={[styles.modalButton, styles.saveButton]}
              onPress={saveEdit}
            >
              <Text style={styles.modalButtonText}>저장</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );

  // 카테고리 선택 모달
  const renderCategoryModal = () => (
    <Modal
      animationType="slide"
      transparent={true}
      visible={categoryModalVisible}
      onRequestClose={() => setCategoryModalVisible(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>카테고리 선택</Text>
          
          {CATEGORIES.map(cat => (
            <TouchableOpacity
              key={cat.id}
              style={[
                styles.modalOption,
                category === cat.id && styles.selectedModalOption
              ]}
              onPress={() => {
                setCategory(cat.id);
                setCategoryModalVisible(false);
              }}
            >
              <Text style={[
                styles.modalOptionText,
                category === cat.id && styles.selectedModalOptionText
              ]}>
                {cat.name}
              </Text>
            </TouchableOpacity>
          ))}
          
          <TouchableOpacity 
            style={[styles.modalButton, styles.cancelButton, { marginTop: 20 }]}
            onPress={() => setCategoryModalVisible(false)}
          >
            <Text style={styles.modalButtonText}>닫기</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  // 정렬 옵션 모달
  const renderSortModal = () => (
    <Modal
      animationType="slide"
      transparent={true}
      visible={sortModalVisible}
      onRequestClose={() => setSortModalVisible(false)}
    >
      <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
          <Text style={styles.modalTitle}>정렬 방식</Text>
          
          {SORT_OPTIONS.map(option => (
            <TouchableOpacity
              key={option.id}
              style={[
                styles.modalOption,
                sortBy === option.id && styles.selectedModalOption
              ]}
              onPress={() => {
                setSortBy(option.id);
                setSortModalVisible(false);
              }}
            >
              <Text style={[
                styles.modalOptionText,
                sortBy === option.id && styles.selectedModalOptionText
              ]}>
                {option.name}
              </Text>
            </TouchableOpacity>
          ))}
          
          <TouchableOpacity 
            style={[styles.modalButton, styles.cancelButton, { marginTop: 20 }]}
            onPress={() => setSortModalVisible(false)}
          >
            <Text style={styles.modalButtonText}>닫기</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );

  return (
    <KeyboardAvoidingView 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <View style={styles.filterContainer}>
        <TouchableOpacity 
          style={styles.filterButton}
          onPress={() => setCategoryModalVisible(true)}
        >
          <Text style={styles.filterButtonText}>
            카테고리: {getCategoryName(category)}
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity 
          style={styles.filterButton}
          onPress={() => setSortModalVisible(true)}
        >
          <Text style={styles.filterButtonText}>
            정렬: {SORT_OPTIONS.find(opt => opt.id === sortBy)?.name}
          </Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="할 일을 입력하세요"
          value={text}
          onChangeText={setText}
          onSubmitEditing={addTodo}
        />
        <TouchableOpacity style={styles.addButton} onPress={addTodo}>
          <Text style={styles.addButtonText}>추가</Text>
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={getSortedTodos()}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        style={styles.list}
      />
      
      {renderEditModal()}
      {renderCategoryModal()}
      {renderSortModal()}
      
      <StatusBar style="auto" />
    </KeyboardAvoidingView>
  );
}

// 친구추가 화면
function FriendsScreen() {
  return (
    <View style={styles.screenContainer}>
      <Text style={styles.screenTitle}>친구추가</Text>
    </View>
  );
}

// 연락처 화면
function ContactsScreen() {
  return (
    <View style={styles.screenContainer}>
      <Text style={styles.screenTitle}>연락처</Text>
    </View>
  );
}

// 일정관리 화면
function ScheduleScreen() {
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [markedDates, setMarkedDates] = useState<{[key: string]: any}>({});

  const onDayPress = (day: any) => {
    setSelectedDate(day.dateString);
    // 선택된 날짜에 마크 추가
    setMarkedDates({
      [day.dateString]: {
        selected: true,
        marked: true,
        selectedColor: '#4A90E2',
      },
    });
  };

  return (
    <View style={styles.screenContainer}>
      <View style={styles.headerContainer}>
        <Text style={styles.screenTitle}>일정관리</Text>
      </View>
      
      <Calendar
        onDayPress={onDayPress}
        markedDates={markedDates}
        theme={{
          backgroundColor: '#ffffff',
          calendarBackground: '#ffffff',
          textSectionTitleColor: '#b6c1cd',
          selectedDayBackgroundColor: '#4A90E2',
          selectedDayTextColor: '#ffffff',
          todayTextColor: '#4A90E2',
          dayTextColor: '#2d4150',
          textDisabledColor: '#d9e1e8',
          dotColor: '#4A90E2',
          selectedDotColor: '#ffffff',
          arrowColor: '#4A90E2',
          monthTextColor: '#4A90E2',
          indicatorColor: '#4A90E2',
          textDayFontWeight: '300',
          textMonthFontWeight: 'bold',
          textDayHeaderFontWeight: '300',
          textDayFontSize: 16,
          textMonthFontSize: 16,
          textDayHeaderFontSize: 16,
        }}
        style={styles.calendar}
      />

      <View style={styles.selectedDateContainer}>
        <Text style={styles.selectedDateText}>
          {selectedDate ? new Date(selectedDate).toLocaleDateString() : '날짜를 선택하세요'}
        </Text>
      </View>
    </View>
  );
}

// Drawer Navigator
function DrawerNavigator() {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      screenOptions={{
        headerStyle: {
          backgroundColor: '#4A90E2',
          elevation: 0,
          shadowOpacity: 0,
        },
        headerTintColor: '#fff',
        headerTitleStyle: {
          fontWeight: 'bold',
          fontSize: 20,
        },
        drawerStyle: {
          backgroundColor: '#fff',
          width: '65%',
          elevation: 0,
          shadowOpacity: 0,
        },
        drawerLabelStyle: {
          marginLeft: 10,
          fontSize: 15,
          fontWeight: '500',
          color: '#333',
        },
        drawerActiveBackgroundColor: '#E8F0FE',
        drawerActiveTintColor: '#4A90E2',
        drawerInactiveTintColor: '#666',
        drawerItemStyle: {
          borderRadius: 8,
          marginHorizontal: 8,
          marginVertical: 4,
          paddingLeft: 8,
          height: 50,
          borderBottomWidth: 1,
          borderBottomColor: '#F0F0F0',
        },
        drawerContentContainerStyle: {
          paddingTop: 20,
        },
      }}
    >
      <Drawer.Screen 
        name="Home" 
        component={HomeScreen} 
        options={{
          title: '할 일 목록',
          drawerIcon: ({ color, size }: DrawerIconProps) => (
            <View style={[styles.drawerIconContainer, { backgroundColor: '#E8F0FE' }]}>
              <Ionicons name="home-outline" size={size} color={color} />
            </View>
          ),
        }}
      />
      <Drawer.Screen 
        name="AppointmentStack" 
        component={AppointmentStack}
        options={{
          title: '약속잡기',
          drawerIcon: ({ color, size }: DrawerIconProps) => (
            <View style={[styles.drawerIconContainer, { backgroundColor: '#FFF3E0' }]}>
              <Ionicons name="calendar-outline" size={size} color={color} />
            </View>
          ),
        }}
      />
      <Drawer.Screen 
        name="Friends" 
        component={FriendsScreen} 
        options={{
          title: '친구추가',
          drawerIcon: ({ color, size }: DrawerIconProps) => (
            <View style={[styles.drawerIconContainer, { backgroundColor: '#E3F2FD' }]}>
              <Ionicons name="people-outline" size={size} color={color} />
            </View>
          ),
        }}
      />
      <Drawer.Screen 
        name="Contacts" 
        component={ContactsScreen} 
        options={{
          title: '연락처',
          drawerIcon: ({ color, size }: DrawerIconProps) => (
            <View style={[styles.drawerIconContainer, { backgroundColor: '#F3E5F5' }]}>
              <Ionicons name="call-outline" size={size} color={color} />
            </View>
          ),
        }}
      />
      <Drawer.Screen 
        name="Schedule" 
        component={ScheduleScreen} 
        options={{
          title: '일정관리',
          drawerIcon: ({ color, size }: DrawerIconProps) => (
            <View style={[styles.drawerIconContainer, { backgroundColor: '#E0F7FA' }]}>
              <Ionicons name="calendar-outline" size={size} color={color} />
            </View>
          ),
        }}
      />
    </Drawer.Navigator>
  );
}

function AppointmentStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="Appointment" 
        component={AppointmentScreen}
        options={{
          headerShown: false
        }}
      />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <NavigationContainer>
        <DrawerNavigator />
        <StatusBar style="auto" />
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  filterContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  filterButton: {
    backgroundColor: '#f0f0f0',
    padding: 10,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 5,
    alignItems: 'center',
  },
  filterButtonText: {
    fontSize: 14,
    color: '#333',
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    height: 50,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    paddingHorizontal: 15,
    marginRight: 10,
    fontSize: 16,
  },
  addButton: {
    backgroundColor: '#f4511e',
    padding: 15,
    borderRadius: 8,
    justifyContent: 'center',
  },
  addButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  list: {
    flex: 1,
  },
  todoItem: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
  },
  todoTextContainer: {
    flex: 1,
  },
  todoHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  todoText: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  completedTodo: {
    textDecorationLine: 'line-through',
    color: '#888',
  },
  todoMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 5,
  },
  categoryText: {
    fontSize: 12,
    color: '#666',
    backgroundColor: '#e0e0e0',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
  },
  dateText: {
    fontSize: 12,
    color: '#888',
  },
  priorityIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginLeft: 10,
  },
  todoActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginTop: 10,
  },
  editButton: {
    backgroundColor: '#4dabf7',
    padding: 8,
    borderRadius: 6,
    marginRight: 10,
  },
  editButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: '#ff6b6b',
    padding: 8,
    borderRadius: 6,
  },
  deleteButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 10,
    padding: 20,
    width: '90%',
    maxHeight: '80%',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  modalInput: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  modalLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  categoryScroll: {
    marginBottom: 15,
  },
  categoryOption: {
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: '#f0f0f0',
    marginRight: 10,
  },
  selectedCategory: {
    backgroundColor: '#f4511e',
  },
  categoryOptionText: {
    color: '#333',
  },
  selectedCategoryText: {
    color: '#fff',
  },
  priorityOptions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  priorityOption: {
    flex: 1,
    padding: 10,
    borderRadius: 8,
    backgroundColor: '#f0f0f0',
    marginHorizontal: 5,
    alignItems: 'center',
  },
  selectedPriority: {
    backgroundColor: '#f4511e',
  },
  priorityOptionText: {
    color: '#333',
  },
  modalButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  modalButton: {
    flex: 1,
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    marginHorizontal: 5,
  },
  cancelButton: {
    backgroundColor: '#e0e0e0',
  },
  saveButton: {
    backgroundColor: '#f4511e',
  },
  modalButtonText: {
    fontWeight: 'bold',
    color: '#333',
  },
  modalOption: {
    padding: 15,
    borderRadius: 8,
    marginBottom: 10,
    backgroundColor: '#f0f0f0',
  },
  selectedModalOption: {
    backgroundColor: '#f4511e',
  },
  modalOptionText: {
    fontSize: 16,
    color: '#333',
  },
  selectedModalOptionText: {
    color: '#fff',
  },
  screenContainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerContainer: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  calendar: {
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 12,
    marginHorizontal: 20,
  },
  selectedDateContainer: {
    marginTop: 20,
    padding: 20,
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    marginHorizontal: 20,
  },
  selectedDateText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
  drawerIconContainer: {
    width: 35,
    height: 35,
    borderRadius: 17.5,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
}); 