import { Ionicons } from '@expo/vector-icons';
import React, { useEffect, useRef, useState } from 'react';
import {
    ActivityIndicator,
    FlatList,
    Image,
    KeyboardAvoidingView,
    Platform,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';
import { useGlobalStore } from '../store/global';
import { ListRoomMessage } from '../types/common';

interface ChatScreenProps {
  route: {
    params: {
      roomNo: string;
      roomNm: string;
    };
  };
  navigation: any;
}

const ChatScreen: React.FC<ChatScreenProps> = ({ route, navigation }) => {
  const { roomNo, roomNm } = route.params;
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const flatListRef = useRef<FlatList>(null);
  const { listRoomMessage } = useGlobalStore();

  // 채팅방 메시지 필터링
  const chatMessages = listRoomMessage.filter(msg => msg.roomNo === roomNo);

  useEffect(() => {
    navigation.setOptions({
      title: roomNm,
      headerRight: () => (
        <TouchableOpacity onPress={handleInfoPress} style={styles.headerButton}>
          <Ionicons name="information-circle-outline" size={24} color="#007AFF" />
        </TouchableOpacity>
      ),
    });
  }, [navigation, roomNm]);

  const handleInfoPress = () => {
    // 채팅방 정보 보기
    navigation.navigate('ChatInfo', { roomNo, roomNm });
  };

  const handleSend = () => {
    if (message.trim() === '') return;

    // TODO: 메시지 전송 로직 구현
    const newMessage: ListRoomMessage = {
      roomNo,
      chatSeq: Date.now().toString(),
      msgTypeCd: 'T',
      msgDesc: message.trim(),
      profileImgFileUrl: '',
      writeMembNo: useGlobalStore.getState().globalData.membNo,
      readChatSeq: '',
      myTextYn: 'Y',
      nickNm: useGlobalStore.getState().membInfo.nickNm,
      addDt: new Date().toISOString(),
      addTime: new Date().toLocaleTimeString(),
      notReadCnt: 0,
      callStatCd: '',
      roomImgUrl: '',
      notReadYn: 'Y',
      roomTypeCd: 'C',
      msgReDesc: '',
      serviceTypeCd: 'M',
      qrNo: '',
      sendSubScr: ''
    };

    // Add message to global store
    useGlobalStore.setState(state => ({
      listRoomMessage: [...state.listRoomMessage, newMessage]
    }));

    // 메시지 전송 후 입력창 초기화
    setMessage('');
  };

  const renderMessage = ({ item }: { item: ListRoomMessage }) => {
    const isMyMessage = item.myTextYn === 'Y';

    return (
      <View style={[
        styles.messageContainer,
        isMyMessage ? styles.myMessageContainer : styles.otherMessageContainer
      ]}>
        {!isMyMessage && (
          <Image
            source={{ uri: item.profileImgFileUrl || 'https://via.placeholder.com/40' }}
            style={styles.profileImage}
          />
        )}
        <View style={[
          styles.messageBubble,
          isMyMessage ? styles.myMessageBubble : styles.otherMessageBubble
        ]}>
          {!isMyMessage && (
            <Text style={styles.senderName}>{item.nickNm}</Text>
          )}
          <Text style={[
            styles.messageText,
            isMyMessage ? styles.myMessageText : styles.otherMessageText
          ]}>
            {item.msgDesc}
          </Text>
          <Text style={styles.messageTime}>
            {new Date(item.addDt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Text>
        </View>
      </View>
    );
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      <FlatList
        ref={flatListRef}
        data={chatMessages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.chatSeq}
        contentContainerStyle={styles.messageList}
        onContentSizeChange={() => flatListRef.current?.scrollToEnd()}
        onLayout={() => flatListRef.current?.scrollToEnd()}
      />

      <View style={styles.inputContainer}>
        <TouchableOpacity style={styles.attachButton}>
          <Ionicons name="attach" size={24} color="#007AFF" />
        </TouchableOpacity>
        
        <TextInput
          style={styles.input}
          value={message}
          onChangeText={setMessage}
          placeholder="메시지를 입력하세요..."
          multiline
          maxLength={1000}
        />
        
        <TouchableOpacity
          style={[styles.sendButton, !message.trim() && styles.sendButtonDisabled]}
          onPress={handleSend}
          disabled={!message.trim()}
        >
          <Ionicons
            name="send"
            size={24}
            color={message.trim() ? '#007AFF' : '#999'}
          />
        </TouchableOpacity>
      </View>

      {isLoading && (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#007AFF" />
        </View>
      )}
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F2F2F7',
  },
  headerButton: {
    marginRight: 15,
  },
  messageList: {
    padding: 10,
  },
  messageContainer: {
    flexDirection: 'row',
    marginBottom: 10,
    maxWidth: '80%',
  },
  myMessageContainer: {
    alignSelf: 'flex-end',
  },
  otherMessageContainer: {
    alignSelf: 'flex-start',
  },
  profileImage: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 8,
  },
  messageBubble: {
    padding: 12,
    borderRadius: 20,
    maxWidth: '100%',
  },
  myMessageBubble: {
    backgroundColor: '#007AFF',
    borderTopRightRadius: 4,
  },
  otherMessageBubble: {
    backgroundColor: '#E5E5EA',
    borderTopLeftRadius: 4,
  },
  senderName: {
    fontSize: 12,
    color: '#666',
    marginBottom: 4,
  },
  messageText: {
    fontSize: 16,
    lineHeight: 20,
  },
  myMessageText: {
    color: '#FFFFFF',
  },
  otherMessageText: {
    color: '#000000',
  },
  messageTime: {
    fontSize: 10,
    color: '#999',
    alignSelf: 'flex-end',
    marginTop: 4,
  },
  inputContainer: {
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#FFFFFF',
    borderTopWidth: 1,
    borderTopColor: '#E5E5EA',
    alignItems: 'center',
  },
  attachButton: {
    padding: 8,
  },
  input: {
    flex: 1,
    backgroundColor: '#F2F2F7',
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 8,
    marginHorizontal: 8,
    maxHeight: 100,
  },
  sendButton: {
    padding: 8,
  },
  sendButtonDisabled: {
    opacity: 0.5,
  },
  loadingContainer: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default ChatScreen; 