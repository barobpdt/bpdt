import React from 'react';
import { Image } from 'react-native';


export type MessageData = {
    mType: string;
    mykey: string;
    msgDesc: string;
    langCd: string; 
    qrNo: string;
    currentDate: string;
    callSeq: string;
    membNo: string;
    roomId: string;    
    onOff:string;
    writeMembNo:string;
    serviceTypeCd: string;
    fileImgUrl: string;
    filePath: string;
    counterPart: string;
}

export type MessageLocation = {
    mType: string;
    roomNo: string ; 
    subScr: string; //요청시 수신받을 구독정보
    membNo: string;
    latitude: number;
    longitude: number; 
}

export type FriendLocation = {
    membNo: string;
    latitude: number;
    longitude: number; 
    curDate: string;
}

export type MessageSendRead = {
    mType: string;
    membNo: string;
    chatSeq: string;
    roomId: string;
}

export type MessageRecieveRead = {
    mType: string;
    roomId: string;
    membNo: string;
    chatSeq: string;  // ,로 여러건 존재할수 잇음
}
/*
{ messageId: '1735794664235669',
  data: 
   { mType: 'M',
     qrNo: 'A-241111-00087-QR',
     callSeq: 'CS250102000006408',
     msgDesc: '차를 이동해주세요',
     mykey: '0n3geshmi',
     fcm_options: { image: 'https://kosk.co.kr/scgd-file/imgData/jikyeojwo_push.png' } },
  mutableContent: true,
  notification: { body: '차를 이동해주세요', title: '차빼줘 문자 호출' },
  from: '684544254587' }
*/ 
export type FCM_RecvData = {
    mType: string;
    qrNo: string;
    callSeq: string;
    msgDesc: string;
    mykey: string;
    membNo: string;
    roomId: string;
    alarmSoundYn?: string;
    alarmInterval?:string;
    image?: string;
}
export type NoteItem = {
    id: string;
    type: string;
    title: string;
    name: string;
    content: string;
    noteList: NoteItem[];
} 

export interface NotificationData {
    title: string;
    message: string;
    data: FCM_RecvData;
}

export interface NotificationData {
    title: string;
    message: string;
    data: FCM_RecvData;
}

/* API 타입정의 */
export type ApiResult = {
    code:string;
    message:string;
    appKey:string;
    status?:number;
    path?:string;
    error?:object;
    isAlert?:string;
    regQr?:string;
    errors?:ApiError[]
}

export type ApiRoom = {
    roomId: string;
    nickNm: string;
}

export type ApiRoomInfo = {
    code: string;
    message: string;
    roomIdList: ApiRoom[]
}

export type ApiError = {
    field:string;
    value:string;
    reason:string;    
}

export type ApiVersionInfo = {
    appKey: string;
    langCd: string;
    storeUrl: string;
    tutoStart: string;
    upRequireInfo: string;
    infoServer: string;
    callServer: string;
}
export type ApiListMenu = {
    appMenuNo: string;
    appMenuNm: string;
    useYn: string;
    viewNum: number;
    filePath: string
}
export type ApiMainMenu = {
    appMenuNo: string;
    appMenuNm: string;
    useYn: string;
    viewNum: number;
    filePath: string;
}
export type ApiRoomIdList = {
    roomId: string;
    nickNm: string;
}
export type ApiMenuInfo = {
    code: string;
    message: string;
    giftYn: string;
    giftUrl: string;
    listMenu: ApiListMenu[];
    mainMenu: ApiMainMenu[];
    roomIdList: ApiRoomIdList[];
}

/* 삭제대상 */
export type ApiTutorialInfo = {
    code:string;
    message:string;
    casMngDataList: ApiCasFields[]
}

export type ApiTutorialImages = {
    code:string;
    message:string;
    tutoDataList: ApiImageFields[]
}

export type ApiCasInfo = {
    code:string;
    message:string;
    casMngDataList: ApiCasFields[]
}

export type ApiImageFields = {
    viewNum: number;
    filePath: string;
    title?:string;
    text?:string;
};

export type ApiCasFields = {
    viewNum: number;
    casNo: string;
    casNm: string;
    casDesc: string;
    requiredYn: string;    
    agreeYn?:boolean|undefined;
    title?:string;
};

export type StackCasFieldsParamList = {
    CasDesc: { data: ApiCasFields }; // CasDesc 스크린에서 받을 데이터 타입 정의
};

export type ApiCasReg = {
    casNo:string;
    selectYn:string;
}
export type ApiCreateSg = {
    deviTpCd:string;
    deviId:string;
    deviOsVer:string;
    appVer:string;
    genCd?:string;
    phoneNo?:string;
    birDt?:string;
    langCd:string;
    currentDate:string;
    casList: ApiCasReg[];
}
export type ApiCreateSgRes = {
    code:string;
    message:string;
    appKey:string;
    langCd:string;
    membNo:string;
    isAlert?:string;
    status?:string;
    errors?:ApiError[]
}

//메인 호출시 전달 파라메타
export type ApiMainRequest = {
    deviTpCd:string;
    langCd:string;
}
//서비스 홈
export type ApiMainMsgRequest = {
    serviceTypeCd:string;
    qrNo:string;
    deviTpCd:string;
    langCd:string;
}
//서비홈 차빼줘
export type ApiMainCarMsgRequest = {
    serviceTypeCd:string;
    qrNo:string;
    deviTpCd:string;
    langCd:string;
    gridSize:number;
    gridPage:number;
    pagingYn:string;
}

//QR 리스트
export type MyQrRequest = {
    serviceTypeCd: string;
    langCd: string;
}

//닉네임 중복체크
export type QrDupNickNmRequest = {
    serviceTypeCd: string;
    nickNm:string;
    langCd: string;
}

export type QrMembJKJRegRequest = {
    qrNo: string;
    serviceTypeCd:string;
    nickNm:string;
    pinNo:string;
    reUseYn:string;  // 재등록시 Y , 신규등록: N
    introductionInfo:string;
    makerCar:string;
    carInfo:string;
    langCd:string;
    currentDate:string;
}

export type QrDtailMsgListRequest = {
    serviceTypeCd: string;
    qrNo: string;
    langCd:string;
}

export type QrDtaiCarMsgListRequest = {
    serviceTypeCd: string;
    qrNo: string;
    langCd:string;
    gridSize: number;
    searchChatSeq: string;
    pagingYn: string
}

export type QrDtailFriendListRequest = {
    serviceTypeCd:string;
    qrNo: string;
    langCd:string;
}

export type SaveFriendRequest = {
    serviceTypeCd: string;
    qrNo: string;
    friendQrNo: string;
    currentDate: string;
    langCd:string;
}

export type DelMsgRequest = {
    serviceTypeCd: string;
    roomNo: string;
    chatSeq: string
    qrNo: string;
    currentDate: string;
    langCd:string;
}

export type FileUploadRequest = {
    fileType:string;
    currentDate:string;
    langCd:string;
    roomNo:string;
    multipartFile:ImageAsset;
}

export type SaveMembNickNmRequest = {
    nickNm:string;
    introductionInfo:string;
    currentDate:string;
    langCd:string;
}

export type SearchFriendListRequest = {
    searchNm:string;
    langCd:string;
}

export type InfoProfileFriendRequest = {
    friendNo:string;
    roomNo: string;
    langCd:string;
}

export type RoomChatMsgListRequest = {
    serviceTypeCd:string;
    roomNo: string;
    langCd:string;
    gridSize: number;
    searchChatSeq: string;
    pagingYn: string;
}

export type ChkRoomInfoRequest = {
    scanQrNo:string;
    myQrNo: string;
    langCd: string;
    currentDate: string;
}


//====================

export type SaveResponse = {
    code: string;
    message: string;
}

//메인 호출시 수신 데이타 
export type ListService = {
    serviceCd: string;
    serviceNm: string;
    useYn: string;
    viewNum: number;
    filePath: string;
}

export type ListAdView = {
    adCd: string;
    adNm: string;
    useYn: string;
}

export type ListRoomMessage = {
    roomNo: string;
    profileImgFileUrl: string;
    nickNm: string;
    msgDesc: string;
    notReadYn: string;
    notReadCnt: number;
    addDt: string;
    addTime: string;
    msgTypeCd: string;
    roomTypeCd: string;
    chatSeq: string;
    msgReDesc: string;
    callStatCd: string;
    serviceTypeCd: string;
    qrNo: string;
    writeMembNo: string;
    sendSubScr: string;
    readChatSeq: string;
    myTextYn: string;
    roomImgUrl: string;
}
export type InfoSetting = {
    alarmUseYn: string;
    alarmIntervalCd: string;
    alarmIntervalNm: string;
    alarmSoundYn: string;
    alarmSoundNm: string;
    alarmVbYn: string;
    callPhoneYn: string;
    callMsgYn: string;
    hideMsgYn: string;
    locationYn: string;
}
export type ListAlert = {
    friendNo: string;
    friendNickNm: string;
    locationCd: string;
    alertMsg: string;
}

export type ListRoom = {
    roomNo: string;
    serviceTypeCd: string;
}

export type ListSubscr = {
    subscr: string;
    serviceTypeCd: string;
}

export type MainResponse = {
    code: string;
    message: string;
    membNo: string;
    nickNm: string;
    introductionInfo: string;
    imgFileUrl: string;
    introImgUrl: string;
    totalNotReadCnt: number;
    totalReadCnt: number;
    listService: ListService[];
    listAdView: ListAdView[];
    listRoomMessage: ListRoomMessage[];
    settingInfo: InfoSetting;
    listAlert: ListAlert[];
    listAppMenu: ListAppMenu[];
    listMyQr: ListMyQr[];
    listSubscr: ListSubscr[];
    listFriend: FriendList[];
}



export type MainMsgResponse = {
    code: string;
    message: string;
    introImgUrl: string;
    totalNotReadCnt: number;
    totalReadCnt: number;
    listRoomMessage: ListRoomMessage[];
}

export type MainCarMsgResponse = {
    code: string;
    message: string;
    introImgUrl: string;
    totalSize: number;
    listRoomMessage: ListRoomMessage[];
}

export type ListAppMenu = {
    appMenuNo: string;
    appMenuNm: string;
    useYn: string;
    viewNum: string;
    fileUrl: string;
}

//myqr리스트 결과
export type MyQrResponse = {
    code: string;
    message: string;
    listMyQr: ListMyQr[];
}

export type QrJKJRegResponse = {
    code: string;
    message: string;
    addQrInfo: ListMyQr;
}

export type RoomListResponse = {
    code: string;
    message: string;
    listSubscr: ListRoom [] ;
}

export type ListMyQr = {
    qrNo: string;
    nickNm: string;
    carInfo: string;
    makerCar: string;
    subScr: string;
    parkText: string;
    introductionInfo: string;
    serviceTypeCd:string;
    qrFileNo: string;
    qrInfo: string;
}

export type ApiCallHistList = {
    membNo: string;
    callSeq: string;
    nickNm: string;
    qrNo: string;
    callTypeCd: string;
    callTypeNm: string;
    callReqMsg: string;
    callStatCd: string;
    callStatNm: string;
    callStatDt: string;
    newYn: string;
}
export type ApiCallHistInfo = {
    code: string;
    message: string;
    adOutYn: string;
    totalSize: number;
    callHistList: ApiCallHistList[]
}

export type ApiMyQrList = {
    membNo: string;
    qrOwnerCd: string;
    qrOwnerNm: string;
    qrUseCd: string;
    qrUseNm: string;
    carInfo: string;
    qrNo: string;
    nickNm: string;
    makerCar: string;
    filePath: string;
    addDt: string;
    parkText: string;
}


export type NickNmAvailableResponse = {
    code: string;
    message: string;
    availableYn: string;
}

export type CallSeqResponse = {
    code: string;
    message: string;
    callSeq: string;
}


export type ApiMyQrInfo = {
    code: string;
    message: string;
    adOutYn: string;
    giftYn: string;
    giftUrl: string;
    myQrList: ApiMyQrList[];
}

export type ApiSettingInfo = {
    code: string;
    message: string;
    alarmUseYn: string;
    alarmIntervalCd: string;
    alarmIntervalNm: string;
    alarmSoundYn: string;
    alarmSoundNm: string;
    alarmVibYn: string;
    callPhoneYn: string;
    callMsgYn: string;
    allowYn: string;
    alramUrl?: string;
    currentDate?: string;
    langCd?:string;
}

export type ApiFaqList = {
    faqNo: string;
    faqTypeNm: string;
    faqSubject: string;
    faqDesc: string
}
export type ApiFaqInfo = {
    code: string;
    message: string;
    faqInfoList: ApiFaqList[]
}

export type ApiNoticeList = {
    annNo: string;
    annNm: string;
    annDesc: string;
}
export type ApiNoticeInfo = {
    code: string;
    message: string;
    totalSize: 0;
    publicList: ApiNoticeList[]
}

export type ApiCarInfo = {
    qrNo: string;
    nickNm: string;
    makerCar: string;
    carInfo: string;
    langCd: string;
    currentDate: string;
}

export type MessageBoxInfo = {
    msgFriend:string;
    chatSeq:number;
	imageUri:string;
	serviceTypeCd:string;
	roomTypeCd:string;
	roomNo:number;
	roomNm:string;
	msgTypeCd:string;
	msgDesc:string;
	msgReDesc:string;
	writeMembNo:string;
	addDt:string;
	addTime:string;
	notReadYn:string;
	nickNm:string;
	notReadCnt:string;
	intro:string;
	locationCd:string;
}

export type ApiQrImgInfo = {
    qr_no: string;
    qrimageUri: string;
    nickNm: string;
}
export type ApiServiceItemInfo = {
    imageUri: string;    // imageUri는 문자열 타입
    label: string;       // label은 문자열 타입
    serviceTypeCd: string; // 서비스타입 Car Find Protect
}

export type QrDtlFriendListResponse = {
    code: string;
    message: string;
    friendCnt: number;
    msgCnt: number;
    friendList: FriendList[];
}

export type FriendList = {
    membNo: string;
    imgFileUrl: string;
    nickNm: string;
    introductionInfo: string;
    membLocationCd: string;
    friendLocationCd: string;
    roomNo: string;
    membLocationNm: string;
    friendLocationNm: string;
    serviceTypeCd: string;
    friendNo: string;
    membQrNo: string;
    friendQrNo: string;
    friendSubScr: string;
}

export type QrDtlMsgListResponse = {
    code: string;
    message: string;
    friendCnt: number;
    msgCnt: number;
    qrMsgList: ListRoomMessage[];
}

export type QrDtlCarMsgListResponse = {
    code: string;
    message: string;
    lastChatSeq: string;
    qrCarCallList: ListRoomMessage[];
}

export type FileResponse = {
    code: string;
    message: string;
    downUrl: string;
}

export type SearchFriendListResponse = {
    code: string;
    message: string;
    searchCnt:number;
    friendList: SearchFriendList [];
}

export type SearchFriendList = {
    membNo: string;
    imgFileUrl: string;
    nickNm: string;
    introductionInfo: string;
    membLocationCd: string;
    friendLocationCd: string;
    roomNo: string;
    membLocationNm: string;
    friendLocationNm: string;
    serviceTypeCd: string;
    qrNickNm: string;
    friendNo: string;
    membQrNo: string;
    friendQrNo: string;
}

export type FriendProfileInfoResponse = {
    code: string;
    message: string;
    friendNo: string;
    imgFileUrl: string;
    nickNm: string;
    introductionInfo: string;
    callPhoneYn: string;
    roomNo: string;
    friendQrNo: string;
    qrInfo:string;
    addDt:string;
}

export type RoomChatInitResponse = {
    code: string;
    message: string;
    lastChatSeq: string;
    mySubScr: string;
    friendList: ChatFriendInfo[];
    chatMsgList: RoomChatMsgInfo [] ;
}

export type ChatFriendInfo = {
    roomNo: string;
    membNo: string;
    nickNm: string;
    locationCd: string;
    qrNo: string;
    alertYn: string; 
}


export type RoomChatMsgListResponse = {
    code: string;
    message: string;
    lastChatSeq: string;
    chatMsgList: RoomChatMsgInfo [] ;
}

export type ChkRoomInfoResponse = {
    code: string;
    message: string;
    roomNo: string;
    qrNo: string;
    subScr: string;
    roomNm: string;
    serviceTypeCd: string;
}

export type RoomChatMsgInfo = {
    roomNo: string;
    chatSeq: string;
    msgTypeCd: string;
    msgDesc: string;
    profileImgFileUrl: string;
    writeMembNo: string;
    readChatSeq: string;
    myTextYn: string;
    nickNm: string;
    addDt: string;
    addTime: string;
    notReadCnt: number;
    callStatCd: string;
    roomImgUrl: string;
}


export type AddFriendResponse = {
    code: string;
    message: string;
    addFriendInfo: FriendList | null;
}
//====================================================
export type ImgProps = {
    uri:string;
    imageWidth:number;
}

/* 페이지 매개변수 타입정의 */
export type tutorial03_params = {
    casNo:string;
    casDesc:string;
}

export type Serviceinfo = {
    serviceCd: string;
    serviceNm: string;
    useYn: string;
    viewNum: number;
    filePath: string;
} 


//=============================================
/* common types */

export type RectEl = {
    x:number;
    y:number;
    width:number;
    height:number;
    pageX:number;
    pageY:number;
}

export const RemoteImage = ({uri, imageWidth}: ImgProps) => {
    const [desiredHeight, setDesiredHeight] = React.useState(0)
    Image.getSize(uri, (width, height) => {
        setDesiredHeight(imageWidth / width * height)
    })
    //console.log("Remote image => ", uri, imageWidth)
    return (
        <Image
            source={{uri}}
            style={{
                borderWidth: 1,
                width: imageWidth,
                height: desiredHeight
            }}
        />
    )
}

// 네비게이션 
export type RootStackParamList = {
    Splash: undefined;             // Splash 스크린은 매개변수가 없음
    Tutorial: { callChangeStack: (param: string) => void };           // Tutorial 스크린은 매개변수가 없음
    CasDesc: { data: ApiCasFields }; // CasDesc 스크린은 ApiCasFields를 받음
    MainHome: undefined;
    Search: undefined;
    MyProfile: undefined;
    MySetting: undefined;
    Chat: {sendTypeData: SendType};  // relNo, etcInfo  relNo: string, etcInfo: string , roomNm: string
    // 추가 스크린 정의...
};

export type QrPageType = {
    searchChatSeq: string;
    totalSize: number;
    lastChatSeq: string;
    preSearchChatSeq: string;
  }

export type QrClickType = {
    qrNo: string ,
    serviceTypeCd: string,
  }  

  //이미지 파일 업로드시 사용할 타입
export type ImageAsset = {
    uri: string | undefined; // 이미지 URI
    type?: string; // MIME 타입 (선택 사항)
    fileName?: string; // 파일 이름 (선택 사항)
}

// 채팅창이나 통화시 전달하는 구조
export type SendType = {
    msgItem:ListRoomMessage;
    sendMothod: string ; // C  close, B : 통화,  M: 문자
}


export type NetworkType = {
    isConnected: boolean ; // 이미지 URI
    type: string;
}

export type MembLocation = {
    latitude: number ; 
    longitude: number;
}


