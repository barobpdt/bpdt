import { create } from 'zustand';

interface AppsState {
  isLoading: boolean;
  isNetworkConnected: boolean;
  currentScreen: string;
  isModalVisible: boolean;
  modalType: string | null;
}

interface AppsStore extends AppsState {
  setLoading: (isLoading: boolean) => void;
  setNetworkStatus: (isConnected: boolean) => void;
  setCurrentScreen: (screenName: string) => void;
  showModal: (modalType: string) => void;
  hideModal: () => void;
  resetAppState: () => void;
}

const initialState: AppsState = {
  isLoading: false,
  isNetworkConnected: true,
  currentScreen: '',
  isModalVisible: false,
  modalType: null,
};

export const useAppsStore = create<AppsStore>((set) => ({
  ...initialState,

  setLoading: (isLoading) => 
    set(() => ({ isLoading })),

  setNetworkStatus: (isNetworkConnected) => 
    set(() => ({ isNetworkConnected })),

  setCurrentScreen: (currentScreen) => 
    set(() => ({ currentScreen })),

  showModal: (modalType) => 
    set(() => ({ isModalVisible: true, modalType })),

  hideModal: () => 
    set(() => ({ isModalVisible: false, modalType: null })),

  resetAppState: () => 
    set(() => ({ ...initialState })),
}));
