import { create } from 'zustand';
import { ApiError, ApiMainRequest, ApiVersionInfo, FriendList, InfoSetting, ListAdView, ListAlert, ListAppMenu, ListMyQr, ListRoom, ListRoomMessage, ListService, ListSubscr, MainResponse } from '../types/common';
import { useAppsStore } from './apps';


const serverMode : boolean = false // 개발:dev,  운영:server 로 설정

export const GlobalData = {
	changeType: '', // 어떤내용이 변경되었는지 체크
	callUrl:  serverMode ? 'https://call.jikyeojo.com' : 'https://kosk.co.kr',
	infoUrl:  serverMode ? 'https://info.jikyeojo.com' : 'https://info.kosk.co.kr',
	sockUrl:  '/signaling',
	langCd: 'KR',
	token: '',
	storeUrl: '',
	uniqueId: '',
	deviTpCd: '',
	deviOsVer: '',
	appVer: '',
	currentDate: '',
	networkIsConnect: false,
	networkType: '',
	pageInfo: '',
	chatRoomNo: '',  // pageInfo Chat일경우 chatRoomNo 넣어줘야함
	membNo: '',
	introImgUrl: '',
	serviceList: [] as ListService[],
	adViewList: [] as ListAdView[],
	SettingData: {} as InfoSetting,
	appMenuList: [] as ListAppMenu[],
	listRoomInfo: [] as ListRoom [],
	listAlert: [] as ListAlert[],
	messageMap: {},
	gridSize: 30,
	socketConnectYn: 'N',
	myKey: '',
	isPeerConnect: false,  // webRtc 연결여부
	webRtcStatus: '',  // 통화 중인지 여부 판단  Calling, Called 통화 요청을 받을 경우 통화중 메세지 전송 처리함
}

export const MembInfo = {
	nickNm : '',
	introductinInfo: '',
	imgFileUrl: ''
}

export const apiCallGet = (apiurl:string, params = {}, callback = (type:string, obj:object)=>{}) => {
	const queryParameters = new URLSearchParams({...params}) ;
	const url=`${GlobalData.infoUrl}${apiurl}?${queryParameters}`;
	console.log("API GET URL:"+url, params);
	fetch(url, {
		method: 'GET',
		headers: {
			'Authorization': 'Bearer ' + GlobalData.token, // 헤더 설정
			'Content-Type': 'application/json', // 요청의 콘텐츠 타입 설정 (선택 사항)
		},
	}).then(res=> res.json() ).then(json=>callback('ok',json)).catch(err=>callback('error',err))
}; 

export const apiCallPost = (apiurl:string, params = {}, callback = (type:string, obj:object)=>{}) => {
	var callUrl = GlobalData.infoUrl + apiurl ;  	
	fetch(callUrl, {
		method: 'POST',
		headers: {
		'Authorization': 'Bearer ' + GlobalData.token, // 헤더 설정 ==========================versionInfo로 변경할지 아니면 해당 값을 넣을지 판단 필요
		'Content-Type': 'application/json', // 요청의 콘텐츠 타입 설정
	},
	body: JSON.stringify(params),
	}).then(res=> res.json() ).then(json=>callback('ok',json)).catch(err=>callback('error',err))
}

export const apiFileCallPost = (apiurl:string, params:FormData, callback = (type:string, obj:object)=>{}) => {
	var callUrl = GlobalData.infoUrl + apiurl ;  
	
	console.log("trans params : " , params);
	
	fetch(callUrl, {
	method: 'POST',
	headers: {
	'Authorization': 'Bearer ' + GlobalData.token, // 헤더 설정
	'Content-Type': 'multipart/form-data', // 요청의 콘텐츠 타입 설정
	},
	body: params,
	}).then(res=> res.json() ).then(json=>callback('ok',json)).catch(err=>callback('error',err))
}

export const GetDate = (date=new Date): string => {	
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	const seconds = String(date.getSeconds()).padStart(2, '0');
	return `${year}${month}${day}${hours}${minutes}${seconds}`;
}

export const GetDateDay = (date=new Date): string => {	
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	return `${year}.${month}.${day}`;
}

export const GetDateTime = (date=new Date): string => {	
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	const seconds = String(date.getSeconds()).padStart(2, '0');
	return `${hours}:${minutes}:${seconds}`;
}

export type ApiResult = {
	code:string;
	message:string;
	appKey:string;
	status?:number;
	path?:string;
	error?:object;
	isAlert?:string;
	regQr?:string;
	errors?:ApiError[]
}

export const ApiInfo = {
    get_version: '/api/session/getVersion',  // 버전정보 가져오기
    get_tutorial: '/api/session/getTutorial', // 튜토리얼 리스트 가져오기
    menu_menuList: '/api/menu/menuList',  // 메뉴리스트 가져오기 -사용여부 판단 필요
    info_faqList: '/api/info/faqList',  // FAQ가져오기
    get_cas: '/api/session/getCas', //약관정보 가져오기
    create_Sg: '/api/session/createSg',
    mainInfo: '/api/main/mainInfo', // 메인 정보 초기에 가져오기
    serviceInfo: '/api/main/mainMsgInfo', // 서비스 홈 데이타 가져오기
    serviceCarInfo: '/api/main/mainCarMsgInfo', // 서비스 홈 데이타 가져오기
    serviceMyQr: '/api/main/serviceMyQr', // 서비스 마이큐알리스트
    // 삭제 qrMsgInfo: '/api/main/qrMsgInfo' , // qr메세지 출력
    nickNmAvailable: '/api/qrInfo/nickNmAvailable', // 닉네임 중복체크
    regJkjQr: '/api/qrInfo/regJkjQr' , // QR 등록
    qrFriendList: '/api/msg/qrFriendList' , // QR 친구 리스트
    qrMsgList: '/api/msg/qrMsgList' , // QR 메세지 리스트
    qrCarMsgList: '/api/msg/qrCarMsgList' , //'/api/msg/qrCarMsgList' , // QR 차빼줘 메세지   /api/msg/qrCarMsgList
    addFriendQr: '/api/room/save-friend', // 친구추가
    delMessage: '/api/msg/del-message', // 메세지 삭제
    
    fileUpload: '/api/file/uploadFile', // 파일 업로드
    saveNickIntro: '/api/main/saveNickIntro', // 닉네임과 소개글 업데이트
    searchFriend: '/api/room/search-qrFriend', // 친구 검색
    friendProfile: '/api/room/info-profile-friend',
    subscrList: '/api/main/getSubscr', // 구독 리스트 가져오기 결과값 RoomListResponse

    //채팅방 api
    chatMsgList: '/api/msg/chatMsgList',
    chatIntiList:'/api/msg/chatInitList',
    getCallSeq: '/api/session/getCallSeq',

    // qr 스캔 통화 문자 처리
    scanAppChkSend: '/api/msg/scanAppChkSend' ,
    sScribeMsgSend: '/topic/msgSend',
    sScribelinkChk: '/topic/linkChk',
    rtnSubscribeCandidate: '/topic/peer/iceCandidate',
    rtnSubscribeOffer: '/topic/peer/offer',
    rtnSubscribeAnswer: '/topic/peer/answer',
    rtnSubscribeCallKey: '/topic/call/key',
    rtnSubscribeSendKey: '/topic/send/key',
    rtnSubscribeLocInfo:'/topic/locInfo',
    rtnSubscribeReadMsg:'/topic/readMsg',
    //rtnSubscribeDelMsg:'/topic/delMsg',
    

    rtnSendMsgSend: '/app/msgSend',
    rtnSendCandidate: '/app/peer/iceCandidate',
    rtnSendAnswer: '/app/peer/answer',
    rtnSendSendKey: '/app/send/key',
    rtnSendLocInfo:'/app/locInfo',
    rtnSendReadMsg:'/app/readMsg',
    //rtnSendDelMsg:'/app/delMsg',
}

const packageJson = require('../../package.json');

export const selectGrobalData = async() => {
	const systemName = 'Android'
    //DeviceInfo.getSystemName().toString();
	//GlobalData.uniqueId = (await DeviceInfo.getUniqueId());
    //DeviceInfo.getSystemVersion();
	GlobalData.deviOsVer = '12.0.0' 
	GlobalData.appVer = packageJson.version;
	if (systemName == "Android") {
		GlobalData.deviTpCd = "SA";
	} else if (systemName == "iOS") {
		GlobalData.deviTpCd = "SI";
	} else {
		GlobalData.deviTpCd = "";
	}
    GlobalData.uniqueId = '961f93975e7e16f9';	
	console.log('@@ GlobalData >>', GlobalData);
}

interface User {
  id: string;
  name: string;
  email: string;
}

interface GlobalState {
  // State
  user: User | null;
  isDarkMode: boolean;
  isLoading: boolean;
  notifications: string[];
  globalData: typeof GlobalData;
  membInfo: typeof MembInfo;
  listRoomMessage: ListRoomMessage[];
  listFriend: FriendList[];
  listService: ListService[];
  listAdView: ListAdView[];
  listSubscr: ListSubscr[];
  listMyQr: ListMyQr[];
  listMyQrProtect: ListMyQr[];
  listMyQrCar: ListMyQr[];
  versionInfo: ApiVersionInfo | null;
  
  // Actions
  setUser: (user: User | null) => void;
  toggleDarkMode: () => void;
  setLoading: (isLoading: boolean) => void;
  addNotification: (message: string) => void;
  removeNotification: (index: number) => void;
  clearNotifications: () => void;
  updateMembInfo: (info: { nickNm: string; introductinInfo: string; imgFileUrl: string }) => void;
  getVersion: () => Promise<void>;
  getMainData: () => Promise<void>;
}

export const useGlobalStore = create<GlobalState>((set, get) => {
    const setLoading = useAppsStore.getState().setLoading;
    const showModal = useAppsStore.getState().showModal;
    return { 
        // Initial State
        user: null,
        isDarkMode: false,
        isLoading: false,
        notifications: [],
        globalData: GlobalData,
        membInfo: MembInfo,
        listRoomMessage: [],
        listFriend: [],
        listService: [],
        listAdView: [],
        listSubscr: [],
        listMyQr: [],
        listMyQrProtect: [],
        listMyQrCar: [],
        versionInfo: null,

        // Actions
        setUser: (user) => set({ user }),
        toggleDarkMode: () => set((state) => ({ isDarkMode: !state.isDarkMode })),
        setLoading: (isLoading) => set({ isLoading }),
        addNotification: (message) => set((state) => ({ notifications: [...state.notifications, message] })),
        removeNotification: (index) => set((state) => ({
            notifications: state.notifications.filter((_, i) => i !== index)
        })),
        clearNotifications: () => set({ notifications: [] }),
        updateMembInfo: (info) => set((state) => ({
            membInfo: { ...state.membInfo, ...info }
        })),
        // 버전 정보 조회
        getVersion: async () => {
            setLoading(true);
            const params = {
                deviTpCd : GlobalData.deviTpCd,
                deviId : GlobalData.uniqueId,
                deviOsVer : GlobalData.deviOsVer,
                appVer : GlobalData.appVer,
                langCd : GlobalData.langCd,
                currentDate : GetDate()
            }
            return new Promise<void>((resolve, reject) => {
                apiCallPost(ApiInfo.get_version, params, (type, response) => {
                    setLoading(false);
                    if (type === 'ok') {
                        set({ versionInfo: response as ApiVersionInfo });
                        console.log("@@ GetVersion >>", get().versionInfo );
                        GlobalData.token = get().versionInfo?.appKey || '';
                        resolve();
                    } else {
                        showModal('error');
                        reject(response);
                    }
                });
            });
        },
        // 메인 데이터 조회
        getMainData: async () => {
            setLoading(true);
            const mainReqParam : ApiMainRequest = {
                deviTpCd:GlobalData.deviTpCd,
                langCd:GlobalData.langCd
            }
            return new Promise<void>((resolve, reject) => {
                apiCallPost(ApiInfo.mainInfo, mainReqParam, (type:string, obj:object) => {
                    if( type=='ok' ) {
                        const info = obj as MainResponse
                        console.log("@@ MainResponse >>", info);
                        updateMainResponse(info)
                        resolve();
                    } else {
                        showModal('error');
                        reject(obj);
                    }
                })
            })
        }
    }
}); 


export const updateMainResponse = (response: MainResponse) => {
	const { globalData, membInfo } = useGlobalStore.getState();	
	GlobalData.membNo = response.membNo;
	GlobalData.introImgUrl = response.introImgUrl;
	GlobalData.SettingData = response.settingInfo;
	GlobalData.listAlert = response.listAlert;
	GlobalData.appMenuList = response.listAppMenu;
    // 채팅 목록 업데이트 addDt, addTime, callStatCd, chatSeq, msgDesc
	useGlobalStore.setState({ listRoomMessage: response.listRoomMessage });

	// 친구 목록 업데이트 friendLocationCd, friendLocationNm, friendNo, friendNickNm, friendIntroductinInfo, friendImgFileUrl, friendStatusCd, friendStatusNm, friendRegDt, friendUpdDt
	useGlobalStore.setState({ listFriend: response.listFriend });
	
	// 서비스 목록 업데이트 serviceTypeCd, serviceTypeNm, serviceNo, serviceNickNm, serviceIntroductinInfo, serviceImgFileUrl, serviceStatusCd, serviceStatusNm, serviceRegDt, serviceUpdDt
	useGlobalStore.setState({ listService: response.listService });

	// 광고 뷰 목록 업데이트 adViewTypeCd, adViewTypeNm, adViewNo, adViewNickNm, adViewIntroductinInfo, adViewImgFileUrl, adViewStatusCd, adViewStatusNm, adViewRegDt, adViewUpdDt
	useGlobalStore.setState({ listAdView: response.listAdView });

	// 구독 목록 업데이트 subscrTypeCd, subscrTypeNm, subscrNo, subscrNickNm, subscrIntroductinInfo, subscrImgFileUrl, subscrStatusCd, subscrStatusNm, subscrRegDt, subscrUpdDt
	useGlobalStore.setState({ listSubscr: response.listSubscr });

	// 내 QR 목록 업데이트 myQrLocationCd, myQrLocationNm, myQrNo, myQrNickNm, myQrIntroductinInfo, myQrImgFileUrl, myQrStatusCd, myQrStatusNm, myQrRegDt, myQrUpdDt
	useGlobalStore.setState({ listMyQr: response.listMyQr });

	const protectQrList = response.listMyQr.filter(item => item.serviceTypeCd == 'Protect') ;
	const CarQrList = response.listMyQr.filter(item => item.serviceTypeCd == 'Car') ;
	useGlobalStore.setState({ listMyQrProtect: protectQrList });
	useGlobalStore.setState({ listMyQrCar: CarQrList }); 
	useGlobalStore.getState().updateMembInfo({
		nickNm: response.nickNm,
		introductinInfo: response.introductionInfo,
		imgFileUrl: response.imgFileUrl
	});

};
 
