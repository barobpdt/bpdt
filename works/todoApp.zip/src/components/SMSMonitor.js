import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Platform, PermissionsAndroid, TouchableOpacity } from 'react-native';
import { EventEmitter } from 'fbemitter';

class SMSMonitor {
  constructor() {
    this.emitter = new EventEmitter();
    this.isMonitoring = false;
  }

  async requestSMSPermission() {
    if (Platform.OS === 'android') {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.READ_SMS,
          {
            title: "SMS 읽기 권한",
            message: "문자 메시지를 읽기 위해 권한이 필요합니다.",
            buttonNeutral: "나중에",
            buttonNegative: "취소",
            buttonPositive: "확인"
          }
        );
        return granted === PermissionsAndroid.RESULTS.GRANTED;
      } catch (err) {
        console.warn(err);
        return false;
      }
    }
    return false;
  }

  startMonitoring() {
    if (this.isMonitoring) return;
    
    // SMS 수신 이벤트 리스너 등록
    this.smsSubscription = this.emitter.addListener('SMS_RECEIVED', (message) => {
      console.log('SMS received:', message);
      // 여기에 SMS 처리 로직 추가
    });

    this.isMonitoring = true;
  }

  stopMonitoring() {
    if (!this.isMonitoring) return;
    
    if (this.smsSubscription) {
      this.smsSubscription.remove();
    }
    
    this.isMonitoring = false;
  }

  // SMS 이벤트 발생 시키기 (테스트용)
  simulateSMSReceived(message) {
    this.emitter.emit('SMS_RECEIVED', message);
  }
}

export const smsMonitor = new SMSMonitor();

export default function SMSMonitorComponent() {
  const [hasPermission, setHasPermission] = useState(false);
  const [lastMessage, setLastMessage] = useState(null);

  const requestPermission = async () => {
    console.log('@@ requestPermission');
    const permission = await smsMonitor.requestSMSPermission();
    console.log('@@ requestPermission permission', permission);
    setHasPermission(permission);
    
    if (permission) {
      smsMonitor.startMonitoring();
    }
  };

  useEffect(() => {
    // SMS 수신 이벤트 리스너 등록
    const subscription = smsMonitor.emitter.addListener('SMS_RECEIVED', (message) => {
      setLastMessage(message);
    });

    smsMonitor.simulateSMSReceived({
        content: "테스트 메시지입니다.",
        timestamp: new Date().getTime()
    });

    return () => {
      subscription.remove();
      smsMonitor.stopMonitoring();
    };
  }, []);

  if (!hasPermission) {
    return (
      <View style={styles.container}>
        <Text style={styles.text}>SMS 모니터링을 위해 권한이 필요합니다.</Text>
        <TouchableOpacity 
          style={styles.permissionButton}
          onPress={requestPermission}
        >
          <Text style={styles.permissionButtonText}>권한 요청하기</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SMS 모니터링</Text>
      {lastMessage ? (
        <View style={styles.messageContainer}>
          <Text style={styles.messageText}>마지막 수신 메시지:</Text>
          <Text style={styles.messageContent}>{lastMessage.content}</Text>
          <Text style={styles.messageTime}>{new Date(lastMessage.timestamp).toLocaleString()}</Text>
        </View>
      ) : (
        <Text style={styles.text}>수신된 메시지가 없습니다.</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 15,
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    marginVertical: 10,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  text: {
    fontSize: 14,
    color: '#666',
    marginBottom: 10,
  },
  messageContainer: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 8,
    marginTop: 10,
  },
  messageText: {
    fontSize: 14,
    color: '#666',
    marginBottom: 5,
  },
  messageContent: {
    fontSize: 16,
    color: '#333',
    marginBottom: 5,
  },
  messageTime: {
    fontSize: 12,
    color: '#999',
  },
  permissionButton: {
    backgroundColor: '#4A90E2',
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  permissionButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
}); 