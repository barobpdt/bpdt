#ifndef WIDGET_IMPL_H
#define WIDGET_IMPL_H

#endif // WIDGET_IMPL_H
