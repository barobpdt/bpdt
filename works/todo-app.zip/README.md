# Todo 앱

React Native와 Expo를 사용하여 개발된 Todo 관리 애플리케이션입니다.

## 설치 과정

1. **프로젝트 생성**
```bash
# 프로젝트 디렉토리에서
npx create-expo-app@latest todo-app --template blank
```

2. **필요한 패키지 설치**
```bash
cd todo-app
npm install @react-navigation/native @react-navigation/native-stack react-native-screens react-native-safe-area-context react-native-web@0.19.6 react-dom@18.2.0 @expo/webpack-config --legacy-peer-deps
npm install @react-native-async-storage/async-storage --legacy-peer-deps
```

3. **앱 실행**
```bash
# 웹 버전으로 실행
npm start -- --web

# 또는 모바일 버전으로 실행
npm start
```

## 주요 기능

### 1. Todo 항목 관리
- **추가**: 새로운 Todo 항목을 추가할 수 있습니다.
- **삭제**: Todo 항목을 삭제할 수 있습니다 (삭제 전 확인 대화상자 표시).
- **완료/미완료**: Todo 항목을 탭하여 완료/미완료 상태를 토글할 수 있습니다.
- **수정**: Todo 항목의 텍스트, 카테고리, 우선순위를 수정할 수 있습니다.

### 2. 카테고리 기능
- Todo 항목에 카테고리를 지정할 수 있습니다 (전체, 업무, 개인, 쇼핑, 건강).
- 카테고리별로 Todo 항목을 필터링할 수 있습니다.

### 3. 우선순위 기능
- Todo 항목에 우선순위를 지정할 수 있습니다 (높음, 중간, 낮음).
- 우선순위에 따라 색상이 표시됩니다.

### 4. 정렬 기능
- 날짜순, 우선순위순, 알파벳순으로 Todo 항목을 정렬할 수 있습니다.

### 5. 데이터 영속성
- AsyncStorage를 사용하여 Todo 항목을 로컬에 저장합니다.
- 앱을 다시 실행해도 데이터가 유지됩니다.

## 사용 방법

1. **Todo 항목 추가**
   - 입력 필드에 텍스트를 입력하고 "추가" 버튼을 클릭하거나 엔터를 누릅니다.
   - 기본적으로 현재 선택된 카테고리와 우선순위가 적용됩니다.

2. **Todo 항목 완료/미완료**
   - Todo 항목을 탭하면 완료/미완료 상태가 토글됩니다.
   - 완료된 항목은 취소선이 표시되고 색상이 회색으로 변경됩니다.

3. **Todo 항목 수정**
   - Todo 항목 옆의 "수정" 버튼을 클릭하여 수정 모달을 열 수 있습니다.
   - 텍스트, 카테고리, 우선순위를 변경할 수 있습니다.

4. **Todo 항목 삭제**
   - Todo 항목 옆의 "삭제" 버튼을 클릭하면 삭제 확인 대화상자가 표시됩니다.
   - "삭제"를 선택하면 해당 항목이 삭제됩니다.

5. **카테고리 필터링**
   - 상단의 "카테고리" 버튼을 클릭하여 카테고리 선택 모달을 열 수 있습니다.
   - 원하는 카테고리를 선택하면 해당 카테고리의 Todo 항목만 표시됩니다.

6. **정렬**
   - 상단의 "정렬" 버튼을 클릭하여 정렬 옵션 모달을 열 수 있습니다.
   - 원하는 정렬 방식을 선택하면 Todo 항목이 해당 방식으로 정렬됩니다.

## 기술 스택

- React Native
- Expo
- React Navigation
- AsyncStorage

## 요구사항

- Node.js
- npm 또는 yarn
- Expo CLI
- iOS 또는 Android 기기 (모바일 테스트용)
- 또는 웹 브라우저 (웹 테스트용) 


## 빌드방법
# EAS CLI가 최신 버전인지 확인
npm install -g eas-cli

# EAS에 로그인 (아직 로그인하지 않았다면)
eas login

# 기존 EAS 설정 초기화
rm -rf .expo

# 새 프로젝트 초기화
eas init

# 빌드 설정
eas build:configure

eas build -p android --profile preview


eas build -p android --profile preview --non-interactive

