import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, Platform } from 'react-native';
import { Calendar, LocaleConfig } from 'react-native-calendars';

// 한글 설정
LocaleConfig.locales['kr'] = {
  monthNames: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
  monthNamesShort: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
  dayNames: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'],
  dayNamesShort: ['일', '월', '화', '수', '목', '금', '토'],
};

LocaleConfig.defaultLocale = 'kr';

export default function ScheduleScreen() {
  const [selectedDate, setSelectedDate] = useState('');
  const [markedDates, setMarkedDates] = useState({});

  useEffect(() => {
    // 2024년 공휴일 설정
    const holidays = {
      '2024-01-01': { marked: true, dotColor: 'red', text: '신정' },
      '2024-02-09': { marked: true, dotColor: 'red', text: '설날' },
      '2024-02-10': { marked: true, dotColor: 'red', text: '설날' },
      '2024-02-11': { marked: true, dotColor: 'red', text: '설날' },
      '2024-02-12': { marked: true, dotColor: 'red', text: '대체공휴일' },
      '2024-03-01': { marked: true, dotColor: 'red', text: '삼일절' },
      '2024-04-10': { marked: true, dotColor: 'red', text: '21대 총선' },
      '2024-05-05': { marked: true, dotColor: 'red', text: '어린이날' },
      '2024-05-06': { marked: true, dotColor: 'red', text: '대체공휴일' },
      '2024-05-15': { marked: true, dotColor: 'red', text: '부처님오신날' },
      '2024-06-06': { marked: true, dotColor: 'red', text: '현충일' },
      '2024-08-15': { marked: true, dotColor: 'red', text: '광복절' },
      '2024-09-16': { marked: true, dotColor: 'red', text: '추석' },
      '2024-09-17': { marked: true, dotColor: 'red', text: '추석' },
      '2024-09-18': { marked: true, dotColor: 'red', text: '추석' },
      '2024-10-03': { marked: true, dotColor: 'red', text: '개천절' },
      '2024-10-09': { marked: true, dotColor: 'red', text: '한글날' },
      '2024-12-25': { marked: true, dotColor: 'red', text: '크리스마스' },
    };

    setMarkedDates(holidays);
  }, []);

  const onDayPress = (day) => {
    const updatedMarkedDates = {
      ...markedDates,
      [day.dateString]: {
        ...(markedDates[day.dateString] || {}),
        selected: true,
        selectedColor: '#4A90E2',
      }
    };
    setSelectedDate(day.dateString);
    setMarkedDates(updatedMarkedDates);
  };

  return (
    <View style={styles.screenContainer}>
      <View style={styles.headerContainer}>
        <Text style={styles.screenTitle}>일정관리</Text>
      </View>
      
      <Calendar
        onDayPress={onDayPress}
        markedDates={markedDates}
        theme={{
          backgroundColor: '#ffffff',
          calendarBackground: '#ffffff',
          textSectionTitleColor: '#b6c1cd',
          selectedDayBackgroundColor: '#4A90E2',
          selectedDayTextColor: '#ffffff',
          todayTextColor: '#4A90E2',
          dayTextColor: '#2d4150',
          textDisabledColor: '#d9e1e8',
          dotColor: '#4A90E2',
          selectedDotColor: '#ffffff',
          arrowColor: '#4A90E2',
          monthTextColor: '#4A90E2',
          indicatorColor: '#4A90E2',
          textDayFontWeight: '300',
          textMonthFontWeight: 'bold',
          textDayHeaderFontWeight: '300',
          textDayFontSize: 16,
          textMonthFontSize: 16,
          textDayHeaderFontSize: 16,
        }}
        style={styles.calendar}
      />

      <View style={styles.selectedDateContainer}>
        <Text style={styles.selectedDateText}>
          {selectedDate ? `${new Date(selectedDate).toLocaleDateString('ko-KR')} ${markedDates[selectedDate]?.text || ''}` : '날짜를 선택하세요'}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  screenContainer: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerContainer: {
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 50 : 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
  },
  calendar: {
    marginTop: 20,
    borderWidth: 1,
    borderColor: '#eee',
    borderRadius: 12,
    marginHorizontal: 20,
  },
  selectedDateContainer: {
    marginTop: 20,
    padding: 20,
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    marginHorizontal: 20,
  },
  selectedDateText: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
  },
}); 