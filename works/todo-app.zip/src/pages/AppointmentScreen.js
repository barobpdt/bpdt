import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, Alert, Platform, ScrollView, PermissionsAndroid } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import MapView, { PROVIDER_GOOGLE, Marker } from 'react-native-maps';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import SMSMonitorComponent from '../components/SMSMonitor';

export default function AppointmentScreen({ navigation }) {
	const [title, setTitle] = useState('');
	const [date, setDate] = useState(new Date());
	const [showDatePicker, setShowDatePicker] = useState(false);
	const [showTimePicker, setShowTimePicker] = useState(false);
	const [location, setLocation] = useState(null);
	const [selectedLocation, setSelectedLocation] = useState(null);
	const [address, setAddress] = useState('');
	const [errorMsg, setErrorMsg] = useState(null);
	const [region, setRegion] = useState(null);
	const mapRef = useRef(null);

	useEffect(() => {
		(async () => {
			try {
				let { status } = await Location.requestForegroundPermissionsAsync();
				if (status !== 'granted') {
					setErrorMsg('위치 권한이 거부되었습니다.');
					return;
				}

				let currentLocation = await Location.getCurrentPositionAsync({});
				const newLocation = {
					latitude: currentLocation.coords.latitude,
					longitude: currentLocation.coords.longitude,
					latitudeDelta: 0.0922,
					longitudeDelta: 0.0421,
				};
				setLocation(newLocation);
				setSelectedLocation({
					latitude: currentLocation.coords.latitude,
					longitude: currentLocation.coords.longitude,
				});
			} catch (error) {
				console.error('위치 정보를 가져오는데 실패했습니다:', error);
				setErrorMsg('위치 정보를 가져오는데 실패했습니다.');
				// 기본 위치 설정 (서울)
				const defaultLocation = {
					latitude: 37.5665,
					longitude: 126.9780,
					latitudeDelta: 0.0922,
					longitudeDelta: 0.0421,
				};
				setLocation(defaultLocation);
				setSelectedLocation({
					latitude: 37.5665,
					longitude: 126.9780,
				});
			}
		})();
	}, []);

	const onDateChange = (event, selectedDate) => {
		setShowDatePicker(false);
		if (selectedDate) {
			setDate(selectedDate);
		}
	};

	const onTimeChange = (event, selectedTime) => {
		setShowTimePicker(false);
		if (selectedTime) {
			setDate(selectedTime);
		}
	};

	const handleMapPress = (e) => {
		const { coordinate } = e.nativeEvent;
		setSelectedLocation(coordinate);
		updateAddress(coordinate);
	};

	const handleRegionChange = (newRegion) => {
		setRegion(newRegion);
	};

	const handleZoomIn = () => {
		if (!mapRef.current || !region) return;
		
		const newRegion = {
			latitude: region.latitude,
			longitude: region.longitude,
			latitudeDelta: region.latitudeDelta / 2,
			longitudeDelta: region.longitudeDelta / 2,
		};
		mapRef.current.animateToRegion(newRegion, 300);
	};

	const handleZoomOut = () => {
		if (!mapRef.current || !region) return;
		
		const newRegion = {
			latitude: region.latitude,
			longitude: region.longitude,
			latitudeDelta: region.latitudeDelta * 2,
			longitudeDelta: region.longitudeDelta * 2,
		};
		mapRef.current.animateToRegion(newRegion, 300);
	};

	const updateAddress = async (coordinate) => {
		try {
			const [addressResult] = await Location.reverseGeocodeAsync({
				latitude: coordinate.latitude,
				longitude: coordinate.longitude
			});
			
			if (addressResult) {
				const formattedAddress = [
					addressResult.street,
					addressResult.city,
					addressResult.region,
					addressResult.country
				].filter(Boolean).join(' ');
				
				setAddress(formattedAddress);
			}
		} catch (error) {
			console.error('주소 변환 중 오류:', error);
		}
	};

	const goToUserLocation = async () => {
		const { status } = await Location.requestForegroundPermissionsAsync();
		if (status === 'granted') {
			const location = await Location.getCurrentPositionAsync({});
			const newLocation = {
				latitude: location.coords.latitude,
				longitude: location.coords.longitude,
				latitudeDelta: 0.01,
				longitudeDelta: 0.01,
			};
			mapRef.current.animateToRegion(newLocation, 1000);
			setSelectedLocation({
				latitude: location.coords.latitude,
				longitude: location.coords.longitude,
			});
			updateAddress(newLocation);
		}
	};

	const saveAppointment = async () => {
		if (!title.trim()) {
			Alert.alert('오류', '약속 제목을 입력해주세요.');
			return;
		}

		const appointment = {
			id: Date.now().toString(),
			title,
			date: date.toISOString(),
			location: selectedLocation,
			address,
		};

		try {
			const existingAppointments = await AsyncStorage.getItem('appointments');
			const appointments = existingAppointments ? JSON.parse(existingAppointments) : [];
			appointments.push(appointment);
			await AsyncStorage.setItem('appointments', JSON.stringify(appointments));
			Alert.alert('성공', '약속이 저장되었습니다.');
			setTitle('');
			navigation.goBack();
		} catch (error) {
			console.error('약속 저장 중 오류 발생:', error);
			Alert.alert('오류', '약속 저장에 실패했습니다.');
		}
	};

	return (
		<View style={styles.container}>
			<View style={styles.headerContainer}>
				<TouchableOpacity 
					style={styles.backButton}
					onPress={() => navigation.goBack()}
				>
					<Ionicons name="arrow-back" size={24} color="#4A90E2" />
				</TouchableOpacity>
				<Text style={styles.headerTitle}>새로운 약속</Text>
			</View>

			<ScrollView style={styles.contentContainer}>
				<View style={styles.inputSection}>
					<Text style={styles.sectionTitle}>약속 제목</Text>
					<TextInput
						style={styles.input}
						placeholder="약속 제목을 입력하세요"
						value={title}
						onChangeText={setTitle}
						placeholderTextColor="#999"
					/>
				</View>

				<View style={styles.inputSection}>
					<Text style={styles.sectionTitle}>날짜와 시간</Text>
					<View style={styles.datetimeContainer}>
						<TouchableOpacity 
							style={styles.datetimeButton}
							onPress={() => setShowDatePicker(true)}
						>
							<Ionicons name="calendar-outline" size={24} color="#4A90E2" />
							<Text style={styles.datetimeText}>
								{date.toLocaleDateString()}
							</Text>
						</TouchableOpacity>

						<TouchableOpacity 
							style={styles.datetimeButton}
							onPress={() => setShowTimePicker(true)}
						>
							<Ionicons name="time-outline" size={24} color="#4A90E2" />
							<Text style={styles.datetimeText}>
								{date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
							</Text>
						</TouchableOpacity>
					</View>
				</View>

				<View style={styles.inputSection}>
					<Text style={styles.sectionTitle}>약속 장소</Text>
					<View style={styles.mapContainer}>
						{errorMsg ? (
							<Text style={styles.errorText}>{errorMsg}</Text>
						) : location && selectedLocation ? (
							<View style={styles.mapWrapper}>
								<MapView
									ref={mapRef}
									provider={PROVIDER_GOOGLE}
									style={styles.map}
									initialRegion={location}
									onRegionChangeComplete={handleRegionChange}
									showsUserLocation={true}
									showsMyLocationButton={true}
									zoomEnabled={true}
									onPress={handleMapPress}
								>
									<Marker
										coordinate={selectedLocation}
										title="약속 장소"
										description="여기를 탭하여 위치를 변경하세요"
										draggable
										onDragEnd={(e) => {
											const newLocation = e.nativeEvent.coordinate;
											setSelectedLocation(newLocation);
											updateAddress(newLocation);
										}}
									/>
								</MapView>
								<TouchableOpacity 
									style={[styles.button, styles.zoomInButton]} 
									onPress={handleZoomIn}
								>
									<Ionicons name="add" size={24} color="#4A90E2" />
								</TouchableOpacity>
								<TouchableOpacity 
									style={[styles.button, styles.zoomOutButton]} 
									onPress={handleZoomOut}
								>
									<Ionicons name="remove" size={24} color="#4A90E2" />
								</TouchableOpacity>
								<TouchableOpacity 
									style={[styles.button, styles.locationButton]} 
									onPress={goToUserLocation}
								>
									<Ionicons name="locate" size={24} color="#4A90E2" />
								</TouchableOpacity>
							</View>
						) : (
							<Text style={styles.mapPlaceholder}>위치 정보를 불러오는 중...</Text>
						)}
					</View>
					<View style={styles.locationInfoContainer}>
						<View style={styles.locationInfoRow}>
							<View style={styles.locationInfoItem}>
								<Text style={styles.locationInfoLabel}>위도</Text>
								<TextInput
									style={styles.locationInfoInput}
									value={selectedLocation ? selectedLocation.latitude.toFixed(6) : ''}
									editable={false}
								/>
							</View>
							<View style={styles.locationInfoItem}>
								<Text style={styles.locationInfoLabel}>경도</Text>
								<TextInput
									style={styles.locationInfoInput}
									value={selectedLocation ? selectedLocation.longitude.toFixed(6) : ''}
									editable={false}
								/>
							</View>
						</View>
						<View style={styles.addressContainer}>
							<Text style={styles.locationInfoLabel}>주소</Text>
							<TextInput
								style={[styles.locationInfoInput, styles.addressInput]}
								value={address}
								editable={false}
								multiline
							/>
						</View>
					</View>
					<Text style={styles.mapInstruction}>
						지도에서 마커를 드래그하거나 탭하여 약속 장소를 선택하세요
					</Text>
				</View>

				<View style={styles.inputSection}>
					<Text style={styles.sectionTitle}>SMS 알림</Text>
					<SMSMonitorComponent />
				</View>
			</ScrollView>

			<View style={styles.footer}>
				<TouchableOpacity 
					style={[styles.saveButton, !title.trim() && styles.saveButtonDisabled]}
					onPress={saveAppointment}
					disabled={!title.trim()}
				>
					<Text style={styles.saveButtonText}>약속 저장</Text>
				</TouchableOpacity>
			</View>

			{showDatePicker && (
				<DateTimePicker
					value={date}
					mode="date"
					display="default"
					onChange={onDateChange}
				/>
			)}

			{showTimePicker && (
				<DateTimePicker
					value={date}
					mode="time"
					display="default"
					onChange={onTimeChange}
				/>
			)}
		</View>
	);
}

const styles = StyleSheet.create({
	container: {
		flex: 1,
		backgroundColor: '#fff',
	},
	headerContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		paddingHorizontal: 20,
		paddingTop: Platform.OS === 'ios' ? 50 : 20,
		paddingBottom: 20,
		borderBottomWidth: 1,
		borderBottomColor: '#eee',
	},
	backButton: {
		marginRight: 15,
		padding: 5,
	},
	headerTitle: {
		fontSize: 18,
		fontWeight: 'bold',
		color: '#333',
	},
	contentContainer: {
		flex: 1,
		padding: 20,
	},
	inputSection: {
		marginBottom: 30,
	},
	sectionTitle: {
		fontSize: 16,
		fontWeight: '600',
		color: '#333',
		marginBottom: 10,
	},
	input: {
		height: 50,
		borderWidth: 1,
		borderColor: '#ddd',
		borderRadius: 12,
		paddingHorizontal: 15,
		fontSize: 16,
		backgroundColor: '#f9f9f9',
	},
	datetimeContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
	},
	datetimeButton: {
		flex: 1,
		flexDirection: 'row',
		alignItems: 'center',
		backgroundColor: '#f9f9f9',
		padding: 15,
		borderRadius: 12,
		marginHorizontal: 5,
		borderWidth: 1,
		borderColor: '#ddd',
	},
	datetimeText: {
		marginLeft: 10,
		fontSize: 16,
		color: '#333',
	},
	mapContainer: {
		height: 300,
		borderRadius: 12,
		overflow: 'hidden',
		backgroundColor: '#f9f9f9',
		borderWidth: 1,
		borderColor: '#ddd',
	},
	mapWrapper: {
		flex: 1,
		position: 'relative',
	},
	map: {
		...StyleSheet.absoluteFillObject,
	},
	mapPlaceholder: {
		fontSize: 16,
		color: '#666',
		textAlign: 'center',
		marginTop: 10,
	},
	footer: {
		padding: 20,
		borderTopWidth: 1,
		borderTopColor: '#eee',
	},
	saveButton: {
		backgroundColor: '#4A90E2',
		padding: 15,
		borderRadius: 12,
		alignItems: 'center',
	},
	saveButtonDisabled: {
		backgroundColor: '#ccc',
	},
	saveButtonText: {
		color: '#fff',
		fontSize: 16,
		fontWeight: 'bold',
	},
	errorText: {
		color: 'red',
		textAlign: 'center',
		marginTop: 10,
	},
	button: {
		position: 'absolute',
		backgroundColor: 'white',
		padding: 10,
		borderRadius: 30,
		shadowColor: '#000',
		shadowOffset: {
			width: 0,
			height: 2,
		},
		shadowOpacity: 0.25,
		shadowRadius: 3.84,
		elevation: 5,
	},
	locationButton: {
		bottom: 20,
		right: 20,
	},
	zoomInButton: {
		top: 20,
		right: 20,
	},
	zoomOutButton: {
		top: 80,
		right: 20,
	},
	mapInstruction: {
		fontSize: 14,
		color: '#666',
		marginTop: 5,
		textAlign: 'center',
	},
}); 