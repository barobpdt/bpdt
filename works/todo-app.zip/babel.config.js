module.exports = function(api) {
  api.cache(true);
  return {
    presets: [
      'babel-preset-expo',
      '@babel/preset-typescript'
    ],
    plugins: [
      'react-native-reanimated/plugin',
      '@babel/plugin-transform-template-literals',
      '@babel/plugin-transform-arrow-functions',
      '@babel/plugin-transform-block-scoping',
      '@babel/plugin-transform-classes',
      '@babel/plugin-transform-destructuring',
      '@babel/plugin-transform-parameters',
      '@babel/plugin-transform-spread',
      '@babel/plugin-transform-typescript'
    ],
  };
}; 