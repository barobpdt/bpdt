const colors = {
  PRIM_BG: '#1f1f1f',
  PRIM_ACCENT: '#FFEB3B',
  WHITE: '#FFFFFF',
  PRIM_FRONT: '#2196F3',
  RED: '#F44336',
  TOUCHPAD: '#272829',
  CLICK_BTN: 'rgba(0,0,0,0.2)',
};
export default colors;
