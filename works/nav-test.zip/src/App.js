import React, {Button} from 'react'
import logo from './logo.svg';
import './App.css';
import styled from 'styled-components';

import { render } from "react-dom";
import AceEditor from "react-ace-builds";
import "react-ace-builds/webpack-resolver-min";
import 'ace-builds/src-noconflict/ext-language_tools';
import { BrowserRouter, Routes, Route, Outlet, Link, NavLink } from 'react-router-dom';
import { useNavigate } from "react-router-dom";

const Content = styled.div`
	width:100%;
	height:100vh;
	display:flex;
	background:#f00;
`

const languages = [
  "javascript",
  "java",
  "python",
  "xml",
  "ruby",
  "sass",
  "markdown",
  "mysql",
  "json",
  "html",
  "handlebars",
  "golang",
  "csharp",
  "elixir",
  "typescript",
  "css"
];

const themes = [
  "monokai",
  "github",
  "tomorrow",
  "kuroir",
  "twilight",
  "xcode",
  "textmate",
  "solarized_dark",
  "solarized_light",
  "terminal"
];

languages.forEach(lang => {
  require(`ace-builds/src-noconflict/mode-${lang}`);
  require(`ace-builds/src-noconflict/snippets/${lang}`);
});

themes.forEach(theme => require(`ace-builds/src-noconflict/theme-${theme}`));
/*eslint-disable no-alert, no-console */

const PageRouter = () => (
	<BrowserRouter>
	<Routes>
		<Route path="/" element={<div>기본 경로</div>}/>
		<Route path="/index" caseSensitive element={<div>인덱스 경로</div>}/>
		<Route path="/two/test?" 
			element={<div></div>}
			errorElement={<div>에러</div>}
		/>
		<Route path="/board" element={
			<>
				<header>헤더</header>
				<Outlet/>
				<Link to="write" relative='route' preventScrollReset>작성</Link>
				<NavLink to="read" style={({isActive, isPending, isTransitioning})=>{
					return {};
				}}>읽기</NavLink>
				<footer>푸터</footer>
			</>
		}>
			<Route path="write" element={<div>Write</div>}/>
			<Route path="read" element={<div>Read</div>}/>
		</Route>
		
	</Routes> 
	</BrowserRouter>
);

function App() {
	const [editor, setEditor] = React.useState(null)
	React.useEffect(()=>{
		console.log('@@ page start')
	},[])
	const onChange = (a) => {
		console.log('ace onchange ->',a)
	}
	const onLoad = () => {
		console.log('@@ ace editor load', editor)
	}

	return  (
		<div className="App"> 
			<Content> 
				<div style={{width:200, height:'100%', backgroundColor:'#fff'}}>
					<PageRouter/>
				</div>
				<AceEditor
					ref={el=>setEditor(el?el.editor:null)}
					mode="java"
					theme="github"
					onLoad={onLoad}
					onChange={onChange}
					name="UNIQUE_ID_OF_DIV"
					style={{width:'100%', height:'100%'}}
				/>
			</Content>
		</div>
	);
}

export default App;
