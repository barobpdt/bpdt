from flask import Flask, request, jsonify
import json
import random
from datetime import datetime
import threading
import time
import os
from dotenv import load_dotenv
from langchain.chat_models import ChatOpenAI
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationChain
from langchain.prompts import PromptTemplate
from news_collector import NewsCollector
from youtube_searcher import YouTubeSearcher
import requests

# 환경 변수 로드
load_dotenv()

app = Flask(__name__)

# 대화 컨텍스트 저장소
conversations = {}

# 뉴스 수집기 초기화
news_collector = NewsCollector()

# YouTube 검색기 초기화
youtube_searcher = YouTubeSearcher()

# API 서버 URL들
API_SERVERS = {
    "weather": "http://localhost:5003",
    "stock": "http://localhost:5002",
    "news": "http://localhost:5001"
}

# LangChain 설정
template = """당신은 친절하고 도움이 되는 AI 어시스턴트입니다. 
이전 대화를 고려하여 자연스럽게 대화를 이어가세요.
뉴스 정보, YouTube 동영상 정보, 날씨 정보, 주식 정보를 활용하여 사용자의 질문에 답변하세요.

사용 가능한 API 기능들:
1. 날씨 정보: 현재 날씨, 1주일 예보
2. 주식 정보: 거래량, 거래대금, 주가 정보
3. 뉴스 정보: 최신 뉴스 검색
4. YouTube 동영상: 관련 동영상 검색

API 호출 예시:
- 날씨: "서울 날씨 알려줘", "부산 1주일 예보"
- 주식: "애플 주식 정보", "테슬라 거래량"
- 뉴스: "AI 관련 뉴스", "최신 기술 뉴스"
- 동영상: "파이썬 강좌", "AI 관련 동영상"

이전 대화:
{history}

현재 대화:
Human: {input}

AI:"""

prompt = PromptTemplate(
    input_variables=["history", "input"],
    template=template
)

def get_conversation_chain(conversation_id):
    if conversation_id not in conversations:
        # 새로운 대화 체인 생성
        llm = ChatOpenAI(temperature=0.7)
        memory = ConversationBufferMemory(return_messages=True)
        conversation = ConversationChain(
            llm=llm,
            memory=memory,
            prompt=prompt,
            verbose=True
        )
        conversations[conversation_id] = {
            "chain": conversation,
            "last_active": datetime.now(),
            "messages": []
        }
    return conversations[conversation_id]

def clean_old_conversations():
    while True:
        current_time = datetime.now()
        to_delete = []
        for conv_id, conv in conversations.items():
            if (current_time - conv["last_active"]).total_seconds() > 3600:  # 1시간
                to_delete.append(conv_id)
        
        for conv_id in to_delete:
            del conversations[conv_id]
        
        time.sleep(300)  # 5분마다 실행

def update_news_periodically():
    while True:
        news_collector.update_news()
        time.sleep(3600)  # 1시간마다 업데이트

def get_news_context(message: str) -> str:
    """메시지와 관련된 뉴스 정보를 검색하고 컨텍스트로 반환"""
    try:
        articles = news_collector.search_articles(message, n_results=3)
        if not articles:
            return ""
        
        context = "관련 뉴스 정보:\n"
        for article in articles:
            context += f"- {article['title']}\n"
            context += f"  요약: {article['content'][:200]}...\n"
            context += f"  출처: {article['url']}\n\n"
        
        return context
    except Exception as e:
        print(f"Error getting news context: {str(e)}")
        return ""

def get_youtube_context(message: str) -> str:
    """메시지와 관련된 YouTube 동영상 정보를 검색하고 컨텍스트로 반환"""
    try:
        # 일반 검색
        videos = youtube_searcher.search_videos(message, n_results=3)
        
        # 인기 동영상 검색 (관련성이 높을 경우)
        trending_videos = youtube_searcher.get_trending_videos(n_results=3)
        
        context = "관련 YouTube 동영상 정보:\n"
        
        if videos:
            context += "\n검색 결과:\n"
            for video in videos:
                context += f"- {video['title']}\n"
                context += f"  채널: {video['channel_title']}\n"
                context += f"  조회수: {video['view_count']}\n"
                context += f"  URL: {video['url']}\n\n"
        
        if trending_videos:
            context += "\n인기 동영상:\n"
            for video in trending_videos:
                context += f"- {video['title']}\n"
                context += f"  채널: {video['channel_title']}\n"
                context += f"  조회수: {video['view_count']}\n"
                context += f"  URL: {video['url']}\n\n"
        
        return context
    except Exception as e:
        print(f"Error getting YouTube context: {str(e)}")
        return ""

def get_weather_context(message: str) -> str:
    """메시지와 관련된 날씨 정보를 가져옵니다."""
    try:
        # 날씨 관련 키워드 확인
        weather_keywords = ["날씨", "온도", "예보", "기온", "비", "맑음", "흐림", "서울", "부산", "대구", "인천", "광주", "대전", "울산"]
        
        if not any(keyword in message for keyword in weather_keywords):
            return ""
        
        # 위치 추출 (간단한 방식)
        locations = ["서울", "부산", "대구", "인천", "광주", "대전", "울산", "제주"]
        found_location = None
        
        for location in locations:
            if location in message:
                found_location = location
                break
        
        if not found_location:
            found_location = "Seoul, Korea"  # 기본값
        
        # 날씨 API 호출
        weather_url = f"{API_SERVERS['weather']}/weather/{found_location}"
        response = requests.get(weather_url, timeout=5)
        
        if response.status_code == 200:
            weather_data = response.json()
            
            if "error" not in weather_data:
                current = weather_data.get("current_weather", {})
                forecast = weather_data.get("weekly_forecast", {}).get("forecast", [])
                
                context = f"🌤️ {found_location} 날씨 정보:\n"
                if current:
                    context += f"현재: {current.get('temperature', 'N/A')}°C, {current.get('description', 'N/A')}\n"
                    context += f"습도: {current.get('humidity', 'N/A')}%, 풍속: {current.get('wind_speed', 'N/A')} m/s\n"
                
                if forecast:
                    context += "1주일 예보:\n"
                    for day in forecast[:3]:  # 처음 3일만
                        context += f"- {day['date']}: {day['temp_min']:.1f}°C ~ {day['temp_max']:.1f}°C, {day['description']}\n"
                
                return context
        
        return ""
    except Exception as e:
        print(f"Error getting weather context: {str(e)}")
        return ""

def get_stock_context(message: str) -> str:
    """메시지와 관련된 주식 정보를 가져옵니다."""
    try:
        # 주식 관련 키워드 확인
        stock_keywords = ["주식", "주가", "거래량", "거래대금", "애플", "테슬라", "구글", "마이크로소프트", "삼성", "현대"]
        
        if not any(keyword in message for keyword in stock_keywords):
            return ""
        
        # 주식 심볼 매핑
        stock_symbols = {
            "애플": "AAPL",
            "테슬라": "TSLA", 
            "구글": "GOOGL",
            "마이크로소프트": "MSFT",
            "삼성": "005930.KS",
            "현대": "005380.KS"
        }
        
        found_symbol = None
        for keyword, symbol in stock_symbols.items():
            if keyword in message:
                found_symbol = symbol
                break
        
        if not found_symbol:
            found_symbol = "AAPL"  # 기본값
        
        # 어제 날짜
        from datetime import timedelta
        yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
        
        # 주식 API 호출
        stock_url = f"{API_SERVERS['stock']}/stock/{found_symbol}/{yesterday}"
        response = requests.get(stock_url, timeout=5)
        
        if response.status_code == 200:
            stock_data = response.json()
            
            if "error" not in stock_data:
                context = f"📈 {found_symbol} 주식 정보 ({yesterday}):\n"
                context += f"종가: ${stock_data.get('close', 'N/A'):.2f}\n"
                context += f"거래량: {stock_data.get('volume', 'N/A'):,}\n"
                context += f"거래대금: ${stock_data.get('trading_amount', 'N/A'):,.0f}\n"
                
                return context
        
        return ""
    except Exception as e:
        print(f"Error getting stock context: {str(e)}")
        return ""

def generate_response(message, context):
    """API 컨텍스트를 포함하여 응답을 생성합니다."""
    # 각 API에서 컨텍스트 가져오기
    news_context = get_news_context(message)
    youtube_context = get_youtube_context(message)
    weather_context = get_weather_context(message)
    stock_context = get_stock_context(message)
    
    # 모든 컨텍스트 결합
    all_context = ""
    if news_context:
        all_context += f"{news_context}\n"
    if youtube_context:
        all_context += f"{youtube_context}\n"
    if weather_context:
        all_context += f"{weather_context}\n"
    if stock_context:
        all_context += f"{stock_context}\n"
    
    # LangChain을 사용하여 응답 생성
    if all_context:
        return f"{all_context}\n{message}"
    else:
        return message

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    conversation_id = data.get('conversation_id', 'default')
    message = data.get('message', '')
    
    conversation = get_conversation_chain(conversation_id)
    conversation["last_active"] = datetime.now()
    
    try:
        # API 컨텍스트를 포함한 응답 생성
        enhanced_message = generate_response(message, conversation)
        
        # LangChain을 사용하여 응답 생성
        response = conversation["chain"].predict(input=enhanced_message)
        
        # 대화 기록 저장
        conversation["messages"].append({
            "user": message,
            "bot": response,
            "timestamp": datetime.now().isoformat()
        })
        
        return jsonify({
            "response": response,
            "conversation_id": conversation_id
        })
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({
            "response": "죄송합니다. 응답을 생성하는 중에 오류가 발생했습니다.",
            "conversation_id": conversation_id
        }), 500

@app.route('/history/<conversation_id>', methods=['GET'])
def get_history(conversation_id):
    if conversation_id in conversations:
        return jsonify(conversations[conversation_id]["messages"])
    return jsonify([])

@app.route('/api/weather/<location>', methods=['GET'])
def api_weather(location):
    """날씨 API 프록시"""
    try:
        response = requests.get(f"{API_SERVERS['weather']}/weather/{location}")
        return jsonify(response.json()), response.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/stock/<symbol>/<date>', methods=['GET'])
def api_stock(symbol, date):
    """주식 API 프록시"""
    try:
        response = requests.get(f"{API_SERVERS['stock']}/stock/{symbol}/{date}")
        return jsonify(response.json()), response.status_code
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # OpenAI API 키 확인
    if not os.getenv("OPENAI_API_KEY"):
        print("Error: OPENAI_API_KEY environment variable is not set")
        exit(1)
    
    # YouTube API 키 확인
    if not os.getenv("YOUTUBE_API_KEY"):
        print("Error: YOUTUBE_API_KEY environment variable is not set")
        exit(1)
    
    # 오래된 대화 정리 스레드 시작
    cleaner_thread = threading.Thread(target=clean_old_conversations, daemon=True)
    cleaner_thread.start()
    
    # 뉴스 업데이트 스레드 시작
    news_update_thread = threading.Thread(target=update_news_periodically, daemon=True)
    news_update_thread.start()
    
    app.run(debug=True, port=5001) 