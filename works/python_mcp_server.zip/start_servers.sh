#!/bin/bash

echo "Starting MCP Servers..."

echo "Starting Chatbot Server..."
python mcp_server.py &
CHATBOT_PID=$!

echo "Starting Stock Server..."
python stock_server.py &
STOCK_PID=$!

echo "Starting News Collector..."
python news_collector.py &
NEWS_PID=$!

echo "All servers started!"
echo "Chatbot Server PID: $CHATBOT_PID"
echo "Stock Server PID: $STOCK_PID"
echo "News Collector PID: $NEWS_PID"

echo "Press Ctrl+C to stop all servers"
trap "kill $CHATBOT_PID $STOCK_PID $NEWS_PID; exit" INT

wait 