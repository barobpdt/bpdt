@echo off
echo Starting MCP Servers...

echo Starting Chatbot Server...
start "Chatbot Server" python mcp_server.py

echo Starting Stock Server...
start "Stock Server" python stock_server.py

echo Starting News Collector...
start "News Collector" python news_collector.py

echo All servers started!
pause 