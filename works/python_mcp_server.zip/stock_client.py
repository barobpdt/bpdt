import requests
import json
from datetime import datetime, timedelta

class StockClient:
    def __init__(self, base_url="http://localhost:5002"):
        self.base_url = base_url
    
    def get_stock_data(self, symbol: str, date: str):
        """특정 주식의 데이터를 가져옵니다."""
        url = f"{self.base_url}/stock/{symbol}/{date}"
        response = requests.get(url)
        return response.json()
    
    def get_multiple_stocks(self, symbols: list, date: str):
        """여러 주식의 데이터를 한번에 가져옵니다."""
        url = f"{self.base_url}/stocks"
        data = {
            "symbols": symbols,
            "date": date
        }
        response = requests.post(url, json=data)
        return response.json()
    
    def get_market_summary(self, date: str):
        """주요 지수들의 요약 정보를 가져옵니다."""
        url = f"{self.base_url}/market-summary/{date}"
        response = requests.get(url)
        return response.json()
    
    def health_check(self):
        """서버 상태를 확인합니다."""
        url = f"{self.base_url}/health"
        response = requests.get(url)
        return response.json()

def format_number(num):
    """숫자를 보기 좋게 포맷팅합니다."""
    if num >= 1e9:
        return f"{num/1e9:.2f}B"
    elif num >= 1e6:
        return f"{num/1e6:.2f}M"
    elif num >= 1e3:
        return f"{num/1e3:.2f}K"
    else:
        return f"{num:,.0f}"

def main():
    client = StockClient()
    
    # 서버 상태 확인
    print("=== 서버 상태 확인 ===")
    health = client.health_check()
    print(json.dumps(health, indent=2, ensure_ascii=False))
    print()
    
    # 오늘 날짜
    today = datetime.now().strftime('%Y-%m-%d')
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    # 개별 주식 데이터 조회
    print("=== 개별 주식 데이터 ===")
    symbols = ['AAPL', 'MSFT', 'GOOGL', 'TSLA']
    
    for symbol in symbols:
        print(f"\n{symbol} ({yesterday}):")
        data = client.get_stock_data(symbol, yesterday)
        
        if 'error' not in data:
            print(f"  시가: ${data['open']:.2f}")
            print(f"  고가: ${data['high']:.2f}")
            print(f"  저가: ${data['low']:.2f}")
            print(f"  종가: ${data['close']:.2f}")
            print(f"  거래량: {format_number(data['volume'])}")
            print(f"  거래대금: ${format_number(data['trading_amount'])}")
        else:
            print(f"  오류: {data['error']}")
    
    # 여러 주식 한번에 조회
    print(f"\n=== 여러 주식 데이터 ({yesterday}) ===")
    multiple_data = client.get_multiple_stocks(symbols, yesterday)
    
    for symbol, data in multiple_data.items():
        if 'error' not in data:
            print(f"{symbol}: 거래량 {format_number(data['volume'])}, 거래대금 ${format_number(data['trading_amount'])}")
        else:
            print(f"{symbol}: 오류 - {data['error']}")
    
    # 시장 요약 정보
    print(f"\n=== 시장 요약 정보 ({yesterday}) ===")
    market_summary = client.get_market_summary(yesterday)
    
    for index, data in market_summary.items():
        if 'error' not in data:
            index_names = {
                '^GSPC': 'S&P 500',
                '^DJI': '다우존스',
                '^IXIC': '나스닥',
                '^KS11': 'KOSPI'
            }
            name = index_names.get(index, index)
            print(f"{name}: 거래량 {format_number(data['volume'])}, 거래대금 ${format_number(data['trading_amount'])}")
        else:
            print(f"{index}: 오류 - {data['error']}")

if __name__ == "__main__":
    main() 