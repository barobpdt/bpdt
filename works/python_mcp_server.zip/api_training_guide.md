# 챗봇 API 호출 학습 가이드

이 가이드는 챗봇이 다양한 API를 자동으로 호출하고 활용하도록 학습시키는 방법을 설명합니다.

## 🎯 학습 목표

챗봇이 사용자의 질문을 분석하여 적절한 API를 자동으로 호출하고, 그 결과를 자연스럽게 대화에 통합하도록 학습시킵니다.

## 📋 학습 방법

### 1. 키워드 기반 API 호출 학습

#### 날씨 API 학습
```python
# 날씨 관련 키워드 인식
weather_keywords = ["날씨", "온도", "예보", "기온", "비", "맑음", "흐림"]

# 위치 인식
locations = ["서울", "부산", "대구", "인천", "광주", "대전", "울산", "제주"]

# 학습 예시
training_examples = [
    "서울 날씨 알려줘",
    "부산 1주일 예보",
    "오늘 기온은 어때?",
    "내일 비 올까?"
]
```

#### 주식 API 학습
```python
# 주식 관련 키워드 인식
stock_keywords = ["주식", "주가", "거래량", "거래대금"]

# 회사명 매핑
stock_symbols = {
    "애플": "AAPL",
    "테슬라": "TSLA", 
    "구글": "GOOGL",
    "마이크로소프트": "MSFT"
}

# 학습 예시
training_examples = [
    "애플 주식 정보",
    "테슬라 거래량",
    "구글 주가 어때?",
    "마이크로소프트 거래대금"
]
```

### 2. 컨텍스트 기반 응답 생성

```python
def generate_response(message, context):
    """API 컨텍스트를 포함하여 응답을 생성합니다."""
    # 각 API에서 컨텍스트 가져오기
    news_context = get_news_context(message)
    youtube_context = get_youtube_context(message)
    weather_context = get_weather_context(message)
    stock_context = get_stock_context(message)
    
    # 모든 컨텍스트 결합
    all_context = ""
    if news_context:
        all_context += f"{news_context}\n"
    if youtube_context:
        all_context += f"{youtube_context}\n"
    if weather_context:
        all_context += f"{weather_context}\n"
    if stock_context:
        all_context += f"{stock_context}\n"
    
    # LangChain을 사용하여 응답 생성
    if all_context:
        return f"{all_context}\n{message}"
    else:
        return message
```

## 🧪 학습 테스트

### 1. 날씨 API 테스트
```bash
# 챗봇과 대화
사용자: "서울 날씨 알려줘"
챗봇: "🌤️ 서울 날씨 정보:
현재: 15.2°C, 맑음
습도: 65%, 풍속: 2.1 m/s

1주일 예보:
- 2024-01-15: 8.5°C ~ 18.2°C, 맑음
- 2024-01-16: 10.2°C ~ 20.1°C, 흐림
- 2024-01-17: 12.5°C ~ 22.3°C, 맑음

현재 서울은 맑고 쾌적한 날씨입니다. 일주일간 대체로 맑은 날씨가 이어질 예정이네요!"
```

### 2. 주식 API 테스트
```bash
사용자: "애플 주식 정보"
챗봇: "📈 AAPL 주식 정보 (2024-01-14):
종가: $185.30
거래량: 45,678,900
거래대금: $8,510,000,000

애플 주식은 어제 185.30달러에 마감했으며, 약 4,567만 주가 거래되어 총 85억 달러의 거래대금을 기록했습니다. 상당히 활발한 거래가 있었네요!"
```

### 3. 뉴스 API 테스트
```bash
사용자: "AI 관련 뉴스 알려줘"
챗봇: "관련 뉴스 정보:
- [뉴스 제목 1]
  요약: AI 기술 발전에 관한 최신 소식...
  출처: [뉴스 URL]

- [뉴스 제목 2]
  요약: 머신러닝 분야의 새로운 연구 결과...
  출처: [뉴스 URL]

최근 AI 분야에서 흥미로운 발전들이 많이 있었네요. 특히 [뉴스 내용 요약]..."
```

## 🔧 고급 학습 기법

### 1. 의도 분류 (Intent Classification)
```python
def classify_intent(message):
    """사용자 메시지의 의도를 분류합니다."""
    intents = {
        "weather": ["날씨", "온도", "예보", "기온"],
        "stock": ["주식", "주가", "거래량", "거래대금"],
        "news": ["뉴스", "소식", "최신", "정보"],
        "youtube": ["동영상", "영상", "강좌", "튜토리얼"]
    }
    
    for intent, keywords in intents.items():
        if any(keyword in message for keyword in keywords):
            return intent
    
    return "general"
```

### 2. 엔티티 추출 (Entity Extraction)
```python
def extract_entities(message):
    """메시지에서 중요한 정보를 추출합니다."""
    entities = {
        "location": None,
        "company": None,
        "date": None,
        "topic": None
    }
    
    # 위치 추출
    locations = ["서울", "부산", "대구", "인천", "광주", "대전", "울산", "제주"]
    for location in locations:
        if location in message:
            entities["location"] = location
            break
    
    # 회사명 추출
    companies = ["애플", "테슬라", "구글", "마이크로소프트", "삼성", "현대"]
    for company in companies:
        if company in message:
            entities["company"] = company
            break
    
    return entities
```

### 3. 대화 컨텍스트 관리
```python
def manage_conversation_context(conversation_id, message, response):
    """대화 컨텍스트를 관리합니다."""
    if conversation_id not in conversations:
        conversations[conversation_id] = {
            "context": {},
            "last_intent": None,
            "entities": {}
        }
    
    # 이전 컨텍스트 활용
    context = conversations[conversation_id]["context"]
    last_intent = conversations[conversation_id]["last_intent"]
    
    # 컨텍스트 업데이트
    current_intent = classify_intent(message)
    current_entities = extract_entities(message)
    
    # 연속된 질문 처리
    if last_intent == "weather" and "거기" in message:
        # 이전에 언급된 위치의 날씨 정보 제공
        location = context.get("last_location", "Seoul, Korea")
        return get_weather_info(location)
```

## 📊 학습 성과 측정

### 1. 정확도 측정
```python
def measure_accuracy(test_cases):
    """API 호출 정확도를 측정합니다."""
    correct = 0
    total = len(test_cases)
    
    for test_case in test_cases:
        user_input = test_case["input"]
        expected_api = test_case["expected_api"]
        
        actual_api = classify_intent(user_input)
        if actual_api == expected_api:
            correct += 1
    
    return correct / total
```

### 2. 응답 품질 평가
```python
def evaluate_response_quality(response):
    """응답 품질을 평가합니다."""
    quality_score = 0
    
    # API 정보 포함 여부
    if "🌤️" in response or "📈" in response:
        quality_score += 1
    
    # 자연스러운 대화
    if "네요" in response or "입니다" in response:
        quality_score += 1
    
    # 추가 정보 제공
    if len(response) > 100:
        quality_score += 1
    
    return quality_score / 3
```

## 🚀 실전 적용

### 1. 서버 실행
```bash
# 모든 서버 실행
python mcp_server.py      # 포트 5001
python stock_server.py    # 포트 5002  
python weather_server.py  # 포트 5003
```

### 2. 테스트 대화
```bash
# 웹 인터페이스 접속
http://localhost:5000

# 테스트 대화 예시
사용자: "안녕하세요"
챗봇: "안녕하세요! 무엇을 도와드릴까요?"

사용자: "서울 날씨 어때?"
챗봇: [날씨 API 호출 후 자연스러운 응답]

사용자: "애플 주식은?"
챗봇: [주식 API 호출 후 자연스러운 응답]

사용자: "AI 관련 뉴스 있어?"
챗봇: [뉴스 API 호출 후 자연스러운 응답]
```

## ⚠️ 주의사항

1. **API 키 관리**: 환경 변수에 안전하게 저장
2. **에러 처리**: API 호출 실패 시 적절한 대응
3. **속도 최적화**: 캐싱을 통한 응답 속도 개선
4. **사용량 제한**: API 호출 횟수 모니터링

## 🔄 지속적 개선

1. **사용자 피드백 수집**: 응답 품질 개선
2. **새로운 API 추가**: 기능 확장
3. **성능 모니터링**: 응답 시간 최적화
4. **정확도 향상**: 더 정확한 의도 분류

이제 챗봇이 다양한 API를 자동으로 호출하고 자연스럽게 대화에 통합할 수 있습니다! 🎉 