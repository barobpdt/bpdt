import requests
import json
from datetime import datetime

class WeatherClient:
    def __init__(self, base_url="http://localhost:5003"):
        self.base_url = base_url
    
    def get_weather(self, location: str):
        """특정 위치의 전체 날씨 정보를 가져옵니다."""
        url = f"{self.base_url}/weather/{location}"
        response = requests.get(url)
        return response.json()
    
    def get_current_weather(self, location: str):
        """현재 날씨만 가져옵니다."""
        url = f"{self.base_url}/weather/current/{location}"
        response = requests.get(url)
        return response.json()
    
    def get_forecast(self, location: str):
        """1주일 예보만 가져옵니다."""
        url = f"{self.base_url}/weather/forecast/{location}"
        response = requests.get(url)
        return response.json()
    
    def get_weather_by_coordinates(self, lat: float, lon: float):
        """좌표로 날씨 정보를 가져옵니다."""
        url = f"{self.base_url}/weather/coordinates"
        data = {
            "latitude": lat,
            "longitude": lon
        }
        response = requests.post(url, json=data)
        return response.json()
    
    def health_check(self):
        """서버 상태를 확인합니다."""
        url = f"{self.base_url}/weather/health"
        response = requests.get(url)
        return response.json()

def format_weather_data(weather_data):
    """날씨 데이터를 보기 좋게 포맷팅합니다."""
    if "error" in weather_data:
        return f"오류: {weather_data['error']}"
    
    result = []
    
    # 위치 정보
    if "location" in weather_data:
        location = weather_data["location"]
        result.append(f"📍 위치: {location['name']}")
        result.append(f"   주소: {location['address']}")
        result.append(f"   좌표: {location['coordinates']['latitude']:.4f}, {location['coordinates']['longitude']:.4f}")
        result.append("")
    
    # 현재 날씨
    if "current_weather" in weather_data:
        current = weather_data["current_weather"]
        if "error" not in current:
            result.append("🌤️ 현재 날씨:")
            result.append(f"   온도: {current['temperature']:.1f}°C")
            result.append(f"   체감온도: {current['feels_like']:.1f}°C")
            result.append(f"   날씨: {current['description']}")
            result.append(f"   습도: {current['humidity']}%")
            result.append(f"   풍속: {current['wind_speed']} m/s")
            result.append(f"   일출: {current['sunrise']}")
            result.append(f"   일몰: {current['sunset']}")
            result.append("")
    
    # 1주일 예보
    if "weekly_forecast" in weather_data:
        forecast = weather_data["weekly_forecast"]
        if "error" not in forecast and "forecast" in forecast:
            result.append("📅 1주일 날씨 예보:")
            for day in forecast["forecast"]:
                day_names = {
                    "Monday": "월요일",
                    "Tuesday": "화요일", 
                    "Wednesday": "수요일",
                    "Thursday": "목요일",
                    "Friday": "금요일",
                    "Saturday": "토요일",
                    "Sunday": "일요일"
                }
                day_name = day_names.get(day["day_name"], day["day_name"])
                result.append(f"   {day['date']} ({day_name}):")
                result.append(f"     최저: {day['temp_min']:.1f}°C, 최고: {day['temp_max']:.1f}°C")
                result.append(f"     평균: {day['temp_avg']:.1f}°C")
                result.append(f"     날씨: {day['description']}")
                result.append(f"     습도: {day['humidity_avg']:.0f}%")
                result.append("")
    
    return "\n".join(result)

def main():
    client = WeatherClient()
    
    # 서버 상태 확인
    print("=== 날씨 서버 상태 확인 ===")
    health = client.health_check()
    print(json.dumps(health, indent=2, ensure_ascii=False))
    print()
    
    # 테스트할 위치들
    locations = ["Seoul, Korea", "Busan, Korea", "Tokyo, Japan", "New York, USA"]
    
    for location in locations:
        print(f"=== {location} 날씨 정보 ===")
        
        # 전체 날씨 정보
        weather_data = client.get_weather(location)
        print(format_weather_data(weather_data))
        
        print("-" * 50)
        print()
    
    # 좌표로 테스트 (서울 시청 좌표)
    print("=== 좌표로 날씨 조회 (서울 시청) ===")
    seoul_coords = client.get_weather_by_coordinates(37.5665, 126.9780)
    print(format_weather_data(seoul_coords))
    
    # 현재 날씨만 테스트
    print("=== 서울 현재 날씨만 ===")
    current_seoul = client.get_current_weather("Seoul, Korea")
    if "error" not in current_seoul:
        current = current_seoul["weather"]
        print(f"온도: {current['temperature']:.1f}°C")
        print(f"날씨: {current['description']}")
        print(f"습도: {current['humidity']}%")
    else:
        print(f"오류: {current_seoul['error']}")
    
    # 1주일 예보만 테스트
    print("\n=== 서울 1주일 예보만 ===")
    forecast_seoul = client.get_forecast("Seoul, Korea")
    if "error" not in forecast_seoul and "forecast" in forecast_seoul:
        for day in forecast_seoul["forecast"][:3]:  # 처음 3일만
            print(f"{day['date']}: {day['temp_min']:.1f}°C ~ {day['temp_max']:.1f}°C, {day['description']}")
    else:
        print(f"오류: {forecast_seoul.get('error', '알 수 없는 오류')}")

if __name__ == "__main__":
    main() 