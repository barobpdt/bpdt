from flask import Flask, request, jsonify
import requests
import pandas as pd
from datetime import datetime, timedelta
import json
import os
from dotenv import load_dotenv
import yfinance as yf

# 환경 변수 로드
load_dotenv()

app = Flask(__name__)

class StockDataManager:
    def __init__(self):
        self.cache = {}
        self.cache_duration = 300  # 5분 캐시
    
    def get_stock_data(self, symbol: str, date: str) -> dict:
        """지정한 날짜의 주식 데이터를 가져옵니다."""
        try:
            # 캐시 키 생성
            cache_key = f"{symbol}_{date}"
            
            # 캐시된 데이터가 있는지 확인
            if cache_key in self.cache:
                cached_data = self.cache[cache_key]
                if (datetime.now() - cached_data['timestamp']).seconds < self.cache_duration:
                    return cached_data['data']
            
            # yfinance를 사용하여 주식 데이터 가져오기
            stock = yf.Ticker(symbol)
            
            # 날짜 범위 설정 (전후 1주일)
            start_date = datetime.strptime(date, '%Y-%m-%d') - timedelta(days=7)
            end_date = datetime.strptime(date, '%Y-%m-%d') + timedelta(days=7)
            
            # 히스토리 데이터 가져오기
            hist = stock.history(start=start_date, end=end_date)
            
            if hist.empty:
                return {"error": "해당 날짜의 데이터를 찾을 수 없습니다."}
            
            # 지정한 날짜의 데이터 찾기
            target_date = pd.to_datetime(date)
            if target_date in hist.index:
                data = hist.loc[target_date]
            else:
                # 가장 가까운 날짜의 데이터 반환
                closest_date = hist.index[hist.index.get_indexer([target_date], method='nearest')[0]]
                data = hist.loc[closest_date]
            
            result = {
                "symbol": symbol,
                "date": data.name.strftime('%Y-%m-%d'),
                "open": float(data['Open']),
                "high": float(data['High']),
                "low": float(data['Low']),
                "close": float(data['Close']),
                "volume": int(data['Volume']),
                "trading_amount": float(data['Volume'] * data['Close']),  # 거래대금 계산
                "currency": "USD"
            }
            
            # 캐시에 저장
            self.cache[cache_key] = {
                'data': result,
                'timestamp': datetime.now()
            }
            
            return result
            
        except Exception as e:
            return {"error": f"데이터 가져오기 실패: {str(e)}"}
    
    def get_multiple_stocks(self, symbols: list, date: str) -> dict:
        """여러 주식의 데이터를 한번에 가져옵니다."""
        results = {}
        for symbol in symbols:
            results[symbol] = self.get_stock_data(symbol, date)
        return results
    
    def get_market_summary(self, date: str) -> dict:
        """주요 지수들의 요약 정보를 가져옵니다."""
        major_indices = ['^GSPC', '^DJI', '^IXIC', '^KS11']  # S&P500, 다우존스, 나스닥, KOSPI
        return self.get_multiple_stocks(major_indices, date)

# 전역 변수로 StockDataManager 인스턴스 생성
stock_manager = StockDataManager()

@app.route('/stock/<symbol>/<date>', methods=['GET'])
def get_stock_data(symbol, date):
    """특정 주식의 지정 날짜 데이터를 반환합니다."""
    try:
        # 날짜 형식 검증
        datetime.strptime(date, '%Y-%m-%d')
        
        data = stock_manager.get_stock_data(symbol, date)
        return jsonify(data)
    except ValueError:
        return jsonify({"error": "잘못된 날짜 형식입니다. YYYY-MM-DD 형식을 사용하세요."}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/stocks', methods=['POST'])
def get_multiple_stocks():
    """여러 주식의 데이터를 한번에 가져옵니다."""
    try:
        data = request.json
        symbols = data.get('symbols', [])
        date = data.get('date')
        
        if not date:
            return jsonify({"error": "날짜가 필요합니다."}), 400
        
        # 날짜 형식 검증
        datetime.strptime(date, '%Y-%m-%d')
        
        results = stock_manager.get_multiple_stocks(symbols, date)
        return jsonify(results)
    except ValueError:
        return jsonify({"error": "잘못된 날짜 형식입니다. YYYY-MM-DD 형식을 사용하세요."}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/market-summary/<date>', methods=['GET'])
def get_market_summary(date):
    """주요 지수들의 요약 정보를 반환합니다."""
    try:
        # 날짜 형식 검증
        datetime.strptime(date, '%Y-%m-%d')
        
        summary = stock_manager.get_market_summary(date)
        return jsonify(summary)
    except ValueError:
        return jsonify({"error": "잘못된 날짜 형식입니다. YYYY-MM-DD 형식을 사용하세요."}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """서버 상태 확인"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "cache_size": len(stock_manager.cache)
    })

if __name__ == '__main__':
    app.run(debug=True, port=5002) 