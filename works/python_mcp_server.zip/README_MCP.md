# MCP 서버 Cursor 등록 가이드

이 프로젝트는 여러 MCP(Model Context Protocol) 서버를 포함하고 있으며, Cursor에서 이들을 등록하여 사용할 수 있습니다.

## 📋 서버 목록

### 1. 챗봇 서버 (mcp_server.py)
- **포트**: 5001
- **기능**: LangChain 기반 자연어 대화, 뉴스 정보, YouTube 동영상 검색
- **API 엔드포인트**: 
  - `POST /chat` - 대화 처리
  - `GET /history/<conversation_id>` - 대화 기록 조회

### 2. 주식 서버 (stock_server.py)
- **포트**: 5002
- **기능**: 주식 거래량, 거래대금 조회
- **API 엔드포인트**:
  - `GET /stock/<symbol>/<date>` - 개별 주식 데이터
  - `POST /stocks` - 여러 주식 데이터
  - `GET /market-summary/<date>` - 시장 요약 정보

### 3. 뉴스 수집기 (news_collector.py)
- **기능**: ChromaDB를 사용한 뉴스 수집 및 검색

## 🚀 설치 및 설정

### 1. 의존성 설치
```bash
pip install -r requirements.txt
```

### 2. 환경 변수 설정
`.env` 파일을 생성하고 다음 내용을 추가:
```env
OPENAI_API_KEY=your_openai_api_key_here
YOUTUBE_API_KEY=your_youtube_api_key_here
```

### 3. 서버 실행

#### Windows:
```bash
start_servers.bat
```

#### Unix/Linux/Mac:
```bash
chmod +x start_servers.sh
./start_servers.sh
```

#### 수동 실행:
```bash
# 터미널 1
python mcp_server.py

# 터미널 2
python stock_server.py

# 터미널 3
python news_collector.py
```

## 🔧 Cursor에서 MCP 서버 등록

### 방법 1: Cursor 설정 UI 사용

1. **Cursor 설정 열기**
   - `Ctrl + ,` (Windows/Linux) 또는 `Cmd + ,` (Mac)

2. **MCP 설정 검색**
   - 검색창에 "MCP" 입력

3. **서버 추가**
   - "MCP Servers" 섹션에서 "Add Server" 클릭
   - 각 서버에 대해 설정 추가

### 방법 2: 설정 파일 직접 편집

1. **Cursor 설정 파일 위치**
   - Windows: `%APPDATA%\Cursor\User\settings.json`
   - Mac: `~/Library/Application Support/Cursor/User/settings.json`
   - Linux: `~/.config/Cursor/User/settings.json`

2. **설정 추가**
```json
{
  "mcp.servers": {
    "chatbot-server": {
      "command": "python",
      "args": ["mcp_server.py"],
      "env": {
        "OPENAI_API_KEY": "your_openai_api_key",
        "YOUTUBE_API_KEY": "your_youtube_api_key"
      }
    },
    "stock-server": {
      "command": "python",
      "args": ["stock_server.py"]
    }
  }
}
```

## 🧪 테스트

### 챗봇 서버 테스트
```bash
python chatbot.py
```
웹 브라우저에서 `http://localhost:5000` 접속

### 주식 서버 테스트
```bash
python stock_client.py
```

### API 직접 테스트
```bash
# 챗봇 서버
curl -X POST http://localhost:5001/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "안녕하세요", "conversation_id": "test"}'

# 주식 서버
curl http://localhost:5002/stock/AAPL/2024-01-15
```

## 📊 사용 예시

### 챗봇과 대화
```
사용자: 안녕하세요
챗봇: 안녕하세요! 오늘은 어떤 일이 있으신가요?

사용자: 최신 뉴스 알려줘
챗봇: [뉴스 정보 제공]

사용자: AI 관련 동영상 추천해줘
챗봇: [YouTube 동영상 추천]
```

### 주식 정보 조회
```
GET /stock/AAPL/2024-01-15
응답:
{
  "symbol": "AAPL",
  "date": "2024-01-15",
  "volume": 45678900,
  "trading_amount": 8510000000.0
}
```

## ⚠️ 주의사항

1. **API 키 보안**: 환경 변수에 API 키를 안전하게 저장
2. **포트 충돌**: 다른 서비스와 포트가 충돌하지 않도록 확인
3. **인터넷 연결**: 뉴스 수집과 YouTube 검색에 인터넷 연결 필요
4. **API 제한**: YouTube API와 OpenAI API 사용량 제한 확인

## 🔍 문제 해결

### 서버가 시작되지 않는 경우
1. 포트가 이미 사용 중인지 확인
2. Python 환경과 의존성 확인
3. 환경 변수 설정 확인

### API 응답 오류
1. API 키 유효성 확인
2. 네트워크 연결 상태 확인
3. 서버 로그 확인

## 📝 추가 정보

- **프로젝트 구조**: 각 서버는 독립적으로 실행 가능
- **캐싱**: 주식 서버는 5분간 데이터 캐싱
- **확장성**: 새로운 MCP 서버 추가 가능
- **모니터링**: `/health` 엔드포인트로 서버 상태 확인 