from flask import Flask, request, jsonify
import requests
import json
from datetime import datetime, timedelta
import os
from dotenv import load_dotenv
from geopy.geocoders import Nominatim
from geopy.exc import GeocoderTimedOut, GeocoderUnavailable
import time

# 환경 변수 로드
load_dotenv()

app = Flask(__name__)

class WeatherManager:
    def __init__(self):
        self.api_key = os.getenv("OPENWEATHER_API_KEY")
        if not self.api_key:
            raise ValueError("OpenWeather API key not found in environment variables")
        
        self.base_url = "http://api.openweathermap.org/data/2.5"
        self.geocoder = Nominatim(user_agent="weather_app")
        self.cache = {}
        self.cache_duration = 600  # 10분 캐시
    
    def get_location_coordinates(self, location: str) -> dict:
        """위치명을 좌표로 변환합니다."""
        try:
            # 캐시 확인
            if location in self.cache:
                cached_data = self.cache[location]
                if (datetime.now() - cached_data['timestamp']).seconds < self.cache_duration:
                    return cached_data['data']
            
            # 지오코딩으로 좌표 가져오기
            location_data = self.geocoder.geocode(location)
            
            if not location_data:
                return {"error": "위치를 찾을 수 없습니다."}
            
            result = {
                "latitude": location_data.latitude,
                "longitude": location_data.longitude,
                "address": location_data.address
            }
            
            # 캐시에 저장
            self.cache[location] = {
                'data': result,
                'timestamp': datetime.now()
            }
            
            return result
            
        except (GeocoderTimedOut, GeocoderUnavailable) as e:
            return {"error": f"지오코딩 오류: {str(e)}"}
        except Exception as e:
            return {"error": f"좌표 변환 실패: {str(e)}"}
    
    def get_current_weather(self, lat: float, lon: float) -> dict:
        """현재 날씨 정보를 가져옵니다."""
        try:
            url = f"{self.base_url}/weather"
            params = {
                "lat": lat,
                "lon": lon,
                "appid": self.api_key,
                "units": "metric",  # 섭씨 온도
                "lang": "kr"  # 한국어
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            
            return {
                "temperature": data["main"]["temp"],
                "feels_like": data["main"]["feels_like"],
                "humidity": data["main"]["humidity"],
                "pressure": data["main"]["pressure"],
                "description": data["weather"][0]["description"],
                "icon": data["weather"][0]["icon"],
                "wind_speed": data["wind"]["speed"],
                "wind_direction": data["wind"].get("deg", 0),
                "visibility": data.get("visibility", 0),
                "clouds": data["clouds"]["all"],
                "sunrise": datetime.fromtimestamp(data["sys"]["sunrise"]).strftime("%H:%M"),
                "sunset": datetime.fromtimestamp(data["sys"]["sunset"]).strftime("%H:%M"),
                "timestamp": datetime.fromtimestamp(data["dt"]).isoformat()
            }
            
        except requests.exceptions.RequestException as e:
            return {"error": f"날씨 API 요청 실패: {str(e)}"}
        except Exception as e:
            return {"error": f"날씨 데이터 처리 실패: {str(e)}"}
    
    def get_weekly_forecast(self, lat: float, lon: float) -> dict:
        """1주일간 날씨 예보를 가져옵니다."""
        try:
            url = f"{self.base_url}/forecast"
            params = {
                "lat": lat,
                "lon": lon,
                "appid": self.api_key,
                "units": "metric",
                "lang": "kr"
            }
            
            response = requests.get(url, params=params)
            response.raise_for_status()
            
            data = response.json()
            
            # 일별 데이터로 그룹화
            daily_data = {}
            
            for item in data["list"]:
                date = datetime.fromtimestamp(item["dt"]).strftime("%Y-%m-%d")
                
                if date not in daily_data:
                    daily_data[date] = {
                        "date": date,
                        "day_name": datetime.fromtimestamp(item["dt"]).strftime("%A"),
                        "temperatures": [],
                        "descriptions": [],
                        "humidity": [],
                        "wind_speed": []
                    }
                
                daily_data[date]["temperatures"].append(item["main"]["temp"])
                daily_data[date]["descriptions"].append(item["weather"][0]["description"])
                daily_data[date]["humidity"].append(item["main"]["humidity"])
                daily_data[date]["wind_speed"].append(item["wind"]["speed"])
            
            # 일별 평균 계산
            forecast = []
            for date, day_data in daily_data.items():
                forecast.append({
                    "date": date,
                    "day_name": day_data["day_name"],
                    "temp_min": min(day_data["temperatures"]),
                    "temp_max": max(day_data["temperatures"]),
                    "temp_avg": sum(day_data["temperatures"]) / len(day_data["temperatures"]),
                    "description": max(set(day_data["descriptions"]), key=day_data["descriptions"].count),
                    "humidity_avg": sum(day_data["humidity"]) / len(day_data["humidity"]),
                    "wind_speed_avg": sum(day_data["wind_speed"]) / len(day_data["wind_speed"])
                })
            
            return {"forecast": forecast}
            
        except requests.exceptions.RequestException as e:
            return {"error": f"예보 API 요청 실패: {str(e)}"}
        except Exception as e:
            return {"error": f"예보 데이터 처리 실패: {str(e)}"}
    
    def get_weather_info(self, location: str) -> dict:
        """위치의 현재 날씨와 1주일 예보를 가져옵니다."""
        # 좌표 가져오기
        coords = self.get_location_coordinates(location)
        if "error" in coords:
            return coords
        
        # 현재 날씨
        current_weather = self.get_current_weather(coords["latitude"], coords["longitude"])
        
        # 1주일 예보
        weekly_forecast = self.get_weekly_forecast(coords["latitude"], coords["longitude"])
        
        return {
            "location": {
                "name": location,
                "address": coords["address"],
                "coordinates": {
                    "latitude": coords["latitude"],
                    "longitude": coords["longitude"]
                }
            },
            "current_weather": current_weather,
            "weekly_forecast": weekly_forecast
        }

# 전역 변수로 WeatherManager 인스턴스 생성
weather_manager = WeatherManager()

@app.route('/weather/<location>', methods=['GET'])
def get_weather(location):
    """특정 위치의 날씨 정보를 반환합니다."""
    try:
        weather_info = weather_manager.get_weather_info(location)
        return jsonify(weather_info)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/weather/current/<location>', methods=['GET'])
def get_current_weather_only(location):
    """현재 날씨만 반환합니다."""
    try:
        coords = weather_manager.get_location_coordinates(location)
        if "error" in coords:
            return jsonify(coords), 400
        
        current_weather = weather_manager.get_current_weather(coords["latitude"], coords["longitude"])
        return jsonify({
            "location": location,
            "weather": current_weather
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/weather/forecast/<location>', methods=['GET'])
def get_forecast_only(location):
    """1주일 예보만 반환합니다."""
    try:
        coords = weather_manager.get_location_coordinates(location)
        if "error" in coords:
            return jsonify(coords), 400
        
        weekly_forecast = weather_manager.get_weekly_forecast(coords["latitude"], coords["longitude"])
        return jsonify({
            "location": location,
            "forecast": weekly_forecast
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/weather/coordinates', methods=['POST'])
def get_weather_by_coordinates():
    """좌표로 직접 날씨 정보를 가져옵니다."""
    try:
        data = request.json
        lat = data.get('latitude')
        lon = data.get('longitude')
        
        if not lat or not lon:
            return jsonify({"error": "위도와 경도가 필요합니다."}), 400
        
        current_weather = weather_manager.get_current_weather(lat, lon)
        weekly_forecast = weather_manager.get_weekly_forecast(lat, lon)
        
        return jsonify({
            "coordinates": {"latitude": lat, "longitude": lon},
            "current_weather": current_weather,
            "weekly_forecast": weekly_forecast
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/weather/health', methods=['GET'])
def health_check():
    """서버 상태 확인"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "cache_size": len(weather_manager.cache)
    })

if __name__ == '__main__':
    # OpenWeather API 키 확인
    if not os.getenv("OPENWEATHER_API_KEY"):
        print("Error: OPENWEATHER_API_KEY environment variable is not set")
        exit(1)
    
    app.run(debug=True, port=5003) 