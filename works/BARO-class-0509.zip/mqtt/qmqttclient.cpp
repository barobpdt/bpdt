/******************************************************************************
**
** Copyright (C) 2017 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtMqtt module.
**
** $QT_BEGIN_LICENSE:GPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 3 or (at your option) any later version
** approved by the KDE Free Qt Foundation. The licenses are as published by
** the Free Software Foundation and appearing in the file LICENSE.GPL3
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
******************************************************************************/

#include "qmqttclient.h"
#include "qmqttconnection_p.h"

#include <QtCore/QLoggingCategory>
#include <QtCore/QUuid>
#include <QtCore/QtEndian>

QT_BEGIN_NAMESPACE

Q_LOGGING_CATEGORY(lcMqttClient, "qt.mqtt.client")

QMqttClient::QMqttClient(QObject *parent) : QObject(parent)
{
    // Q_D(QMqttClient);
    m_connection = new QMqttConnection(this);
    m_connection->setClientPrivate(this);
}


void QMqttClient::setTransport(QIODevice *device, QMqttClient::TransportType transport)
{
    // Q_D(QMqttClient);

    if (m_state != Disconnected) {
        qCDebug(lcMqttClient) << "Changing transport layer while connected is not possible.";
        return;
    }
    m_connection->setTransport(device, transport);
}

/*!
    Returns the transport used for communication with the broker.
 */
QIODevice *QMqttClient::transport() const
{
    // Q_D(const QMqttClient);
    return m_connection->transport();
}

/*!
    Adds a new subscription to receive notifications on \a topic. The parameter
    \a qos specifies the level at which security messages are received. For more
    information about the available QoS levels, see \l {Quality of Service}.

    This function returns a pointer to a \l QMqttSubscription. If the same topic
    is subscribed twice, the return value points to the same subscription
    instance. The MQTT client is the owner of the subscription.
 */
QMqttSubscription *QMqttClient::subscribe(const QMqttTopicFilter &topic, quint8 qos)
{
    return subscribe(topic, QMqttSubscriptionProperties(), qos);
}

/*!
    \since 5.12

    Adds a new subscription to receive notifications on \a topic. The parameter
    \a properties specifies additional subscription properties to be validated
    by the broker. The parameter \a qos specifies the level at which security
    messages are received. For more information about the available QoS levels,
    see \l {Quality of Service}.

    This function returns a pointer to a \l QMqttSubscription. If the same topic
    is subscribed twice, the return value points to the same subscription
    instance. The MQTT client is the owner of the subscription.

    \note \a properties will only be passed to the broker when the client
    specifies MQTT_5_0 as ProtocolVersion.
*/
QMqttSubscription *QMqttClient::subscribe(const QMqttTopicFilter &topic, const QMqttSubscriptionProperties &properties, quint8 qos)
{
    // Q_D(QMqttClient);

    if (m_state != QMqttClient::Connected)
        return nullptr;

    return m_connection->sendControlSubscribe(topic, qos, properties);
}

/*!
    Unsubscribes from \a topic. No notifications will be sent to any of the
    subscriptions made by calling subscribe().

    \note If a client disconnects from a broker without unsubscribing, the
    broker will store all messages and publish them on the next reconnect.
 */
void QMqttClient::unsubscribe(const QMqttTopicFilter &topic)
{
    unsubscribe(topic, QMqttUnsubscriptionProperties());
}

/*!
    \since 5.12

    Unsubscribes from \a topic. No notifications will be sent to any of the
    subscriptions made by calling subscribe(). \a properties specifies
    additional user properties to be passed to the broker.

    \note If a client disconnects from a broker without unsubscribing, the
    broker will store all messages and publish them on the next reconnect.

    \note \a properties will only be passed to the broker when the client
    specifies MQTT_5_0 as ProtocolVersion.
*/
void QMqttClient::unsubscribe(const QMqttTopicFilter &topic, const QMqttUnsubscriptionProperties &properties)
{
    // Q_D(QMqttClient);
    m_connection->sendControlUnsubscribe(topic, properties);
}

/*!
    Publishes a \a message to the broker with the specified \a topic. \a qos
    specifies the level of security required for transferring the message.

    If \a retain is set to \c true, the message will stay on the broker for
    other clients to connect and receive the message.

    Returns an ID that is used internally to identify the message.
*/
qint32 QMqttClient::publish(const QMqttTopicName &topic, const QByteArray &message, quint8 qos, bool retain)
{
    return publish(topic, QMqttPublishProperties(), message, qos, retain);
}

/*!
    \since 5.12

    Publishes a \a message to the broker with the specified \a properties and
    \a topic. \a qos specifies the level of security required for transferring
    the message.

    If \a retain is set to \c true, the message will stay on the broker for
    other clients to connect and receive the message.

    Returns an ID that is used internally to identify the message.

    \note \a properties will only be passed to the broker when the client
    specifies MQTT_5_0 as ProtocolVersion.
*/
qint32 QMqttClient::publish(const QMqttTopicName &topic, const QMqttPublishProperties &properties,
                            const QByteArray &message, quint8 qos, bool retain)
{
    // Q_D(QMqttClient);
    if (qos > 2)
        return -1;

    if (m_state != QMqttClient::Connected)
        return -1;

    return m_connection->sendControlPublish(topic, message, qos, retain, properties);
}

/*!
    Sends a ping message to the broker and expects a reply. If the connection
    is active, the MQTT client will automatically send a ping message at
    \l keepAlive intervals.

    To check whether the ping is successful, connect to the
    \l pingResponseReceived() signal.

    Returns \c true if the ping request could be sent.
 */
bool QMqttClient::requestPing()
{
    // Q_D(QMqttClient);
    return m_connection->sendControlPingRequest();
}

QString QMqttClient::hostname() const
{
    // Q_D(const QMqttClient);
    return m_hostname;
}

quint16 QMqttClient::port() const
{
    // Q_D(const QMqttClient);
    return m_port;
}

/*!
    Initiates a connection to the MQTT broker.
 */
void QMqttClient::connectToHost()
{
    connectToHost(false, QString());
}

/*!
    Initiates an encrypted connection to the MQTT broker.

    \a sslPeerName specifies the peer name to be passed to the socket.
 */
#ifndef QT_NO_SSL
void QMqttClient::connectToHostEncrypted(const QString &sslPeerName)
{
    connectToHost(true, sslPeerName);
}
#endif

void QMqttClient::connectToHost(bool encrypted, const QString &sslPeerName)
{
    // Q_D(QMqttClient);

    if (state() == QMqttClient::Connecting) {
        qCDebug(lcMqttClient) << "Connection request currently ongoing.";
        return;
    }

    if (state() == QMqttClient::Connected) {
        qCDebug(lcMqttClient) << "Already connected to a broker. Rejecting connection request.";
        return;
    }

    if (!m_connection->ensureTransport(encrypted)) {
        qCDebug(lcMqttClient) << "Could not ensure connection.";
        setStateAndError(Disconnected, TransportInvalid);
        return;
    }
    m_error = QMqttClient::NoError; // Fresh reconnect, unset error
    setStateAndError(Connecting);

    if (m_cleanSession)
        m_connection->cleanSubscriptions();

    if (!m_connection->ensureTransportOpen(sslPeerName)) {
        qCDebug(lcMqttClient) << "Could not ensure that connection is open.";
        setStateAndError(Disconnected, TransportInvalid);
        return;
    }

    // Once transport has connected, it will invoke
    // QMqttConnection::sendControlConnect to
    // handshake with the broker
}

/*!
    Disconnects from the MQTT broker.
 */
void QMqttClient::disconnectFromHost()
{
    // Q_D(QMqttClient);

    switch (m_connection->internalState()) {
    case QMqttConnection::BrokerConnected:
        m_connection->sendControlDisconnect();
        break;
    case QMqttConnection::BrokerDisconnected:
        break;
    case QMqttConnection::BrokerConnecting:
    case QMqttConnection::BrokerWaitForConnectAck:
        m_connection->m_transport->close();
        break;
    }
}

QMqttClient::ClientState QMqttClient::state() const
{
    // Q_D(const QMqttClient);
    return m_state;
}

QString QMqttClient::username() const
{
    // Q_D(const QMqttClient);
    return m_username;
}

QString QMqttClient::password() const
{
    // Q_D(const QMqttClient);
    return m_password;
}

bool QMqttClient::cleanSession() const
{
    // Q_D(const QMqttClient);
    return m_cleanSession;
}

QString QMqttClient::willTopic() const
{
    // Q_D(const QMqttClient);
    return m_willTopic;
}

quint8 QMqttClient::willQoS() const
{
    // Q_D(const QMqttClient);
    return m_willQoS;
}

QByteArray QMqttClient::willMessage() const
{
    // Q_D(const QMqttClient);
    return m_willMessage;
}

bool QMqttClient::willRetain() const
{
    // Q_D(const QMqttClient);
    return m_willRetain;
}

/*!
    \since 5.12

    Sets the connection properties to \a prop. \l QMqttConnectionProperties
    can be used to ask the server to use a specific feature set. After a
    connection request the server response can be obtained by calling
    \l QMqttClient::serverConnectionProperties.

    \note The connection properties can only be set if the MQTT client is in the
    \l Disconnected state.

    \note QMqttConnectionProperties can only be used when the client specifies
    MQTT_5_0 as ProtocolVersion.
*/
void QMqttClient::setConnectionProperties(const QMqttConnectionProperties &prop)
{
    // Q_D(QMqttClient);
    m_connectionProperties = prop;
}

/*!
    \since 5.12

    Returns the connection properties the client requests to the broker.

    \note QMqttConnectionProperties can only be used when the client specifies
    MQTT_5_0 as ProtocolVersion.
*/
QMqttConnectionProperties QMqttClient::connectionProperties() const
{
    // Q_D(const QMqttClient);
    return m_connectionProperties;
}

/*!
    \since 5.12

    Sets the last will properties to \a prop. QMqttLastWillProperties allows
    to set additional features for the last will message stored at the broker.

    \note The connection properties can only be set if the MQTT client is in the
    \l Disconnected state.

    \note QMqttLastWillProperties can only be used when the client specifies
    MQTT_5_0 as ProtocolVersion.
*/
void QMqttClient::setLastWillProperties(const QMqttLastWillProperties &prop)
{
    // Q_D(QMqttClient);
    m_lastWillProperties = prop;
}

/*!
    \since 5.12

    Returns the last will properties.

    \note QMqttLastWillProperties can only be used when the client specifies
    MQTT_5_0 as ProtocolVersion.
*/
QMqttLastWillProperties QMqttClient::lastWillProperties() const
{
    // Q_D(const QMqttClient);
    return m_lastWillProperties;
}

/*!
    \since 5.12

    Returns the QMqttServerConnectionProperties the broker returned after a
    connection attempt.

    This can be used to verify that client side connection properties set by
    QMqttClient::setConnectionProperties have been accepted by the broker. Also,
    in case of a failed connection attempt, it can be used for connection
    diagnostics.

    \note QMqttServerConnectionProperties can only be used when the client
    specifies MQTT_5_0 as ProtocolVersion.

    \sa connectionProperties()
*/
QMqttServerConnectionProperties QMqttClient::serverConnectionProperties() const
{
    // Q_D(const QMqttClient);
    return m_serverConnectionProperties;
}

/*!
    \since 5.12

    Sends an authentication request to the broker. \a prop specifies
    the required information to fulfill the authentication request.

    This function should only be called after a
    QMqttClient::authenticationRequested signal has been emitted.

    \note Extended authentication is part of the MQTT 5.0 standard and can
    only be used when the client specifies MQTT_5_0 as ProtocolVersion.

    \sa authenticationRequested(), authenticationFinished()
*/
void QMqttClient::authenticate(const QMqttAuthenticationProperties &prop)
{
    // Q_D(QMqttClient);
    if (protocolVersion() != QMqttClient::MQTT_5_0) {
        qCDebug(lcMqttClient) << "Authentication is only supported on protocol level 5.";
        return;
    }
    if (state() == QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Cannot send authentication request while disconnected.";
        return;
    }
    m_connection->sendControlAuthenticate(prop);
}

QMqttClient::ClientError QMqttClient::error() const
{
    // Q_D(const QMqttClient);
    return m_error;
}

QMqttClient::ProtocolVersion QMqttClient::protocolVersion() const
{
    // Q_D(const QMqttClient);
    return m_protocolVersion;
}

QString QMqttClient::clientId() const
{
    // Q_D(const QMqttClient);
    return m_clientId;
}

quint16 QMqttClient::keepAlive() const
{
    // Q_D(const QMqttClient);
    return m_keepAlive;
}

void QMqttClient::setHostname(const QString &hostname)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing hostname while connected is not possible.";
        return;
    }

    if (m_hostname == hostname)
        return;

    m_hostname = hostname;
    emit hostnameChanged(hostname);
}

void QMqttClient::setPort(quint16 port)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing port while connected is not possible.";
        return;
    }

    if (m_port == port)
        return;

    m_port = port;
    emit portChanged(port);
}


void QMqttClient::setKeepAlive(quint16 keepAlive)
{
    // Q_D(QMqttClient);
    if (m_keepAlive == keepAlive)
        return;

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing keepAlive while connected is not possible.";
        return;
    }

    m_keepAlive = keepAlive;
    emit keepAliveChanged(keepAlive);
}

void QMqttClient::setProtocolVersion(ProtocolVersion protocolVersion)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing protocol version while connected is not possible.";
        return;
    }

    if (m_protocolVersion == protocolVersion)
        return;

    if (protocolVersion < 3 || protocolVersion > 5)
        return;

    m_protocolVersion = protocolVersion;
    emit protocolVersionChanged(protocolVersion);
}

void QMqttClient::setState(ClientState state)
{
    // Q_D(QMqttClient);
    if (m_state == state)
        return;

    m_state = state;
    emit stateChanged(state);
    if (m_state == QMqttClient::Disconnected)
        emit disconnected();
    else if (m_state == QMqttClient::Connected)
        emit connected();
}

void QMqttClient::setUsername(const QString &username)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing username while connected is not possible.";
        return;
    }

    if (m_username == username)
        return;

    m_username = username;
    emit usernameChanged(username);
}

void QMqttClient::setPassword(const QString &password)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing password while connected is not possible.";
        return;
    }

    if (m_password == password)
        return;

    m_password = password;
    emit passwordChanged(password);
}

void QMqttClient::setCleanSession(bool cleanSession)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing clean session while connected is not possible.";
        return;
    }

    if (m_cleanSession == cleanSession)
        return;

    m_cleanSession = cleanSession;
    emit cleanSessionChanged(cleanSession);
}

void QMqttClient::setWillTopic(const QString &willTopic)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing will topic while connected is not possible.";
        return;
    }

    if (m_willTopic == willTopic)
        return;

    m_willTopic = willTopic;
    emit willTopicChanged(willTopic);
}

void QMqttClient::setWillQoS(quint8 willQoS)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing will qos while connected is not possible.";
        return;
    }

    if (m_willQoS == willQoS)
        return;

    m_willQoS = willQoS;
    emit willQoSChanged(willQoS);
}

void QMqttClient::setWillMessage(const QByteArray &willMessage)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing will message while connected is not possible.";
        return;
    }

    if (m_willMessage == willMessage)
        return;

    m_willMessage = willMessage;
    emit willMessageChanged(willMessage);
}

void QMqttClient::setWillRetain(bool willRetain)
{
    // Q_D(QMqttClient);

    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing will retain while connected is not possible.";
        return;
    }

    if (m_willRetain == willRetain)
        return;

    m_willRetain = willRetain;
    emit willRetainChanged(willRetain);
}

void QMqttClient::setError(ClientError e)
{
    // Q_D(QMqttClient);
    if (m_error == e)
        return;

    m_error = e;
    emit errorChanged(m_error);
}


void QMqttClient::setStateAndError(QMqttClient::ClientState s, QMqttClient::ClientError e)
{
    // Q_Q(QMqttClient);

    if (s != m_state)
        setState(s);
    if (e != QMqttClient::NoError && m_error != e)
        setError(e);
}

void QMqttClient::setClientId(const QString &id)
{
    // Q_Q(QMqttClient);
    if (state() != QMqttClient::Disconnected) {
        qCDebug(lcMqttClient) << "Changing client ID while connected is not possible.";
        return;
    }
    if (m_clientId == id)
        return;

    m_clientId = id;
    emit clientIdChanged(id);
}

QT_END_NAMESPACE
