package com.jikyeojwo.app

import android.provider.Settings
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.Promise

class DeviceInfoModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    override fun getName(): String {
        return "DeviceInfoModule"
    }

    @ReactMethod
    fun getJikyeojwoKey(promise: Promise) {
        try {
            val jikyeojwoKey = Settings.Secure.getString(reactContext.contentResolver, "android_id")  //android_id
            promise.resolve(jikyeojwoKey)
        } catch (e: Exception) {
            promise.reject("ERROR", e)
        }
    }
}