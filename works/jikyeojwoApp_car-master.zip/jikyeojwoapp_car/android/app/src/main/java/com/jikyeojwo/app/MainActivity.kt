package com.jikyeojwo.app

import android.os.Bundle
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint.fabricEnabled
import com.facebook.react.defaults.DefaultReactActivityDelegate
import android.media.AudioManager;

class MainActivity : ReactActivity() {

  /**
   * Returns the name of the main component registered from JavaScript. This is used to schedule
   * rendering of the component.
   */
  override fun getMainComponentName(): String = "jikyeojwoApp"

  /**
   * Returns the instance of the [ReactActivityDelegate]. We use [DefaultReactActivityDelegate]
   * which allows you to enable New Architecture with a single boolean flags [fabricEnabled]
   */
  override fun createReactActivityDelegate(): ReactActivityDelegate =
      DefaultReactActivityDelegate(this, mainComponentName, fabricEnabled)

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // AudioManager 인스턴스 생성
    //AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        
    // 통화 모드로 설정
    //audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        
    // 스피커폰 비활성화
    //audioManager.setSpeakerphoneOn(false); // 연결된 이어폰 사용
  } 
}
