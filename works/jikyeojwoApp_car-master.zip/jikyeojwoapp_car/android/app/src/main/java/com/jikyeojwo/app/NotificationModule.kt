package com.jikyeojwo.app

import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.Promise
import com.jikyeojwo.helpers.NotificationHelper

class NotificationModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    private val notificationHelper = NotificationHelper(reactContext) // NotificationHelper 인스턴스 생성

    override fun getName(): String {
        return "NotificationModule"
    }

    @ReactMethod
    fun showNotification(notificationId: Int, title: String, body: String, promise: Promise) {
        try {
            notificationHelper.showNotification(notificationId, title, body)
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("ERROR", "Error showing notification: ${e.message}")
        }
    }

    @ReactMethod
    fun dismissNotification(notificationId: Int, promise: Promise) {
        try {
            notificationHelper.dismissNotification(notificationId)
            promise.resolve(null)
        } catch (e: Exception) {
            promise.reject("ERROR", "Error dismissing notification: ${e.message}")
        }
    }
}