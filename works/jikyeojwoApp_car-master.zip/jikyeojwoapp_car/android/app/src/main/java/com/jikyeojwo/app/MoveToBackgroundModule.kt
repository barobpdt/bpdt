package com.jikyeojwo.app


import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class MoveToBackgroundModule(reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {
    
    override fun getName(): String {
        return "MoveToBackground"
    }

    @ReactMethod
    fun moveTaskToBack() {
        val activity: Activity? = currentActivity
        activity?.moveTaskToBack(true) // 앱을 백그라운드로 보냄
    }

    @ReactMethod
    fun exitApp() {
        val activity: Activity? = currentActivity
        activity?.finishAndRemoveTask() // 앱 종료
    }
}