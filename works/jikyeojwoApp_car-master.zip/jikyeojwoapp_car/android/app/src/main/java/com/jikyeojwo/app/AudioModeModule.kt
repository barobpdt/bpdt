package com.jikyeojwo.app

import android.content.Context
import android.media.AudioManager
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class AudioModeModule(private val reactContext: ReactApplicationContext) : ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String {
        return "AudioModeModule"
    }

    @ReactMethod
    fun getAudioMode(promise: Promise) {
        val audioManager = reactContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val ringerMode = audioManager.ringerMode

        val mode = when (ringerMode) {
            AudioManager.RINGER_MODE_SILENT -> "Silent" // 음소거 모드
            AudioManager.RINGER_MODE_VIBRATE -> "Vibrate" // 진동 모드
            AudioManager.RINGER_MODE_NORMAL -> "Normal" // 일반 소리 모드
            else -> "Unknown" // 알 수 없는 상태
        }

        promise.resolve(mode) // 모드 반환
    }
}