#import "AudioStatusModule.h"
#import <AVFoundation/AVFoundation.h>

@implementation AudioStatusModule

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(getAudioStatus:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject) {
  AVAudioSession *session = [AVAudioSession sharedInstance];
  NSString *category = [session category];
  
  NSError *error = nil;
     [session setCategory:AVAudioSessionCategoryPlayback error:&error];
  
  if (error) {
      reject(@"error", @"Failed to set audio session category", error);
      return;
  }

  // **추가된 부분**: 현재 출력 볼륨 가져오기
  float outputVolume = session.outputVolume; // 출력 볼륨 값 가져오기
  NSLog(@"Current Output Volume: %f", outputVolume); // **출력 볼륨 로그 출력**
  if (outputVolume > 1) {
      resolve(@"Sound"); // 사운드 모드
  } else {
      resolve(@"Vibrate"); // 음소거 모드
  }
  
  /*
  if ([category isEqualToString:AVAudioSessionCategoryPlayAndRecord]) {
    NSLog(@"Current Output Volume  AVAudioSessionCategoryPlayAndRecord"); // 무음모드 **출력 볼륨 로그 출력**
    if (outputVolume > 0) {
        resolve(@"Vibrate"); // 사운드 모드
    } else {
        resolve(@"Silent"); // 음소거 모드
    }
  } else if ([category isEqualToString:AVAudioSessionCategoryPlayback]) {
     NSLog(@"Current Output Volume  AVAudioSessionCategoryPlayback"); // **출력 볼륨 로그 출력**
    resolve(@"Sound"); // 소리 모드 // 배경 음악이나 비디오 재생용 카테고리
  } else {
        bool isSilent = [session isOtherAudioPlaying]; // 다른 오디오가 재생 중인지 체크
        NSLog(@"Current Output Volume  isSilent");
        if (isSilent) {
            resolve(@"Silent"); // 음소거 모드
        } else {
            resolve(@"Vibrate"); // 진동 모드, 진동 모드와 음소거 모드의 구분이 명확하지 않으므로 직접적인 확인이 필요
        }
  }
  */
}

@end
