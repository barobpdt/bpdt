import Foundation
import Network

@objc(LocalNetworkPermissionModule)
class LocalNetworkPermissionModule: NSObject {
  
  @objc func requestLocalNetworkPermission(_ resolver: @escaping RCTPromiseResolveBlock, rejecter: @escaping RCTPromiseRejectBlock) {
    if #available(iOS 14.0, *) {
      let monitor = NWPathMonitor()
      monitor.start(queue: DispatchQueue.global())
      
      // Local network request logic: (Dummy code for triggering the permission request)
      DispatchQueue.main.async {
        resolver("Local Network Permission requested successfully.")
      }
    } else {
      rejecter("ERR_IOS14", "This feature is only available on iOS 14 and above.", nil)
    }
  }
}

