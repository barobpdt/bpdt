//
//  AudioStatusModule.h
//  jikyeojwoApp
//
//  Created by youngnrim@gmail.com on 3/30/25.
//  Copyright © 2025 Jikyeojwo. All rights reserved.
//

#ifndef AudioStatusModule_h
#define AudioStatusModule_h
#import <React/RCTBridgeModule.h>

@interface AudioStatusModule : NSObject <RCTBridgeModule>
@end 

#endif /* AudioStatusModule_h */
