#import <RCTAppDelegate.h>
#import <UIKit/UIKit.h>
#import <UserNotifications/UNUserNotificationCenter.h>

// @interface AppDelegate () <UNUserNotificationCenterDelegate>
@interface AppDelegate : RCTAppDelegate <UNUserNotificationCenterDelegate>
// @interface AppDelegate : RCTAppDelegate

@end
