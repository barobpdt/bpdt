#import <React/RCTBridgeModule.h>
#import <AVFoundation/AVFoundation.h>

@interface AudioStatusModule : NSObject <RCTBridgeModule>
@end

@implementation AudioStatusModule

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(getAudioStatus:(RCTPromiseResolveBlock)resolve
                  rejecter:(RCTPromiseRejectBlock)reject) {
  AVAudioSession *session = [AVAudioSession sharedInstance];
  NSString *category = [session category];
  
  if ([category isEqualToString:AVAudioSessionCategoryPlayAndRecord]) {
    resolve(@"Sound"); // 소리 모드
  } else if ([category isEqualToString:AVAudioSessionCategoryPlayback]) {
    resolve(@"Vibrate"); // 진동 모드
  } else {
    resolve(@"Silent"); // 음소거 모드
  }
}

@end