#import "AppDelegate.h"
#import <React/RCTBundleURLProvider.h>
#import <UserNotifications/UserNotifications.h>
#import <RNCPushNotificationIOS.h>
#import <AVFoundation/AVFoundation.h>
#import <Firebase.h>
#import <GoogleMaps/GoogleMaps.h>
#import "AudioStatusModule.h"
// #import <AppTrackingTransparency/AppTrackingTransparency.h>

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
  // Google Maps API 키 설정
  NSString *apiKey = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"GoogleMapsApiKey"];
  if (apiKey) {
    [GMSServices provideAPIKey:apiKey];
  } else {
    NSLog(@"Warning: Google Maps API key not found in Info.plist");
  }

  self.moduleName = @"jikyeojwoApp";
  // You can add your custom initial props in the dictionary below.
  // They will be passed down to the ViewController used by React Native.
  self.initialProps = @{};

  // AVAudioSession을 설정하여 수화기로 통화
  [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord error:nil];
  [[AVAudioSession sharedInstance] setMode:AVAudioSessionModeVoiceChat error:nil];
  [[AVAudioSession sharedInstance] setActive:YES error:nil];
  
  // 스피커폰 비활성화
  NSError *error = nil;
  [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryPlayAndRecord
              withOptions:AVAudioSessionCategoryOptionDefaultToSpeaker //AVAudioSessionCategoryOptionDefault
                error:&error];
  if (error) {
      NSLog(@"Error setting audio session category: %@", error.localizedDescription);
  }
  
  // [self requestTrackingAuthorization];
  [super application:application didFinishLaunchingWithOptions:launchOptions];
  
  [FIRApp configure];
    
  // 사용자에게 알림 권한 요청
  UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
  center.delegate = self;

  [center requestAuthorizationWithOptions:(UNAuthorizationOptionAlert | UNAuthorizationOptionSound | UNAuthorizationOptionBadge)
    completionHandler:^(BOOL granted, NSError * _Nullable error) {
      if (granted) {
          NSLog(@"Local Notification permission granted.");
          dispatch_async(dispatch_get_main_queue(), ^{
              [application registerForRemoteNotifications];
          });
      }
  }];
  [application registerForRemoteNotifications];
  // self.initialProps = [RNFBMessagingModule addCustomPropsToUserProps:nil withLaunchOptions:launchOptions];
  
  return YES;
}


// URL 스킴을 통해 앱이 열렸을 때 호출
- (BOOL)application:(UIApplication *)app openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    NSLog(@"Opened with URL: %@", url.absoluteString);
    // URL에 대한 처리 로직을 추가합니다.
    
    // 예: URL에서 정보를 추출하고 처리하는 로직
    if ([url.scheme isEqualToString:@"myapp"]) {
        // 'myapp' 스킴에 대한 처리
        // 예: 특정 화면을 여는 코드
    }
    return YES;
}

// iOS 8 이상에서 URL을 통해 앱이 열렸을 때 호출
- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray *))restorationHandler {
    NSURL *url = userActivity.webpageURL;
    // URL에 대한 처리 로직을 추가합니다.
    NSLog(@"Opened via continueUserActivity with URL: %@", url.absoluteString);
    return YES;
}


- (NSURL *)sourceURLForBridge:(RCTBridge *)bridge
{
  return [self bundleURL];
}

- (NSURL *)bundleURL
{
#if DEBUG
  return [[RCTBundleURLProvider sharedSettings] jsBundleURLForBundleRoot:@"index"];
#else
  return [[NSBundle mainBundle] URLForResource:@"main" withExtension:@"jsbundle"];
#endif
}

// Required for the registrationError event.
- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error
{
  [RNCPushNotificationIOS didFailToRegisterForRemoteNotificationsWithError:error];
}

// APNs에 대한 토큰 받기
- (void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
  NSString *token = [deviceToken description];
  /*
  token = [token stringByReplacingOccurrencesOfString:@"<" withString:@""];
  token = [token stringByReplacingOccurrencesOfString:@">" withString:@""];
  token = [token stringByReplacingOccurrencesOfString:@" " withString:@""];
  */
  NSLog(@"Notification token: %@", deviceToken);
  [FIRMessaging messaging].APNSToken = deviceToken;
}

// FCM에서 메시지 수신
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    // 메시지 데이터 처리
    NSLog(@"Notification received: %@", userInfo);

    // Completion 핸들러 호출
    completionHandler(UIBackgroundFetchResultNewData);
}

// 포그라운드에서 수신된 알림 처리
- (void)userNotificationCenter:(UNUserNotificationCenter *)center didReceiveNotificationResponse:(UNNotificationResponse *)response withCompletionHandler:(void (^)(void))completionHandler {
    // 알림 응답 처리
    NSString *message = response.notification.request.content.body;
    NSLog(@"Foreground notification received: %@", message);
    
    completionHandler();
}
/*
- (void)requestTrackingAuthorization {
    if (@available(iOS 14, *)) {
        [ATTrackingManager requestTrackingAuthorizationWithCompletionHandler:^(ATTrackingManagerAuthorizationStatus status) {
            switch (status) {
                case ATTrackingManagerAuthorizationStatusAuthorized:
                    NSLog(@"사용자가 추적을 허용했습니다.");
                    // 추적을 사용할 수 있습니다.
                    break;
                case ATTrackingManagerAuthorizationStatusDenied:
                    NSLog(@"사용자가 추적을 거부했습니다.");
                    // 추적을 사용할 수 없는 상황 처리
                    break;
                case ATTrackingManagerAuthorizationStatusNotDetermined:
                    NSLog(@"사용자가 아직 선택하지 않았습니다.");
                    // 사용자에게 다시 요청할 수 있는 기회를 마련
                    break;
                case ATTrackingManagerAuthorizationStatusRestricted:
                    NSLog(@"사용자가 추적을 사용할 수 없습니다 (제한됨).");
                    // 제한된 상태에 대한 처리
                    break;
            }
        }];
    } else {
        // iOS 14 미만
        NSLog(@"ATT는 iOS 14 이상의 기기에서만 지원됩니다.");
    }
}
*/

@end

