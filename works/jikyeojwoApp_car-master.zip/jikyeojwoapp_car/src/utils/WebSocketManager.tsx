import React, { createContext, useState, useRef, useEffect } from 'react';
import SockJS from 'sockjs-client';
import { PermissionsAndroid, Platform, AppState, Alert } from 'react-native';
import { GlobalData, useGlobalStore, GetDate, callPost, apiCallGet, callGet, GetDateDay, GetDateTime, MembInfo } from '../store/global';
import NetInfo, { NetInfoState, NetInfoStateType } from '@react-native-community/netinfo';
import ApiInfo from '../gvar/ApiInfo';
import Stomp, { Client } from 'stompjs';
import {NetworkType, MessageData, CallSeqResponse, MessageLocation, MessageSendRead, MembLocation, FriendList, ListRoomMessage
	    , ChgRoomInfoRequest, ChgRoomInfoResponse, ChangeInfo, AlarmAddFriendResponse, SaveResponse} from '../types/common';
import Geolocation from 'react-native-geolocation-service';
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';
import { RTCPeerConnection, RTCSessionDescription, mediaDevices, MediaStream,  RTCIceCandidate } from 'react-native-webrtc';
import {MessageRoomInfoRequest, MessageRoomInfoResponse, SaveFriendRequest} from '../types/common';

interface SocketStompContextType {
	connect: () => void;
	disconnect: () => void;
	isconnected: () => boolean;
	reconnect: () => void;
	sendMessage: (msg: {}, sendSubscr: string) => boolean;
	sendLocMessage: (msg: string, sendSubscr: string) => boolean;
	sendReadMessage: (msg: any, sendSubscr: string) => boolean;
	subscribeToWebRTC: (roomNo: string) => boolean;
	disconnectWebRtc: () => void;
	sendCallKey: (sendSubScr: string) => void;
	sendSendKey: () => void;
	startLocationUpdates: () => void;
	stopLocationUpdates: () => void;
	sendAddFriendMessage: (msg: any, sendSubscr: string) => boolean;
	receiveDataProcess: (msgData: MessageData) => void;
  }
  
  // 초기값을 선언해서 타입과 함께 지정
  const defaultValue: SocketStompContextType = {
	connect: () => {},
	disconnect: () => {},
	isconnected: () => {return false},
	reconnect: () => {},
	sendMessage: () => {return false},
	sendLocMessage: () => {return false},
	sendReadMessage: () => {return false},
	subscribeToWebRTC: () => {return false},
	disconnectWebRtc: () => {},
	sendCallKey: () => {},
	sendSendKey:  () => {},
	startLocationUpdates: () => {},
	stopLocationUpdates: () => {},
	sendAddFriendMessage: () => {return false},
	receiveDataProcess: () => {},

  };

  // 타입 선언
  type StompSubscription = {
	unsubscribe: () => void;
  };

  type RoomSubScr = {
    roomNo: string;
    subscrList: StompSubscription[];
  };
const wrtcState = {
	targetKey: '',
	targetRoomId: '',
	roomId: '',
	reconnectState: ''
}
let clientObject = null;
let lastLocationTime = 0;
let backgroundLocationTime = 0;
let watchId = -1;
let currentMessageLocation : MessageLocation | null = null;


export const SocketStompContext = createContext<SocketStompContextType>(defaultValue);

export const SocketStompProvider = ({ children }) => {
  const stompClient = useRef<Stomp.Client | null>(null);
  const subscriptionsRef = useRef<StompSubscription[]>([]); // 구독 리스트 저장
  // const [receivedData, setReceivedData] = useState<MessageData | null>(null);
  const [infoCallKey, setInfoCallKey] = useState('');  // C 요청 받음,  R 답변받음  -- webRTC시 callkey 상호전달 정보
  
  const [roomSubscriptions, setRoomSubscriptions] = useState<RoomSubScr[]>([]);
  const reconnectInterval = 5000;
  
  const global = useGlobalStore();
  const state = useGlobalStore.getState();

  // 서버 주소 수정
  const SERVER_URL = GlobalData.callUrl + GlobalData.sockUrl;

 //webRTC관련 로직///////////////////////////
 const peerConnectionRef = useRef<RTCPeerConnection | null>(null);
 const callKey: string = GlobalData.myKey ;
 
 const localStreamRef = useRef<MediaStream | null>(null);
 const remoteStreamRef = useRef<MediaStream | null>(null);
 
 const [audioSoundType, setAudioSoundType] = useState(false);   // false 전화통화 true 스피커폰 
 const [isRemoteDescriptionSet, setIsRemoteDescriptionSet] = useState(false);   // false 전화통화 true 스피커폰 

  // 위치 업데이트를 위한 watchId 저장


 /*
 const [otherKey, setOtherKey] = useState('');
 const [sendSubScr, setSendSubScr] = useState(''); 
 const [targetKey, setTargetKey] = useState('');  // 통화 상대방 키
 const [targetRoomId, setTargetRoomId] = useState('');  // 통화 상대방 방번호
 */


 
 let subRtcScriptionIds:string[] = []; // 구독 ID를 저장하는 배열
 let candidates: string[] = [] ; // candidate 전송할 데이타 모음
 const [roomId, setRoomId] = useState('');   // false 전화통화 true 스피커폰 

 //////////////////////////////////////////////

  const connect = () => {
	const state = useGlobalStore.getState();
	GlobalData.myKey = getMyKey();

	if (state.listSubscr.length < 1) {
		console.log("@@ stompClient.current 구독데이타 없음");
		return ;
	}
    if ( clientObject ) {
		console.log("@@ stompClient.current 이미 연결된 상태면 안 함");
		return; // 이미 연결된 상태면 안 함
	}

    const socket = new SockJS(SERVER_URL);
    const client = Stomp.over(socket) as any;	
	// console.log("SERVER_URL===>", SERVER_URL);
    // 디버그 끄기
    client.debug = (str) => { console.log('stompjs debug:', str); };
    client.connect({}, () => {		
      clientObject = client;
	  console.log("@@ connect listSubscr size: ", state.listSubscr.length );
		//구독 리트 가져와 구독 처한다.ApiInfo.sScribeMsgSend
	  for (const subscrInfo of state.listSubscr) {
		const subList: StompSubscription[] = [];
		const subscrMsgSendId = client.subscribe(ApiInfo.sScribeMsgSend + "/" + subscrInfo.subscr, (message) => {
			//메세지 구독
			var msgdata: MessageData = JSON.parse(message.body);
			console.log("Socket receive Data sScribeMsgSend", msgdata);
			//1. 서비스 확인 , 2. 바로 전송건일 경우 
			receiveDataProcess(msgdata);
		}) ;
		subList.push(subscrMsgSendId);

		const subSendLocateId = client.subscribe(ApiInfo.rtnSubscribeLocInfo + "/" + subscrInfo.subscr, (message) => {
			//위치정보 구독
			//1. R 요청으로 A 현 위치 정보를 제공한다., A로 받으면 위치 업데이트 
			var msgdata: MessageLocation = JSON.parse(message.body);
			console.log("@@ location receive " , msgdata);
			// 위치정보 처리를 한다.
			receiveLocProcess(msgdata);
		}) ;
		subList.push(subSendLocateId);

		//메세지 읽음표시
		const subSendReadMsgId = client.subscribe(ApiInfo.rtnSubscribeReadMsg + "/" + subscrInfo.subscr, (message) => {
			//읽음 정보 수신
			const parseData = JSON.parse(message.body);
			receiveReadProcess(parseData);
		}) ;
		subList.push(subSendReadMsgId);

		const subCallKeyId = client.subscribe(ApiInfo.rtnSubscribeCallKey + "/" + subscrInfo.subscr, (message) => {
			//통화 key전송 구독
			const state = useGlobalStore.getState();	
			const cur = state.currentSendData || state.currentReceivedData || state.currentCarMessageData
			console.log("@@ subCallKeyId "+subscrInfo.subscr +'=='+cur?.roomId, cur);
			subscribeToWebRTC(subscrInfo.subscr) ;
			// sendSendKey();	
			if( stompClient.current && cur  && cur.targetRoomId ) { 
				if( state.currentReceivedData ) {
					wrtcState.targetRoomId = cur.roomId;
					stompClient.current.send(ApiInfo.rtnSendCallKey + '/' + cur.roomId, {}, '');
					stompClient.current.send(ApiInfo.rtnSendSendKey + '/' + cur.roomId, {}, JSON.stringify(GlobalData.myKey));
				} else {
					wrtcState.targetRoomId = cur.roomId;
					stompClient.current.send(ApiInfo.rtnSendSendKey + '/' + cur.roomId, {}, JSON.stringify(GlobalData.myKey));
				} 
			}
			state.setIncallKey('C');
		}) ;
		subList.push(subCallKeyId);
		// subscriptionsRef.current.push(subCallKeyId);

		const subSendKeyId = client.subscribe(ApiInfo.rtnSubscribeSendKey + "/" + subscrInfo.subscr, (message) => {
			//otherKey에 저장
			const key = JSON.parse(message.body);
			wrtcState.targetKey = key;
			console.log("@@ subSendKeyId setTargetKey => ", subscrInfo.subscr, key);
			const state = useGlobalStore.getState();
			const cur = state.currentSendData || state.currentCarMessageData
			if( cur ) {
				console.log("@@ subSendKeyId createOffer => ", key, cur.roomId);
				setTimeout(() => createOffer(), 1000);
			}
			state.setIncallKey('R');
		});
		subList.push(subSendKeyId);
		//subscriptionsRef.current.push(subSendKeyId);

		//메세지 읽음표시
		const subSendChangeInfoId = client.subscribe(ApiInfo.rtnSubscribeChangeInfo + "/" + subscrInfo.subscr, (message) => {
			//읽음 정보 수신
			const parseData = JSON.parse(message.body);
			receiveChangeInfoProcess(parseData);
		}) ;
		subList.push(subSendChangeInfoId);
		

		console.log("구독리스트 출력 ", subscriptionsRef.current.length, subscriptionsRef.current);
		// 방별로 구독 리스트 별도 저장함 .. 사유 : QR삭제시 해당 관련 부분 구독 취소 처리 하기 위함
	  	const roomSub:RoomSubScr = {roomNo: subscrInfo.subscr, subscrList: subList}
   	    setRoomSubscriptions(prev => [...prev, roomSub]);

	  }
    }, (err) => {
      console.log('@@ STOMP 연결 실패:', err);
      clientObject = null;
	  reconnect();
    });
	clientObject = client;
    stompClient.current = client;	
  };

  useEffect(() => {
	const unsubscribe = NetInfo.addEventListener((state: NetInfoState) => {
		console.log('네트워크 상태 변화:', state);
		const netStatus: NetworkType = { isConnected: state.isConnected ?? false, type: state.type} ;
		global.updateNetworkStatus(netStatus);
	  });
	  return () => unsubscribe();
  }, []); 


  

  const receiveDataProcess = async (msgData:MessageData) => {
		console.log("@@ receiveDataProcess msgData", msgData);
		//GlobalData.pageInfo  ==:> Called, Calling 이외는 알림떠야함
		//mType,callSeq, msgDesc, qrNo, membNo, roomId, serviceTypeCd, fileImgUrl, filePath, counterPart
		let sendData: any = null ;
		let callSeq = msgData.callSeq;
		let checkReverse = false;
		// let retData: CallSeqResponse ;
		// let sendYn = 'N';		
		const state = useGlobalStore.getState();
		if (msgData.mType == 'OY') {  //통신 가능여부 옛날버전
			//OY로 전송 membNo 차빼줘 membNo
			sendData = setSendDataSetting('OP',callSeq, '', msgData.qrNo,  GlobalData.membNo
				  , msgData.targetRoomId, msgData.serviceTypeCd, '', '', msgData.writeMembNo, msgData.roomId) ;
		} else if (msgData.mType == 'RC') {  //통화가능여부 문의
			let callType = '';
			receiveCallOutPring(msgData);
			if ( state.currentReceivedData || state.processScreen == 'Calling' ) {
				// 통화중 전송
				callType = 'FR';
			} else {
				callType = 'RT'; //통화가능 전송
			}
			if( msgData.serviceTypeCd == 'Car' ) {	
				sendData = setSendDataSetting(
					callType ,callSeq, '', msgData.qrNo,  GlobalData.membNo
					, msgData.targetRoomId, msgData.serviceTypeCd, '', '', msgData.writeMembNo, msgData.roomId
				);
				checkReverse = true;
			} else {
				sendData = setSendDataSetting(
					callType ,callSeq, '', msgData.qrNo,  GlobalData.membNo
					, msgData.roomId, msgData.serviceTypeCd, '', '', msgData.counterPart, msgData.targetRoomId
				);
				if (callType === 'FR') {
					sendCallOutPring(sendData);
				}
			}
			console.log("@@ receiveDataProcess RT ===================", msgData, sendData);
		} else if (msgData.mType == 'RT') {		//통화가능시 -->BR	
			const cur = state.currentSendData || state.currentCarMessageData;
			if( msgData.serviceTypeCd == 'Car' && cur ) {
				return;
			}
					
			if( msgData.serviceTypeCd == 'Car' ) {		
				sendData = setSendDataSetting(
					"BR", callSeq, '', msgData.qrNo,  GlobalData.membNo
					, msgData.roomId, msgData.serviceTypeCd, '', '', msgData.writeMembNo, msgData.targetRoomId
				);	
				global.setCurrentCarMessageData(sendData);
				global.setCarRoomType('recv');
				// global.setPopupPageId('CallingCarPopup');
			} else {
				console.log("@@ counterpart data call", msgData);
				sendData = setSendDataSetting(
					"BR", callSeq, '', msgData.qrNo,  GlobalData.membNo
					, msgData.roomId, msgData.serviceTypeCd, '', '', msgData.counterPart, msgData.targetRoomId
				);	
				global.setCurrentSendData(sendData);
				global.setProcessScreen('Calling');
			}
			global.setIncallKey('CALLING');
		} else if (msgData.mType == 'BR') {
			// 통화팝업 화면 뛰움 -- rece  ==> receiveCallPop 오픈함 
			const cur = state.currentReceivedData;
			if( cur ) {
				if(cur.callCount===undefined) {
					cur.callCount = 0;
				} else {
					cur.callCount++;
				}
			} else {
				if (msgData.serviceTypeCd === 'Car') {
					const recvData = setSendDataSetting(
						"BR" ,callSeq, '', msgData.qrNo,  GlobalData.membNo
						,msgData.roomId, msgData.serviceTypeCd, '', '', msgData.writeMembNo, msgData.targetRoomId
					) as MessageData
					global.setCurrentReceivedData(recvData);
					global.setPopupPageId('ReceiveCallPop');
				} else {
					const recvData = setSendDataSetting(
						"BR" ,callSeq, '', msgData.qrNo,  GlobalData.membNo
						,msgData.roomId, msgData.serviceTypeCd, '', '', msgData.counterPart, msgData.targetRoomId
					) as MessageData
					global.setCurrentReceivedData(recvData);
					global.setPopupPageId('ReceiveCallPop');
				}
				
			}
			// setReceivedData(msgData);
		} else if (msgData.mType == 'FR') {
			global.setIncallKey('FR');  // 통화거절
			receiveCallOutPring(msgData);
		} else if (msgData.mType == 'BC') {
			const cur = state.currentSendData || state.currentCarMessageData;
			global.setIncallKey('BC'); //통화연결
			console.log("@@ BC recv: cur => ", cur);
			if( cur ) {
				cur.mType = 'BC';
				if( stompClient.current) {
					console.log("@@ BC recv: msgData.roomId =="+msgData.roomId, ApiInfo.rtnSendCallKey + '/' + cur.roomId );
					stompClient.current.send(ApiInfo.rtnSendCallKey + '/' + cur.roomId, {}, '');
				}
				// sendCallKey(cur.roomId, cur.targetRoomId);
				// clientObject?.send(ApiInfo.rtnSendCallKey + '/' + cur.roomId, {}, '');	
				receiveCallOutPring(msgData);
			}
			// setReceivedData(msgData); receiveCallPop 팝업에서 통화를 누르면 
			// call
		} else if (msgData.mType == 'RL') {

			console.log('===========================================================');
			console.log(' RL 받은데이타 ',msgData);

			global.setLocationStatus('M',msgData, '30', '수락요청중');
			
			// const accetpData = setSendDataSetting(
			// 	"RL",callSeq, msgData.msgDesc, msgData.roomId,  msgData.counterPart
			// 	,msgData.roomId, msgData.serviceTypeCd, '', msgData.qrNo, msgData.membNo, msgData.targetRoomId
			// ) as MessageData; 		

			global.setCurrentLocationRequest(msgData);
			global.setPopupPageId('LocationAllowPop');
		} else if (msgData.mType == 'JL') {
			Alert.alert("알림", msgData.writeNickNm + '님이 위치정보 거절 하였습니다.');	
			global.setLocationStatus('F',msgData, '90', '거절');
		} else if (msgData.mType == 'AL') {
			Alert.alert("알림", msgData.writeNickNm + '님이 위치정보 허용 하였습니다.');
			global.setLocationStatus('F',msgData, '50', '허용');
		} else if (msgData.mType == 'CL') {
			//Alert.alert("알림", msgData.writeNickNm + '님이 위치정보 허용 취쇠 하였습니다.');
			global.setLocationStatus('F',msgData, '10', '미요청');
		} else if (msgData.mType == 'FR') {
			global.setIncallKey('FR');
		} else if (msgData.mType == 'BJ' || msgData.mType == 'BT') {
			global.setIncallKey(msgData.mType);
			receiveCallOutPring(msgData);
			// 통화 종료 시키고 문자를 뛰움  // 채팅창 ChatScreen 으로 화면을 오픈하고  CallingScreen 화면을 닫는다.
			// setReceivedData(msgData);
		} else if (msgData.mType == 'O') {  // webRTC 종료 처리
			const cur = state.currentSendData || state.currentReceivedData;
			if( cur ) {
				cur.mType = 'O';
			}
			global.setIncallKey('O');
			disconnectWebRtc();
		} else if (msgData.mType == 'M') { //데이타 작업
			console.log("@@ receiveDataProcess M");	

			if( msgData.serviceTypeCd === 'Car' ) {
				if( !state.currentCarMessageData ) {
					/*
					const recvData = msgData.writeMembNo === GlobalData.membNo ? setSendDataSetting("M",callSeq, '', msgData.qrNo,  GlobalData.membNo
						,msgData.targetRoomId, msgData.serviceTypeCd, '', '', msgData.counterPart, msgData.roomId
 					) as MessageData :
					setSendDataSetting("M",callSeq, '', msgData.qrNo,  GlobalData.membNo
						,msgData.roomId, msgData.serviceTypeCd, '', '', msgData.counterPart, msgData.targetRoomId
 					) as MessageData
					*/
					global.setCurrentCarMessageData(msgData);
				}
				if( state.popupPageId !== 'CallingCarPopup' ) {
					global.setPopupPageId('CallingCarPopup');
				}
				global.addCarRoomChat(msgData, false);
			} else {
				if (msgData.writeMembNo === GlobalData.membNo) return;
				let isChatRoomOpen = false;
				// console.log("@@ receiveDataProcess processScreen:", state.processScreen, state.currentRoomInfo.roomNo);
				let incrNum = true
				if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
					incrNum = false;
					global.addRoomChatMsg(msgData, false);
					//읽음표시 전송
					const sendReadMsg = setSendDataSetting('R', msgData.callSeq, '','', GlobalData.membNo, msgData.roomId, 'Protect', '','', msgData.counterPart, msgData.targetRoomId)
					console.log("@@ sendReadMessage  수신후 전송전", sendReadMsg);
					// sendReadMessage(sendReadMsg, msgData.targetRoomId) ;
					if( state.listRoomFriend ) {
						state.listRoomFriend.forEach(item => {
							console.log("@@ sendReadMessage ========> ", item.subScr);
							sendReadMessage(sendReadMsg, item.subScr);
						})
					}
					isChatRoomOpen = true;
				} 

				// listRoomMessage에 데이타 존재하는지 여부 확인해서 업데이트
				// 내가 받은qr번호, 내가 받은 구독번호	해당룸의 멤버수
				const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
				console.log("@@ receiveDataProcess findListMessage", msgData.counterPart);
				if( findListMessage) {
					if( !findListMessage.nickNm ) {
						const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
						console.log("@@ receiveDataProcess friend", friend);
						if( friend ) {
							findListMessage.nickNm = friend.nickNm;
						}
					}
					findListMessage.msgDesc = msgData.msgTypeCd === 'T' ? msgData.msgDesc : '파일을 받았습니다.';
					findListMessage.notReadYn = incrNum ? 'Y' : 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
					findListMessage.addDt = GetDateDay();
					findListMessage.addTime = GetDateTime();	
					findListMessage.chatSeq = msgData.callSeq;				 
					if (isChatRoomOpen) {
						findListMessage.notReadCnt = 0 ;
					} else {
						findListMessage.notReadCnt = findListMessage.notReadCnt + 1;
					}
					console.log("@@ receiveDataProcess findListMessage", findListMessage);
					global.updateRoomChatMessage(findListMessage);
				} else {
					//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
					const msgRoomInfoRequest = () => {
						const node = {} as MessageRoomInfoRequest
						node.serviceTypeCd=msgData.serviceTypeCd
						node.roomNo=msgData.counterPart
						return node;
					}
					const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
					if(info.hasOwnProperty('errors')) return global.showToast(info.message);
					const updateListRoomMessage:ListRoomMessage = {
						roomNo: msgData.counterPart,
						profileImgFileUrl: '',
						nickNm: '',
						msgDesc: msgData.msgTypeCd === 'T' ? msgData.msgDesc : '파일을 받았습니다.',
						notReadYn: incrNum ? 'Y' : 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
						notReadCnt: 1,
						addDt: GetDateDay(),
						addTime: GetDateTime(),
						msgTypeCd: msgData.msgTypeCd,
						roomTypeCd: '',
						chatSeq: msgData.callSeq,
						msgReDesc: '',
						callStatCd: '' ,
						serviceTypeCd: msgData.serviceTypeCd,
						qrNo: msgData.roomId,  //내QR
						membNo: GlobalData.membNo,
						writeMembNo: msgData.writeMembNo,
						sendSubScr: msgData.targetRoomId,
						targetMembNo: msgData.roomId,
						mySubScr: msgData.roomId,
						roomMembCnt: 0,
					}
					if (info) {
						updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
						updateListRoomMessage.nickNm = info.roomNm;
					}
					console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
					global.addRoomMessage(updateListRoomMessage);
				}

			}
		} else if (msgData.mType == 'NG' || msgData.mType == 'NF' || msgData.mType == 'EF') { //데이타 작업
			console.log("@@ receiveDataProcess MG", msgData, state.currentRoomInfo);	
			let isChatRoomOpen = false;
			console.log("@@ receiveDataProcess processScreen:", state.processScreen, state.currentRoomInfo.roomNo);
			//global.setChgRoomType(msgData.mType) ;


			const chgRoomInfoRequest = () => {
				const node = {} as ChgRoomInfoRequest
				node.roomNo=msgData.counterPart
				node.langCd=GlobalData.langCd
				return node;
			}
			const info = await callPost(ApiInfo.getGrpRFInfo, chgRoomInfoRequest()) as ChgRoomInfoResponse;
			if (info) {
				global.updateGroupList(info.listGroup);
				global.filterGroupList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
			}
			
			let incrNum = true;
			if (msgData.mType == 'EF') {  // 친구만 추가
				if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
					incrNum = false;
					global.addRoomChatMsg(msgData, false);					
					isChatRoomOpen = true;					
					global.updateListRoomFriend(info.friendList);		
				} 
			} else if (msgData.mType == 'NG') { 
				// 그룹 정보와 방 친구정보를 다시 겨져온다.
				if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.filePath ) {
					//기존 방을 새로 세팅 - 그룹정보 가져와 세팅
					global.updateListRoomFriend(info.friendList);	
					global.setCurrentMessageData(msgData)	;
					global.setCurrentRoomInfo(msgData.counterPart, msgData.roomNm, msgData.roomImg);
					global.setChgRoomType('NG');
				} 
			} 				
				// listRoomMessage에 데이타 존재하는지 여부 확인해서 업데이트
				// 내가 받은qr번호, 내가 받은 구독번호	해당룸의 멤버수
			const newlistRoomMessage:ListRoomMessage = {
				roomNo: msgData.counterPart,
				profileImgFileUrl: msgData.roomImg,
				nickNm: msgData.roomNm,
				msgDesc: msgData.msgTypeCd === 'T' ? msgData.msgDesc : '파일을 받았습니다.',
				notReadYn: incrNum ? 'Y' : 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				notReadCnt: 0,
				addDt: GetDateDay(),
				addTime: GetDateTime(),
				msgTypeCd: msgData.msgTypeCd,
				roomTypeCd: '',
				chatSeq: msgData.callSeq,
				msgReDesc: '',
				callStatCd: '' ,
				serviceTypeCd: msgData.serviceTypeCd,
				qrNo: msgData.roomId,  //내QR
				membNo: GlobalData.membNo,
				writeMembNo: msgData.writeMembNo,
				sendSubScr: msgData.targetRoomId,
				targetMembNo: msgData.roomId,
				mySubScr: msgData.roomId ,
				roomMembCnt: 0
			}
			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			if (findListMessage) {
				if (isChatRoomOpen) {
					newlistRoomMessage.notReadCnt = 0 ;
				} else {
					newlistRoomMessage.notReadCnt = findListMessage.notReadCnt + 1 ;
				}
				global.updateRoomChatMessage(newlistRoomMessage);
			} else {
				//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
				const msgRoomInfoRequest = () => {
					const node = {} as MessageRoomInfoRequest
					node.serviceTypeCd=msgData.serviceTypeCd
					node.roomNo=msgData.counterPart
					return node;
				}
				const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
				if(info.hasOwnProperty('errors')) return global.showToast(info.message);
				if (info) {
					newlistRoomMessage.notReadCnt = 0 ; 
					newlistRoomMessage.profileImgFileUrl = info.imgFileUrl;
					newlistRoomMessage.nickNm = info.roomNm;
				}
				console.log("=====newlistRoomMessage===========================", newlistRoomMessage)
				global.addRoomMessage(newlistRoomMessage);
			}
		} else if (msgData.mType == 'EG') { //그룹 방 나가기
			console.log("@@ receiveDataProcess EG", msgData, state.currentRoomInfo);	
			let isChatRoomOpen = false;
			if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
				global.addRoomChatMsg(msgData, false);					
				isChatRoomOpen = true;		
			} 
			// 해당 친구 삭제처리함
			global.removeListRoomFriend(msgData.writeMembNo);				
				
				// listRoomMessage에 데이타 존재하는지 여부 확인해서 업데이트
				// 내가 받은qr번호, 내가 받은 구독번호	해당룸의 멤버수
			const newlistRoomMessage:ListRoomMessage = {
				roomNo: msgData.counterPart,
				profileImgFileUrl: msgData.roomImg,
				nickNm: msgData.roomNm,
				msgDesc: msgData.msgDesc,
				notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				notReadCnt: 0,
				addDt: GetDateDay(),
				addTime: GetDateTime(),
				msgTypeCd: msgData.msgTypeCd,
				roomTypeCd: '',
				chatSeq: msgData.callSeq,
				msgReDesc: '',
				callStatCd: '' ,
				serviceTypeCd: msgData.serviceTypeCd,
				qrNo: msgData.roomId,  //내QR
				membNo: GlobalData.membNo,
				writeMembNo: msgData.writeMembNo,
				sendSubScr: msgData.targetRoomId,
				targetMembNo: msgData.roomId,
				mySubScr: msgData.roomId ,
				roomMembCnt: 0
			}
			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			if (findListMessage) {
				if (isChatRoomOpen) {
					newlistRoomMessage.notReadCnt = 0 ;
				} else {
					newlistRoomMessage.notReadCnt = findListMessage.notReadCnt + 1 ;
				}
				global.updateRoomChatMessage(newlistRoomMessage);
			} else {
				//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
				const msgRoomInfoRequest = () => {
					const node = {} as MessageRoomInfoRequest
					node.serviceTypeCd=msgData.serviceTypeCd
					node.roomNo=msgData.counterPart
					return node;
				}
				const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
				if(info.hasOwnProperty('errors')) return global.showToast(info.message);
				if (info) {
					newlistRoomMessage.notReadCnt = 0 ; 
					newlistRoomMessage.profileImgFileUrl = info.imgFileUrl;
					newlistRoomMessage.nickNm = info.roomNm;
				}
				console.log("=====newlistRoomMessage===========================", newlistRoomMessage)
				global.addRoomMessage(newlistRoomMessage);
			}

		} else if (msgData.mType == 'DM') { //채팅데이타 전체 삭제			
			if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
				global.removeListRoomChatMsg(msgData.callSeq);	
				// listMessage마지막글일경우 삭제되었습니다. 문구 출력
			} 
			console.log("@@ DM Delete data", msgData);
			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			console.log("@@ DM Delete data filter ", findListMessage);
			if (findListMessage?.chatSeq === msgData.callSeq) {
				findListMessage.msgDesc = '삭제 되었습니다.';
				console.log("@@ DM Delete data find ", findListMessage);
				global.updateRoomChatMessage(findListMessage);
			}

		}
		// console.log("@@ receiveDataProcess sendData", sendData, msgData);
		//전송 처리함
		if( sendData) {
			sendMessage(sendData, checkReverse ? sendData.targetRoomId : sendData.roomId) ;
		}		
  }

  const setSendDataSetting = (mType,callSeq, msgDesc, qrNo, membNo, roomId, serviceTypeCd, fileImgUrl, filePath, counterPart, targetRoomId ) => {  //sendMsgData: MessageData
	
	const param = {} ;
		param["mType"] = mType ;  // 차주앱 통신가능여부 체크
		param["mykey"] = GlobalData.myKey ;
		param["msgDesc"] = msgDesc;  // 앱에서 초기에 데이타 가져와 보관후 사용하는 문구로 함  -Loc 받는사람이름
		param["qrNo"] = qrNo;  //호출받은QRNO값  loc- 보내는사람qr
		param["langCd"] = GlobalData.langCd;  //웹 단말기 언어를 가져와 세팅
		param["currentDate"] = GetDate;  //웹 단말기 날짜세팅
		param["callSeq"] = callSeq;  //호출받은 callSeq값
		param["membNo"] = membNo;  //wait-init 에서 받아오는 값   loc 보내는사람 회원번호
		param["roomId"] = targetRoomId;  //wait-init 에서 받아오는 값   loc 받는사람 구독번호
		param["onOff"] = 'Y';  //wait-init 에서 받아오는 값
		param["writeMembNo"] =  mType == 'RL' ? filePath  : GlobalData.membNo; // loc 받는사람QR번호
		param["serviceTypeCd"] = serviceTypeCd;
		param["fileImgUrl"] = fileImgUrl;
		param["filePath"] = filePath;         
		param["counterPart"] = counterPart ;   // loc 받는사람 회원번호
		param["targetRoomId"] = roomId;   // Loc보내는사람구독
		param["callCount"] = 0;
		param["writeNickNm"] = MembInfo.nickNm ;   // loc 받는사람 회원번호
		param["writeImgFileUrl"] = MembInfo.imgFileUrl;   // Loc보내는사람구독
	
	return param ;
	
  }

  const sendMessage = (msg, sendSubscr) => {
	console.log("@@ sendMessage ....", sendSubscr,  msg );
    if (stompClient.current && clientObject ) {
      // 목적지 수정 필요
	  try {
		stompClient.current.send(ApiInfo.rtnSendMsgSend + '/' + sendSubscr, {}, JSON.stringify(msg));
		  return true;
	  } catch (error) {
		console.log("@@ 전송오류", error);
		clientObject = null;
		reconnect();
		return false;
	  }
    } else {
		clientObject = null;
		reconnect();
		return false;
	}
  };

  const sendLocMessage = (msg, sendSubscr) => {
	console.log("@@ sendLocMessage ...." );
    if (stompClient.current && clientObject) {
      // 목적지 수정 필요
	  try {
		stompClient.current.send(ApiInfo.rtnSendLocInfo + '/' + sendSubscr, {}, JSON.stringify(msg));
		return true;
	  } catch (error) {
		console.log("@@ sendLocMessage 전송오류", error);
		clientObject = null;
		reconnect();
		return false;
	  }
    } else {
		clientObject = null;
		reconnect();
		return false;
	}
  };

  const sendReadMessage = (msg:any, sendSubscr) => {
	console.log('@@ sendReadMessage 데이타 전송 ==> ',msg, sendSubscr );	 
    if (stompClient.current && clientObject ) {
      // 목적지 수정 필요
	  try {
		stompClient.current.send(ApiInfo.rtnSendReadMsg + '/' + sendSubscr, {}, JSON.stringify(msg));
		return true;
	  } catch (error) {
		console.log("@@ sendReadMessage 전송오류", error);
		clientObject = null;
		reconnect();
		return false;
	  }
    } else {
		console.log('@@ send data connect errror ', stompClient.current,  clientObject)
		clientObject = null;
		reconnect();
		return false;
	}
  };


  const sendAddFriendMessage = (msg:any, sendSubscr) => {

	console.log("@@ sendAddFriendMessage ...." , stompClient.current, clientObject);
	console.log('@@ sendAddFriendMessage 데이타 전송 ==> ',msg, sendSubscr );
    if (stompClient.current && clientObject ) {
      // 목적지 수정 필요
	  try {
		stompClient.current.send(ApiInfo.rtnSendChangeInfo + '/' + sendSubscr, {}, JSON.stringify(msg));
		return true;
	  } catch (error) {
		console.log("@@ sendReadMessage 전송오류", error);
		clientObject = null;
		reconnect();
		return false;
	  }
    } else {
		console.log('@@ send data connect errror ', stompClient.current,  clientObject)
		clientObject = null;
		reconnect();
		return false;
	}
  };

const checkLocation = () => {
	// 맵모드가 아니고 최종위치 업데이트 시간이 10초 이상 지났으면 위치 업데이트 중지
	const dist = new Date().getTime() - lastLocationTime;
	if( dist>10000 ) {
		console.log('@@ checkLocation dist>10000 ', dist);
		lastLocationTime = 0;
		stopLocationUpdates();
		return true;
	}
	setTimeout(checkLocation, 10000);
}

const receiveLocProcess = async (msgData:MessageLocation) => {
	//GlobalData.pageInfo  ==:> Called, Calling 이외는 알림떠야함
	//mType,membNo, latitude, longitude
	if (GlobalData.membNo == msgData.membNo) return;
	console.log("@@ receiveLocProcess " , msgData)
	const state = useGlobalStore.getState();
	if (msgData.mType === 'A') {  // 요청에 대한 답변
		if( state.mapMode ) {
			const infoFriend = {
				membNo: msgData.membNo,  latitude: msgData.latitude, longitude: msgData.longitude, curDate: GetDate()
				//membNo 친구번호
			}
			global.updateListLocation(infoFriend);		
		}
	} else { // 요청에 대한 위치 답변 단, 위치허용 대상자만 가능  mType: R
		//내 위치 알림 일시 정지 인지 확인 setting 
		console.log("@@ receiveLocProcess 위치 알림 일시 정지 인지 확인 setting", GlobalData.SettingData.locationYn);
		if (GlobalData.SettingData.locationYn === 'Y') {
			const existingIndex = state.listFriend.findIndex(finfo => finfo.friendNo === msgData.membNo);
			console.log("@@ receiveLocProcess 친구 존재 여부 확인", existingIndex, state.listFriend);
			if( lastLocationTime == 0 ) {
				checkLocation();
			}
			lastLocationTime = new Date().getTime();
			global.setMapMode(true);
			startLocationUpdates();
			if (existingIndex !== -1) {  // 친구가 존재시
				if (state.listFriend[existingIndex].membLocationCd === '50') {
					// 위치값 전송처리함
					// getLocation(msgData.roomNo, msgData.subScr);
					currentMessageLocation = {
						mType: 'A',
						membNo: GlobalData.membNo,
						latitude: state.infoLocation.latitude,
						longitude: state.infoLocation.longitude,
						roomNo: msgData.roomNo,
						targetSubScr: '',
						subScr: ''
					}	
					sendLocMessage(currentMessageLocation, msgData.subScr);
				}
			}
		}
	}
	
}

const receiveReadProcess = async (msgData:MessageSendRead) => {
	//GlobalData.pageInfo  ==:>  mType: string;membNo: string;chatSeq: string; roomId
	//mType,membNo, latitude, longitude	
	const state = useGlobalStore.getState();
	console.log('@@ receiveReadProcess 받는데이타 => ',msgData , state.currentMessageData );
	if( !msgData.chatSeq ) {
		return;
	}
	if (msgData.roomId == state.currentMessageData?.counterPart) {
		console.log('@@ receiveReadProcess 데이타 업데이트 ==> ',msgData );		
		global.readListRoomChatMsg(msgData);
	}
}

const receiveChangeInfoProcess = async (msgData:ChangeInfo) => {
	//GlobalData.pageInfo  ==:>  mType: string;membNo: string;chatSeq: string; roomId
	//mType,membNo, latitude, longitude	
	const state = useGlobalStore.getState();
	console.log('@@ receiveReadProcess 받는데이타 => ',msgData , state.currentMessageData );
	if (msgData.transData === 'F') {
		const param = {
			serviceTypeCd : "Protect",
			qrNo: msgData.transData2,
			friendQrNo: msgData.transData1,
			currentDate: GetDate(),
			langCd:GlobalData.langCd
		} as SaveFriendRequest

		const info = await callPost(ApiInfo.alarmAddFriend, param ) as AlarmAddFriendResponse

		if( "errors" in info ) {
			global.showToast("친구추가 오류:"+info.message);
		}

		if( info.code == "20006") {
			if( info.addFriendInfo ) {
				global.addFriend(info.addFriendInfo)
				global.filterFriendList(global.qrClickData.serviceTypeCd, msgData.transData2);
			}
		} else {
			global.showToast("친구추가 오류:"+info.message);
		}	
	}	
}


  const isconnected = () => {
	return clientObject == null ? false : true;
  }
  //접속 오류시 재 접속 진행
  const reconnect = () => {
	console.log('@@ reconnect start');
	if( wrtcState.reconnectState == 'start' ) {
		return;
	}
	console.log('@@ reconnect start  isconnected');

	if( isconnected() ) {
		// console.log("@@ reConnect 이미 연결되어 있음");
		return;
	}
	let retryCnt = 0;
	wrtcState.reconnectState = 'start';
	console.log('@@ connectSocket');
	const connectSocket = () => {
		console.log("@@ reconnect connect call");
		if ( global.networkStatus.isConnected ) {
			connect(); // 재연결 시도
			wrtcState.reconnectState = 'call';
		} 
		if( stompClient.current == null ) {
			retryCnt++;
			if (retryCnt < 3) {
				setTimeout(connectSocket, reconnectInterval);
			} else {
				wrtcState.reconnectState = 'end';
			}
		} else {
			wrtcState.reconnectState = 'end';
		}
	}
	connectSocket();

  }

  const disconnect = async () => {
	console.log("@@ disconnect 호출");
    disconnectWebRtc();
    if (subscriptionsRef.current.length > 0) {
		// 구독 해제
		subscriptionsRef.current.forEach(sub => {
			if (sub) {
				sub.unsubscribe();
			}
		});
		// 구독 리스트 초기화
		subscriptionsRef.current = [];
		setRoomSubscriptions([]);
	}
	
	if( stompClient.current ) {
		stompClient.current.disconnect(() => {
			stompClient.current = null;
			clientObject = null;
		});
	}	
  };

  //roomNo 별로 구독 취소 처리
  const removeUnitSubScr = (targetRoomNo: string) => {
	setRoomSubscriptions(prev => {
		// 이전 리스트를 필터링하면서
		const remaining = prev.filter(roomSub => {
		  if (roomSub.roomNo === targetRoomNo) {
			// 대상 방이면, 구독 취소
			roomSub.subscrList.forEach(sub => sub.unsubscribe());
			
			return false;  //대상 방의 구독을 제거하기 위해 false 반환
		  }
		  return true;  // 대상이 아니면 그대로 유지한다.
		});
		return remaining;
	  });
  }

  // 구독 리스트 체크
  useEffect(() => {
	if (clientObject==null) {
		connect();
	}
  }, [global.listSubscr]);    ///[connected]);

  // 네트워크 상태 감지 후 연결/해제  networkState
  useEffect(() => {
	console.log("@@ === network status" , global.networkStatus, global.isAppActive );
	if( global.isAppActive ) {
		if ( global.networkStatus.isConnected) {
			if( clientObject==null ) reconnect();
		} else {
			clientObject = null;
			reconnect()
		}
	}
  }, [global.networkStatus]);    ///[connected]);

  	const sendLocationRequest = async (latitude: number, longitude: number) => {
		const params = {
			latitude: latitude,
			longitude: longitude,
			currentDate: GetDate(),
			langCd:GlobalData.langCd
		}
		const info = await callPost("/api/main/save-location", params );
		console.log("@@ sendLocationRequest info", info);
	}

  // 위치 업데이트 시작
  const startLocationUpdates = () => {
	console.log('location permission @@ startLocationUpdates ', watchId);
	if (watchId !== -1) return watchId;

	const id = Geolocation.watchPosition(
		position => {
			const mylocat: MembLocation = {
				latitude: position.coords.latitude,
				longitude: position.coords.longitude
			}
			const state = useGlobalStore.getState();
			console.log('@@ startLocationUpdates ' , position.coords.latitude, position.coords.longitude, state.mapMode, state.isAppActive);
			global.updateInfoLocation(mylocat);
			let checkSendLocation = false;
			// 위치 알림 처리
			if( state.mapMode ) {
				const msgInfo = state.currentMessageData;				
				state.listRoomFriend.forEach(item => {
					if (item.locationCd === '50' ) {
						if( msgInfo ) {
							console.log("@@ location request chatroom ", state.currentRoomInfo.roomNo, msgInfo.targetRoomId, item.subScr);
							// requestLocation(state.currentRoomInfo.roomNo, msgInfo.targetRoomId, item.subScr);  
							// 방번호 , 내 구독번보, 전송할 번호 그룹일일경우는 위치는 내 qr구독을 받아 처리됨
							const sendLocData: MessageLocation = {
								mType: 'R',
								membNo: GlobalData.membNo,  // 내회원번호
								latitude: mylocat.latitude,
								longitude: mylocat.longitude,
								roomNo: state.currentRoomInfo.roomNo,  // 채팅방번호
								targetSubScr: item.subScr,
								subScr: msgInfo.targetRoomId  //내가 받을 구독번호
							}	 
							if( !sendLocMessage(sendLocData, item.subScr) ) return false;

						} else if( currentMessageLocation ) {
							const sendLocData: MessageLocation = {
								mType: 'R',
								membNo: GlobalData.membNo,  // 내회원번호
								latitude: mylocat.latitude,
								longitude: mylocat.longitude,
								roomNo: currentMessageLocation.roomNo,  // 채팅방번호
								targetSubScr: currentMessageLocation.subScr,
								subScr: currentMessageLocation.targetSubScr  //내가 받을 구독번호
							}	 
							if( !sendLocMessage(sendLocData, currentMessageLocation.subScr) ) return false;
						}
						currentMessageLocation = null;
					}
				});
			} else if( state.isAppActive ) {
				checkLocation();
			}
			// 1 분마다 위치 전송 처리함
			if( backgroundLocationTime==0 ) {
				backgroundLocationTime = new Date().getTime();
				checkSendLocation = true;
			} else {
				const dist = new Date().getTime() - backgroundLocationTime;
				// 1분 체크
				if( dist > 60000 ) {
					checkSendLocation = true;
					backgroundLocationTime = new Date().getTime();				
				} else  {
					checkSendLocation = false;
				}
				console.log("@@ backgroundLocationTime", dist, checkSendLocation);
			}
			if( checkSendLocation ) {
				// 지도기 모드가 아니고 앱이 활성화 되어 있으면 위치 업데이트 중지
				sendLocationRequest(position.coords.latitude, position.coords.longitude);
				if( state.mapMode==false && state.isAppActive ) {
					console.log('@@ startLocationUpdates stopLocationUpdates');
					stopLocationUpdates();
				}
			}
		}, error => {
			console.warn(error.message);
			console.log('@@ startLocationUpdates error.message ' , error.message);
		}, {
			enableHighAccuracy: true,
			distanceFilter: 2, // 2 미터마다 업데이트
			interval: 1000, // 5초마다 업데이트
			fastestInterval: GlobalData.colLocationTime*1000, // 최소 5초 간격
			forceRequestLocation: true, // 백그라운드에서도 강제로 위치 요청
		}
	);
	console.log("@@ startLocationUpdates id : ", id);
	watchId = id;
  };

  // 위치 업데이트 중지
  const stopLocationUpdates = () => {
	console.log("@@ stopLocationUpdates 호출", watchId);
	if ( watchId !== -1) {
		Geolocation.clearWatch(watchId);
		watchId = -1;
	}
  };

  // 앱 상태 변경 감지
  /*
  useEffect(() => {
	const subscription = AppState.addEventListener('change', nextAppState => {
		if (nextAppState === 'active') {
			startLocationUpdates();
		} else if (nextAppState === 'background') {
			// 백그라운드에서도 위치 업데이트 유지
			startLocationUpdates();
		}
	});

	return () => {
		subscription.remove();
		stopLocationUpdates();
	};
  }, []);

  // 컴포넌트 마운트 시 위치 업데이트 시작
  useEffect(() => {
	startLocationUpdates();
	return () => {
		stopLocationUpdates();
	};
  }, []);
*/

  const getMyKey = ():string => {
		return 'QR' + getRandomString(36).substring(2, 12);
	}

	const getRandomString = (length: number): string => {
		const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		let result = '';
		for (let i = 0; i < length; i++) {
			const randomIndex = Math.floor(Math.random() * characters.length);
			result += characters.charAt(randomIndex);
		}
		return result;
	};	


/////////////////////////////////////////////////////////////////////webRTC 
const configuration = {
	iceServers: [
		{ urls: "stun:turn.kosk.co.kr:3478" },
		{ urls: "stun:stun.l.google.com:19302" },
		{ urls: "stun:stun1.l.google.com:19302" },
		{ urls: "stun:stun.services.mozilla.com" },
		{
			urls: 'turn:kosk.co.kr:3478?transport=udp',
			username: 'kosk',
			credential: 'kosk1234!@',
		},
		{
			urls: 'turn:kosk.co.kr:3478?transport=tcp',
			username: 'kosk',
			credential: 'kosk1234!@',
		}   
   ]   
}

const sendCallKey = (subScr) => {
	console.log("@@ sendCallKey 호출", subScr);
    if ( stompClient.current && clientObject ) {
	    wrtcState.targetRoomId = subScr;
		// 목적지 수정 필요
		if ( wrtcState.targetKey == '') {
			console.log("@@ sendCallKey ==> ", subScr );
			stompClient.current.send(ApiInfo.rtnSendCallKey + '/' + subScr, {}, '');	
		}
    }
};

const sendSendKey = () => {
	console.log("@@ sendSendKey 호출");
    if (stompClient.current && clientObject ) {
		// 목적지 수정 필요
		stompClient.current.send(ApiInfo.rtnSendSendKey + '/' + wrtcState.targetRoomId, {}, JSON.stringify(GlobalData.myKey));
    }
};

// webRTC 구독 처리함
const subscribeToWebRTC = (roomId) => {
	// setRoomId(roomNo) ;
	console.log("@@ subscribeToWebRTC 호출", GlobalData.myKey, roomId, wrtcState );
	const rtnSubscribeCandidateId = stompClient.current?.subscribe(ApiInfo.rtnSubscribeCandidate + '/' + GlobalData.myKey + '/' + roomId, (message) => {	
		console.log("subscribeToWebRTC  생성 - rtnSubscribeCandidate 전송받음", message);
		const candidateData  = JSON.parse(message.body);
		const { candidate, sdpMLineIndex, sdpMid } = candidateData.body;
		
		if (sdpMLineIndex === null || sdpMid === null ) {
			return false; // 여기서 반환하여 ICE 후보 추가를 중단
		}
		
		if (sdpMLineIndex === undefined  || sdpMid === undefined ) {
			return false; // 여기서 반환하여 ICE 후보 추가를 중단
		}
		const iceCandidate = new RTCIceCandidate({
			candidate: candidate,
			sdpMLineIndex: sdpMLineIndex, // 이 값이 null이 아니어야 합니다.
			sdpMid: sdpMid               // 이 값이 null이 아니어야 합니다.
		});
		
		if (typeof iceCandidate.sdpMLineIndex === 'number' && typeof iceCandidate.sdpMid === 'string') {
			// ICE 후보 추가
		//	console.log("ICE 후보 추가" , this.isRemoteDescriptionSet);
			if (peerConnectionRef.current  ) { // 수정된 부분
			//	if (this.isRemoteDescriptionSet) {
					peerConnectionRef.current.addIceCandidate(iceCandidate)
							.then(() => {
							//	console.log('ICE후보 등록 완료 ==> ICE Candidate added successfully');
							})
							.catch(e => {
							//	console.error('ICE후보 등록 오류 ==> Error adding ICE candidate:', e);
							});
						}
					}

		// } else {
		// 	console.error('Invalid ICE candidate values:', iceCandidate);
		// }
		

	}); // 구독 ID 저장
	//console.log("subscribeToWebRTC  생성 - rtnSubscribeCandidate 구독처리");
	if (rtnSubscribeCandidateId) {
		subRtcScriptionIds.push(rtnSubscribeCandidateId.id); 
	}

	const rtnSubscribeOfferId = stompClient.current?.subscribe(ApiInfo.rtnSubscribeOffer + '/' + GlobalData.myKey + '/' + roomId, (message) => {	
		//console.log("Offer 구독 받음");
		const offer = JSON.parse(message.body);
		console.log("@@ subscribeOfferId handleOffer => ", offer, roomId, wrtcState );
		handleOffer(offer);
	}); // 구독 ID 저장
	//console.log("Offer 구독 처리");
	if (rtnSubscribeOfferId) {
		subRtcScriptionIds.push(rtnSubscribeOfferId.id); 
	}

	const rtnSubscribeAnswerId = stompClient.current?.subscribe(ApiInfo.rtnSubscribeAnswer + '/' + GlobalData.myKey + '/' + roomId, (message) => {			
		//console.log("Answer 구독 받음");
		console.log("@@ rtnSubscribeAnswerId 호출", message );
		const answer = JSON.parse(message.body);
		console.log("@@ rtnSubscribeAnswerId handleAnswer => ", answer );
		handleAnswer(answer);
	}); // 구독 ID 저장
	//console.log("Answer 구독 처리");
	if (rtnSubscribeAnswerId) {
		subRtcScriptionIds.push(rtnSubscribeAnswerId.id); 
	}
	return true;
}

const createOffer = async () => {
	console.log("@@ createOffer 호출", wrtcState );
	try {
		peerConnectionRef.current = await new RTCPeerConnection(configuration); //  new RTCPeerConnection(CONFIG);
		GlobalData.isPeerConnect = true
		
		// ICE 후보 및 상태 변경 핸들러 바인딩
		peerConnectionRef.current.onicecandidate = (event) => {
			// 현재 ICE 연결 상태를 확인합니다.
			const iceConnectionState = peerConnectionRef.current?.iceConnectionState;
			// 연결 상태가 "connected" 인 경우 후보 생성 및 처리 중지
			if (iceConnectionState === 'connected') {
				console.log("접속 성공! 더 이상 후보를 처리하지 않습니다.");
				return; // 후보 처리를 중지하고 함수를 종료합니다.
			}

			if (event.candidate) {
				//console.log( "ICE 추가 " , event.candidate);
				sendIceCandidate(event.candidate);
			} else {
				// 만약 상태가 connect 가 아니면 turn서버 연결 처리함
			}
		}; 		
		peerConnectionRef.current.oniceconnectionstatechange = onIceConnectionStateChange.bind(this);
		
		
		const stream: MediaStream = await mediaDevices.getUserMedia({ audio: true, video: false });
		localStreamRef.current = stream ;
		// 미디어 스트림 가져오기 null이면 생성
		const audioTracks = localStreamRef.current.getAudioTracks();
		if (audioTracks.length > 0) {
			audioTracks.forEach((track) => {
				peerConnectionRef.current?.addTrack(track, localStreamRef.current!);
			})
		} 
		
		const offer = await peerConnectionRef.current?.createOffer();

		await peerConnectionRef.current?.setLocalDescription(offer);
		
		// 원격 스트림 수신 시
		peerConnectionRef.current.ontrack = (event) => {
		
			const remoteStream = new MediaStream();
			remoteStreamRef.current = remoteStream;
			
			// 원격 오디오 트랙 추가
			if (event.track.kind === 'audio') {
				const remoteAudioTracks = remoteStreamRef.current.getAudioTracks();
				if (remoteAudioTracks.length === 0) {
					remoteStreamRef.current.addTrack(event.track);
					//console.log('원격 오디오 트랙이 MediaStream에 추가되었습니다:', event.track);
				} else {
					console.warn('원격 스트림에 이미 오디오 트랙이 존재합니다:', audioTracks);
				}
			}

			//this.remoteStreamRef.addTrack(event.track);
		};
		

		const sendOfferrUrl = ApiInfo.rtnSendOffer + '/' + wrtcState.targetKey + "/" + wrtcState.targetRoomId ;
		const offerData = {
			key: GlobalData.myKey,
			body: offer, // 사용 시 검증 포인트
		};
		console.log("@@ sendOfferrUrl => ", sendOfferrUrl, offerData);
		if (stompClient.current && clientObject ) {
			stompClient.current.send(sendOfferrUrl, {}, JSON.stringify(offerData));
		}

	} catch (error) {
		console.error("@@ WebRTC 오퍼 처리 중 오류 발생:", error);
	}

}


const handleOffer = async (offer: any) => {
	try {
		//console.log("handleOffer 실행", offer);
		peerConnectionRef.current = await new RTCPeerConnection(configuration); //  new RTCPeerConnection(CONFIG);
		
		GlobalData.isPeerConnect = true
		
		// 원격 설명을 설정하기 전에 ICE 후보를 추가하면 오류 발생 -- 먼저 생성함
		await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(offer.body));
		
		setIsRemoteDescriptionSet(true);
		
		// ICE 후보 및 상태 변경 핸들러 바인딩
		peerConnectionRef.current.onicecandidate = (event) => {
			// 현재 ICE 연결 상태를 확인합니다.
			const iceConnectionState = peerConnectionRef.current?.iceConnectionState;
			// 연결 상태가 "connected" 인 경우 후보 생성 및 처리 중지
			if (iceConnectionState === 'connected') {
				console.log("접속 성공! 더 이상 후보를 처리하지 않습니다.");
				return; // 후보 처리를 중지하고 함수를 종료합니다.
			}

			if (event.candidate) {
				//console.log( "ICE 추가 " , event.candidate);
				sendIceCandidate(event.candidate);
			} else {
				// 만약 상태가 connect 가 아니면 turn서버 연결 처리함
			}
		}; 
		
		peerConnectionRef.current.oniceconnectionstatechange = onIceConnectionStateChange.bind(this);
		
		// configureAudio(); // 오디오 전화통화 부분 세팅
		
		const stream: MediaStream = await mediaDevices.getUserMedia({ audio: true, video: false });
		localStreamRef.current = stream ;
		// 미디어 스트림 가져오기 null이면 생성
		const audioTracks = localStreamRef.current.getAudioTracks();
		if (audioTracks.length > 0) {
			audioTracks.forEach((track) => {
				peerConnectionRef.current?.addTrack(track, localStreamRef.current!);
			})
		} 
		
		// 응답 생성
		const answer = await peerConnectionRef.current.createAnswer();
		
		await peerConnectionRef.current.setLocalDescription(answer);
		
		// 응답 전송
		const sendAnswerUrl = ApiInfo.rtnSendAnswer + "/" + wrtcState.targetKey + "/" + wrtcState.targetRoomId ;
		const answerData = {
			key: GlobalData.myKey,
			body: answer, // 사용 시 검증 포인트
		};
		
		stompClient.current?.send(sendAnswerUrl, {}, JSON.stringify(answerData));
		sendAllCandidate();
		
		// 원격 스트림 수신 시
		peerConnectionRef.current.ontrack = (event) => {
			console.log("@@ ontrack 호출", event );
			const remoteStream = new MediaStream();
			remoteStreamRef.current = remoteStream;
			
			// 원격 오디오 트랙 추가
			if (event.track.kind === 'audio') {
				const remoteAudioTracks = remoteStreamRef.current.getAudioTracks();
				if (remoteAudioTracks.length === 0) {
					remoteStreamRef.current.addTrack(event.track);
					//console.log('원격 오디오 트랙이 MediaStream에 추가되었습니다:', event.track);
				} else {
					console.warn('원격 스트림에 이미 오디오 트랙이 존재합니다:', audioTracks);
				}
			}

			//this.remoteStreamRef.addTrack(event.track);
		};

	
	
	} catch (error) {
		console.error("WebRTC 오퍼 처리 중 오류 발생:", error);
	}
};

const handleAnswer = (answer: any) => {
	if (!answer || !answer.body) {
		console.error('Invalid answer data:', answer);
		return;
	}
	
	peerConnectionRef.current?.setRemoteDescription(new RTCSessionDescription(answer.body))
		.then(() => {
			console.log('Remote description set successfully');
		})
		.catch(e => {
			console.error('Set Remote Description error:', e);
		});
};

const sendIceCandidate = (candidate:any) => {
	const message = {
		candidate: candidate.candidate,
		sdpMLineIndex: candidate.sdpMLineIndex, // 사용 시 검증 포인트
		sdpMid: candidate.sdpMid, // 사용 시 검증 포인트
		usernameFragment: candidate.usernameFragment
	};
	const condiData = {
		key: GlobalData.myKey,
		body: message, // 사용 시 검증 포인트
	}
	// 꼭 필요한 값이 있는지 확인하고 전송
	
	if (message.sdpMLineIndex !== null && message.sdpMid !== null) {		
		//if (this.candidate_trans == "Y") {
			stompClient.current?.send(ApiInfo.rtnSendCandidate+'/'+wrtcState.targetKey+'/'+wrtcState.targetRoomId, {}, JSON.stringify(condiData));
		// } else {
		// 	console.log("Call key 담금");
		// 	this.candidates.push(JSON.stringify(condiData));
		// }
	} else {
		console.error('ICE candidate values are invalid:', condiData);
	}
}

const sendAllCandidate = () => {
	let count = 0 ;
	candidates.forEach(candidate => {
		stompClient.current?.send(ApiInfo.rtnSendCandidate+'/'+wrtcState.targetKey+'/'+wrtcState.targetRoomId, {}, candidate);
	});
}

const onIceConnectionStateChange = () => {
	if (peerConnectionRef.current) { 
		const state = peerConnectionRef.current.iceConnectionState;
		console.log("@@ onIceConnectionStateChange 호출", state );
		if ( state === 'disconnected' || state === 'failed' || state=='closed' ) {
			disconnectWebRtc(); // 통화 종료 처리
		} else if ( state === 'connected' ) {
			GlobalData.pageInfo = 'calling'
		}
	} else {
	//	console.log("================this.peerConnectionRef==>", this.peerConnectionRef);
	}
}

const disconnectWebRtc = () => {	
	console.log("@@ disconnectWebRtc 호출", wrtcState );
	GlobalData.isPeerConnect = false ;
	wrtcState.targetKey = '';
	wrtcState.targetRoomId = '';
	wrtcState.roomId = '';
	setIsRemoteDescriptionSet(false);	
	if (peerConnectionRef) {
		for (const subscriptionId of subRtcScriptionIds) {
			stompClient.current?.unsubscribe(subscriptionId); // 구독 해제
		}
		subRtcScriptionIds = []; // 구독 ID 배열 초기화
		peerConnectionRef.current?.close();
		peerConnectionRef.current = null;
	}
	setInfoCallKey('O');
}


//FR
const sendCallOutPring =async (msgData:MessageData) => {
	
	if( msgData.serviceTypeCd !== 'Car' )  {

		if (msgData.writeMembNo === GlobalData.membNo) return;
		let isChatRoomOpen = false;

		if (msgData.mType === 'FR') {
			msgData.msgDesc = '통화중으로 통화 거절';
		} else if (msgData.mType === 'BJ') {
			msgData.msgDesc = '통화거절';
		} else if (msgData.mType == 'RC') {
			console.log('@@RC data', msgData);
			msgData.msgDesc = '통화수신';
		}
		msgData.currentDate = GetDate();
		console.log("@@call out print data 11111", msgData);
		if (msgData.mType === 'FR' ||  msgData.mType === 'BJ') {
			console.log("@@call out print data 22222", msgData);
			if (msgData.mType === 'FR') {
				msgData.writeMembNo = GlobalData.membNo;
			}
			const info = await callPost(ApiInfo.saveChatMsg, msgData) as SaveResponse;
		}
		
		 console.log("@@call out print data 3333", state.processScreen, state.currentRoomInfo.roomNo, msgData.counterPart);
		//let incrNum = true
		if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo === msgData.counterPart ) {
			//incrNum = false;
			console.log("@@call out print data 4444", msgData);
			
			global.addRoomChatMsg(msgData, true);
			isChatRoomOpen = true;
		} 

		// listRoomMessage에 데이타 존재하는지 여부 확인해서 업데이트
		// 내가 받은qr번호, 내가 받은 구독번호	해당룸의 멤버수
		const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
		console.log("@@call out print data 5555", findListMessage);
		if( findListMessage) {
			if( !findListMessage.nickNm ) {
				const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
				console.log("@@ receiveDataProcess friend", friend);
				if( friend ) {
					findListMessage.nickNm = friend.nickNm;
				}
			}
			findListMessage.msgDesc = msgData.msgDesc;
			findListMessage.notReadYn = 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
			findListMessage.addDt = GetDateDay();
			findListMessage.addTime = GetDateTime();	
			findListMessage.chatSeq = msgData.callSeq;				 
			// if (isChatRoomOpen) {
			// 	findListMessage.notReadCnt = 0 ;
			// } else {
				findListMessage.notReadCnt = findListMessage.notReadCnt ; // + 1;
			//}
			console.log("@@ receiveDataProcess findListMessage", findListMessage);
			global.updateRoomChatMessage(findListMessage);
		} else {
			//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
			const msgRoomInfoRequest = () => {
				const node = {} as MessageRoomInfoRequest
				node.serviceTypeCd=msgData.serviceTypeCd
				node.roomNo=msgData.counterPart
				return node;
			}
			const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
			if(info.hasOwnProperty('errors')) return global.showToast(info.message);
			const updateListRoomMessage:ListRoomMessage = {
				roomNo: msgData.counterPart,
				profileImgFileUrl: '',
				nickNm: '',
				msgDesc: msgData.msgDesc,
				notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				notReadCnt: 1,
				addDt: GetDateDay(),
				addTime: GetDateTime(),
				msgTypeCd: msgData.msgTypeCd,
				roomTypeCd: '',
				chatSeq: msgData.callSeq,
				msgReDesc: '',
				callStatCd: '' ,
				serviceTypeCd: msgData.serviceTypeCd,
				qrNo: msgData.roomId,  //내QR
				membNo: GlobalData.membNo,
				writeMembNo: msgData.writeMembNo,
				sendSubScr: msgData.targetRoomId,
				targetMembNo: msgData.roomId,
				mySubScr: msgData.roomId,
				roomMembCnt: 0,
			}
			if (info) {
				updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
				updateListRoomMessage.nickNm = info.roomNm;
			}
			console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
			global.addRoomMessage(updateListRoomMessage);
		}

	}
}


const receiveCallOutPring =async (msgData:MessageData) => {
	if( msgData.serviceTypeCd !== 'Car' )  {

		if (msgData.writeMembNo === GlobalData.membNo) return;
		let isChatRoomOpen = false;

		if (msgData.mType === 'RC') {   // ok
			msgData.msgDesc = '통화 호출';
		
		} else if (msgData.mType === 'FR') {
			msgData.msgDesc = '통화중으로 통화 거절';
		} else if (msgData.mType === 'BJ') {
			msgData.msgDesc = '통화거절';
		} else if (msgData.mType == 'RC') {
			console.log('@@RC data', msgData);
			msgData.msgDesc = '통화 수신';
		}
		msgData.currentDate = GetDate();
		console.log("@@call out print data 11111", msgData);
		
		 console.log("@@call out print data 3333", state.processScreen, state.currentRoomInfo.roomNo, msgData.counterPart);
		//let incrNum = true
		if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo === msgData.counterPart ) {
			//incrNum = false;
			console.log("@@call out print data 4444", msgData);
			
			global.addRoomChatMsg(msgData, false);
			isChatRoomOpen = true;
		} 

		// listRoomMessage에 데이타 존재하는지 여부 확인해서 업데이트
		// 내가 받은qr번호, 내가 받은 구독번호	해당룸의 멤버수
		const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
		console.log("@@call out print data 5555", findListMessage);
		if( findListMessage) {
			if( !findListMessage.nickNm ) {
				const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
				console.log("@@ receiveDataProcess friend", friend);
				if( friend ) {
					findListMessage.nickNm = friend.nickNm;
				}
			}
			findListMessage.msgDesc = msgData.msgDesc;
			findListMessage.notReadYn = 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
			findListMessage.addDt = GetDateDay();
			findListMessage.addTime = GetDateTime();	
			findListMessage.chatSeq = msgData.callSeq;				 
			// if (isChatRoomOpen) {
			// 	findListMessage.notReadCnt = 0 ;
			// } else {
				findListMessage.notReadCnt = findListMessage.notReadCnt ; // + 1;
			//}
			console.log("@@ receiveDataProcess findListMessage", findListMessage);
			global.updateRoomChatMessage(findListMessage);
		} else {
			//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
			const msgRoomInfoRequest = () => {
				const node = {} as MessageRoomInfoRequest
				node.serviceTypeCd=msgData.serviceTypeCd
				node.roomNo=msgData.counterPart
				return node;
			}
			const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
			if(info.hasOwnProperty('errors')) return global.showToast(info.message);
			const updateListRoomMessage:ListRoomMessage = {
				roomNo: msgData.counterPart,
				profileImgFileUrl: '',
				nickNm: '',
				msgDesc: msgData.msgDesc,
				notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				notReadCnt: 1,
				addDt: GetDateDay(),
				addTime: GetDateTime(),
				msgTypeCd: msgData.msgTypeCd,
				roomTypeCd: '',
				chatSeq: msgData.callSeq,
				msgReDesc: '',
				callStatCd: '' ,
				serviceTypeCd: msgData.serviceTypeCd,
				qrNo: msgData.roomId,  //내QR
				membNo: GlobalData.membNo,
				writeMembNo: msgData.writeMembNo,
				sendSubScr: msgData.targetRoomId,
				targetMembNo: msgData.roomId,
				mySubScr: msgData.roomId,
				roomMembCnt: 0,
			}
			if (info) {
				updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
				updateListRoomMessage.nickNm = info.roomNm;
			}
			console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
			global.addRoomMessage(updateListRoomMessage);
		}

	}
}

/////////////////////////////////////////////////////////////////////webRTC 

/* 퍼미션 체크 시점은 따로 함
	const requestLocationPermission = async () => {
		try {
		  if (Platform.OS === 'android') {
			const granted = await PermissionsAndroid.request(
			  PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
			);
			if (granted === PermissionsAndroid.RESULTS.GRANTED) {
			  console.log('Location permission granted');
			} else {
			  console.log('Location permission denied');
			}
		  } else {
			const result = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
			if (result === RESULTS.GRANTED) {
			  console.log('Location permission granted');
			} else {
			  console.log('Location permission denied');
			}
		  }
		} catch (err) {
		  console.warn(err);
		}
	  };
*/
  return (
    <SocketStompContext.Provider value={{
	  connect,
	  disconnect,
      isconnected,
	  reconnect,
      sendMessage,
	  sendLocMessage,
	  sendReadMessage,
	  subscribeToWebRTC,
	  disconnectWebRtc,
	  sendCallKey,
	  sendSendKey,
	  startLocationUpdates,
	  stopLocationUpdates,
	  sendAddFriendMessage,
	  receiveDataProcess,
    }}>
      {children}
    </SocketStompContext.Provider>
  );
};