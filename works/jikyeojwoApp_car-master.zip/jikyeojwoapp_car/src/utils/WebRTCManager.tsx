import { RTCPeerConnection, RTCSessionDescription, mediaDevices, MediaStream,  RTCIceCandidate } from 'react-native-webrtc';
import Stomp, { Client } from 'stompjs';
import ApiInfo from '../gvar/ApiInfo';
import { GlobalData } from '../store/global';


class WebRTCManager {

	private peerConnectionRef: RTCPeerConnection | null = null;
	private client: Client ; 
	private roomId: string; // 방 ID
	private callKey: string; // 내 키
	private localStreamRef: MediaStream | null = null;
	private remoteStreamRef: MediaStream | null = null;
	private audioSoundType: boolean = false;  // false 전화통화 true 스피커폰 
	private isRemoteDescriptionSet: boolean = false;
	
	private subRtcScriptionIds: string[] = []; // 구독 ID를 저장하는 배열

	private candidates: string[] = [] ; // candidate 전송할 데이타 모음
	
	


	public configuration = {
		iceServers: [
			{ urls: "stun:turn.kosk.co.kr:3478" },
			{ urls: "stun:stun.l.google.com:19302" },
            { urls: "stun:stun1.l.google.com:19302" },
            { urls: "stun:stun.services.mozilla.com" },
			{
                urls: 'turn:kosk.co.kr:3478?transport=udp',
                username: 'kosk',
                credential: 'kosk1234!@',
            },
			{
                urls: 'turn:kosk.co.kr:3478?transport=tcp',
                username: 'kosk',
                credential: 'kosk1234!@',
            }   
	   ]
	   
	}


	constructor(client: Client,  roomId: string, callKey: string) {
		this.client = client ;
		this.roomId = roomId;
		this.callKey = callKey;
		this.subscribeToWebRTC();
		
	}    

	



	// 마이크 권한 요청
	public requestAudioPermission = async () => {
		
	};

	public subscribeToWebRTC() {

		////=>dwkim  통화연결 시작시 통화 연결 진행 중 입니다.
		
		const rtnSubscribeCandidateId = this.client!.subscribe(`${ApiInfo.rtnSubscribeCandidate}/${GlobalData.myKey}/${this.roomId}`, (message) => {
			//console.log("subscribeToWebRTC  생성 - rtnSubscribeCandidate 전송받음");
			const candidateData  = JSON.parse(message.body);
			const { candidate, sdpMLineIndex, sdpMid } = candidateData.body;
			
			if (sdpMLineIndex === null || sdpMid === null ) {
			//	console.error('sdpMLineIndex or sdpMid is null:', { sdpMLineIndex, sdpMid });
				return; // 여기서 반환하여 ICE 후보 추가를 중단
			}
			
			if (sdpMLineIndex === undefined  || sdpMid === undefined ) {
			//	console.error('sdpMLineIndex or sdpMid is undefined:', candidateData.body);
				return; // 여기서 반환하여 ICE 후보 추가를 중단
			}
			const iceCandidate = new RTCIceCandidate({
				candidate: candidate,
				sdpMLineIndex: sdpMLineIndex, // 이 값이 null이 아니어야 합니다.
				sdpMid: sdpMid               // 이 값이 null이 아니어야 합니다.
			});
			
			if (typeof iceCandidate.sdpMLineIndex === 'number' && typeof iceCandidate.sdpMid === 'string') {
				// ICE 후보 추가
			//	console.log("ICE 후보 추가" , this.isRemoteDescriptionSet);
				if (this.peerConnectionRef  ) { // 수정된 부분
				//	if (this.isRemoteDescriptionSet) {
						this.peerConnectionRef?.addIceCandidate(iceCandidate)
									.then(() => {
									//	console.log('ICE후보 등록 완료 ==> ICE Candidate added successfully');
									})
									.catch(e => {
									//	console.error('ICE후보 등록 오류 ==> Error adding ICE candidate:', e);
									});
								}
							}

			// } else {
			// 	console.error('Invalid ICE candidate values:', iceCandidate);
			// }
			

		}).id; // 구독 ID 저장
		//console.log("subscribeToWebRTC  생성 - rtnSubscribeCandidate 구독처리");
		this.subRtcScriptionIds.push(rtnSubscribeCandidateId); 

		
		const rtnSubscribeOfferId = this.client!.subscribe(`${ApiInfo.rtnSubscribeOffer}/${GlobalData.myKey}/${this.roomId}`, (message) => {
			//console.log("Offer 구독 받음");
			const offer = JSON.parse(message.body);
			this.handleOffer(offer);
		}).id; // 구독 ID 저장
		//console.log("Offer 구독 처리");
		this.subRtcScriptionIds.push(rtnSubscribeOfferId); 
		
		const rtnSubscribeAnswerId = this.client!.subscribe(`${ApiInfo.rtnSubscribeAnswer}/${GlobalData.myKey}/${this.roomId}`, (message) => {
			//console.log("Answer 구독 받음");
			const answer = JSON.parse(message.body);
			this.handleAnswer(answer);
		}).id; // 구독 ID 저장
		//console.log("Answer 구독 처리");
		this.subRtcScriptionIds.push(rtnSubscribeAnswerId); 

	}

	
	public handleOffer = async (offer: any) => {
		try {
			//console.log("handleOffer 실행", offer);
			const self = this
			this.peerConnectionRef = await new RTCPeerConnection(this.configuration); //  new RTCPeerConnection(CONFIG);
			
			GlobalData.isPeerConnect = true
			
			// 원격 설명을 설정하기 전에 ICE 후보를 추가하면 오류 발생 -- 먼저 생성함
			await this.peerConnectionRef.setRemoteDescription(new RTCSessionDescription(offer.body));
			
			

			this.isRemoteDescriptionSet = true;
			
			// ICE 후보 및 상태 변경 핸들러 바인딩
			this.peerConnectionRef.onicecandidate = (event) => {

				// 현재 ICE 연결 상태를 확인합니다.
				const iceConnectionState = this.peerConnectionRef?.iceConnectionState;
				// 연결 상태가 "connected" 인 경우 후보 생성 및 처리 중지
				if (iceConnectionState === 'connected') {
					//console.log("접속 성공! 더 이상 후보를 처리하지 않습니다.");
					return; // 후보 처리를 중지하고 함수를 종료합니다.
				}

				if (event.candidate) {
					//console.log( "ICE 추가 " , event.candidate);
					self.sendIceCandidate(event.candidate);
				} else {
					// 만약 상태가 connect 가 아니면 turn서버 연결 처리함
				}
			}; 


			
			this.peerConnectionRef.oniceconnectionstatechange = this.onIceConnectionStateChange.bind(this);
			
			


			// configureAudio(); // 오디오 전화통화 부분 세팅
		    
			const stream: MediaStream = await mediaDevices.getUserMedia({ audio: true, video: false });
			this.localStreamRef = stream ;
			// 미디어 스트림 가져오기 null이면 생성
			const audioTracks = this.localStreamRef.getAudioTracks();
			if (audioTracks.length > 0) {
				audioTracks.forEach((track) => {
					this.peerConnectionRef?.addTrack(track, this.localStreamRef!);
				})
			} 
			
			// 응답 생성
			const answer = await this.peerConnectionRef.createAnswer();
			
			await this.peerConnectionRef.setLocalDescription(answer);
			
			// 응답 전송
			const sendAnswerUrl = ApiInfo.rtnSendAnswer + "/" + this.callKey + "/" + this.roomId ;
			const answerData = {
				key: GlobalData.myKey,
				body: answer, // 사용 시 검증 포인트
			};
			
			this.client.send(sendAnswerUrl, {}, JSON.stringify(answerData));

			this.sendAllCandidate();
			
			// 원격 스트림 수신 시
			this.peerConnectionRef.ontrack = (event) => {
			
				if (!self.remoteStreamRef) {
					self.remoteStreamRef = new MediaStream();
				}
			
				// 원격 오디오 트랙 추가
				if (event.track.kind === 'audio') {
					const remoteAudioTracks = self.remoteStreamRef.getAudioTracks();
					if (remoteAudioTracks.length === 0) {
						self.remoteStreamRef.addTrack(event.track);
						//console.log('원격 오디오 트랙이 MediaStream에 추가되었습니다:', event.track);
					} else {
						console.warn('원격 스트림에 이미 오디오 트랙이 존재합니다:', audioTracks);
					}
				}

				//this.remoteStreamRef.addTrack(event.track);
			};

		
		
		} catch (error) {
			console.error("WebRTC 오퍼 처리 중 오류 발생:", error);
		}
	};

	
	public handleAnswer = (answer: any) => {
		this.peerConnectionRef!.setRemoteDescription(new RTCSessionDescription(answer))
		.catch(e => console.error('Set Remote Description error:', e));
	};

	public sendIceCandidate(candidate:any) {
		const message = {
			candidate: candidate.candidate,
			sdpMLineIndex: candidate.sdpMLineIndex, // 사용 시 검증 포인트
			sdpMid: candidate.sdpMid, // 사용 시 검증 포인트
			usernameFragment: candidate.usernameFragment
		};
		const condiData = {
			key: GlobalData.myKey,
			body: message, // 사용 시 검증 포인트
		}
		// 꼭 필요한 값이 있는지 확인하고 전송
		if (message.sdpMLineIndex !== null && message.sdpMid !== null) {

			
			//if (this.candidate_trans == "Y") {
				this.client.send(`${ApiInfo.rtnSendCandidate}/${this.callKey}/${this.roomId}`, {}, JSON.stringify(condiData));
			// } else {
			// 	console.log("Call key 담금");
			// 	this.candidates.push(JSON.stringify(condiData));
			// }
		} else {
			console.error('ICE candidate values are invalid:', condiData);
		}
	}

	public sendAllCandidate() {
		let count = 0 ;
		this.candidates.forEach(candidate => {
			this.client.send(`${ApiInfo.rtnSendCandidate}/${this.callKey}/${this.roomId}`, {}, candidate);
		});
	}

	public onIceConnectionStateChange() {
		if (this.peerConnectionRef) { 
			const state = this.peerConnectionRef.iceConnectionState;
			if ( state === 'disconnected' || state === 'failed' || state=='closed' ) {
				this.disconnect(); // 통화 종료 처리
			} else if ( state === 'connected' ) {
				GlobalData.webRtcStatus = 'calling'
			}
		} else {
		//	console.log("================this.peerConnectionRef==>", this.peerConnectionRef);
		}
	}

	public disconnect() {
		
		GlobalData.isPeerConnect = false ;
		this.isRemoteDescriptionSet = false;
		
		
		if (this.peerConnectionRef) {
			for (const subscriptionId of this.subRtcScriptionIds) {
				this.client.unsubscribe(subscriptionId); // 구독 해제
			}
			this.subRtcScriptionIds = []; // 구독 ID 배열 초기화
			this.peerConnectionRef.close();
			this.peerConnectionRef = null;
		}
	}

	public getRemoteStream() {
		return this.remoteStreamRef; // 원격 스트림 반환
	}

}

export default WebRTCManager;