import React, { useEffect, useRef, useState } from 'react';
import { View, FlatList, Image, Text, StyleSheet, Dimensions, TouchableOpacity, Animated, Modal, NativeSyntheticEvent, NativeScrollEvent, StatusBar, BackHandler, ToastAndroid} from 'react-native';
import { apiCallGet,apiCallPost, GlobalData, GetDate } from '../../store/global';
import ApiInfo from '../../gvar/ApiInfo';
import {  ApiTutorialImages, ApiImageFields, ApiCasInfo, ApiCasFields, RootStackParamList, ApiCreateSg, ApiCasReg , ApiCreateSgRes, TutorialProps } from '../../types/common';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import CasInfoPop from '../../components/CasInfoPop';
import { SafeAreaView } from 'react-native-safe-area-context';



const { width, height } = Dimensions.get('window');
//TutorialProps
//const TutorialScreen = () => {  
const TutorialScreen: React.FC<TutorialProps> = ({ callChangeStack }) => {

  const [tutorialImagInfoList, setTutorialImagInfoList] = useState<ApiImageFields[]>([]); 
  const [casInfoList, setCasInfoList] = useState<ApiCasFields[]>([]); 
  const [activeIndex, setActiveIndex] = useState(0);
  const flatListRef = useRef<FlatList<any>>(null); // FlatList에 대한 참조 설정
  const [showTerms, setShowTerms] = useState(false); //약관보기
  const [showCasDetail, setShowCasDetail] = useState(false); //약관상세보기
  const [casDetail, setCasDetail] = useState<ApiCasFields>();  //약관상세내역
  const slideAnim = useRef(new Animated.Value(-height / 2)).current; // 슬라이드 애니메이션 초기화

  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
 
 
  useEffect(() => {
    const fetchImages = async () => {
      try {
        apiCallGet(ApiInfo.get_tutorial,{langCd:'KO'}, (type:string, obj:object)=>{
          if(type=='ok') {
              var info=obj as ApiTutorialImages ;
              console.log("tutor==>", info.tutoDataList);
              const sortedData = info.tutoDataList.sort((a, b) => a.viewNum - b.viewNum); // viewNum으로 정렬
              setTutorialImagInfoList(sortedData)  ;
              // 첫 번째로 표시할 인덱스를 viewNum이 가장 작은 이미지로 설정
              const initialIndex = 0 ; //sortedData.findIndex(image => image.viewNum === Math.min(...sortedData.map(img => img.viewNum)));
              setActiveIndex(initialIndex); 
              flatListRef.current?.scrollToIndex({ index: initialIndex }); // 초기 인덱스 스크롤
              console.log("Initial viewNum:", sortedData[initialIndex].viewNum); // 초기 viewNum 출력
          } else {
              //튜토리얼 오류
          }    
      }) 
      } catch (error) {
        console.error(error);
      }
    };

   

    const fetchCas = async () => {
      try {
        apiCallGet(ApiInfo.get_cas,{casTyCd:'A',langCd:'KR'}, (type:string, obj:object) => {
          console.log("cas=type=>" , type );
          if( type=='ok' ) {
            var info=obj as ApiCasInfo
            for(const row of info.casMngDataList) row.agreeYn=false
            const casSortedData = info.casMngDataList.sort((a, b) => a.viewNum - b.viewNum); // viewNum으로 정렬
            setCasInfoList(casSortedData)  ;
            console.log("cas==>" , info.casMngDataList, casInfoList );
          }

        }) 

      } catch (error) {
        console.error(error);
      }
    };
    fetchImages();
    fetchCas();

  }, []);



  const showCas = (index: number) => {
    console.log("show terms valeu=>" , showTerms);
    if (index < tutorialImagInfoList.length-1) {
      if (showTerms) {
        console.log("pre true", index);
        setShowTerms(false);
        slideOut(); // 그 외 경우 슬라이드 아웃
      }
    } else {
      if (!showTerms) {
        console.log("pre false", tutorialImagInfoList.length);
        setShowTerms(true);
        slideIn(); // 슬라이드 인 애니메이션
      }
    }
  }
    

  const handleMomentumScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const index = Math.round(scrollPosition / width);

    if (index !== activeIndex && index < tutorialImagInfoList.length) { // 인덱스가 변경된 경우
      setActiveIndex(index);
    }
     showCas(index) ;
    
  };

  const handlePressRight = () => {
     
     if (flatListRef.current && activeIndex < tutorialImagInfoList.length - 1) {
       const nextIndex = activeIndex + 1;
       flatListRef.current.scrollToIndex({ index: nextIndex });
       setActiveIndex(nextIndex); // 인덱스 업데이트
       console.log("change index => ", nextIndex);

       showCas(nextIndex) ;
     }
  };

 

  const handlePressLeft = () => {
    if (flatListRef.current && activeIndex > 0) {
      const prevIndex = activeIndex - 1;
      flatListRef.current.scrollToIndex({ index: prevIndex });
      setActiveIndex(prevIndex); // 인덱스 업데이트
       console.log("change index => ", prevIndex);
       showCas(prevIndex) ;
    }
  };

  const slideIn = () => {
    Animated.timing(slideAnim, {
      toValue: 0, // 화면의 절반 높이로 슬라이드
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  const slideOut = () => {
    Animated.timing(slideAnim, {
      toValue: -height / 2, // 화면 아래로 슬라이드
      duration: 300,
      useNativeDriver: false,
    }).start();
  };

  // 약관상세정보 가져와서 상세팝업 뛰우기
  const viewCasDesc = (selCasData: ApiCasFields) => {
      //setCasDetail(selCasData) ;
      console.log("viewCasDesc====>" , selCasData, "=", selCasData); 
      //navigation.navigate('CasDesc', { data : selCasData }); 
  }


  useEffect(() => {
    //console.log("viewCasDesc1111==>", casDetail);
    setShowCasDetail(true);
}, [casDetail]); 

  //전문 상세팝업 닫기
  const onPopClose = () => {
    setShowCasDetail(false);
  }

  //약관동의 후 시작하기 클릭시 이벤트 받음  
  const goStart = (agreeCasList: ApiCasFields[]) => {
    console.log("Start button pressed.", agreeCasList);
    // 가입저장하기 처리
    slideOut(); // 팝업 닫기
    setShowTerms(false); // 팝업 상태 업데이트
    navigation.navigate("RegConnectInfo", {casList: agreeCasList });
    
    
  };


  const renderItem = ({ item } : {item: ApiImageFields}) => (
    <Image source={{ uri: item.filePath }} style={styles.image} /> // filePath 사용
  );

  const handleScroll = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
    // 필요없을듯 
  };

  return (

      <React.Fragment>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
      />
      <SafeAreaView style={{flex:1, backgroundColor: '#fff', }}>
    <View style={styles.container}>
      <FlatList
        ref={flatListRef}
        data={tutorialImagInfoList}
        renderItem={renderItem}
        keyExtractor={(item, index) => index.toString()}
        horizontal
        removeClippedSubviews={false}
        pagingEnabled={true}
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        onMomentumScrollEnd={handleMomentumScrollEnd} // 스크롤이 끝날 때 인덱스 업데이트
        scrollEventThrottle={16}
      />

      <View style={styles.navigationContainer}>

        { <View>
            <TouchableOpacity onPress={handlePressLeft} style={[styles.navButton, { display: activeIndex > 0 ? 'flex' : 'none' }]}>
            <Image 
              source={require('../../assets/ic_pager_prev.png')} // 왼쪽 네비게이션 이미지
              style={styles.navImage} 
            />
          </TouchableOpacity>  
          </View>}

        { activeIndex < tutorialImagInfoList.length - 1 && <TouchableOpacity onPress={handlePressRight} style={styles.navButton}>
        <Image 
            source={require('../../assets/ic_pager_next.png')} // 오른쪽 네비게이션 이미지
            style={styles.navImage} 
          />
        </TouchableOpacity> }
      </View> 
      <View style={styles.dotsContainer}>
        {tutorialImagInfoList.map((_, index) => (
          <View
            key={index}
            style={[
              styles.dot,
              { backgroundColor: index === activeIndex ? '#FF851D' : 'lightgrey' }
            ]}
          />
        ))}
      </View>



      {/* CasInfoPop 팝업 컴포넌트 */ }
      {showTerms && <CasInfoPop data={{ casInfoList}} slideAnim={slideAnim}  goStart={goStart} viewCasDesc={viewCasDesc}/> }
      
      

    </View>
    </SafeAreaView>
    </React.Fragment>
  );
};



const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  navigationContainer: {
    position: 'absolute',
    width: width,
    height: height,
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    
  },
  navButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    padding: 5,
    borderRadius: 5,
    top:'-7%'
    
  },
  navText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  image: {
    width: width,
    height: height, // 화면에 꽉 차도록 설정
    resizeMode: 'contain',
  },
  dotsContainer: {
    position: 'absolute',
    bottom: 20,
    flexDirection: 'row',
  },
  dot: {
    width: 15,
    height: 15,
    borderRadius: 8,
    margin: 5,

  },
  navImage: {
    width: 38, // 이미지의 너비를 설정합니다.
    height: 45, // 이미지의 높이를 설정합니다.
  },
});

export default TutorialScreen;

function closeApp() {
  throw new Error('Function not implemented.');
}
