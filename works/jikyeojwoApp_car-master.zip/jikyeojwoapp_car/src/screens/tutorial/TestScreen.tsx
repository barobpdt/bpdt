import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';

const TestScreen: React.FC = () => {
  return (
    <View style={styles.container}>
     <Text>sdfsdfsdfs</Text>
     </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  image: {
    width: 200,
    height: 200,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
  },
});

export default TestScreen;