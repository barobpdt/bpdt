import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  SafeAreaView,
  FlatList,
  Alert,
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { ListMyQr, RootStackParamList, ServiceQrBoxProps } from '../../types/common';
import { GlobalData } from '../../store/global';
import RNFS from 'react-native-fs';
import RNFetchBlob from 'react-native-blob-util';
import Share from 'react-native-share';

const QRListScreen = (props: ServiceQrBoxProps) => {
    const [isCarRemoveOn, setIsCarRemoveOn] = useState(false);
    const [isProtectOn, setIsProtectOn] = useState(false);
    const [isListVisible, setIsListVisible] = useState(true);  
    const [selectedQrNo, setSelectedQrNo] = useState('');  // 선택한 QR이미지 정보
    const maxTextLength = 4 ;  
    const [addQRimageSource, setAddQRImageSource] = useState(require('../../assets/addQR.png'));
    const serviceTypeCd = props.serviceCd;
    const dummyQrList: ListMyQr[] = [
        {
          qrNo: "QR001",
          nickNm: "홍길동",
          carInfo: "아반떼 2021",
          makerCar: "현대",
          subScr: "Y",
          parkText: "지하 1층 A-15",
          introductionInfo: "연락주세요 :)",
          serviceTypeCd: "01",
          qrFileNo: "FILE001",
          qrInfo: "../../assets/qr.png"
        },
        {
          qrNo: "QR002",
          nickNm: "김영희",
          carInfo: "K5 2022",
          makerCar: "기아",
          subScr: "N",
          parkText: "지상 2층 B-07",
          introductionInfo: "잠시 주차했습니다.",
          serviceTypeCd: "02",
          qrFileNo: "FILE002",
          qrInfo: "https://example.com/qr2"
        },
        {
          qrNo: "QR003",
          nickNm: "박철수",
          carInfo: "모닝 2020",
          makerCar: "기아",
          subScr: "Y",
          parkText: "지하 2층 C-03",
          introductionInfo: "금방 나갑니다!",
          serviceTypeCd: "01",
          qrFileNo: "FILE003",
          qrInfo: "https://example.com/qr3"
        },
        {
          qrNo: "QR004",
          nickNm: "이지은",
          carInfo: "쏘렌토 2023",
          makerCar: "기아",
          subScr: "N",
          parkText: "옥상층 R-01",
          introductionInfo: "연락 부탁드려요~",
          serviceTypeCd: "03",
          qrFileNo: "FILE004",
          qrInfo: "https://example.com/qr4"
        },
        {
          qrNo: "QR005",
          nickNm: "최민수",
          carInfo: "그랜저 2019",
          makerCar: "현대",
          subScr: "Y",
          parkText: "지상 1층 D-20",
          introductionInfo: "긴급 시 전화 주세요.",
          serviceTypeCd: "01",
          qrFileNo: "FILE005",
          qrInfo: "https://example.com/qr5"
        }
      ];

  const [qrImgInfo, setQrImgInfo] = useState<ListMyQr[]>([]);  // 메세지 내용
    const [carRemoveData, setCarRemoveData] = useState([
    { id: '1', name: '차량 1' },
    { id: '2', name: '차량 2' },
  ]);
  const [protectData, setProtectData] = useState([
    { id: '1', name: '보호 대상 1' },
    { id: '2', name: '보호 대상 2' },
  ]);
  const handleAddQR = () => {
    //부모에 QR추가 이벤트 전달함
    props.onAddQR(serviceTypeCd);
  };


  const handleBack = () => {
    navigation.goBack();
  };

  const handleGoHome = () => {
    navigation.navigate('MainHome');
  };

  const handleToggleCarRemove = () => setIsCarRemoveOn(!isCarRemoveOn);
  const handleToggleProtect = () => setIsProtectOn(!isProtectOn);
  const handleOpenModal = (qrNo:string, serviceTypeCd:string) => {
    //setSelQrInfo(qrInfo);
   // setModalVisible(true);  //goToQrDataChange
  // 부모창에 QR 정보 전달
    setSelectedQrNo(qrNo); // 클릭한 이미지의 인덱스로 상태 업데이트  
    props.onQrDataSearch(qrNo, serviceTypeCd) ;

  };
    const goToDownload = (qrNo:string , qrInfo:string ) => {
      Alert.alert(
        'QR 이미지',
        '다운로드를 하시겠습니까?',
        [
          {
            text: '취소',
            style: 'cancel',
          },
          { text: '다운로드', onPress: () => downloadImage(qrNo, qrInfo) }, // OK 버튼 클릭 시 downloadImage 호출
        ],
        { cancelable: false }
      );
     };
     
        const downloadImage = async (qrNo:string, qrInfo:string) => {
         console.log("downloadImage==>", qrNo, qrInfo);
         // 다운로드할 파일의 경로
         if (GlobalData.deviTpCd === 'SA') {
           androidDownloadImage(qrNo, qrInfo);
         } else {
           iosDownloadImage(qrNo, qrInfo) ;
         }
       };

  // ios qr다운로드
  const iosDownloadImage = async (qrNo:string, qrInfo:string) => {
    const fileName = qrInfo.split('/').pop(); // 파일 이름 추출
    const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}`; // 다운로드 경로

    try {
        // 이미지 다운로드
        const res = await RNFS.downloadFile({
            fromUrl: qrInfo,
            toFile: filePath,
            background: true,
        }).promise;

        if (res.statusCode === 200) {
            // 공유
            await Share.open({
                url: `file://${filePath}`, // 'file://' 접두사를 추가하여 파일을 Sharing
                type: 'image/jpeg', // 이미지 파일 타입
            });

            Alert.alert('성공', '이미지가 공유되었습니다.');
        } else {
            Alert.alert('다운로드 실패', `상태 코드: ${res.statusCode}`);
        }
    } catch (error) {
        console.error('파일 다운로드 중 오류 발생:', error);
        Alert.alert('다운로드 오류', '파일을 다운로드하는 동안 오류가 발생했습니다.');
    }
};
  const androidDownloadImage = async (qrNo:string, qrInfo:string) => {
    const { config, fs } = RNFetchBlob;
    let PictureDir = fs.dirs.DownloadDir; 
    let filePath = PictureDir + '/' + qrNo + '.png';
    
    return config({
      fileCache: true,
      addAndroidDownloads: {
        useDownloadManager: true, // Uses the Android native download manager
        notification: true,
        path: filePath,
        description: 'Image',
      },
    })
      .fetch('GET', qrInfo)
      .then(res => {
        console.log('The file saved to ', res.path());
      })
      .catch((error) => {
        console.error('Download error', error);
      });
    
  };


  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();

  const renderItem = ({ item }: { item: { name: string } }) => (
    <View style={styles.itemContainer}>
      <Text style={styles.itemText}>{item.name}</Text>
    </View>
  ); 

    function alert(arg0: string): void {
        throw new Error('Function not implemented.');
    }

  return (
    <SafeAreaView style={styles.bottomContainer}>
      <View style={styles.mainContent}>
        {/* 상단바 */}
        <View style={styles.headerContainer}>
          <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
            <Image
              source={require('../../assets/ic_arr_left.png')}
              style={styles.prevIcon}
            />
          </TouchableOpacity>

          <View style={styles.titleContainer}>
            <Text style={styles.titleText}>검색</Text>
          </View>

          <TouchableOpacity style={styles.homeButton} onPress={handleGoHome}>
            <Image
              source={require('../../assets/ic_home_copy.png')}
              style={styles.homeIcon}
            />
          </TouchableOpacity>
        </View>

        {/* 차빼줘 영역 */}
        <View style={[styles.sectionContainer, {marginTop: 20, borderBottomColor:'#edeeee', borderBottomWidth:1, }]}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>차빼줘</Text>
            <TouchableOpacity onPress={handleToggleCarRemove}>
              <Image
                source={isCarRemoveOn
                  ? require('../../assets/ic_arrow_top.png')  // "ON" 상태 이미지
                  : require('../../assets/ic_arrow_bottom.png') // "OFF" 상태 이미지
                }
                style={styles.switchImage}
              />
            </TouchableOpacity>
          </View>
            { isCarRemoveOn &&
            <View style={styles.qrList_box}>
              <FlatList
                showsVerticalScrollIndicator={false}
                removeClippedSubviews={false}
                data={dummyQrList}  // 더미 데이터 사용
                extraData={selectedQrNo}  // 상태 변화에 따른 재렌더링
                renderItem={({ item }) => (
                    <View style={[styles.flat_qr_nonSelbg, selectedQrNo === item.qrNo && styles.flat_qr_selbg]}>
                    <TouchableOpacity style={styles.qr_contener} onPress={() => handleOpenModal(item.qrNo, item.serviceTypeCd)}>
                        <View>
                        <Image
                            //source={{ uri: item.qrInfo }}
                            //style={[styles.qrNonSelImg, selectedQrNo === item.qrNo && styles.qrSelImg]}   
                            source={require('../../assets/qr.png')}
                            style={[styles.qrNonSelImg]}   
                        />
                        </View>
                    </TouchableOpacity>
                    <View style={styles.container_row}>
                        <Text style={{ marginTop: 5, marginBottom: 5, fontSize: 10 }} numberOfLines={1}>
                        {item.nickNm.length > maxTextLength ? item.nickNm.substring(0, maxTextLength) + '...' : item.nickNm}
                        </Text>
                        <TouchableOpacity style={styles.qr_contener} onPress={() => goToDownload(item.qrNo, item.qrInfo)}>
                        <View>
                            <Image
                            source={require('../../assets/ic_download.png')}
                            style={styles.down_image}
                            />
                        </View>
                        </TouchableOpacity>
                    </View>
                    </View>
                )}
                keyExtractor={item => item.qrNo.toString()}
                horizontal={true} // 가로 방향으로 나열
                contentContainerStyle={styles.flat_container} // 아이템의 간격을 포함할 수 있는 스타일
                />
              {/*<View style={styles.flat_view}>
                      <TouchableOpacity style={styles.qr_contener} onPress={() => handleAddQR()}>
                        <View>
                          <Image
                            source={addQRimageSource}
                            style={{ width: 50, height: 50, borderRadius: 30 }}
                          />
                        </View>
                      </TouchableOpacity>
              </View>*/}
            </View>
          }
        </View>

        {/* 지켜줘 영역 */}
        <View style={styles.sectionContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>지켜줘</Text>
            <TouchableOpacity onPress={handleToggleProtect}>
              <Image
                source={isProtectOn
                  ? require('../../assets/ic_arrow_top.png')  // "ON" 상태 이미지
                  : require('../../assets/ic_arrow_bottom.png') // "OFF" 상태 이미지
                }
                style={styles.switchImage}
              />
            </TouchableOpacity>
          </View>
          {isProtectOn && (
            <View style={styles.qrList_box}>
                <FlatList
                showsVerticalScrollIndicator={false}
                removeClippedSubviews={false}
                data={dummyQrList}  // 더미 데이터 사용
                extraData={selectedQrNo}  // 상태 변화에 따른 재렌더링
                renderItem={({ item }) => (
                    <View style={[styles.flat_qr_nonSelbg, selectedQrNo === item.qrNo && styles.flat_qr_selbg]}>
                    <TouchableOpacity style={styles.qr_contener} onPress={() => handleOpenModal(item.qrNo, item.serviceTypeCd)}>
                        <View>
                        <Image
                            //source={{ uri: item.qrInfo }}
                            //style={[styles.qrNonSelImg, selectedQrNo === item.qrNo && styles.qrSelImg]}   
                            source={require('../../assets/qr.png')}
                            style={[styles.qrNonSelImg]}   
                        />
                        </View>
                    </TouchableOpacity>
                    <View style={styles.container_row}>
                        <Text style={{ marginTop: 5, marginBottom: 5, fontSize: 10 }} numberOfLines={1}>
                        {item.nickNm.length > maxTextLength ? item.nickNm.substring(0, maxTextLength) + '...' : item.nickNm}
                        </Text>
                        <TouchableOpacity style={styles.qr_contener} onPress={() => goToDownload(item.qrNo, item.qrInfo)}>
                        <View>
                            <Image
                            source={require('../../assets/ic_download.png')}
                            style={styles.down_image}
                            />
                        </View>
                        </TouchableOpacity>
                    </View>
                    </View>
                )}
                keyExtractor={item => item.qrNo.toString()}
                horizontal={true} // 가로 방향으로 나열
                contentContainerStyle={styles.flat_container} // 아이템의 간격을 포함할 수 있는 스타일
                />
            </View>
          )}
        </View>
      </View>

      {/* QR 등록 버튼 */}
      <View style={styles.qrButtonContainer}>
        <TouchableOpacity style={styles.qrButton} onPress={() => alert('QR 등록')}>
          <Text style={styles.qrButtonText}>QR등록</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
  },
  mainContent: {
    flex: 1,
    paddingBottom: 80, // QR 버튼을 위해 여백 추가
  },
  headerContainer: {
    height: 60,
    backgroundColor: '#fff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  sectionContainer: {
    paddingHorizontal: 16,
    backgroundColor: '#fff',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FF851D',
  },
  flatListContainer: {
  },
  ListContainer:{
    paddingVertical: 10,
    marginVertical:10,
    backgroundColor: '#f4f4f4',
    borderRadius: 8,},
  itemContainer: {
    marginRight: 16,
    padding: 12,
    marginHorizontal:5,
  },
  itemText: {
    fontSize: 14,
    color: '#333',
  },
  qrButtonContainer: {
    position: 'absolute',
    bottom: 0,
    width: '100%',
    paddingHorizontal: 16,
    paddingBottom: 20,
  },
  qrButton: {
    backgroundColor: '#FF851D',
    borderRadius: 8,
    paddingVertical: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  qrButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  switchImage: {
    width: 40,
    height: 24,
    resizeMode: 'contain',
  },
  qrList_box: {
    width: '94%',
    alignItems: 'center',
    padding: 10,
    flexDirection: 'row',
    backgroundColor: '#f4f4f4',
    borderRadius:8,
    marginBottom:10,
  },
  flat_qr_nonSelbg: {
    paddingLeft: 10, // 양쪽에 20의 패딩을 추가
    paddingRight: 10, // 양쪽에 20의 패딩을 추가
    borderColor: 'white',
  },
  flat_qr_selbg: {
    paddingLeft: 10, // 양쪽에 20의 패딩을 추가
    paddingRight: 10, // 양쪽에 20의 패딩을 추가
    borderColor: '#FF851D',
  },
  qr_contener: {
    justifyContent: 'center', alignItems: 'center'
   },
  qrNonSelImg: {
    width: 56, 
    height: 56, 
    borderRadius: 5, 
    marginTop: 10,
    borderColor: 'white',
  },
  qrSelImg: {
    width: 65, 
    height: 65, 
    borderRadius: 20, 
    marginTop: 10,
    borderColor: '#FF851D',
  },
  container_row: {
    flexDirection: 'row', // 가로 방향으로 배치
    justifyContent: 'space-between', // 각 텍스트 사이에 여백을 추가
  },
  
  down_image: {
    width: 20,
    height: 20,
    marginTop: 0, 
    marginBottom: 5, 
  },
   flat_container: {
    paddingHorizontal: 10, // 양쪽에 20의 패딩을 추가
  },
  flat_view: {
    paddingLeft: 10, // 양쪽에 20의 패딩을 추가
    paddingRight: 10, // 양쪽에 20의 패딩을 추가
  },
});

export default QRListScreen;
