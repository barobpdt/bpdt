import React, { useRef, useState } from 'react';
import {
  SafeAreaView,
  View,
  TextInput,
  TouchableOpacity,
  Image,
  KeyboardAvoidingView,
  Platform,
  StyleSheet,
  Text,
  FlatList,
  InteractionManager,
} from 'react-native';
import { RootStackParamList } from '../../types/common';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';

const TestPage = () => {
  const [showOptionBox, setShowOptionBox] = useState(false);
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const [showMenu, setShowMenu] = useState(false);

  type ChatMessage = {
    id: string;
    sender: 'me' | 'other';
    message: string;
    time: string;
    profileImg?: any;
    nickname?: string;
  };

  const [dummyMessages, setDummyMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      sender: 'me',
      message: '오늘 퇴근한다고 했지? 이제 퇴근한다고 했었는데...',
      time: '오후 3:45',
    },
    {
      id: '2',
      sender: 'other',
      message: '송대에서 오늘 반지 만들기 하자고 했잖아! 왜 연락 제대로 안가?',
      time: '오후 3:45',
      profileImg: require('../../assets/ic_my.png'),
      nickname: '세미',
    },
    {
      id: '3',
      sender: 'other',
      message: '송대에서 오늘 반지 만들기 하자고 했잖아! 왜 연락 제대로 안가?',
      time: '오후 3:45',
      profileImg: require('../../assets/ic_my.png'),
      nickname: '세미',
    },
    {
      id: '4',
      sender: 'other',
      message: '송대에서 오늘 반지 만들기 하자고 했잖아! 왜 연락 제대로 안가?',
      time: '오후 3:45',
      profileImg: require('../../assets/ic_my.png'),
      nickname: '세미',
    },
    {
      id: '5',
      sender: 'other',
      message: '송대에서 오늘 반지 만들기 하자고 했잖아! 왜 연락 제대로 안가?',
      time: '오후 3:45',
      profileImg: require('../../assets/ic_my.png'),
      nickname: '세미',
    },
  ]);

  const [message, setMessage] = useState('');
  const flatListRef = useRef<FlatList>(null);

  const sendMessage = () => {
    if (!message.trim()) return;

    const newMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'me',
      message,
      time: getCurrentTime(),
    };

    setDummyMessages(prev => {
      const updated = [...prev, newMessage];
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
      return updated;
    });

    setMessage('');
  };

  const getCurrentTime = () => {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? '오후' : '오전';
    const hour12 = hours % 12 || 12;
    return `${ampm} ${hour12}:${minutes}`;
  };

  const handleBack = () => {
    InteractionManager.runAfterInteractions(() => {
      navigation.goBack();
    });
  };

  const handleGoHome = () => {
    navigation.navigate('MainHome');
  };

  const renderItem = ({ item }: { item: ChatMessage }) => {
    if (item.sender === 'me') {
      return (
        <View style={styles.myMessageContainer}>
          <View style={styles.myMessageBox}>
            <Text>{item.message}</Text>
          </View>
          <Text style={styles.timeText}>{item.time}</Text>
        </View>
      );
    }

    return (
      <View style={styles.otherMessageContainer}>
        <Image source={item.profileImg} style={styles.profileImg} />
        <View style={{ flex: 1 }}>
          <Text style={styles.nickname}>{item.nickname}</Text>
          <View style={styles.otherMessageContent}>
            <View style={styles.otherMessageBox}>
              <Text>{item.message}</Text>
            </View>
            <View style={{ marginLeft: 6 }}>
              <Text style={styles.timeText}>{item.time}</Text>
              <Text style={styles.timeText}>1</Text>
            </View>
          </View>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerContainer}>
        <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
          <Image
            source={require('../../assets/ic_arr_left.png')}
            style={styles.prevIcon}
          />
        </TouchableOpacity>
        <View style={styles.titleContainer}>
          <Text style={styles.titleText}>채팅</Text>
        </View>
        <TouchableOpacity style={styles.homeButton} onPress={() => setShowMenu(prev => !prev)}>
          <Image
            source={require('../../assets/ico_floating_menu.png')}
            style={styles.homeIcon}
          />
        </TouchableOpacity>
      </View>

      {showMenu && (
        <View style={styles.dropdownMenu}>
          <TouchableOpacity style={styles.dropdownItem}>
            <Text style={styles.dropdownText}>위치공유</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.dropdownItem} onPress={handleGoHome}>
            <Text style={styles.dropdownExit}>채팅방 나가기</Text>
          </TouchableOpacity>
        </View>
      )}

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={60}
        style={{ flex: 1 }}
      >
        <View style={styles.chatListWrapper}>
          <FlatList
            ref={flatListRef}
            data={dummyMessages}
            keyExtractor={(item) => item.id}
            renderItem={renderItem}
            contentContainerStyle={{ paddingVertical: 10, paddingBottom: 30 }}
            showsVerticalScrollIndicator={false}
          />
        </View>
      </KeyboardAvoidingView>

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
      >
        {showOptionBox ? (
          <View style={styles.optionBox}>
            <View style={styles.optionHeader}>
              <TouchableOpacity onPress={() => setShowOptionBox(false)}>
                <Image
                  source={require('../../assets/ico_floating_close.png')}
                  style={styles.icon}
                />
              </TouchableOpacity>
              <TextInput
                style={styles.searchBar}
                placeholder="메시지를 입력하세요"
                placeholderTextColor="#aaa"
                value={message}
                onChangeText={setMessage}
              />
            </View>

            <View style={styles.optionRow}>
              <View style={styles.optionItem}>
                <Image source={require('../../assets/ico_ask.png')} style={styles.optionIcon} />
                <Text style={styles.optionText}>사진전송</Text>
              </View>
              <View style={styles.optionItem}>
                <Image source={require('../../assets/ic_add_friend.png')} style={styles.optionIcon} />
                <Text style={styles.optionText}>그룹추가</Text>
              </View>
              <TouchableOpacity style={styles.optionItem} onPress={() => navigation.navigate('Location', { locate: '위치' })}>
                <Image source={require('../../assets/ic_locat_find.png')} style={styles.optionIcon} />
                <Text style={styles.optionText}>위치보기</Text>
              </TouchableOpacity>
            </View>
          </View>
        ) : (
          <View style={styles.inputContainer}>
            <TouchableOpacity onPress={() => setShowOptionBox(true)}>
              <Image source={require('../../assets/addQR.png')} style={styles.icon} />
            </TouchableOpacity>
            <TextInput
              style={styles.textInput}
              placeholder="메시지를 입력하세요"
              placeholderTextColor="#aaa"
              value={message}
              onChangeText={setMessage}
            />
            <TouchableOpacity onPress={sendMessage}>
              <Image source={require('../../assets/icon_next_bf.png')} style={styles.icon} />
            </TouchableOpacity>
          </View>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  chatListWrapper: { flex: 1, paddingTop: 60 },
  headerContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  myMessageContainer: {
    alignItems: 'flex-end',
    paddingHorizontal: 10,
    marginVertical: 4,
  },
  myMessageBox: {
    backgroundColor: '#ffcc80',
    borderRadius: 12,
    padding: 8,
    maxWidth: '80%',
  },
  otherMessageContainer: {
    flexDirection: 'row',
    paddingHorizontal: 10,
    marginVertical: 4,
  },
  profileImg: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 8,
  },
  nickname: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#333',
  },
  otherMessageContent: {
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  otherMessageBox: {
    backgroundColor: '#eee',
    borderRadius: 12,
    padding: 8,
    maxWidth: '80%',
  },
  timeText: {
    fontSize: 10,
    color: '#999',
    marginTop: 2,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderTopWidth: 1,
    borderColor: '#e0e0e0',
    backgroundColor: '#f9f9f9',
  },
  icon: {
    width: 24,
    height: 24,
    marginHorizontal: 8,
  },
  textInput: {
    flex: 1,
    height: 40,
    paddingHorizontal: 10,
    backgroundColor: '#fff',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  optionBox: {
    backgroundColor: '#f2f2f2',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderTopWidth: 1,
    borderColor: '#ccc',
  },
  optionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  searchBar: {
    height: 35,
    backgroundColor: '#fff',
    borderRadius: 20,
    marginVertical: 10,
    flex: 1,
    paddingHorizontal: 10,
  },
  optionRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 10,
    paddingTop: 20,
    paddingBottom: 40,
  },
  optionItem: {
    alignItems: 'center',
  },
  optionIcon: {
    width: 28,
    height: 28,
    marginBottom: 4,
  },
  optionText: {
    fontSize: 12,
    color: '#333',
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  dropdownMenu: {
    position: 'absolute',
    top: 60,
    right: 10,
    backgroundColor: '#fff',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 5,
    zIndex: 20,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  dropdownItem: {
    paddingVertical: 8,
  },
  dropdownText: {
    fontSize: 14,
    color: '#333',
  },
  dropdownExit: {
    fontSize: 14,
    color: 'red',
    fontWeight: 'bold',
  },
});

export default TestPage;
