import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Modal,
  FlatList,
  ScrollView,
  SafeAreaView
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList } from '../../types/common';

const optionsList = {
  bell: ['기본벨소리', '벨소리2', '벨소리3'],
  language: ['한국어', '영어', '일본어'],
  stealTime: ['10초', '20초', '30초'],
};

const SettingScreen = () => {
  const [sound, setSound] = useState(true);
  const [vibration, setVibration] = useState(true);
  const [voiceTalk, setVoiceTalk] = useState(true);
  const [messageHide, setMessageHide] = useState(true);
  const [locationAllow, setLocationAllow] = useState(true);

  const [bell, setBell] = useState('기본벨소리');
  const [language, setLanguage] = useState('한국어');
  const [stealTime, setStealTime] = useState('10초');

  const handleBack = () => {
    navigation.goBack();
  };

  const handleGoHome = () => {
    navigation.navigate('MainHome');
  };
      const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();

  return (
    <SafeAreaView style={styles.bottomContainer}>
        <View>{/*상단바*/}
            <View style={styles.headerContainer}>
                <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                    <Image
                    source={require('../../assets/ic_arr_left.png')}
                    style={styles.prevIcon}
                    />
                </TouchableOpacity>
            
                <View style={styles.titleContainer}>
                    <Text style={styles.titleText}>검색</Text>
                </View>
            
                <TouchableOpacity style={styles.homeButton} onPress={handleGoHome}>
                    <Image
                    source={require('../../assets/ic_home_copy.png')}
                    style={styles.homeIcon}
                    />
                </TouchableOpacity>
            </View>
        </View>
    <ScrollView style={styles.container}>

      <Text style={styles.sectionTitle}>공통</Text>
      <SettingItem label="소리" value={sound} onValueChange={setSound} />
      <SettingItem label="진동" value={vibration} onValueChange={setVibration} />
      <SettingItem label="보이스톡" value={voiceTalk} onValueChange={setVoiceTalk} />
      <SettingItem label="메시지 숨김처리" value={messageHide} onValueChange={setMessageHide} />

      <CustomDropdown label="벨소리 설정" value={bell} onChange={setBell} options={optionsList.bell} />
      <CustomDropdown label="언어설정" value={language} onChange={setLanguage} options={optionsList.language} />

      <Text style={styles.sectionTitle}>차빼줘</Text>
      <CustomDropdown label="알림설정" value={stealTime} onChange={setStealTime} options={optionsList.stealTime} />

      <Text style={styles.sectionTitle}>지켜줘</Text>
      <SettingItem label="위치허용" value={locationAllow} onValueChange={setLocationAllow} />

      <TouchableOpacity style={styles.saveButton}>
        <Text style={styles.saveButtonText}>저장</Text>
      </TouchableOpacity>
    </ScrollView>
    </SafeAreaView>
  );
};

// ✅ 토글 스위치 커스텀
const SettingItem = ({ label, value, onValueChange }: any) => (
    <View style={styles.settingItem}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity
        onPress={() => onValueChange(!value)}
        style={[
          styles.toggleWrapper,
          value ? styles.toggleOn : styles.toggleOff,
        ]}
        activeOpacity={0.8}
      >
        <View
          style={[
            styles.toggleCircle,
            value ? styles.circleOn : styles.circleOff,
          ]}
        />
      </TouchableOpacity>
    </View>
  );

// ✅ 커스텀 드롭다운
const CustomDropdown = ({ label, value, onChange, options }: any) => {
  const [visible, setVisible] = useState(false);

  return (
      <SafeAreaView style={styles.bottomContainer}>
  
    <View style={styles.dropdownRow}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity
        style={styles.dropdownBox}
        onPress={() => setVisible(true)}
      >
        <Text style={styles.dropdownText}>{value}</Text>
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} onPress={() => setVisible(false)}>
          <View style={styles.modalContent}>
            <FlatList
              data={options}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.optionItem}
                  onPress={() => {
                    onChange(item);
                    setVisible(false);
                  }}
                >
                  <Text style={styles.optionText}>{item}</Text>
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>
    
        </SafeAreaView>
    
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7fcff',
    padding: 16,
  },
  sectionTitle: {
    backgroundColor: '#EFEFEF',
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontWeight: 'bold',
    color: '#333',
    fontSize: 14,
    marginTop: 20,
  },
  settingItem: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
  },
  label: {
    fontSize: 15,
    color: '#222',
  },
  switchImage: {
    width: 50,
    height: 30,
    resizeMode: 'contain',
  },
  dropdownRow: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
  },
  dropdownBox: {
    backgroundColor: '#f5f5f5',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  dropdownText: {
    fontSize: 14,
    color: '#333',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: '#00000077',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 8,
    width: 200,
    paddingVertical: 10,
  },
  optionItem: {
    padding: 12,
    borderBottomColor: '#ddd',
    borderBottomWidth: 1,
  },
  optionText: {
    fontSize: 14,
    color: '#333',
  },
  saveButton: {
    backgroundColor: '#FF7A00',
    marginTop: 32,
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },toggleWrapper: {
    width: 50,
    height: 28,
    borderRadius: 14,
    padding: 2,
    justifyContent: 'center',
  },
  toggleOn: {
    backgroundColor: '#FF7A00', // 주황색 (켜짐)
    alignItems: 'flex-end',
  },
  toggleOff: {
    backgroundColor: '#ccc', // 회색 (꺼짐)
    alignItems: 'flex-start',
  },
  toggleCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#fff',
    elevation: 2, // Android 그림자
    shadowColor: '#000', // iOS 그림자
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  circleOn: {
    transform: [{ translateX: 0 }],
  },
  circleOff: {
    transform: [{ translateX: 0 }],
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  headerContainer: {
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default SettingScreen;
