import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, SafeAreaView, InteractionManager } from 'react-native';
import BottomTabBar from '../../components/BottomTabBar';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import ApiInfo from '../../gvar/ApiInfo';
import { ApiMainRequest, ListAdView, ListRoomMessage, ListService, MainResponse, QrClickType, QrPageType, RootStackParamList, } from '../../types/common';
import {apiCallPost, GlobalData, MembInfo, isAdViewYn,GetDate} from '../../store/global';

const MyPage = () => {
    const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); 
    const [callScannerView, setCallScannerView] = useState(false);  // QR 전화 문자 스캔
    const [qrCarCallInfo, setQrCarCallInfo] = useState<QrPageType>({ gridPage: 1, totalSize: 1 });
    const [qrClickData, setQrClickData] = useState<QrClickType>({ qrNo: '', serviceTypeCd: '' });
    const [readCnt, setReadCnt] = useState(0);
    const [notReadCnt, setNotReadCnt] = useState(0);
    const [isAdView, setIsAdView] = useState(true) ;
    const [listRoomMessage, setListRoomMessage] = useState<ListRoomMessage[]>([]) ; //메세지 정보
    const [qrClickStatus, setQrClickStatus] = useState('10'); // QR클릭 여  10 : qr클릭안함, 20 : qr클릭 메세재, 30 : qr클릭 친구



  //맨 아래 QR 전화 문자 하기 스캔 화면 오픈
    const bottonCall = (jobType:string) => {
      //jobType Q : 스캔  ,H : home 
      if (jobType == "Q"){
        setCallScannerView(true);
      } else {
        mainApiData();
      }
      
    }


    const handleBack = () => {
        InteractionManager.runAfterInteractions(() => {
        navigation.goBack();
        });
    };

    const handleGoHome = () => {
        navigation.navigate('MainHome');
    };
    
    type MenuItem = {
        label: string;
        screen: keyof RootStackParamList; // 정확한 스크린 이름만 허용
      };

      
    //메뉴리스트
    const menuList = [
        { label: '설정', screen: 'Setting' },
        { label: '공지', screen: 'Notice'},
        { label: '매뉴얼', screen: 'Manual'},
        { label: 'FAQ', screen: 'FAQ'},
        { label: '1:1 문의', screen: 'Inquiry'},
      ];



  const mainApiData = async() => {
    console.log("home start =========================");
    qrCarCallInfo.gridPage = 1 ;
    qrCarCallInfo.totalSize = 1;
    qrClickData.qrNo = '';
    qrClickData.serviceTypeCd = '';

    
    const mainReqParam = () => {
        const node = {} as ApiMainRequest
        node.deviTpCd=GlobalData.deviTpCd
        node.langCd=GlobalData.langCd
        return node;
      }

    try {
      await apiCallPost(ApiInfo.mainInfo, mainReqParam(), (type:string, obj:object) => {
        if( type=='ok' ) {
          const info = obj as MainResponse
          console.log('main first data => ', info)
          GlobalData.membNo = info.membNo;
          MembInfo.nickNm = info.nickNm;
          GlobalData.SettingData  = info.settingInfo ;
          MembInfo.introductinInfo = info.introductionInfo;
          MembInfo.imgFileUrl = info.imgFileUrl;
          GlobalData.introImgUrl = info.introImgUrl;
          setReadCnt(info.totalReadCnt);
          setNotReadCnt(info.totalNotReadCnt);
          
          if (Array.isArray(info.listService) && info.listService.length > 0 ) {
            GlobalData.serviceList = info.listService as ListService[] ;
          } 

          if (Array.isArray(info.listAdView) && info.listAdView.length > 0 ) {
            GlobalData.adViewList = info.listAdView as ListAdView[] ;
            
            //광고  출력 여부
            setIsAdView(isAdViewYn('AM'));
          } 

          if (Array.isArray(info.listRoomMessage) && info.listRoomMessage.length > 0 ) {
            setListRoomMessage(info.listRoomMessage as ListRoomMessage[]) ;
          } else {
            setListRoomMessage([]) ;
          }
         
          setQrClickStatus("10");
        }

      })
      } catch (error) {
          console.error("API 호출 중 오류 발생:", error);
      }
  }



  return (
    <SafeAreaView style={styles.bottomContainer}>

        <View style={styles.headerContainer}>
            <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                <Image
                source={require('../../assets/ic_arr_left.png')}
                style={styles.prevIcon}
                />
            </TouchableOpacity>

            <View style={styles.titleContainer}>
                <Text style={styles.titleText}>MY</Text>
            </View>

            <TouchableOpacity style={styles.homeButton} onPress={handleGoHome}>
                <Image
                source={require('../../assets/ic_home_copy.png')}
                style={styles.homeIcon}
                />
            </TouchableOpacity>
        </View>


        <ScrollView style={styles.container}>
        {/* 프로필 */}
        <View style={styles.profileBox}>
            <View>
            <Text style={styles.profileTitle}>테스터</Text>
            <Text style={styles.profileSubtitle}>소개글입니다.</Text>
            </View>
            <View style={styles.profileImageWrapper}>
            <Image
                source={require('../../assets/ic_my_disable.png')}
                style={styles.profileImage}
            />
            </View>
        </View>

        {/* QR 모아보기 */}
        <TouchableOpacity style={styles.qrBox} onPress={() => navigation.navigate('QrList')} >
            <View style={styles.qrLeft}>
            <Image
                source={require('../../assets/qr.png')}
                style={styles.qrIcon}
            />
            <View>
                <Text style={styles.qrTitle}>QR 모아보기</Text>
                <Text style={styles.qrSubtitle}>등록한 QR을 한번에 확인하세요!</Text>
            </View>
            </View>
            <Image
                source={require('../../assets/icon_next_bf.png')}
            style={styles.arrowIcon}
            />
        </TouchableOpacity>

        {/* 메뉴 리스트 */}
      {menuList.map((item, idx) => (
        <TouchableOpacity
          key={idx}
          style={styles.menuItem}
          onPress={() => navigation.navigate(item.screen as never)} // <== 여기에 연결
        >
          <Text style={styles.menuText}>{item.label}</Text>
          <Image
            source={require('../../assets/icon_next_bf.png')}
            style={styles.arrowIcon}
          />
        </TouchableOpacity>
      ))}
        </ScrollView>
        { <BottomTabBar  navigation={navigation} bottonCall={bottonCall} /> }
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7fcff',
    padding: 12,
  },
  headerContainer:{
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  profileBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFE7BD',
    paddingVertical: 18,
    paddingHorizontal: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
  },
  profileTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  profileSubtitle: {
    fontSize: 13,
    color: '#666',
  },
  profileImageWrapper: {
    backgroundColor: '#fff',
    borderRadius: 999,
    padding: 6,
  },
  profileImage: {
    width: 40,
    height: 40,
    resizeMode: 'contain',
  },
  qrBox: {
    backgroundColor: '#fff9f3',
    borderColor:'#FF851D',
    borderWidth:1,
    borderRadius: 10,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  qrLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  qrIcon: {
    width: 32,
    height: 32,
    resizeMode: 'contain',
    marginRight: 12,
  },
  qrTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#000',
  },
  qrSubtitle: {
    fontSize: 12,
    color: '#888',
    marginTop: 4,
  },
  arrowIcon: {
    width: 18,
    height: 18,
    resizeMode: 'contain',
  },
  menuItem: {
    backgroundColor: '#fff9f3',
    borderBottomWidth:2,
    borderColor:'gray',
    paddingVertical: 16,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  menuText: {
    fontSize: 15,
    color: '#222',
  },
});

export default MyPage;
