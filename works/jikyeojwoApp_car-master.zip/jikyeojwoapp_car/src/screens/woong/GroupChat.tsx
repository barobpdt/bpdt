import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  SafeAreaView,
  TouchableOpacity,
  Modal,
  Image,
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList } from '../../types/common.tsx';
import GroupMemberItem from '../../components/GroupMemberItem.tsx';
import MemberSelectModal from '../../components/MemberSelectModal';

type Member = {
  name: string;
  image: string;
  statusMsg: string;
};
const allMembers: Member[] = [
    {
      name: '아빠',
      image: 'https://example.com/semi.jpg',
      statusMsg: '운동 중이에요!',
    },
    {
      name: '엄마',
      image: 'https://example.com/semi.jpg',
      statusMsg: '요리 중이에요.',
    },
    {
      name: '세미',
      image: 'https://example.com/semi.jpg',
      statusMsg: '공부 중!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    },
    {
      name: '오빠',
      image: 'https://example.com/semi.jpg',
      statusMsg: '운전 중',
    },
    {
      name: '여동생',
      image: 'https://example.com/semi.jpg',
      statusMsg: '노래 듣는 중',
    },
    {
        name: '아빠1',
        image: 'https://example.com/semi.jpg',
        statusMsg: '운동 중이에요!',
      },
      {
        name: '엄마1',
        image: 'https://example.com/semi.jpg',
        statusMsg: '요리 중이에요.',
      },
      {
        name: '세미1',
        image: 'https://example.com/semi.jpg',
        statusMsg: '공부 중!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
      },
      {
        name: '오빠1',
        image: 'https://example.com/semi.jpg',
        statusMsg: '운전 중',
      },
      {
        name: '여동생1',
        image: 'https://example.com/semi.jpg',
        statusMsg: '노래 듣는 중',
      },
    // 나머지 멤버들...
  ];
const GroupChat = () => {
  const [groupName, setGroupName] = useState('');
  const [selectedMembers, setMembers] = useState<Member[]>([
    {
      name: '아빠',
      image: 'https://example.com/semi.jpg',
      statusMsg: '운동 중이에요!',
    },
    {
      name: '엄마',
      image: 'https://example.com/semi.jpg',
      statusMsg: '요리 중이에요.',
    },
    {
      name: '세미',
      image: 'https://example.com/semi.jpg',
      statusMsg: '공부 중!aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',
    },
  ]);
 const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();

  const handleBack = () => {
    navigation.goBack();
  };

  const handleGoHome = () => {
    navigation.navigate('MainHome');
  };
  const [isModalVisible, setModalVisible] = useState(false);

  const addMember = () => {
    setModalVisible(true);
  };
  
  const closeModal = () => {
    setModalVisible(false);
  };
  

  const removeMember = (name: string) => {
    setMembers(selectedMembers.filter(member => member.name !== name));
  };

  return (
    <SafeAreaView style={styles.bottomContainer}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.scrollContainer}>
          <View>
            <View style={styles.headerContainer}>
                  <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                    <Image
                      source={require('../../assets/ic_arr_left.png')}
                      style={styles.prevIcon}
                    />
                  </TouchableOpacity>
            
                  <View style={styles.titleContainer}>
                    <Text style={styles.titleText}>그룹만들기</Text>
                  </View>
            
                  <TouchableOpacity style={styles.homeButton} onPress={handleGoHome}>
                    <Image
                      source={require('../../assets/ic_home_copy.png')}
                      style={styles.homeIcon}
                    />
                  </TouchableOpacity>
                </View>
          </View>
          
          <Text style={styles.label}>그룹명</Text>
          <TextInput
            style={styles.input}
            placeholder="그룹명을 입력해주세요."
            value={groupName}
            onChangeText={setGroupName}
            placeholderTextColor="#aaa"
          />

          <TouchableOpacity style={styles.addButton} onPress={addMember}>
            <Text style={styles.addButtonText}>➕  멤버추가</Text>
          </TouchableOpacity>

          {/* 친구 목록 부분에만 스크롤 추가 */}
          <ScrollView style={styles.memberList}>
            {selectedMembers.map((member) => (
                <GroupMemberItem
                    key={member.name}
                    name={member.name}
                    image={member.image}
                    statusMsg={member.statusMsg}
                    mode="remove"
                    onRemove={() => removeMember(member.name)} // 이 부분 정상 작동함
                />
            ))}
          </ScrollView>

        </View>

        <TouchableOpacity style={styles.saveButton}>
          <Text style={styles.saveButtonText}>저장</Text>
        </TouchableOpacity>
        
      <MemberSelectModal
        visible={isModalVisible}
        selected={selectedMembers.map(m => m.name)}
        members={allMembers} // ✅ 이걸 추가
        onToggle={(name) => {
            const isAlready = selectedMembers.find(m => m.name === name);
            if (isAlready) {
              setMembers(selectedMembers.filter(m => m.name !== name));
            } else {
              const newMember = allMembers.find(m => m.name === name);
              if (newMember) setMembers([...selectedMembers, newMember]);
            }
        }}
        onClose={closeModal}
      />
      </KeyboardAvoidingView>

    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  scrollContainer: {
    flex: 1,
    padding: 10,
    paddingBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 8,
    fontWeight: 'bold',
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    borderRadius: 6,
    marginBottom: 15,
  },
  addButton: {
    backgroundColor: '#FF851D',
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: 'center',
    marginBottom: 20,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  memberList: {
    marginBottom: 100,
  },
  saveButton: {
    backgroundColor: '#FF851D',
    paddingVertical: 12,
    borderRadius: 6,
    alignItems: 'center',
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    marginHorizontal: 20,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  scrollViewContent: {
    padding: 10,
    paddingBottom: 100,
  },
  searchContainer: {
    marginHorizontal:10,
    marginVertical: 10,
  },searchBox: {
    marginTop:10,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 25,
    borderWidth: 1,
    borderColor:'#FF851D',
    backgroundColor: '#f2f2f2',
    paddingHorizontal: 15,
    paddingVertical: 5,
  },
  clearButton: {
  },
  clearText: {
    fontSize: 18,
    color: '#999',
  },
  groupArea:{
    marginVertical:10,
  },
  iconArea: {
    marginLeft: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    paddingVertical: 15,
  },
  emptyResult: {
    fontSize: 16,
    color: 'red',
    textAlign: 'center',
    marginTop: 40,
  },
  resultArea:{
    padding:10,
    marginHorizontal:10,
    marginBottom:40,
    flex:1,
  },
  headerContainer: {
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default GroupChat;
