import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  TouchableOpacity,
  Image,
  StyleSheet,
  Text,
  InteractionManager ,
} from 'react-native';
import { RouteProp, useRoute } from '@react-navigation/native';

import {
  RootStackParamList,
} from '../../types/common';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';

type LocationRouteProp = RouteProp<RootStackParamList, 'Location'>;
const Location = () => {
    const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();


    const route = useRoute<LocationRouteProp>();
    const { locate } = route.params;
  
  const handleBack = () => {
    InteractionManager.runAfterInteractions(() => {
      navigation.goBack();
    });
  };



  return (
    <SafeAreaView style={styles.container}>
        <View style={styles.headerContainer}>
            <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                <Image
                source={require('../../assets/ic_arr_left.png')}
                style={styles.prevIcon}
                />
            </TouchableOpacity>
        
            <View style={styles.titleContainer}>
                <Text style={styles.titleText}>{locate}</Text>
            </View>
        </View>
        <View style={styles.mapContainer}>
          <Image
            source={require('../../assets/map.png')}
            style={styles.mapImg}/>
        </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({ 
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  headerContainer: {
    position: 'absolute', // 💡 상단 고정
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  mapContainer:{
    flex:1
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapImg:{
    flex:1,
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  titleContainer: {
    paddingRight:40,
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default Location;
