import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Modal,
  FlatList,
  ScrollView,
  SafeAreaView
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList } from '../../types/common';



const FriendProfile = () => {

    const [friendItem, setFriendItem] = useState([{
        profile: 'http://test.com',
        name: '세미',
        statusMsg: '오늘 나랑 밥먹을사람! 어어어어어어어어어어어어어기기기기기기',
        regiDate: '2025.01.04',
      }]);
  const handleBack = () => {
    navigation.goBack();
  };

  const handleGoHome = () => {
    navigation.navigate('MainHome');
  };
      const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();

  return (
    <SafeAreaView style={styles.bottomContainer}>
        <View>{/*상단바*/}
            <View style={styles.headerContainer}>
                <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                    <Image
                    source={require('../../assets/ic_arr_left.png')}
                    style={styles.prevIcon}
                    />
                </TouchableOpacity>
            </View>
        </View>
        <View style={styles.content}>
            <View style={styles.contentTop}>
                <Image
                    //source={{friendItem.profile}')}
                    source={require('../../assets/ic_my.png')}
                    style={styles.imgIco}
                />
                <Text style={{fontSize:14, fontWeight:'bold', marginBottom:10}}>{friendItem[0].name}</Text>
                <Text style={{fontSize:14,  marginBottom:20, width:'70%'}}>{friendItem[0].statusMsg}</Text>
                <Text style={{fontSize:14,  marginBottom:10}}>친구 등록일: {friendItem[0].regiDate}</Text>
            </View>
            <View style={styles.contentBtm}>
                <TouchableOpacity>
                    <Image 
                        style={styles.imgIco}
                        source={require('../../assets/ico_user.png')}
                    />
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image 
                        style={styles.imgIco}
                        source={require('../../assets/ico_user.png')}
                    />
                </TouchableOpacity>
                <TouchableOpacity>
                    <Image 
                        style={styles.imgIco}
                        source={require('../../assets/ico_user.png')}
                    />
                </TouchableOpacity>
            </View>
        </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7fcff',
    padding: 16,
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#fff9f3',
  },
  headerContainer: {
    height: 60,
    backgroundColor: '#fff9f3',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  content:{
    flex:1,
    paddingHorizontal:30
    
  },
  contentTop:{
    flex:1,
    alignContent:'center',
    justifyContent:'center',
    alignItems:'center',
    paddingTop:'30%',
  },
  contentBtm:{
    
    width:'100%',
    flexDirection:'row',
    justifyContent:'space-between',
    alignItems:'center',
    alignContent:'center',
    paddingBottom:120
  },
  imgIco:{
    height:70,
    width:70
  },
});

export default FriendProfile;
