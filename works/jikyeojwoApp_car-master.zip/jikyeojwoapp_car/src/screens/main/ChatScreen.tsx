import React, { useEffect, useRef, useState, useContext, useCallback } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
	View,
	TextInput,
	TouchableOpacity,
	Image,
	KeyboardAvoidingView,
	Platform,
	StyleSheet,
	Text,
	FlatList,
	InteractionManager,
	Keyboard,
	Alert,
	ToastAndroid,
	Modal,
	ActivityIndicator,
	StatusBar,
	ScrollView,
	TouchableWithoutFeedback,
	Dimensions
} from 'react-native';
import { RootStackParamList,RoomChatMsgInfo , QrPageType, ChatFriendInfo, RoomChatMsgListRequest
	, RoomChatInitResponse, RoomChatMsgListResponse, CallSeqResponse, FileUploadRequest, ImageAsset, FileResponse,
	MembLocation,
	ListRoomMessage,
	MessageData, MessageRoomInfoRequest, MessageRoomInfoResponse, FriendList, ChangeRoomInfoRequest, ChkRoomInfoResponse,
	SaveResponse, SaveMsgDataRequest, ChgRoomInfoRequest, ChgRoomInfoResponse, RemoveDataRequest,
	RoomFriendLocationRequest,
	FriendLocation,
	ChgRoomNmRequest,
	ChgRoomNmResponse} from '../../types/common';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import ApiInfo from '../../gvar/ApiInfo';
import {GlobalData, GetDate, useGlobalStore, apiFileCallPost, GetDateDay, GetDateTime, callPost, callGet} from '../../store/global';
import Clipboard from '@react-native-clipboard/clipboard';
import { SocketStompContext  } from '../../utils/WebSocketManager';
import { launchImageLibrary, MediaType, PhotoQuality, launchCamera } from 'react-native-image-picker';
import MapView, { Marker, Region } from 'react-native-maps';
import RNFS from 'react-native-fs';
import Share from 'react-native-share';
import RNFetchBlob from 'react-native-blob-util';
import { SafeAreaView } from 'react-native-safe-area-context';

let mapKeyIndex = 0;
const ChatScreen = ({ route }) => {
	const global = useGlobalStore();
	const windowHeight = Dimensions.get('window').height;
	//const state = useGlobalStore.getState();
	const insets = useSafeAreaInsets();
	const [showOptionBox, setShowOptionBox] = useState(false);  // 바닥부분 옵션
	const { sendMessage,  disconnect , sendReadMessage, startLocationUpdates, stopLocationUpdates } = useContext(SocketStompContext);  //requestLocation

	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
	const [showMenu, setShowMenu] = useState(false); // 오른쪽 메뉴
	const [showMap, setShowMap] = useState(false); //지도
	const [showMarkers, setShowMarkers] = useState(false); //마커 표시
	const [mapFullScreen, setMapFullScreen] = useState(false); //지도확대
	const [height, setHeight] = useState(40); // 기본 높이 설정 - 채팅창 글자 input size
	const [selectedImage, setSelectedImage] = useState<any>(null);  // 이미지 선택번호
	const [selectedImageNm, setSelectedImageNm] = useState<any>(null);  // 이미지 선택번호
	const [isImageModalVisible, setImageModalVisible] = useState(false); //이미지 팝업 확대 팝업

	const [locationCheckCount, setLocationCheckCount] = useState(0);
	const [prevUserLocation, setPrevUserLocation] = useState<MembLocation>({latitude: 0, longitude: 0});
	const mapRef = useRef<MapView>(null);
	const [mapRegion, setMapRegion] = useState<Region>({
		latitude: 37.5665,
		longitude: 126.9780,
		latitudeDelta: 0.005,
		longitudeDelta: 0.005,
	});
	const [message, setMessage] = useState('');
	const [uploadFileInfo, setUploadFileInfo] = useState<FileResponse>({ code: '', message: '' , fileNo: '', downUrl: '', orgFileNm: ''});
	const flatListRef = useRef<FlatList>(null);

	const [qrCarCallInfo, setQrCarCallInfo] = useState<QrPageType>({ searchChatSeq: '', totalSize: 1 , lastChatSeq: '', preSearchChatSeq: ''});
	//const [listRoomChatMsg, setListRoomChatMsg] = useState<RoomChatMsgInfo[]>([]) ; //메세지 정보
	//const [listRoomFriend, setListRoomFriend] = useState<ChatFriendInfo[]>([]) ; //메세지 정보
	const [mySubScr, setMySubScr] = useState('') ; //내 채팅방 구독 정보
	const [qrSubScr, setQrSubScr] = useState('') ; //내 채팅방 QR 구독정보 -- 로케이션 처리
	const [roomTypeCd, setRoomTypeCd] = useState('') ; //내 채팅방 구독 정보
	//오픈시 첨 데이타 호출 판단
	
	const [isLoading, setIsLoading] = useState(false); // 로딩 상태
	const [scrollTime, setScrollTime] = React.useState(0)
	const [listData, setListData] = useState<RoomChatMsgInfo[]|ChatItem[]>([])
	const [roomInfo, setRoomInfo] = useState({roomNo: '', roomNm: ''});
	const [msgInfo, setMsgInfo] = useState<MessageData|null>(null);
	//날짜 알림 추가
	type ChatItem = RoomChatMsgInfo | { type: 'date'; date: string };

	//친구추가시 처리 하는 함수 및 변수 검색팝업
	const [searchAddFriendList, setSearchAddFriendList] = useState<FriendList[]>([]) ;  //검색 대상
	const [orgFriendList, setOrgFriendList] = useState<FriendList[]>([]) ;  //검색 대상
	const [searchData, setSearchData] = useState('');
	const [isModalVisible, setIsModalVisible] = useState(false);
	const [selectFriend, setSelectFriend] = useState<ChatFriendInfo[]>([]) ;  //선택친구
	//const [preRoomTypeCd, setPreRoomTypeCd] = useState('') ;  //이전 방그룹정보
	//const [preRoomNo, setPreRoomNo] = useState('') ;  //이전 방그룹정보

	//전체보기 추가
	const [messageLineExceeds, setMessageLineExceeds] = useState<Record<string, boolean>>({});
	const [isTextModalVisible, setTextModalVisible] = useState(false);
	const [currentFullMessage, setCurrentFullMessage] = useState('');

	//초기 그룹방 저장
	const [groupName, setGroupName] = useState('');

	//멤버인포 모달
	const [isInfoModalVisible, setInfoModalVisible] = useState(false); //이미지 팝업 확대 팝업
	const [mapIndex, setMapIndex] = useState(0);
	const today = new Date().toISOString().split('T')[0].replaceAll('-','.');
	const [contentHeight, setContentHeight] = useState(windowHeight);


	//메세지 길게눌렀을때 뜨는 옵션 관련 변수
	const [msgOptionVisible, setMsgOptionVisible] = useState(false)
	const [selectedMsgOwner, setSelectedMsgOwner] = useState<'me' | 'other' | null>(null);
	const [selectedMessageText, setSelectedMessageText] = useState('');
	const [selectedMessageId, setSelectedMessageId] = useState('');
	const [selectedMessageSeqs, setSelectedMessageSeqs] = useState<string[]>([]);
	 

	//삭제 관련 변수
	const [delChkUse, setDelChkUse] = useState(false)

	//오픈시
	useEffect(() => {
		// 채팅데이타를 불러온다. 
		// global.initLocation();
		console.log('그룹네임초기세팅')
		if (roomInfo?.roomNm) {
			setGroupName(roomInfo.roomNm);
		}
		setMapIndex(mapKeyIndex++);
		replaceChatRoom();
		const optionHeight = 50;
		const insetsHeight = (Platform.OS === 'android' && Platform.Version < 33) ? 20: insets.bottom;
		console.log("@@ insetsHeight", insets, windowHeight);
		setContentHeight(windowHeight - insetsHeight );
		
		const keyboardDidShowListener = Keyboard.addListener(
			Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow',
			(e) => {
				const hh = (showOptionBox ? optionHeight : 0) + (Platform.OS === 'ios' ? -15: 0);
				setContentHeight(windowHeight - insetsHeight - e.endCoordinates.height - hh);
				setTimeout(() => {
					flatListRef.current?.scrollToEnd({ animated: true });
				}, 100);
			}
		);
		const keyboardWillHide = Keyboard.addListener(
			Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide',
			() => {
				setContentHeight(windowHeight - insetsHeight - (showOptionBox ? optionHeight : 0));
			}
		);

		if( global.infoLocation.latitude !== 0 ) {
			const initialRegion = {
				latitude: global.infoLocation.latitude,
				longitude: global.infoLocation.longitude,
				latitudeDelta: 0.005,
				longitudeDelta: 0.005,
			}; 
			setMapRegion(initialRegion);
		}

		return () => {
			keyboardDidShowListener.remove();
			keyboardWillHide.remove();
			global.initLocation();
		};
	}, []);

	const replaceChatRoom = () => {
		console.log("replaceChatRoom start");
		const state = useGlobalStore.getState();

		global.removeAllListRoomChatMsg();
		global.updateListRoomFriend([]);
		setMsgInfo(state.currentMessageData);  //채팅데이타 
		setRoomInfo(state.currentRoomInfo);   //방정보 

		console.log("@@ Add Friend replaceChatRoom start cur currentMessageData", global.currentMessageData);
		console.log("@@ Add Friend replaceChatRoom start cur currentRoomInfo", global.currentRoomInfo);
		// 조회조건 초기화
		qrCarCallInfo.searchChatSeq = '' ;
		qrCarCallInfo.lastChatSeq = '' ;
		qrCarCallInfo.preSearchChatSeq = '' ;
		qrCarCallInfo.totalSize = GlobalData.chatGridSize;
		setScrollTime(0);
		//초기 채팅 데이타 가져오기
		getRoomChatStart();

		console.log("@@ processScreen  ", state.processScreen);
	} 

	//대화 변경 이벤트
	useEffect(() => {
		if ( global.listRoomChatMsg.length > 0 && flatListRef.current) {	
			setListData( insertDateSeparators(global.listRoomChatMsg) );
		}
	}, [global.listRoomChatMsg]);


	useEffect(() => {		
		global.listRoomFriend.forEach(item => {
			const globalFriendInfo = global.listFriend?.find(gitem => gitem.friendNo === item.membNo);
			if (globalFriendInfo) {
				item.locationCd = globalFriendInfo.friendLocationCd ;
				item.imgFileUrl = globalFriendInfo.imgFileUrl;
			}
		});
	}, [global.listFriend]);

	useEffect(() => {		
		setTimeout(() => flatListRef.current?.scrollToEnd({ animated: true }), 500);
	}, [listData]);

	/*
	useEffect(() => { 
		if( global.processScreen !== 'Chat' ) {
			console.log("@@ 채팅 화면 종료 : ", global.processScreen);
			closePage();
		}
	}, [global.processScreen]);
	
	*/
	useEffect(() => {
		/*
		if( global.mapMode==false ) {
			global.setMapMode(true);
		}
		*/
		console.log("@@ location data ====>", global.listLocation, global.mapMode);
	}, [global.listLocation]);

	const insertDateSeparators = (messages: RoomChatMsgInfo[]): ChatItem[] => {
		const result: ChatItem[] = [];
		let lastDate: string | null = null;

		messages.forEach((msg) => {
			const currentDate = msg.addDt; // 예: "2025-05-01" 또는 "25.05.01"
			if (currentDate !== lastDate) {
				result.push({ type: 'date', date: currentDate });
				lastDate = currentDate;
			}
			result.push(msg);
		});

		return result;
	};
	

	const getRoomChatStart = async() => {
		console.log('@@ Add Friend getRoomChatStart');
		const state = useGlobalStore.getState();
		const msgInfo = state.currentMessageData;
		console.log('@@ Add Friend getRoomChatStart msgInfo', msgInfo);
		if( msgInfo == null) {
			console.log("@@ Add Friend@@ getRoomChatStart msgInfo null : ", global.currentMessageData);
			return;
		}
		setIsLoading(true);
		const roomMsgReqeuest = () => {
			const node = {} as RoomChatMsgListRequest
			node.serviceTypeCd=msgInfo.serviceTypeCd
			node.roomNo=msgInfo.counterPart
			node.gridSize=GlobalData.chatGridSize
			node.searchChatSeq=qrCarCallInfo.searchChatSeq
			node.pagingYn='Y'        
			node.langCd=GlobalData.langCd
			return node;
		}
		qrCarCallInfo.preSearchChatSeq = qrCarCallInfo.searchChatSeq ;
		console.log('@@ Add Friend getRoomChatStart msgInfo', roomMsgReqeuest());
		const info = await callPost(ApiInfo.chatIntiList, roomMsgReqeuest()) as RoomChatInitResponse;
		if(info.hasOwnProperty('errors')) return global.showToast(info.message);
		console.log('@@ Add Friend getRoomChatStart info', info);
		console.log("@@ chat inf data : ", info);
		global.updateListRoomChatMsg(info.chatMsgList);

		if (info.chatMsgList.length < GlobalData.chatGridSize) {
			qrCarCallInfo.lastChatSeq = info.lastChatSeq ;
		} 


		qrCarCallInfo.searchChatSeq = info.lastChatSeq ;
		global.updateListRoomFriend(info.friendList);		
		setMySubScr(info.mySubScr);	
		setQrSubScr(info.qrSubScr);
		setRoomTypeCd(info.roomTypeCd);

		console.log("chat room info info.qrSubScr===>",info.qrSubScr );

		const param = {} ;
			param["mType"] = 'R' ;  
			param["mykey"] = GlobalData.myKey ;
			param["msgDesc"] = '';  
			param["qrNo"] = msgInfo.qrNo;  
			param["langCd"] = GlobalData.langCd;  
			param["currentDate"] = GetDate();  
			param["callSeq"] = info.lastChatSeq  ;  
			param["membNo"] = GlobalData.membNo;  
			param["roomId"] = msgInfo.roomId;  //wait-init 에서 받아오는 값   loc 받는사람 구독번호
			param["onOff"] = 'Y';  //wait-init 에서 받아오는 값
			param["writeMembNo"] =  GlobalData.membNo; 
			param["serviceTypeCd"] = msgInfo.serviceTypeCd;
			param["fileImgUrl"] = '';
			param["filePath"] = '';         
			param["counterPart"] = msgInfo.counterPart ;   // loc 받는사람 회원번호
			param["targetRoomId"] = msgInfo.targetRoomId;   // Loc보내는사람구독
			param["callCount"] = 0;
			param["writeNickNm"] = '';   // loc 받는사람 회원번호
			param["writeImgFileUrl"] = '';   // Loc보내는사람구독
			param["roomNm"] = state.currentRoomInfo.roomNm;   // loc 받는사람 회원번호
			param["roomImg"] = state.currentRoomInfo.roomImg;   // Loc보내는사람구독

		console.log("sendReadMessage==========================param========>", param);
		console.log("sendReadMessage==========================msgInfo.roomId========>", msgInfo.roomId)
		// sendReadMessage(param, msgInfo.roomId);
		info.friendList.forEach(item => {
			console.log("@@ sendReadMessage==========================item========>", item.subScr);
			sendReadMessage(param, item.subScr)
		});

		setIsLoading(false);
	} 

	// 방정보 타이틀에 방의 이미지와 닉네임 정보를 가져옴
	/*
	const getTitleRoomInfo = async(serviceTypeCd, roomNo) => {
		
		const msgRoomInfoRequest = () => {
			const node = {} as MessageRoomInfoRequest
			node.serviceTypeCd=serviceTypeCd
			node.roomNo=roomNo
			return node;
		}
		const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
		if(info.hasOwnProperty('errors')) return global.showToast(info.message);
		console.log("@@ chat inf data : ", info);

		return info;
		
	} 
		*/

	function isRoomChatMsgInfo(item: ChatItem): item is RoomChatMsgInfo {
		return !('type' in item);
	}

	// const handleDelete = (msgId) => {
	// 	Alert.alert(
	// 		'삭제 확인',
	// 		'정말 삭제하시겠습니까?',
	// 		[
	// 			{
	// 				text: '취소',
	// 				style: 'cancel',
	// 			}, {
	// 				text: '확인',
	// 				style: 'destructive',
	// 				onPress: () => removeDelMsg(msgId)
	// 			}
	// 		],
	// 		{ cancelable: true }
	// 	);
	// };
	const logPressMsg = (msgOwner, item) => {
		if (msgOptionVisible) {
			return ;
		} else {
			setSelectedMsgOwner(msgOwner); 
			setSelectedMessageText(item.msgDesc || '');
			setSelectedMessageId(item.chatSeq);
			setMsgOptionVisible(true);
		}
	}

	//메세지 삭제처리
	const removeDelMsg =async () => {
		setMsgOptionVisible(false);
		
		if( msgInfo ) {
			const params = {
				roomNo:roomInfo.roomNo,
				langCd:GlobalData.langCd,
				chatSeq:selectedMessageId,
			}

			console.log('removeMyMsg call req', params);

			const info = await callPost(ApiInfo.delChatPerfMessage, params) as SaveResponse
			if( "errors" in info ) {
				global.showToast(info.message);
			} else {
				if( info.code == "20005") { //삭제 성공
					msgInfo.mType = 'DM';
					msgInfo.callSeq = selectedMessageId;

					global.listRoomFriend.forEach(item => {
						msgInfo.roomId = item.subScr;
						sendMessage(msgInfo, item.subScr)
					});
					global.removeMultiListRoomChatMsg(selectedMessageSeqs);			// db에 삭제 저장함
					mainMsgListChange();
				} else {
					global.showToast(info.message);
				}
			}
	
			global.removeListRoomChatMsg(selectedMessageId);
			mainMsgListChange();
			console.log("remove after ", global.listRoomChatMsg);
		}
	}

	//나에게만 삭제 시작
	const selectDelMsg = ()=>{		
		setDelChkUse(true);
		setMsgOptionVisible(false);
	}

	//나에게만 삭제모드 취소
	const delCancel = () => {
		setDelChkUse(false);
		setSelectedMessageSeqs([]);
	}

	const removeMyDelMsg = async () => {
		console.log("Selected Message Sequences:", selectedMessageSeqs);
		
		if( msgInfo ) {
			const params = {
				serviceTypeCd:'Protect',
				roomNo:roomInfo.roomNo,
				currentDate:GetDate(),
				langCd:GlobalData.langCd,
				gridDeleteData:selectedMessageSeqs,
			}

			console.log('removeMyMsg call req', params);

			const info = await callPost(ApiInfo.delChatMessage, params) as SaveResponse
			if( "errors" in info ) {
				global.showToast(info.message);
			} else {
				if( info.code == "20005") { //삭제 성공
					global.removeMultiListRoomChatMsg(selectedMessageSeqs);			// db에 삭제 저장함

					if (selectedMessageSeqs) {
							const maxString = selectedMessageSeqs.reduce((acc, curr) => 
								acc.localeCompare(curr) >= 0 ? acc : curr
							); 
							setSelectedMessageId(maxString);
					}

					mainMsgListChange();
				} else {
					global.showToast(info.message);
				}
			}

		}
		setMsgOptionVisible(false);
	}

	const mainMsgListChange = () => {
		
		const state = useGlobalStore.getState();
		const findListMessage = state.listRoomMessage?.find(item => item.roomNo === roomInfo.roomNo);
		console.log("@@ DM Delete data filter ", findListMessage);

		if (findListMessage?.chatSeq === selectedMessageId) {
			findListMessage.msgDesc = '삭제 되었습니다.';
			console.log("@@ DM Delete data find ", findListMessage);
			global.updateRoomChatMessage(findListMessage);
		}

		setSelectedMessageId('');
		setSelectedMessageSeqs([]);
	}

	const handleDownloadImage = () => {
		Alert.alert(
			'QR 이미지',
			'다운로드를 하시겠습니까?',
			[
			{
				text: '취소',
				style: 'cancel',
			},
			{ text: '다운로드', onPress: () => downloadImage() }, // OK 버튼 클릭 시 downloadImage 호출
			],
			{ cancelable: false }
		);
	};   
	
	const downloadImage = async () => {
		// 다운로드할 파일의 경로
		if (GlobalData.deviTpCd === 'SA') {
		  androidDownloadImage();
		} else {
		  iosDownloadImage() ;
		}
	};
	
	const androidDownloadImage = async () => {
		const { config, fs } = RNFetchBlob;
		let PictureDir = fs.dirs.DownloadDir; 
		let filePath = PictureDir + '/' + selectedImageNm;		
		return config({
			fileCache: true,
			addAndroidDownloads: {
				useDownloadManager: true, // Uses the Android native download manager
				notification: true,
				path: filePath,
				description: 'Image',
			},
		}).fetch('GET', selectedImage).then(res => {
			console.log('The file saved to ', res.path());
		}).catch((error) => {
			console.error('Download error', error);
		});
	};

	const iosDownloadImage = async () => {
		const fileName = selectedImageNm.split('/').pop(); // 파일 이름 추출
		const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}`; // 다운로드 경로
	
		try {
			// 이미지 다운로드
			const res = await RNFS.downloadFile({
				fromUrl: selectedImageNm,
				toFile: filePath,
				background: true,
			}).promise;	
			if (res.statusCode === 200) {
				// 공유
				await Share.open({
					url: `file://${filePath}`, // 'file://' 접두사를 추가하여 파일을 Sharing
					type: 'image/jpeg', // 이미지 파일 타입
				});	
				global.showToast('이미지가 공유되었습니다.');
			} else {
				Alert.alert('다운로드 실패', `상태 코드: ${res.statusCode}`);
			}
		} catch (error) {
			console.error('파일 다운로드 중 오류 발생:', error);
			Alert.alert('다운로드 오류', '파일을 다운로드하는 동안 오류가 발생했습니다.');
		}
	};

	//전송버튼 클릭시 진행
	const sendDataMessage = async (msgTypeCd:string) => {
		const state = useGlobalStore.getState();
		if( msgInfo == null ) return;

		//const state = useGlobalStore.getState()
		const qrInfo =  global.listMyQr.find(item => item.qrNo === msgInfo.qrNo);
		console.log("@@ sendDataMessage msgTypeCd : ", msgInfo);
		if (msgTypeCd == 'T') {
			if (!message.trim()) return;
		} else if (msgTypeCd == 'F') {
			if (!uploadFileInfo.downUrl.trim()) return;
		}
		const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
		
		msgInfo.mType = 'M';
		msgInfo.serviceTypeCd = 'Protect';
		msgInfo.msgTypeCd = msgTypeCd;
		msgInfo.msgDesc = msgTypeCd === 'T' ? message : uploadFileInfo.orgFileNm;
		msgInfo.callSeq = data.callSeq;		
		msgInfo.fileImgUrl = uploadFileInfo.downUrl;
		msgInfo.filePath = uploadFileInfo.fileNo;
		msgInfo.currentDate = GetDate();
		msgInfo.roomNm =  roomTypeCd==='SG' ? qrInfo?.nickNm ? qrInfo?.nickNm : global.membInfo.nickNm : state.currentRoomInfo.roomNm;
		msgInfo.roomImg = roomTypeCd==='SG' ? qrInfo?.imgFileUrl ? qrInfo?.imgFileUrl : global.membInfo.imgFileUrl : state.currentRoomInfo.roomImg;
		msgInfo.writeMembNo = GlobalData.membNo;
		setMessage('');
		setHeight(40); // 높이 초기화 추가
		setUploadFileInfo({ code: '', message: '' , fileNo: '', downUrl: '', orgFileNm: ''});
		Keyboard.dismiss() ;
 
		
		//루프 돌려서 친구들에게 메세지 전송처리함
		global.listRoomFriend.forEach(item => {
			msgInfo.roomId = item.subScr;
			console.log("@@ send msg item ==>", item, msgInfo);
			sendMessage(msgInfo, item.subScr)
			sendReadMessage(msgInfo, item.subScr)
		});

		//보낸 내용 DB저장
		const node = {} as SaveMsgDataRequest
		node.mType=msgInfo.mType
		node.mykey=msgInfo.mykey
		node.msgDesc=msgInfo.msgDesc
		node.langCd=msgInfo.langCd
		node.currentDate=msgInfo.currentDate
		node.qrNo=msgInfo.qrNo
		node.roomId=msgInfo.roomId
		node.callSeq=msgInfo.callSeq
		node.membNo=msgInfo.membNo
		node.writeMembNo=msgInfo.writeMembNo
		node.serviceTypeCd=msgInfo.serviceTypeCd
		node.fileImgUrl=msgInfo.fileImgUrl
		node.filePath=msgInfo.filePath
		node.counterPart=msgInfo.counterPart
		node.targetRoomId=msgInfo.targetRoomId
		node.writeNickNm=msgInfo.writeNickNm
		node.writeImgFileUrl=msgInfo.writeImgFileUrl
		node.msgTypeCd=msgInfo.msgTypeCd
		
		const info = await callPost(ApiInfo.saveChatMsg, node) as SaveResponse;

		// DB전송
		console.log("@@ msg file out print ", msgInfo);
		global.addRoomChatMsg(msgInfo, true);
		console.log('@@ send chatdata ==>', msgInfo);

		const newlistRoomMessage:ListRoomMessage = {
			roomNo: msgInfo.counterPart,
			profileImgFileUrl: msgInfo.roomImg,
			nickNm: msgInfo.roomNm,
			msgDesc: msgTypeCd === 'T' ? message : '파일을 보냈습니다.',
			notReadYn: 'Y',  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
			notReadCnt: global.listRoomFriend.length,
			addDt: GetDateDay(),
			addTime: GetDateTime(),
			msgTypeCd: msgTypeCd,
			roomTypeCd: roomTypeCd,
			chatSeq: data.callSeq,
			msgReDesc: '',
			callStatCd: '' ,
			serviceTypeCd: msgInfo.serviceTypeCd,
			qrNo: msgInfo.qrNo,  //내QR
			membNo: GlobalData.membNo,
			writeMembNo: GlobalData.membNo,
			sendSubScr: msgInfo.roomId,
			targetMembNo: msgInfo.targetRoomId,
			mySubScr: msgInfo.targetRoomId ,
			roomMembCnt:global.listRoomFriend.length + 1
		}

		const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgInfo.counterPart);
		if (findListMessage) {
			newlistRoomMessage.profileImgFileUrl = findListMessage.profileImgFileUrl;
			newlistRoomMessage.nickNm = findListMessage.nickNm;
			global.updateRoomMessage(newlistRoomMessage);
		} else {
			//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
			const msgRoomInfoRequest = () => {
				const node = {} as MessageRoomInfoRequest
				node.serviceTypeCd=msgInfo.serviceTypeCd
				node.roomNo=msgInfo.counterPart
				return node;
			}
			const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
			if(info.hasOwnProperty('errors')) return global.showToast(info.message);
			if (info) {
				newlistRoomMessage.profileImgFileUrl = info.imgFileUrl;
				newlistRoomMessage.nickNm = info.roomNm;
			}
			global.addRoomMessage(newlistRoomMessage);
		}
	};
 

	//리렌더링 안되도록
	// const handleToggle = useCallback((friendNo: string) => {
	// setSelectFriend(prev => {
	// 	const exists = prev.find(item => item.membNo === friendNo);
	// 	if (exists) {
	// 	return prev.filter(item => item.membNo !== friendNo);
	// 	} else {
	// 	const newFriend = searchAddFriendList.find(f => f.friendNo === friendNo);
	// 	return newFriend ? [...prev, {
	// 		roomNo: msgInfo?.counterPart || '',
	// 		membNo: newFriend.friendNo,
	// 		nickNm: newFriend.nickNm,
	// 		locationCd: newFriend.friendLocationCd,
	// 		qrNo: newFriend.friendQrNo,
	// 		alertYn: 'N',
	// 		imgFileUrl: newFriend.imgFileUrl,
	// 		subScr: newFriend.friendSubScr
	// 	}] : prev;
	// 	}
	// });
	// }, [searchAddFriendList, msgInfo]);

	const handleBack = () => {
		InteractionManager.runAfterInteractions(() => {
			closePage();
			navigation.goBack();
		});
	};

	const exitRoom = async () => {
		//EG
		
		const state = useGlobalStore.getState();
		const msgData = state.currentMessageData ;
		
		if( msgData == null ) return;
		
		const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
	
		msgData.mType = 'EG';
		msgData.serviceTypeCd = 'Protect';
		msgData.msgTypeCd = 'T';
		msgData.callSeq = data.callSeq;		
		msgData.fileImgUrl = '';
		msgData.filePath = '';
		msgData.currentDate = GetDate();
		msgData.roomNm = state.currentRoomInfo.roomNm;
		msgData.roomImg = state.currentRoomInfo.roomImg;
		msgData.writeMembNo = GlobalData.membNo;
		msgData.counterPart = state.currentRoomInfo.roomNo;
		msgData.msgDesc = global.membInfo.nickNm + '님이 대화방을 나갔습니다.' ;
				
		state.listRoomFriend.forEach(item => {
			sendMessage(msgData, item.subScr);
		});

		//필터처리
		global.deletGpListRoomMessage(msgData.counterPart);
		global.filterGroupList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);

		//그룹리스트 삭제처리

		
		//메세지 내용 db저장
		const node = {} as SaveMsgDataRequest
		node.mType='EG'
		node.mykey=msgData.mykey
		node.msgDesc=msgData.msgDesc
		node.langCd=msgData.langCd
		node.currentDate=msgData.currentDate
		node.qrNo=msgData.qrNo
		node.roomId=msgData.roomId
		node.callSeq=msgData.callSeq
		node.membNo=msgData.membNo
		node.writeMembNo=msgData.writeMembNo
		node.serviceTypeCd=msgData.serviceTypeCd
		node.fileImgUrl=''
		node.filePath=''
		node.counterPart=msgData.counterPart
		node.targetRoomId=msgData.targetRoomId
		node.writeNickNm=msgData.writeNickNm
		node.writeImgFileUrl=msgData.writeImgFileUrl
		node.msgTypeCd=msgData.msgTypeCd
		
		const info = await callPost(ApiInfo.saveChatMsg, node) as SaveResponse;

		// 그룹 디비정보 삭제처리
		const delNode = {} as RemoveDataRequest 
		delNode.removeType='G'
		myQrNo:'';
		serviceTypeCd: msgData.serviceTypeCd;
		friendQrNo: '';  // 
		friendNo: state.currentRoomInfo.roomNo;  //친구는 친구번호, 그룹은 room번호
		langCd: GlobalData.langCd;
		const gdelinfo = await callPost(ApiInfo.removeData, node) as SaveResponse;

		closePage();
		navigation.goBack();
		
	};

	const closePage = () => {
		global.updateListRoomMessage(roomInfo.roomNo, '', false); // 읽음처리 초기화
		global.updateListRoomFriend([]);
		global.setProcessScreen('');
		global.removeAllListRoomChatMsg();
	}
	// 스크롤 이벤트 핸들러
	const handleScroll = (event) => {
		const offsetY = event.nativeEvent.contentOffset.y;    
		if (offsetY <= 0) {
			// 맨 위 도달시 로드
			if (qrCarCallInfo.lastChatSeq == '' || qrCarCallInfo.preSearchChatSeq === qrCarCallInfo.searchChatSeq ) return;
		
			getMsgPaging();
		}
		setScrollTime(new Date().getTime())
	};

	const getMsgPaging = async () => {
		if (qrCarCallInfo.lastChatSeq == '' || qrCarCallInfo.preSearchChatSeq === qrCarCallInfo.searchChatSeq ) return;

		const state = useGlobalStore.getState();
		const msgInfo = state.currentMessageData;

		qrCarCallInfo.preSearchChatSeq = qrCarCallInfo.searchChatSeq

		const roomChatMsgListRequest = () => {
			const node = {} as RoomChatMsgListRequest
			node.serviceTypeCd= msgInfo == null ? 'Protect' : msgInfo.serviceTypeCd
			node.roomNo=state.currentRoomInfo.roomNo
			node.gridSize=GlobalData.chatGridSize
			node.searchChatSeq=qrCarCallInfo.searchChatSeq
			node.pagingYn='Y'        
			node.langCd=GlobalData.langCd
			return node;
		}
		
		const info = await callPost(ApiInfo.chatMsgList, roomChatMsgListRequest()) as RoomChatMsgListResponse;
		if(info.hasOwnProperty('errors')) return global.showToast(info.message);
		
		global.updateListRoomChatMsg(info.chatMsgList);

		if (info.chatMsgList.length < GlobalData.chatGridSize) {
			qrCarCallInfo.lastChatSeq = info.lastChatSeq ;
		} 
		qrCarCallInfo.searchChatSeq = info.lastChatSeq ;
	}

	const imgCamera = async() => {
		global.setLaunchModule('ImageCamera');
		const options = {
			mediaType: 'photo' as MediaType,
			maxWidth: 512,
			maxHeight: 512,
			quality: 0.5 as PhotoQuality,
			includeBase64: true,
			saveToPhotos: true
		};

		launchCamera(options, (response) => {
			if (response.didCancel) {
				console.log('User cancelled camera');
			} else if (response.errorCode) {
				console.log('Camera Error: ', response.errorMessage);
				Alert.alert('오류', '카메라를 실행하는 중 오류가 발생했습니다.');
			} else if (response.assets && response.assets.length > 0) {
				const asset = response.assets[0];
				const imageAsset: ImageAsset = {
					uri: asset.uri,
					type: asset.type,
					fileName: asset.fileName || 'camera_photo.jpg',
				};
				uploadAlert(imageAsset);
			}
		});
	}
	const imgFileSelect = async() => {
		global.setLaunchModule('ImagePicker');
		launchImageLibrary({
			mediaType: 'photo',
			maxWidth: 512,
			maxHeight: 512,
			quality: 0.5,
			includeBase64: true
		}, 
		(response) => {
			global.setLaunchModule('');
			if (response.didCancel) {
				console.log('User cancelled image picker');
			} else if (response.assets && response.assets.length > 0) {
					const asset = response.assets[0]; 
					const imageAsset: ImageAsset = {
						uri: asset.uri, // string 타입 안전하게 할당
						type: asset.type, // type은 선택적이므로 사용
						fileName: asset.fileName || 'myProfile.jpg', // fileName이 없으면 기본값 사용
					};
				// setSelectedImage(imageAsset);      
				// console.log("selectimg ", selectedImage);             
				uploadAlert(imageAsset);
				
			} else {
				console.warn('An unexpected error occurred or no assets were returned');
			} 				
		})
	}

	const uploadAlert = (imageAss : ImageAsset) => {
		Alert.alert(
			"이미지 올리기",  // 대화상자 제목
			"이미지를 업로드 하시겠습니까?",  // 대화상자 메시지
			[
			  {
				text: "취소",
				onPress: () => console.log("취소 버튼 클릭"),
				style: "cancel"
			  },
			  {
				text: "확인",
				onPress: () => uploadImage(imageAss)
			  }
			],
			{ cancelable: false }  // 대화상자를 사용자가 직접 닫을 수 없도록 설정
		  );
	}

	

	//파일 업로드
	const uploadImage = async (imageAss : ImageAsset) => {
		//파일 업로드 여부 확인문의 
		if( msgInfo == null ) return;		
		const formData = new FormData();
		formData.append('multipartFile', {
			uri: imageAss?.uri,
			type: imageAss?.type || 'image/jpeg', // MIME 타입
			name: imageAss?.fileName|| 'photo.jpg', // 파일 이름
		});

		formData.append('fileType', 'CF')
		formData.append('currentDate', GetDate())
		formData.append('langCd', GlobalData.langCd)
		formData.append('roomNo', roomInfo.roomNo)
		formData.append('qrNo', '')
		console.log("@@ file upload formData size : ", formData);
		// let info: FileResponse = { code: '', message: '' , downUrl: ''}; // 기본값 할당
		const info: FileResponse = await callPost(ApiInfo.fileUpload, formData) as FileResponse;
		if('errors' in info ) return global.showToast(info.message);
		setUploadFileInfo(info);
	};

	useEffect(() => {
		if( uploadFileInfo.downUrl != '' ) {			
			sendDataMessage('F');
		}
	}, [uploadFileInfo]);

	const renderItem = ({ item }: { item: ChatItem }) => {
		if ('type' in item && item.type === 'date') {
			return (
				<View style={{ alignItems: 'center', marginVertical: 10 }}>
					<View style={{borderWidth:1, borderColor: '#999', borderRadius: 8 , paddingHorizontal:15, alignItems: 'center', marginVertical: 10 }}>
						<Text style={{  fontSize: 12, color: '#999' }}>{item.date}</Text>
					</View>
				</View>
			);
		}

		if (isRoomChatMsgInfo(item)) {
			if (item.myTextYn === 'Y') {
				return (
					<View style={{flexDirection:'row', justifyContent:'space-between'}}>
						{delChkUse && (
							<TouchableOpacity 
								style={{marginLeft:10, padding:5, justifyContent:'center', alignItems:'center'}}
								onPress={() => toggleMessageSelection(item.chatSeq)}
							>
								<Image
									source={
										selectedMessageSeqs.includes(item.chatSeq)
										? require('../../assets/check.png')
										: require('../../assets/check_disable.png')
									}
									style={{width:20, height:20}}
								/>
							</TouchableOpacity>
						)}
						<View style={[styles.myMessageContainer]}>
							<View style={{flexDirection:'row'}}>
								<View style={{justifyContent:'flex-end'}}>{item.notReadCnt !== 0 &&<Text style={{marginRight:5, color:'#FF851D',}}>{item.notReadCnt}</Text>}</View>
								<View style={styles.myMessageBox}>
									{item.msgTypeCd !== 'D' && item.msgTypeCd  !== 'F' && (
										<View >
										<Text
											style={{ 
												fontSize: 16, 
												lineHeight: 22,
												textDecorationLine: 'underline'  // 밑줄 추가
											}}
											numberOfLines={10}
											onLongPress={() => {
												logPressMsg('me', item)
											}}
											ellipsizeMode="tail"
											onTextLayout={(e) => {
												const lineCount = e.nativeEvent.lines.length;
												if (lineCount > 10) {
												setMessageLineExceeds(prev => ({
													...prev,
													[item.chatSeq]: true
												}));
												}
											}}>{item.msgDesc}</Text>
											
										{/* 10줄 초과 시에만 전체보기 버튼 */}
										{messageLineExceeds[item.chatSeq] && (
											<TouchableOpacity onPress={() => {
												setCurrentFullMessage(item.msgDesc);
												setTextModalVisible(true);
											}}>
												<Text style={{ color: 'black', fontWeight: 'bold', marginTop: 4 }}>전체보기</Text>
											</TouchableOpacity>
										)}
											
										</View>
									)}
									{item.msgTypeCd === 'D' && (
										<Text>{item.msgDesc}</Text>
									)}
									{item.msgTypeCd === 'F' && (
										<TouchableOpacity
											onPress={() => {
												setSelectedImage(item.roomImgUrl);
												setSelectedImageNm(item.msgDesc);
												setImageModalVisible(true);
											}}>
											<Image source={{ uri: item.roomImgUrl }} style={styles.messageImage} />
										</TouchableOpacity>
									)}
								</View>
							</View>
							<View style={styles.myMsgOption}>
								<Text style={styles.timeText}>
								{today === item.addDt ? item.addTime : `${item.addDt} ${item.addTime}`}
								</Text> 
							</View>
						</View>
					</View>
				);
			}
		
			return (
				<View style={{flexDirection:'row', }}>
					{delChkUse && (
						<TouchableOpacity 
							style={{marginLeft:10, padding:5, justifyContent:'center', alignItems:'center',alignContent:'center'}}
							onPress={() => toggleMessageSelection(item.chatSeq)}
						>
							<Image
								source={
									selectedMessageSeqs.includes(item.chatSeq)
									? require('../../assets/check.png')
									: require('../../assets/check_disable.png')
								}
								style={{width:20, height:20}}
								/>
						</TouchableOpacity>
					)}
					<View style={styles.otherMessageContainer}>
						<Image source={{ uri: item.profileImgFileUrl }} style={styles.profileImg} />
						<View style={{ flex: 1 }}>
							<Text style={styles.nickname}>{item.nickNm}</Text>
							<View style={styles.otherMessageContent}>
								<View style={styles.otherMessageBox}>
									
									{item.msgTypeCd !== 'D' && item.msgTypeCd  !== 'F' && (
									<View>
										<Text
											style={{ fontSize: 16, lineHeight: 22 }}
											numberOfLines={10}
											onLongPress={() => {
												logPressMsg('other', item)
											}}
											ellipsizeMode="tail"
											onTextLayout={(e) => {
												const lineCount = e.nativeEvent.lines.length;
												if (lineCount > 10) {
												setMessageLineExceeds(prev => ({
													...prev,
													[item.chatSeq]: true
												}));
												}
											}}>{item.msgDesc}</Text>
											
										{/* 10줄 초과 시에만 전체보기 버튼 */}
										{messageLineExceeds[item.chatSeq] && (
											<TouchableOpacity onPress={() => {
												setCurrentFullMessage(item.msgDesc);
												setTextModalVisible(true);
											}}>
												<Text style={{ color: 'black', fontWeight: 'bold', marginTop: 4 }}>전체보기</Text>
											</TouchableOpacity>
										)}
											
									</View>
									)}
									{item.msgTypeCd === 'D' && (
										<Text>{item.msgDesc}</Text>
									)}
									{item.msgTypeCd === 'F' && (
										<TouchableOpacity
											onPress={() => {
												setSelectedImage(item.roomImgUrl);
												setSelectedImageNm(item.msgDesc);
												setImageModalVisible(true);
											}}>
											<Image source={{ uri: item.roomImgUrl }} style={styles.messageImage} />
										</TouchableOpacity>
									)}
								</View>
								<View style={{ marginLeft: 6 }}>
									{item.notReadCnt !== 0 &&<Text style={{marginRight:5, color:'#FF851D',}}>{item.notReadCnt}</Text>}
									<Text style={styles.timeText}>{item.addDt} {item.addTime}</Text>
								</View>
							</View>
						</View>

						<Modal
							visible={isTextModalVisible}
							transparent
							animationType="fade"
							onRequestClose={() => setTextModalVisible(false)}
							>
							<View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.1)', justifyContent: 'center', alignItems: 'center' }}>
								<View style={{ width: '85%', height: '70%', backgroundColor: 'white', borderRadius: 10, padding: 15,  }}>
									<TouchableOpacity style={{position:'absolute', padding:15, top:0, right:5, }} onPress={() => setTextModalVisible(false)}>
										<Text style={{fontSize:22}}>X</Text>
									</TouchableOpacity>
								
								<ScrollView style={{ flex: 1, marginTop:20 }}>
									<Text style={{ fontSize: 16, lineHeight: 22 }}>
									{currentFullMessage}
									</Text>
								</ScrollView>
								</View>
							</View>
						</Modal>
						<Modal
							visible={msgOptionVisible}
							transparent
							animationType="fade"
							onRequestClose={() => setMsgOptionVisible(false)}
						>
							<TouchableWithoutFeedback onPress={() => setMsgOptionVisible(false)}>
								<View style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.1)', justifyContent: 'center', alignItems: 'center' }}>
									<View style={{ width: '75%', height: 170, backgroundColor: 'white', borderRadius: 10, padding: 15, justifyContent:'center' }}>
										<TouchableOpacity style={{position:'absolute', padding:15, top:0, right:5, zIndex:999}} onPress={() => setMsgOptionVisible(false)}>
											<Text style={{fontSize:22}}>X</Text>
										</TouchableOpacity>
										<View style={{backgroundColor:'white', paddingHorizontal:15, }}>
											<TouchableOpacity style={{paddingVertical:10}} onPress={() => {
												Clipboard.setString(selectedMessageText);
												if (Platform.OS === 'android') {
												ToastAndroid.show('클립보드에 복사되었습니다.', ToastAndroid.SHORT);
												} else {
												Alert.alert('알림', '클립보드에 복사되었습니다.');
												}
												setMsgOptionVisible(false); // 모달 닫기
											}}><Text style={{fontSize:16}}>복사</Text></TouchableOpacity>
											<TouchableOpacity style={{paddingVertical:10}}  onPress={selectDelMsg}><Text style={{fontSize:16}}>나에게만 삭제</Text></TouchableOpacity>
											{selectedMsgOwner === 'me' && (<TouchableOpacity style={{ paddingVertical: 10 }} onPress={removeDelMsg} ><Text style={{ fontSize: 16 }}>전체 삭제</Text></TouchableOpacity>
											)}
										</View>

										
									</View>
								</View>
								</TouchableWithoutFeedback>
						</Modal>
					</View>
				</View>
			);
		};

		return null;
	};

	// 위치 보기 확대/축소 버튼 클릭시 호출되는 함수
	const handleZoomIn = () => {
		if (!mapRef.current) return;
		const newRegion = {
			...mapRegion,
			latitudeDelta: mapRegion.latitudeDelta / 2,
			longitudeDelta: mapRegion.longitudeDelta / 2,
		};
		setMapRegion(newRegion);
		mapRef.current.animateToRegion(newRegion, 300);
	};

	const handleZoomOut = () => {
		if (!mapRef.current) return;
		const newRegion = {
			...mapRegion,
			latitudeDelta: mapRegion.latitudeDelta * 2,
			longitudeDelta: mapRegion.longitudeDelta * 2,
		};
		setMapRegion(newRegion);
		mapRef.current.animateToRegion(newRegion, 300);
	};

	const roomFriendLocation = async () => {
		// 채팅방 친구 위치 조회
		const info = await callGet('/api/msg/get-location', { roomNo: roomInfo.roomNo }) as RoomFriendLocationRequest;
		console.log("@@ roomFriendLocation info", info, global.listRoomFriend, global.listLocation);
		if( info.code=='200' ) {
			const state = useGlobalStore.getState();
			const friendLocationList = info.friendLocationList;
			friendLocationList.forEach(item => {
				const friend = state.listRoomFriend.find(subitem => subitem.membNo === item.friendNo);
				if( friend ) {
					// global.listLocation 리스트에 친구 위치가 등록되었는지 체크
					// const location = state.listLocation.find(subitem=>subitem.membNo===item.friendNo);
					state.updateListLocation({
						membNo: item.friendNo,
						latitude: item.latitude,
						longitude: item.longitude,
						nickNm: friend.nickNm,
						profileImgFileUrl: friend.imgFileUrl,
					} as FriendLocation); 
				}
			});
		} 
		setShowMarkers(true);
	}

	// 위치 정보 업데이트를 위한 useEffect
	useEffect(() => {
		if( showMap ) {	
			roomFriendLocation();			
			const moveMap = () => {
				const state = useGlobalStore.getState();
				// console.log("@@ moveMap ==================> ", state.infoLocation, state.listLocation );
				if( mapRef.current && state.infoLocation.latitude !== 0  ) {
					const initialRegion = {
						latitude: state.infoLocation.latitude,
						longitude: state.infoLocation.longitude,
						latitudeDelta: 0.005,
						longitudeDelta: 0.005,
					}; 
					// reqLocationCheck();
					setMapRegion(initialRegion);
					global.setMapMode(true);
					mapRef.current.animateToRegion(initialRegion, 300);
					flatListRef.current?.scrollToEnd({ animated: true })
				} else {
					setTimeout(moveMap, 500);
				}
			}
			// 지도가 처음 열릴 때 내 위치로 확대
			// global.updateInfoLocation({latitude: 0, longitude: 0});
			startLocationUpdates();				
			setTimeout(moveMap, 500);
		} else {			
			setShowMarkers(false);
			stopLocationUpdates(); 
			global.setMapMode(false);
		}
	}, [showMap]);


	// 위치 보기 화면구현 함수
	const renderMap = () => {
		const state = useGlobalStore.getState();
		return (
			<View style={[{display: showMap ? 'flex' : 'none'}, styles.mapContainer, mapFullScreen && styles.mapFull]}>
				<View style={styles.mapControls}>
					{!mapFullScreen ? (
						<>
							<TouchableOpacity onPress={() => setMapFullScreen(true)} style={styles.mapButton}>
								<Text style={styles.mapButtonText}>크게</Text>
							</TouchableOpacity>
							<TouchableOpacity onPress={() => {
								setShowMap(false); 
							}} style={styles.mapButton}>
								<Text style={styles.mapButtonText}>닫기</Text>
							</TouchableOpacity>
						</>
					) : (
						<>
							<TouchableOpacity onPress={() => setMapFullScreen(false)} style={styles.mapButton}>
								<Text style={styles.mapButtonText}>작게</Text>
							</TouchableOpacity>
							<TouchableOpacity onPress={() => {
								setShowMap(false);
							}} style={styles.mapButton}>
								<Text style={styles.mapButtonText}>닫기</Text>
							</TouchableOpacity>
						</>
					)}
				</View>

				<MapView
					ref={mapRef}
					key={`map-${mapKeyIndex}`}
					initialRegion={mapRegion} 
					style={styles.map}
					showsUserLocation={true}
					showsMyLocationButton={true}
					showsCompass={true}
					showsScale={true}
					showsBuildings={true}
					provider="google"
				>
					<Marker
						key="myLocation"
						coordinate={{
							latitude: state.infoLocation.latitude,
							longitude: state.infoLocation.longitude,
						}}
					/>
					{ state.listLocation.map((location, index) => (
						<Marker
							key={location.membNo}
							coordinate={{
								latitude: location.latitude,
								longitude: location.longitude,
							}}
						>
							<View style={styles.markerContainer}>
								<Image 
									source={{ uri: location.profileImgFileUrl }} 
									style={styles.markerImage}
								/>
								<View style={styles.markerTextContainer}>
									<Text style={styles.markerText}>{location.nickNm || '친구'}</Text>
								</View>

							</View>
						</Marker>
					))}
				</MapView> 				
				<View style={ Platform.OS === 'ios' ? styles.zoomControls_ios : styles.zoomControls}>
					<TouchableOpacity onPress={handleZoomIn} style={styles.zoomButton}>
						<Text style={styles.zoomButtonText}>+</Text>
					</TouchableOpacity>
					<TouchableOpacity onPress={handleZoomOut} style={styles.zoomButton}>
						<Text style={styles.zoomButtonText}>-</Text>
					</TouchableOpacity>
				</View>
			</View>
		);
	};
	const toggleOptionBox = () => {
		if( !showOptionBox ) {
			setTimeout(()=>flatListRef.current?.scrollToEnd({ animated: true }), 500)
		}
		setShowOptionBox(!showOptionBox);
	}


	//////////////////////////////친구추가 로직
	//친구추가 버튼 처리
	const addFriendChat = () => {
		const state = useGlobalStore.getState();
		//친구추가 팝업 오픈
		// searchFriendList = state.listFriend
		setSearchAddFriendList([]);
		setSelectFriend([]);
		//console.log("addFriendChat=listFriend==>", global.listFriend);
		state.listFriend.forEach(item => {
			const targetData = global.listRoomFriend.find(subitem => subitem.membNo === item.friendNo);			
			if (!targetData) {
				setSearchAddFriendList(prevList => [...prevList, item]);
			}
		});
		
		setIsModalVisible(true);
	} 

	//통화 버튼 처리
	const callFriend= async () =>{
		const msgInfo = global.currentMessageData;
		if( msgInfo == null ) return;
		const msgData = await global.getMessageData('Call', msgInfo.targetRoomId, msgInfo.roomId);
		console.log('@@RC data', msgData);
		const seqData: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
		//msgData.mType = 'RC';
		msgData.callSeq = seqData.callSeq;
		sendMessage(msgData, msgData.roomId);
		global.setCurrentSendData(msgData);
		saveCallData(msgData);
		navigation.navigate('Calling'); 
	}

	const saveCallData =async (msgData:MessageData) => {
		const state = useGlobalStore.getState();
		
		if( msgData ) {
			const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
			msgData.callSeq = data.callSeq;

			//통화요청 저장
			msgData.mType = 'RC';
			msgData.msgDesc = '통화 호출';
			const info = await callPost(ApiInfo.saveChatMsg, msgData) as SaveResponse;

			//채팅룸에 데이타 추가및 메인에 화면 정보 저장처리함 - 바탕도 업데이트 처리함
			if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
				console.log("@@ call ==========================>", msgData);
				msgData.msgDesc = '통화 호출';
				global.addRoomChatMsg(msgData, true);
			}

			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			
			if( findListMessage) {
				if( !findListMessage.nickNm ) {
					const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
					console.log("@@ receiveDataProcess friend", friend);
					if( friend ) {
						findListMessage.nickNm = friend.nickNm;
					}
				}
				findListMessage.msgDesc = '통화 호출';
				findListMessage.notReadYn = 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				findListMessage.addDt = GetDateDay();
				findListMessage.addTime = GetDateTime();	
				findListMessage.chatSeq = data.callSeq;				 
				findListMessage.notReadCnt = findListMessage.notReadCnt ;				
				console.log("@@ receiveDataProcess findListMessage", findListMessage);
				global.updateRoomChatMessage(findListMessage);
			} else {
				//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
				const msgRoomInfoRequest = () => {
					const node = {} as MessageRoomInfoRequest
					node.serviceTypeCd=msgData.serviceTypeCd
					node.roomNo=msgData.counterPart
					return node;
				}
				const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
				if(info.hasOwnProperty('errors')) return global.showToast(info.message);
				const updateListRoomMessage:ListRoomMessage = {
					roomNo: msgData.counterPart,
					profileImgFileUrl: '',
					nickNm: '',
					msgDesc: '통화 호출',
					notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
					notReadCnt: 0,
					addDt: GetDateDay(),
					addTime: GetDateTime(),
					msgTypeCd: msgData.msgTypeCd,
					roomTypeCd: '',
					chatSeq: data.callSeq,
					msgReDesc: '',
					callStatCd: '' ,
					serviceTypeCd: msgData.serviceTypeCd,
					qrNo: msgData.roomId,  //내QR
					membNo: GlobalData.membNo,
					writeMembNo: msgData.writeMembNo,
					sendSubScr: msgData.targetRoomId,
					targetMembNo: msgData.roomId,
					mySubScr: msgData.roomId,
					roomMembCnt: 0,
				}
				if (info) {
					updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
					updateListRoomMessage.nickNm = info.roomNm;
				}
				console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
				global.addRoomMessage(updateListRoomMessage);
			}
		}
	}


	const friendInfo = () => {
		setShowMenu(false);
		const roomNo = roomInfo.roomNo;
		navigation.navigate("Group",{roomNo: roomNo} )
	} 


	const closeModal = () => {
		setSelectFriend([]);
		setIsModalVisible(false);	
		setInfoModalVisible(false);			
	}

	const onAddFriend = async() => {
		console.log('@@ Add Friend ', roomTypeCd);
		const preRoomNo = roomInfo.roomNo ;
		const preRoomTypeCd = roomTypeCd
	
		setIsModalVisible(false);
		
		if (msgInfo == null) return;
		console.log("@@ Add Friend selectFriend", selectFriend);
		const msgData = await global.getChatMessageData(msgInfo?.serviceTypeCd, msgInfo?.counterPart, selectFriend);
		console.log('@@ dwkim 1 Add Friend  msgData', msgData);
		global.setCurrentMessageData(msgData);		
		
		// DB에 초대내역 저장하고 
		//친구 추가 메세지 전송
		await addFriendSendMsg(msgData, preRoomTypeCd, preRoomNo) ; // 메세지 전송
		
		// 환경 세팅
		await addFriendInit(preRoomTypeCd);
		console.log('@@ dwkim 3 Add Friend  msgData', global.currentMessageData);
		//전송처리후 초기화 한다.
		setSelectFriend([]);
	}

	const addFriendInit =  (preRoomTypeCd:string) => {
		console.log('@@ Add Friend addFriendInit');
		if (preRoomTypeCd === 'SG' ) {
			console.log('@@ Add Friend addFriendInit SG');
			//화면 새로 세팅
			// 채팅데이타를 불러온다.
			replaceChatRoom();
		} else {  //멤버만 추가 저장함		
			console.log('@@ Add Friend addFriendInit EF',global.listFriend );	
			selectFriend.forEach(item => {
				const targetData = global.listFriend.find(subitem => subitem.friendNo === item.membNo);
				const addF = {
					roomNo: roomInfo.roomNo,
					membNo: targetData?.friendNo,
					nickNm: targetData?.nickNm,
					locationCd: targetData?.friendLocationCd,
					qrNo: targetData?.friendQrNo,
					alertYn: 'N',
					subScr: targetData?.friendSubScr,
					imgFileUrl: targetData?.imgFileUrl,
				} as ChatFriendInfo
				global.addListRoomFriend(addF);
			});
		}
	}

	// useEffect(() => {
	// 	console.log('@@ Add Friend effect ========================', global.currentMessageData);
	// 	if (global.currentMessageData == null) return;
	// 	setMsgInfo(global.currentMessageData);  //채팅데이타 		
	// 	setRoomInfo({roomNo: global.currentMessageData.counterPart, roomNm: ''});   //방정보 
	// }, [global.currentMessageData,msgInfo, roomInfo]);

	const addFriendSendMsg = async(msgData:MessageData, preRoomTypeCd:string, preRoomNo: string) => {
		const state = useGlobalStore.getState();
		
		if( msgInfo == null ) return;
		
		const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
		let msgTargetNickNm = '';
		let msgNewTargetNickNm = '';

		msgData.serviceTypeCd = 'Protect';
		msgData.msgTypeCd = 'T';
		msgData.callSeq = data.callSeq;		
		msgData.fileImgUrl = '';
		msgData.filePath = '';
		msgData.currentDate = GetDate();
		msgData.roomNm = state.currentRoomInfo.roomNm;
		msgData.roomImg = state.currentRoomInfo.roomImg;
		msgData.writeMembNo = GlobalData.membNo;
		selectFriend.forEach(item => {
			msgNewTargetNickNm =  (msgNewTargetNickNm === '' ? '' : ',')  + item.nickNm ;
		});

		
		msgNewTargetNickNm = msgNewTargetNickNm + ' 님 대화방에 초대되었습니다.';
		msgTargetNickNm = msgNewTargetNickNm + ' 님 대화방에 초대되었습니다.'; //global.membInfo.nickNm + ' 님이 ' + msgNewTargetNickNm +'님을 대화방에 초대하였습니다.';
		
		if (preRoomTypeCd == 'SG') {
			// 1:1방에서 
			msgData.mType = 'NG'; //그룹이 새로 생성되었을경우
			msgData.filePath = preRoomNo;  //기존 열려진 방번호 전달 받아처리하기위해 전달함=====================
			
			console.log("@@ Add Friend listRoomFriend  ", state.listRoomFriend);
			state.listRoomFriend.forEach(item => {
					msgData.msgDesc = msgNewTargetNickNm ;
					msgData.roomId = item.subScr
					
					sendMessage(msgData, item.subScr);
			});
			selectFriend.forEach(item => {
					msgData.msgDesc = msgTargetNickNm ;
					msgData.roomId = item.subScr
					console.log('@@ Add Friend send existnew.subScr', item.subScr);
					sendMessage(msgData, item.subScr);
			});
			console.log('@@ Add Friend send', preRoomTypeCd);
		} else {
			state.listRoomFriend.forEach(item => {
					msgData.mType = 'EF'; // 기존 대화자일경우
					msgData.msgDesc = msgNewTargetNickNm ;
					msgData.roomId = item.subScr
					sendMessage(msgData, item.subScr);  // item.roomId
			});
			selectFriend.forEach(item => {
				msgData.mType = 'NF';  // 신규초대자일경우
				msgData.msgDesc = msgTargetNickNm ;
				msgData.roomId = item.subScr
				sendMessage(msgData, item.subScr);
			});
		}
		//메세지 내용 db저장
		const node = {} as SaveMsgDataRequest
		node.mType='NF'
		node.mykey=msgData.mykey
		node.msgDesc=msgNewTargetNickNm
		node.langCd=msgData.langCd
		node.currentDate=msgData.currentDate
		node.qrNo=msgData.qrNo
		node.roomId=msgData.roomId
		node.callSeq=msgData.callSeq
		node.membNo=msgData.membNo
		node.writeMembNo=msgData.writeMembNo
		node.serviceTypeCd=msgData.serviceTypeCd
		node.fileImgUrl=''
		node.filePath=''
		node.counterPart=msgData.counterPart
		node.targetRoomId=msgData.targetRoomId
		node.writeNickNm=msgData.writeNickNm
		node.writeImgFileUrl=msgData.writeImgFileUrl
		node.msgTypeCd=msgData.msgTypeCd
		
		const info = await callPost(ApiInfo.saveChatMsg, node) as SaveResponse;


		// 화면에 출력할 내용
		if (preRoomTypeCd !== 'SG') {
			msgInfo.msgDesc = msgTargetNickNm ;
			state.addRoomChatMsg(msgInfo, true);
		}
		

		const newlistRoomMessage:ListRoomMessage = {
			roomNo: msgData.counterPart,
			profileImgFileUrl: global.membInfo.imgFileUrl,
			nickNm: global.membInfo.nickNm,
			msgDesc: msgTargetNickNm ,
			notReadYn: 'Y',  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
			notReadCnt: global.listRoomFriend.length,
			addDt: GetDateDay(),
			addTime: GetDateTime(),
			msgTypeCd: 'T',
			roomTypeCd: roomTypeCd,
			chatSeq: data.callSeq,
			msgReDesc: '',
			callStatCd: '' ,
			serviceTypeCd: msgData.serviceTypeCd,
			qrNo: msgData.qrNo,  //내QR
			membNo: GlobalData.membNo,
			writeMembNo: GlobalData.membNo,
			sendSubScr: msgData.roomId,
			targetMembNo: msgData.targetRoomId,
			mySubScr: msgData.targetRoomId ,
			roomMembCnt:global.listRoomFriend.length + 1
		}

		const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
		if (findListMessage) {
			newlistRoomMessage.profileImgFileUrl = findListMessage.profileImgFileUrl;
			newlistRoomMessage.nickNm = findListMessage.nickNm;
			global.updateRoomMessage(newlistRoomMessage);
		} else {
			//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
			const msgRoomInfoRequest = () => {
				const node = {} as MessageRoomInfoRequest
				node.serviceTypeCd=msgData.serviceTypeCd
				node.roomNo=msgData.counterPart
				return node;
			}
			const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
			if(info.hasOwnProperty('errors')) return global.showToast(info.message);
			if (info) {
				newlistRoomMessage.profileImgFileUrl = info.imgFileUrl;
				newlistRoomMessage.nickNm = info.roomNm;
			}
			global.addRoomMessage(newlistRoomMessage);
		}

		// 그룹 생성일경우 그룹정보를 가져와 재처리한다. 
		console.log('@@ Add Friend group', preRoomTypeCd);
		if (preRoomTypeCd == 'SG') {
			const chgRoomInfoRequest = () => {
				const node = {} as ChgRoomInfoRequest
				node.roomNo=msgData.counterPart
				node.langCd=GlobalData.langCd
				return node;
			}
			const info = await callPost(ApiInfo.getGrpRFInfo, chgRoomInfoRequest()) as ChgRoomInfoResponse;
			console.log('@@ Add Friend group info', info);
			if (info) {
				global.updateGroupList(info.listGroup);
				global.filterGroupList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
			}
		}
	}
	
	useEffect(() => {
		// NG  , NF,   EF
		if (global.chgRoomType == 'NG') {
			//새로운 방으로 세팅함
			console.log("@@Add Friend ==>NG-----------", global.currentMessageData);
			replaceChatRoom();
		} else if (global.chgRoomType == 'NF') {
			//처리안함
		} else if (global.chgRoomType == 'EF') {
			//친구 추가  ==> db호출하여 가져옴
		}
	}, [global.chgRoomType]);



	const searchFriend = () => {
			//친구 추가 관련 함수
	}

	function GroupMemberItem({
		friendNo,
		nickNm,
		imgFileUrl,
		introductionInfo,
		isSelected,
		onToggle,
		onRemove,
		mode,
	  }: {
		friendNo: string;
		nickNm:string
		imgFileUrl: string;
		introductionInfo: string;
		isSelected?: boolean;
		onToggle?: () => void;
		onRemove?: () => void;
		mode: 'select' | 'remove';
	  }) {
		return (
		  <View style={styles.itemContainer}>
			<Image source={{ uri: imgFileUrl}} style={styles.avatar} />
			<View style={styles.info}>
			  <Text style={styles.name}>{nickNm}</Text>
			  <Text style={styles.statusMsg} numberOfLines={1} ellipsizeMode="tail">
				{introductionInfo}
			  </Text>
			</View>
	
			{mode === 'select' && onToggle && (
			  <TouchableOpacity onPress={onToggle}>
				<Image source={
					isSelected
					  ? require('../../assets/check.png')
					  : require('../../assets/check_disable.png')
				  } style={styles.toggleButton} /> 
			  
			  </TouchableOpacity>
	
			)}
		  </View>
		);
	  }

	  //그룹멤버정보
	  
	function GroupMemberInfo({
		friendNo,
		nickNm,
		imgFileUrl
	  }: {
		friendNo: string;
		nickNm:string
		imgFileUrl: string;
	  }) {
		return (
		  <View style={styles.itemContainer}>
			<Image source={{ uri: imgFileUrl}} style={styles.avatar} />
			<View style={styles.info}>
			  <Text style={styles.name}>{nickNm}</Text>
			</View>
		  </View>
		);
	  }


	function MemberSelectModal({ 
		visible, 
		onClose, 
		onAdd 
		}) {
		const [internalSearchData, setInternalSearchData] = useState('');
		
		const handleToggle = (friendNo: string) => {
			console.log("@@ Add Friend select ", friendNo);
			const isAlready = selectFriend.find(m => m.membNo === friendNo);
			if (isAlready) {
				//삭제
				const filterList = selectFriend.filter(m => m.membNo !== friendNo);
				setSelectFriend(filterList);
			}  else  {
				//추가
				const addItem = searchAddFriendList.find(m => m.friendNo === friendNo) as FriendList ;			
					const addFriendInfo = {
						roomNo: msgInfo?.counterPart,
						membNo: addItem?.friendNo,
						nickNm: addItem?.nickNm,
						locationCd: addItem?.friendLocationCd,
						qrNo: addItem?.friendQrNo,
						alertYn: 'N',
						imgFileUrl: addItem?.imgFileUrl,
						subScr: addItem?.friendSubScr
					} as ChatFriendInfo
					setSelectFriend([...selectFriend, addFriendInfo]);
			}			
		};

		const handleAdd =() => {
			onAdd(selectFriend);
		};

		return (
			<Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
			<View style={modalStyles.modalOverlay}>
				<View style={modalStyles.modalContent}>
					<View style={{padding:20, flex:1}}>
						<Text style={modalStyles.title}>친구 추가</Text>
						<View style={{marginBottom:15, borderRadius:20, borderWidth:1, borderColor:'#FF851D', paddingHorizontal:8, flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
							<TextInput
							style={{flex:1}}
							placeholder="검색어를 입력해주세요"
							value={internalSearchData} // 🔥 내부 상태 사용
							onChangeText={setInternalSearchData} // 🔥 내부 상태 업데이트
							placeholderTextColor="#aaa"
							/>
							<TouchableWithoutFeedback onPress={() => {}}>
							<Image source={require('../../assets/ic_search.png')} style={{width:20, height:20}}/>
							</TouchableWithoutFeedback>
						</View>
						<ScrollView>
							{searchAddFriendList.map((member) => (
							<GroupMemberItem
								key={member.friendNo}
								friendNo={member.friendNo}
								nickNm={member.nickNm}
								imgFileUrl={member.imgFileUrl}
								introductionInfo={member.introductionInfo}
								isSelected={selectFriend.some(friend => friend.membNo === member.friendNo)}
								onToggle={() => handleToggle(member.friendNo)}
								mode="select"
							/>
							))}
						</ScrollView>
					</View>
					<View style={modalStyles.buttonRow}>
						<TouchableOpacity style={modalStyles.rejectButton} onPress={onClose}>
						<Text style={[modalStyles.buttonText, {color:'black'}]}>취소</Text>
						</TouchableOpacity>
						<TouchableOpacity 
						style={modalStyles.acceptButton} 
						onPress={handleAdd}>
						<Text style={modalStyles.buttonText}>추가</Text>
						</TouchableOpacity>
					</View>
				</View>
			</View>
			</Modal>
		);
	}

	const toggleMessageSelection = (messageSeq: string) => {
		setSelectedMessageSeqs(prev => {
			if (prev.includes(messageSeq)) {
				return prev.filter(seq => seq !== messageSeq);
			} else {
				return [...prev, messageSeq];
			}
		});
	};

	return (
	<React.Fragment>
		<StatusBar
		barStyle="dark-content"
		backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
		/>
		<SafeAreaView style={{ marginTop: insets.top, height: contentHeight, backgroundColor: '#fff' }}>
			<View style={styles.headerContainer}>
				<TouchableOpacity style={styles.prevButton} onPress={handleBack}>
					<Image
						source={require('../../assets/ic_arr_left.png')}
						style={styles.prevIcon}
					/>
				</TouchableOpacity>
				<View style={styles.titleContainer}>
					<Text style={styles.titleText}>{msgInfo?.serviceTypeCd === 'Car' ? '차빼줘 : ' : '지켜줘 : '} {global.currentRoomInfo.roomNm}</Text>
				</View>
				{roomTypeCd==='GP'  &&  <TouchableOpacity style={styles.homeButton} onPress={() => setShowMenu(prev => !prev)}>
					<Image
						source={require('../../assets/ico_floating_menu.png')}
						style={styles.homeIcon}
					/>
				</TouchableOpacity>}
			</View>

			{showMenu && (
				<View style={styles.dropdownMenu}>
					{/* 그룹일경우에만 출력됨 */}
					<TouchableOpacity style={styles.dropdownItem} onPress={friendInfo}>
							<Text style={{fontSize:16}}>그룹정보보기</Text>
					</TouchableOpacity>
					<TouchableOpacity style={styles.dropdownItem} onPress={exitRoom}>
							<Text style={styles.dropdownExit}>채팅방 나가기</Text>
					</TouchableOpacity>
					
				</View>
			)}

			<KeyboardAvoidingView
				behavior={Platform.OS === 'ios' ? 'padding' : undefined}
				keyboardVerticalOffset={60}
				style={{ flex: 1 }}
			>
				<View style={styles.chatListWrapper}>
					<View style={{ flex:  1 }}>
						<FlatList 
							data={listData}
							removeClippedSubviews={false}
							ref={flatListRef}
							keyExtractor={(item, index) =>
								'type' in item ? `date-${item.date}-${index}` : `chat-${item.chatSeq}-${index}`
							}
							renderItem={renderItem}
							contentContainerStyle={{paddingVertical: 10, paddingBottom: 30 }}
							showsVerticalScrollIndicator={false}
							onScroll={handleScroll}   // 아래 설정은 스크롤이 맨 위로 갔을데 데이타 가져오는 로직
							scrollEventThrottle={16} // 이벤트 호출 빈도 조절
							ListFooterComponent={isLoading ? <ActivityIndicator size="large" color="#0000ff" /> : null}
							ListEmptyComponent={<Text style={{textAlign:'center', fontSize:16, fontWeight:'bold', color:'black', marginVertical: 5}}>메시지가 없습니다.</Text>}
						/>
					</View>
					{ renderMap() }
				</View>
			</KeyboardAvoidingView>

			{delChkUse&&<View style={{flexDirection:'row', justifyContent:'space-between', alignItems:'center'}}>
				<TouchableOpacity style={{ backgroundColor:'#ddd', padding:15, flex:1}} onPress={delCancel}>
					<Text style={{textAlign:'center', fontSize:16, fontWeight:'bold', color:'#777'}}>취소</Text>
				</TouchableOpacity>
				<TouchableOpacity style={{ backgroundColor:'#FF851D', padding:15, flex:1}} onPress={removeMyDelMsg}>
					<Text style={{textAlign:'center', fontSize:16, fontWeight:'bold', color:'white'}}>삭제</Text>
				</TouchableOpacity>
			</View>}
			
			{!delChkUse&&<View style={styles.inputContainer}>
				<TouchableOpacity onPress={() => toggleOptionBox()}>
					{showOptionBox ? (
						<Image source={require('../../assets/ic_arrow_bottom.png')} style={styles.icon} />
					) : (
						<Image source={require('../../assets/ic_arrow_top.png')} style={styles.icon} />
					)}
				</TouchableOpacity> 

				<TextInput
					style={[styles.textInput, { height: Math.max(40, height) }]}
					placeholder="메시지를 입력하세요"
					placeholderTextColor="#aaa"
					value={message}
					onChangeText={setMessage}  
					onContentSizeChange={(e) => {
						setHeight(e.nativeEvent.contentSize.height);
					}}
					multiline // 줄바꿈을 허용
					onSubmitEditing={() => sendDataMessage('T')}
				/>
				<TouchableOpacity 
					onPress={() => sendDataMessage('T')}
					style={styles.sendButton}
				>
					<Text style={styles.sendButtonText}>전송</Text>
				</TouchableOpacity>
			</View>}
			{showOptionBox &&
				<View style={styles.optionBox}>						
					<View style={styles.optionRow}>
						<View style={styles.optionItem}>
							<TouchableOpacity style={{justifyContent:'center', alignItems:'center'}} onPress={imgCamera}>
							<Image source={require('../../assets/ico_ask.png')} style={styles.optionIcon} />
							<Text style={styles.optionText}>카메라</Text>
							</TouchableOpacity>
						</View>
						<View style={styles.optionItem}>
							<TouchableOpacity style={{justifyContent:'center', alignItems:'center'}} onPress={imgFileSelect}>
							<Image source={require('../../assets/ico_ask.png')} style={styles.optionIcon} />
							<Text style={styles.optionText}>이미지전송</Text>
							</TouchableOpacity>
						</View>
						<View style={styles.optionItem}>
							<TouchableOpacity style={{justifyContent:'center', alignItems:'center'}} onPress={addFriendChat}>
								<Image source={require('../../assets/ic_add_friend.png')} style={styles.optionIcon} />
								<Text style={styles.optionText}>친구추가</Text>
							</TouchableOpacity>
						</View>
						<View style={styles.optionItem}>
							<TouchableOpacity style={{justifyContent:'center', alignItems:'center'}} onPress={callFriend}>
								<Image source={require('../../assets/ic_phone_img.png')} style={styles.optionIcon} />
								<Text style={styles.optionText}>통화</Text>
							</TouchableOpacity>
						</View>
						<TouchableOpacity
							style={styles.optionItem}
							onPress={() => {
								setShowMap(true);									
								setMapFullScreen(false);
								setTimeout(() => {
									flatListRef.current?.scrollToEnd({ animated: true });
								},80); 
							}}
						>
							<Image source={require('../../assets/ic_locat_find.png')} style={styles.optionIcon} />
							<Text style={styles.optionText}>위치보기</Text>
						</TouchableOpacity>
					</View>
				</View>
			} 
			<Modal visible={isImageModalVisible} transparent={true} animationType="fade">
				<View style={styles.modalContainer}>
					{/* 모달 닫기용 배경 */}
					<TouchableOpacity style={styles.modalBackground} onPress={() => setImageModalVisible(false)} />

					{/* X 버튼 */}
					<TouchableOpacity style={styles.closeButton} onPress={() => setImageModalVisible(false)}>
						<Text style={styles.closeButtonText}>✕</Text>
					</TouchableOpacity>

					{/* 이미지 */}  
					<Image source={{ uri: selectedImage }} style={styles.fullscreenImage} resizeMode="contain" />

					{/* 다운로드 버튼 */}
					<TouchableOpacity style={styles.downloadButton} onPress={handleDownloadImage}>
						<Text style={styles.downloadButtonText}>다운로드</Text>
					</TouchableOpacity>
				</View>
			</Modal>

			<MemberSelectModal
				visible={isModalVisible}
				onClose={closeModal}
				onAdd={onAddFriend} // 선택된 ID 배열 받도록 변경
			/>
		</SafeAreaView>
	</React.Fragment>
	);
};

const modalStyles = StyleSheet.create({
	modalOverlay: {
	  flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center',
	},
	modalContent: {
	  width: '90%', backgroundColor: '#fff', borderRadius: 16,  height: '80%',
	},
	title: {
	  fontSize: 17, fontWeight: 'bold', color: '#FF851D', textAlign: 'center', marginBottom: 10,
	},
	closeButton: {
	  backgroundColor: '#FF851D', padding: 10, borderRadius: 8, marginTop: 16, alignItems: 'center',
	},
	closeButtonText: {
	  color: '#fff', fontWeight: 'bold', fontSize: 16,
	},
	buttonRow: {
		flexDirection: 'row',
		justifyContent:'space-around',
		
	
	},
	rejectButton: {
		backgroundColor: '#ccc',
		paddingVertical: 15,
		flex:1, 
		borderBottomLeftRadius:15
	},
	acceptButton: {
		backgroundColor: '#FF851D',
		paddingVertical: 15,
		flex:1,
		borderBottomRightRadius:15
	},
	buttonText: {
		color: '#fff',
		fontSize: 17,
		textAlign:'center'
	},
  });

const styles = StyleSheet.create({
	 
	chatListWrapper: { flex: 1, paddingTop: 60 },
	headerContainer: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		zIndex: 10,
		height: 60,
		backgroundColor: '#f2f7fcff',
		flexDirection: 'row',
		alignItems: 'center',
		paddingHorizontal: 10,
	},
	myMessageContainer: {
		alignItems: 'flex-end',
		paddingHorizontal: 10,
		marginVertical: 4,
		flex:1
	},
	myMessageBox: {
		backgroundColor: '#ffcc80',
		borderRadius: 12,
		padding: 8,
		maxWidth: '80%',
	},
	otherMessageContainer: {
		flexDirection: 'row',
		paddingHorizontal: 10,
		marginVertical: 4,
		flex:1,
		alignItems:'center'
	},
	profileImg: {
		width: 40,
		height: 40,
		borderRadius: 20,
		marginRight: 8,
	},
	nickname: {
		fontSize: 12,
		fontWeight: 'bold',
		color: '#333',
	},
	otherMessageContent: {
		flexDirection: 'row',
		alignItems: 'flex-end',
	},
	otherMessageBox: {
		backgroundColor: '#eee',
		borderRadius: 12,
		padding: 8,
		maxWidth: '80%',
	},
	timeText: {
		fontSize: 10,
		color: '#999',
		marginTop: 2,
	},
	inputContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		paddingHorizontal: 10,
		paddingVertical: 8,
		borderTopWidth: 1,
		borderColor: '#e0e0e0',
		backgroundColor: '#f9f9f9',
	},
	icon: {
		width: 24,
		height: 24,
		marginHorizontal: 8,
	},
	textInput: {
		flex: 1,
		paddingHorizontal: 10,
		backgroundColor: '#fff',
		borderRadius: 20,
		borderWidth: 1,
		borderColor: '#ddd',
	},
	optionBox: {
		backgroundColor: '#f2f2f2',
		paddingVertical: 12,
		paddingHorizontal: 16,
		borderTopWidth: 1,
		borderColor: '#ccc',
	},
	optionHeader: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	searchBar: {
		height: 35,
		backgroundColor: '#fff',
		borderRadius: 20,
		marginVertical: 10,
		flex: 1,
		paddingHorizontal: 10,
	},
	optionRow: {
		flexDirection: 'row',
		justifyContent: 'space-around',
		marginTop: 5,
		paddingTop: 20,
		paddingBottom: 20,
	},
	optionItem: {
		alignItems: 'center',
	},
	optionIcon: {
		width: 28,
		height: 28,
		marginBottom: 4,
	},
	optionText: {
		fontSize: 12,
		color: '#333',
	},
	prevButton: {
		width: 40,
		alignItems: 'center',
		justifyContent: 'center',
	},
	homeButton: {
		width: 40,
		alignItems: 'center',
		justifyContent: 'center',
	},
	prevIcon: {
		width: 17,
		height: 17,
		resizeMode: 'contain',
	},
	homeIcon: {
		width: 30,
		height: 30,
		resizeMode: 'contain',
	},
	titleContainer: {
		flex: 1,
		alignItems: 'center',
	},
	titleText: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#333',
	},
	dropdownMenu: {
		position: 'absolute',
		top: 60,
		right: 10,
		backgroundColor: '#fff',
		borderRadius: 8,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.2,
		shadowRadius: 4,
		elevation: 5,
		zIndex: 20,
		paddingVertical: 8,
		paddingHorizontal: 12,
	},
	dropdownItem: {
		paddingVertical: 8,
	},
	dropdownText: {
		fontSize: 14,
		color: '#333',
	},
	dropdownExit: {
		fontSize: 16,
		color: 'red',
		fontWeight: 'bold',
	},
	mapContainer: {
		height: '50%',
		backgroundColor: '#e6e6e6',
		borderTopLeftRadius: 12,
		borderTopRightRadius: 12,
	},
	mapFull: {
		height: '100%',
	},
	mapControls: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		padding: 10,
		backgroundColor: 'rgba(255,255,255,0.9)',
	},
	mapButton: {
		paddingHorizontal: 12,
		paddingVertical: 6,
		backgroundColor: '#FF851D',
		borderRadius: 8,
	},
	mapButtonText: {
		color: '#fff',
		fontWeight: 'bold',
	},
	mapImage: {
		flex: 1,
		width: '100%',
	},
	mapSmallButton: {
		position: 'absolute',
		top: 10,
		right: 10,
		paddingHorizontal: 12,
		paddingVertical: 6,
		backgroundColor: '#FF851D',
		borderRadius: 8,
	},
	sendImg:{
		width:80,
		height:80,
	},
	downloadBtn: {
		marginLeft: 10,
		justifyContent: 'center',
		alignItems: 'center',
	},
	
	downloadIcon: {
		width: 16,
		height: 16,
		tintColor: '#555', // 필요시 색상 변경
	},
	messageImage: {
		width: 150,
		height: 150,
		borderRadius: 10,
		marginTop: 5,
	},
	modalContainer: {
		flex: 1,
		backgroundColor: 'rgba(0,0,0,0.9)',
		justifyContent: 'center',
		alignItems: 'center',
	},
	modalBackground: {
		position: 'absolute',
		top: 0, bottom: 0, left: 0, right: 0,
	},
	fullscreenImage: {
		width: '100%',
		height: '80%',
	},
	downloadButton: {
		position: 'absolute',
		bottom: 40,
		backgroundColor: '#FF851D',
		paddingHorizontal: 20,
		paddingVertical: 10,
		borderRadius: 20,
	},
	downloadButtonText: {
		color: '#000',
		fontSize: 16,
		fontWeight: 'bold',
	},
	closeButton: {
		position: 'absolute',
		top: 40,
		right: 20,
		zIndex: 10,
		borderRadius: 20,
		paddingHorizontal: 12,
		paddingVertical: 4,
	},
	closeButtonText: {
		color: '#FF851D',
		fontSize: 22,
		fontWeight: 'bold',
	},
	myMsgOption:{
		flexDirection:'row',
		justifyContent:'flex-end',
		alignContent:'center',
		alignItems:'center'
	},
	msgBtn:{
		width: 18,
		height: 18,
		marginRight:5,
	},
	map: {
		flex: 1,
		width: '100%',
	},
	zoomControls: {
		position: 'absolute',
		right: 10,
		bottom: 20,
		backgroundColor: 'rgba(255, 255, 255, 0.9)',
		borderRadius: 8,
		padding: 5,
	},
	zoomControls_ios: {
		position: 'absolute',
		right: 10,
		top: 55,
		backgroundColor: 'rgba(255, 255, 255, 0.9)',
		borderRadius: 8,
		padding: 5,
	},
	zoomButton: {
		width: 40,
		height: 40,
		backgroundColor: '#FF851D',
		borderRadius: 20,
		justifyContent: 'center',
		alignItems: 'center',
		marginVertical: 2,
	},
	zoomButtonText: {
		fontSize: 24,
		color: '#fff',
		fontWeight: 'bold',
	},
	markerContainer: {
		width: 40,
		height: 40,
		borderRadius: 20,
		backgroundColor: '#fff',
		borderWidth: 2,
		borderColor: '#FF851D',
		overflow: 'hidden',
		alignItems: 'center',
	},
	markerImage: {
		width: '100%',
		height: '100%',
		borderRadius: 18,
	},
	markerTextContainer: {
		position: 'absolute',
		fontSize: 9,
		bottom: 5,
		backgroundColor: 'rgba(0, 0, 0, 0.7)',
		paddingHorizontal: 2,
		paddingVertical: 2,
		borderRadius: 2,
	},
	markerText: {
		color: '#fff',
		fontSize: 12,
		fontWeight: 'bold',
	},
	sendButton: {
		paddingHorizontal: 16,
		paddingVertical: 8,
		backgroundColor: '#FF851D',
		borderRadius: 20,
		marginLeft: 8,
		justifyContent: 'center',
		alignItems: 'center',
	},
	sendButtonText: {
		color: '#fff',
		fontSize: 14,
		fontWeight: 'bold',
	},

	//GroupMemberItem 스타일일
	itemContainer: {
		flexDirection: 'row',
		backgroundColor: '#FFF6EF',
		borderRadius: 10,
		padding: 10,
		marginBottom: 8,
		alignItems: 'center',
	},
	info: {
		flex: 1,
	},
	name: {
		fontSize: 16,
		color: '#000',
		fontWeight: 'bold',
	},
	statusMsg: {
		fontSize: 12,
		color: '#888',
		flexShrink: 1,
		maxWidth: '90%',
	},
	toggleButton: {
		width: 24,
		height: 24,
		marginLeft: 8,
	},
	avatar: {
		width: 40,
		height: 40,
		borderRadius: 20,
		marginRight: 12,
	},
});

export default ChatScreen;
