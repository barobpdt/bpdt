import React, { useState, useEffect } from 'react';
import {
	View,
	Text,
	TextInput,
	StyleSheet,
	ScrollView,
	KeyboardAvoidingView,
	Platform,
	TouchableOpacity,
	Modal,
	Image,
	TouchableWithoutFeedback,
	Keyboard,
	Alert,
	StatusBar
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList, FriendList, GroupInfoRequest, SaveGroupFriendRequest , GroupFriendInfo
			, GroupListResponse, GroupInfoResponse, ChgRoomNmRequest, ChgRoomNmResponse, ListRoomMessage} from '../../types/common.tsx';
import { useGlobalStore, GetDate, GlobalData, apiCallPost, MembInfo, callPost} from '../../store/global';
import ApiInfo from '../../gvar/ApiInfo.tsx';
import { SafeAreaView } from 'react-native-safe-area-context';

const GroupScreen = ({ route }) => {
	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
	const global = useGlobalStore();

	const [roomNm, setRoomNm] = useState('');
	const [searchData, setSearchData] = useState('');
	const [qrNo, setQrNo] = useState('');

	const [orgFriendList, setOrgFriendList] = useState<FriendList[]>([]) ;  //원본 그룹에 추가되어져 있는 대상 리스트
	const [addFriendList, setAddFriendList] = useState<FriendList[]>([]) ;  //추가 
	const [delFriendList, setDelFriendList] = useState<FriendList[]>([]) ;  //삭제대상
	const [groupFriendList, setGroupFriendList] = useState<FriendList[]>([]) ;  //그룹 대상
	const [searchFriendList, setSearchFriendList] = useState<FriendList[]>([]) ;  //검색 대상


	const [isModalVisible, setModalVisible] = useState(false);


	// 수정 버튼 핸들러
	const handleUpdate = () => {
		console.log(roomNo, global.qrClickData.qrNo )
		// 여기에 API 호출 등 추가 로직 구현 가능
		setGroupNameAPI()
	};

	const setGroupNameAPI= async() => { 		
		const param =  {
			roomNo: roomNo,
			qrNo: qrNo,
			nickNm: roomNm,
			currentDate: GetDate(),
			langCd: GlobalData.langCd,
		} as ChgRoomNmRequest
		console.log("@@ Group info ", param);
		const info = await callPost(ApiInfo.chgRoomNm, param) as ChgRoomNmResponse;
		console.log('=======info========',info)
		if('errors' in info) return global.showToast('그룹명 변경 오류:'+info.message);
		else{
			//그룹리스트 변경
			let groupInfo: ListRoomMessage|undefined = global.listGroup.find(item => item.roomNo == roomNo);
			if (!groupInfo) {return;} ;
			groupInfo.nickNm = roomNm;	
			global.updateGroup(groupInfo);
			global.currentRoomInfo.roomNm = roomNm;
			
			let roomMessage: ListRoomMessage | undefined = global.listRoomMessage.find(item => item.roomNo == roomNo);
						console.log("@@ roomMessage==>", roomMessage);
						if (roomMessage) {              
							const newlistRoomMessage:ListRoomMessage = {
									roomNo: roomMessage.roomNo,
									profileImgFileUrl: roomMessage.profileImgFileUrl,
									nickNm: roomNm,
									msgDesc: roomMessage.msgDesc,
									notReadYn: roomMessage.notReadYn,
									notReadCnt: roomMessage.notReadCnt,
									addDt: roomMessage.addDt,
									addTime: roomMessage.addTime,
									msgTypeCd: roomMessage.msgTypeCd,
									roomTypeCd:roomMessage.roomTypeCd,
									chatSeq: roomMessage.chatSeq,
									msgReDesc: roomMessage.msgReDesc,
									callStatCd: roomMessage.callStatCd ,
									serviceTypeCd: roomMessage.serviceTypeCd,
									qrNo: roomMessage.qrNo,  //내QR
									membNo: roomMessage.membNo,
									writeMembNo: roomMessage.writeMembNo,
									sendSubScr: roomMessage.sendSubScr,
									targetMembNo: roomMessage.targetMembNo,
									mySubScr: roomMessage.mySubScr ,
									roomMembCnt: roomMessage.roomMembCnt,
								}
			
							console.log("@@ roomMessage change ==>", roomNm, newlistRoomMessage);
							global.updateRoomMessage(newlistRoomMessage);
						}


			global.showToast('그룹명이 변경 되었습니다.');
		}
	}



	let roomNo = route.params.roomNo;

	useEffect(() => {
		console.log("@@ Group No " , roomNo);
		if (roomNo !== '') {
			//DB에서 불러오기    
			getGroupInfo();
		} else {
			setSearchFriendList(global.listFriendCurrent);
		}
		 
	}, []);


	// 그룹번호가 존재시 그렙 내역 가져오기
	const getGroupInfo = async() => {
		console.log("group call");
		const groupRequestParam = () => {
		const node = {} as GroupInfoRequest
		node.roomNo = roomNo
		node.langCd = GlobalData.langCd
		return node;
		}
		console.log("group request" , groupRequestParam());
		try {
			await apiCallPost(ApiInfo.infoGroup, groupRequestParam(), (type:string, obj:object) => {
			// console.log("group info call result", type);
			if( type=='ok' ) {
				const info = obj as GroupInfoResponse
				setOrgFriendList(info.listGroupFriend);
				setGroupFriendList(info.listGroupFriend);
				roomNo = info.roomNo;
				console.log("@@ group info call data", groupFriendList);
				setQrNo(info.qrNo);
				setRoomNm(info.roomNm);
			}
		})
		} catch (error) {
				
				console.error("API 호출 중 오류 발생:", error);
		}
				
	}

	const saveChkGroup = () => {
		console.log("===========saveChkGroup");
		if (roomNo  == '') {
			if (addFriendList.length === 0 ) {
				global.showToast('추가할 친구내역이 없습니다.!');
				return;
			}
		}

		if (roomNm === '') {
			global.showToast('그룹명을 입력해주세요!');
			return;
		}

		saveGroup();
	}


	const saveGroup = () => {
		console.log("===========saveGroup");
		const GroupRequestParam = () => {
			const node = {} as SaveGroupFriendRequest
			node.serviceTypeCd = 'Protect' ;
			node.roomNo =  roomNo;
			node.roomNm =  roomNm;
			node.qrNo = global.qrClickData.qrNo;
			node.currentDate =  GetDate();
			node.langCd = GlobalData.langCd;
			node.gridInsertData = addFriendList;
			node.gridDeleteData = delFriendList;
			return node;
		}
		try {
			console.log("================>request", GroupRequestParam());
			apiCallPost(ApiInfo.saveGroup, GroupRequestParam(), (type:string, obj:object) => {
				console.log("===========apiCallPost", type);
				if( type=='ok' ) {
					const info = obj as GroupListResponse
					if (info.code === '20001') {
							//저장 성공  
							console.log("===========info.listGroup   ok", info.listGroup);
							global.updateGroupList(info.listGroup);
							global.filterGroupList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
							
							navigation.goBack();

					} else {
						Alert.alert(info.message);
					}
				}
			})
		} catch (error) {
				console.error("API 호출 중 오류 발생:", error);
		}
	}


	const handleBack = () => {
		navigation.goBack();
	};

	const addMember = () => {
		setModalVisible(true);
	}

	const closeModal = () => {
		setModalVisible(false);
	}
	
//검색
	const searchFriend = () => {
		//searchData
		console.log(" search data ====>", searchData);
		setSearchFriendList(global.listFriendCurrent.filter(m => m.nickNm.includes(searchData)));

	}
	

	const removeMember = (friendNo: string) => {

		const isAlready = groupFriendList.find(m => m.friendNo === friendNo);
		const delMember = orgFriendList.find(m => m.friendNo === friendNo);
		if (isAlready) {  // 삭제              
			//org 있는데 삭제시 삭제 에 입력
			if (delMember) {
					setDelFriendList([...delFriendList, delMember]);
			}
			setGroupFriendList(groupFriendList.filter(m => m.friendNo !== friendNo));
		} 
	
	};

	function GroupMemberItem({
		friendNo,
		nickNm,
		imgFileUrl,
		introductionInfo,
		isSelected,
		onToggle,
		onRemove,
		mode,
	}: {
		friendNo: string;
		nickNm:string
		imgFileUrl: string;
		introductionInfo: string;
		isSelected?: boolean;
		onToggle?: () => void;
		onRemove?: () => void;
		mode: 'select' | 'remove';
	}) {
		// console.log("@@ GroupMemberItem", friendNo, nickNm);
		return (
			<View style={styles.itemContainer}>
				<Image source={{ uri: imgFileUrl}} style={styles.avatar} />
				<View style={styles.info}>
					<Text style={styles.name}>{nickNm}</Text>
					<Text style={styles.statusMsg} numberOfLines={1} ellipsizeMode="tail">
						{introductionInfo}
					</Text>
				</View>
				{/* {mode === 'select' && onToggle && (
					<TouchableOpacity onPress={onToggle}>
						<Image source={
								isSelected
									? require('../../assets/ic_del_circle.png')
									: require('../../assets/ic_plus_circle.png')
							} style={styles.toggleButton} /> 
					
					</TouchableOpacity>

				)}

				{mode === 'remove' && onRemove && (
					<TouchableOpacity onPress={onRemove}>
						<Image
							source={require('../../assets/ic_del_circle.png')}
							style={styles.toggleButton}
						/>
					</TouchableOpacity>
				)} */}
			</View>
		);
	}

	// MemberSelectModal 정의
	function MemberSelectModal({ visible, selected, members, onToggle, onClose }) {
		return (
			<Modal  visible={visible} transparent animationType="fade" onRequestClose={onClose}>			
				<View style={modalStyles.modalOverlay}>					
					<View style={modalStyles.modalContent}>
						<Text style={modalStyles.title}>친구 추가</Text>
						<View style={{marginBottom:15, borderRadius:20, borderWidth:1, borderColor:'#FF851D', paddingHorizontal:8, flexDirection:'row', alignItems:'center', justifyContent:'space-between'}}>
							<TextInput
								style={{flex:1}}
								placeholder="검색어를 입력해주세요"
								value={searchData}
								onChangeText={setSearchData}
								placeholderTextColor="#aaa"
							/>
							<TouchableWithoutFeedback onPress={searchFriend}>
								<Image source={require('../../assets/ic_search.png')} style={{width:20, height:20}}/>
							</TouchableWithoutFeedback>
						</View>
						<ScrollView>
							{searchFriendList.map((member) => {
								const isSelected = selected.includes(member.friendNo);
								return (
									<GroupMemberItem
										key={member.friendNo}
										friendNo={member.friendNo}
										nickNm={member.nickNm}
										imgFileUrl={member.imgFileUrl}
										introductionInfo={member.introductionInfo}
										isSelected={isSelected}
										onToggle={() => onToggle(member.friendNo)}
										mode="select"
									/>
								);
							})}
						</ScrollView>
						<TouchableOpacity style={modalStyles.closeButton} onPress={onClose}>
							<Text style={modalStyles.closeButtonText}>닫기</Text>
						</TouchableOpacity>
					</View>
					
				</View>
				
			</Modal>
		);
	}

	return (
		<React.Fragment>
			<StatusBar
			barStyle="dark-content"
			backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
			/>
		<SafeAreaView style={styles.bottomContainer}>
			<KeyboardAvoidingView
				style={styles.container}
				behavior={Platform.OS === 'ios' ? 'padding' : undefined}
			>
				<View style={styles.scrollContainer}>
					<View>
						<View style={styles.headerContainer}>
							<TouchableOpacity style={styles.prevButton} onPress={handleBack}>
								<Image
									source={require('../../assets/ic_arr_left.png')}
									style={styles.prevIcon}
								/>
							</TouchableOpacity>
				
							<View style={styles.titleContainer}>
								<Text style={styles.titleText}>{roomNo?'그룹정보': '그룹생성'}</Text>
							</View>
						</View>
					</View>
						<View style={{flexDirection:'row', alignContent:'center', alignItems:'center', justifyContent:'space-between', gap:10, marginBottom:10}}>
							{/* 로컬 상태 사용 */}
							<TextInput
								placeholder='그룹명을 입력해주세요'
								value={roomNm}
								maxLength={20}
								onChangeText={setRoomNm}
								style={{backgroundColor:'#fff', borderWidth:1, borderColor:'#ccc', flex:1, paddingLeft:15, borderRadius:10, fontSize:16}}
							/>
							{/* 수정 버튼에 로컬 핸들러 연결 */}
							<TouchableOpacity 
								style={{backgroundColor:'#FF851D', borderRadius:10, paddingHorizontal:15, paddingVertical:10}}
								onPress={handleUpdate}>
								<Text style={{fontSize:16,color:'#fff'}}>수정</Text>
							</TouchableOpacity>
						</View>

					{/* 친구 목록 부분에만 스크롤 추가 */}
					<ScrollView style={styles.memberList}>
						{groupFriendList.map((member) => (
							<GroupMemberItem
								key={member.friendNo}
								friendNo={member.friendNo}
								nickNm={member.nickNm}
								imgFileUrl={member.imgFileUrl}
								introductionInfo={member.introductionInfo}
								mode="remove"
								onRemove={() => removeMember(member.friendNo)} 
							/>
						))}

					</ScrollView>
				</View>
				<MemberSelectModal
					visible={isModalVisible}
					selected={groupFriendList.map(m => m.friendNo)}
					members={searchFriendList} 
					onToggle={(friendNo) => {
						const isAlready = groupFriendList.find(m => m.friendNo === friendNo);
						const orgMember = orgFriendList.find(m => m.friendNo === friendNo);
						if (isAlready) {  // 삭제              
							//org 있는데 삭제시 삭제 에 입력
							if (orgMember) {
								setDelFriendList([...delFriendList, orgMember]);
							}
							setGroupFriendList(groupFriendList.filter(m => m.friendNo !== friendNo));
						} else {  //추가
							const newMember = searchFriendList.find(m => m.friendNo === friendNo);              
							if (newMember) {
								setGroupFriendList([...groupFriendList, newMember]);
								if (!orgMember) {
									setAddFriendList([...addFriendList, newMember]);
								}							
								const delChkMember = delFriendList.find(m => m.friendNo === friendNo);
								if (delChkMember) {
									setDelFriendList(delFriendList.filter(m => m.friendNo !== friendNo));
								}							
							}
						}
					}}
					onClose={closeModal}
				/>
			</KeyboardAvoidingView>
		</SafeAreaView>
		</React.Fragment>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	bottomContainer: {
		flex: 1,
		width: '100%',
		height: '100%',
		justifyContent: 'flex-end',
		backgroundColor: '#F7F8FA',
	},
	scrollContainer: {
		flex: 1,
		padding: 10,
		paddingBottom: 10,
	},
	label: {
		fontSize: 16,
		marginBottom: 8,
		fontWeight: 'bold',
	},
	input: {
		borderColor: '#ccc',
		borderWidth: 1,
		padding: 10,
		borderRadius: 6,
		marginBottom: 15,
	},
	addButton: {
		backgroundColor: '#FF851D',
		paddingVertical: 12,
		borderRadius: 6,
		alignItems: 'center',
		marginBottom: 20,
	},
	addButtonText: {
		color: '#fff',
		fontSize: 16,
	},
	memberList: {
		marginBottom: 100,
	},
	saveButton: {
		backgroundColor: '#FF851D',
		paddingVertical: 12,
		borderRadius: 6,
		alignItems: 'center',
		position: 'absolute',
		bottom: 20,
		left: 0,
		right: 0,
		marginHorizontal: 20,
	},
	saveButtonText: {
		color: '#fff',
		fontSize: 16,
	},
	scrollViewContent: {
		padding: 10,
		paddingBottom: 100,
	},
	searchContainer: {
		marginHorizontal:10,
		marginVertical: 10,
	},searchBox: {
		marginTop:10,
		flexDirection: 'row',
		alignItems: 'center',
		borderRadius: 25,
		borderWidth: 1,
		borderColor:'#FF851D',
		backgroundColor: '#f2f2f2',
		paddingHorizontal: 15,
		paddingVertical: 5,
	},
	clearButton: {
	},
	clearText: {
		fontSize: 18,
		color: '#999',
	},
	groupArea:{
		marginVertical:10,
	},
	iconArea: {
		marginLeft: 10,
		width: 20,
		height: 20,
		justifyContent: 'center',
		alignItems: 'center',
	},
	resultText: {
		fontSize: 18,
		fontWeight: 'bold',
		paddingVertical: 15,
	},
	emptyResult: {
		fontSize: 16,
		color: 'red',
		textAlign: 'center',
		marginTop: 40,
	},
	resultArea:{
		padding:10,
		marginHorizontal:10,
		marginBottom:40,
		flex:1,
	},
	headerContainer: {
		height: 60,
		backgroundColor: '#f2f7fcff',
		flexDirection: 'row',
		alignItems: 'center',
		paddingHorizontal: 10,
	},
	prevButton: {
		width: 40,
		alignItems: 'center',
		justifyContent: 'center',
	},
	homeButton: {
		width: 40,
		alignItems: 'center',
		justifyContent: 'center',
	},
	prevIcon: {
		width: 17,
		height: 17,
		resizeMode: 'contain',
	},
	homeIcon: {
		width: 30,
		height: 30,
		resizeMode: 'contain',
	},
	titleContainer: {
		flex: 1,
		alignItems: 'center',
	},
	titleText: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#333',
	},

		//GroupMemberItem 스타일일
	itemContainer: {
		flexDirection: 'row',
		backgroundColor: '#FFF6EF',
		borderRadius: 10,
		padding: 10,
		marginBottom: 8,
		alignItems: 'center',
	},
	avatar: {
		width: 40,
		height: 40,
		borderRadius: 20,
		marginRight: 12,
	},
	info: {
		flex: 1,
	},
	name: {
		fontSize: 16,
		color: '#000',
		fontWeight: 'bold',
	},
	statusMsg: {
		fontSize: 12,
		color: '#888',
		flexShrink: 1,
		maxWidth: '90%',
	},
	toggleButton: {
		width: 24,
		height: 24,
		marginLeft: 8,
	},

	//
});


// MemberSelectModal스타일
const modalStyles = StyleSheet.create({
	modalOverlay: {
		flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center',
	},
	modalContent: {
		width: '90%', backgroundColor: '#fff', borderRadius: 16, padding: 20, maxHeight: '80%',
	},
	title: {
		fontSize: 17, fontWeight: 'bold', color: '#FF851D', textAlign: 'center', marginBottom: 10,
	},
	closeButton: {
		backgroundColor: '#FF851D', padding: 10, borderRadius: 8, marginTop: 16, alignItems: 'center',
	},
	closeButtonText: {
		color: '#fff', fontWeight: 'bold', fontSize: 16,
	},
});

export default GroupScreen;
