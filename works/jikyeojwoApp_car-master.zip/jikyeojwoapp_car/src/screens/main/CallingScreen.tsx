import React, { useEffect, useRef, useState, useContext } from 'react';
import {GlobalData, GetDate, useGlobalStore, apiCallGet, callGet, callPost , GetDateDay, GetDateTime} from '../../store/global';
import { CallType, RootStackParamList, CallSeqResponse, MessageData, SaveResponse
	    , MessageRoomInfoRequest, MessageRoomInfoResponse, ListRoomMessage} from '../../types/common';
import {
	Image, Text, TouchableOpacity, View, StyleSheet, SafeAreaView
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { SocketStompContext  } from '../../utils/WebSocketManager';
import ApiInfo from '../../gvar/ApiInfo';



const CallingScreen = () => {
	const global = useGlobalStore();
	const { sendMessage} = useContext(SocketStompContext);
	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();	
	const [outText, setOutText] = useState('통화 시도 중입니다.');
	const [callType, setCallType] = useState(''); 
	const [startCallTm, setStartCallTm] = useState(0);
	//오픈시
	useEffect(() => {
		const state = useGlobalStore.getState();
		const cur = state.currentSendData || state.currentCarMessageData;
		//받기용 인지 거는용인지 판단 필요
		console.log("@@ CallingScreen useEffect cur : ", cur);
		if ( cur ) {  //전화걸기
			global.setIncallKey('CALL');
			setCallType('send');
			sendCallingMessage();			
		} else if( state.currentReceivedData) {  //전화받기
			setCallType('receive');
		}
		if( state.popupPageId ) {
			global.setPopupPageId('');
		}
		console.log("@@ CallingScreen useEffect incallKey : ", cur);
		setStartCallTm(new Date().getTime());
	}, []);

	useEffect(() => { 
		console.log("@@ useEffect global.incallKey : ", global.incallKey);
		if( global.incallKey === 'FR' ) {
			setOutText('상대방이 통화중입니다');
			global.showToast('상대방이 통화중입니다');
			setTimeout(() => callOff(), 1000);
			return;
		}
		if (global.incallKey === 'C') {
			setOutText('통화중 ...');
		} else if (global.incallKey === 'CALL' || global.incallKey === 'CALLING' ) {
			setOutText('연결중 ...');
		} else if (global.incallKey === 'RT' ) {
			setOutText('통화연결');
		} else if(global.incallKey ==='O' || global.incallKey ==='BT' || global.incallKey ==='BJ') {			
			callOff();
		}
	}, [global.incallKey]);	

	
	const sendCallingMessage = async () => {
		let sendCount = 0;
		let tid: NodeJS.Timeout | null = null;
		let interval = Number(GlobalData.SettingData.alarmIntervalCd) * 1000;
		if( interval < 2000 ) {
			interval = 5000;
		}		
		const call = () => {
			const state = useGlobalStore.getState();
			const cur = state.currentSendData || state.currentCarMessageData;
	
			console.log("@@ sendCallingMessage timeout cur : ", cur, state.incallKey, interval);
			if( cur && (state.incallKey=='CALLING' || state.incallKey=='CALL') ) {
				if( state.incallKey=='CALL' ) {
					global.setIncallKey('CALLING');
				}
				if( sendCount++ < 20 ) {				
					cur.mType = 'BR';
					sendMessage(cur, cur.roomId);
					console.log("@@ sendCallingMessage currentSendData : ", sendCount, cur);
					tid = setTimeout(() => call(), interval);
				}
			} else {
				// callOff();
				if( tid ) clearTimeout(tid);
				return;
			}
		}
		const state = useGlobalStore.getState();
		const cur = state.currentSendData || state.currentCarMessageData;
		if( cur ) {
				console.log("@@ calling BR out", cur);
				const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
				cur.callSeq = data.callSeq;
	
				//통화요청 저장
				//cur.mType = 'BR';
				//const info = await callPost(ApiInfo.saveChatMsg, cur) as SaveResponse;
			}
		
		call();
		// tid = setTimeout(() => call(), interval);
	}

	const hangOff = () => {
		const state = useGlobalStore.getState();
		const cur = state.currentSendData || state.currentReceivedData;
		console.log("@@ hangOff start : ", cur);
		if( cur ) {
			cur.mType = 'O';			
			sendMessage(cur, cur.roomId);
			setTimeout(() => callOff(), 250);
		} else {
			console.log("@@ hangOff global.currentCarMessageData : ", global.currentCarMessageData);
			if( global.currentCarMessageData ) {
				const cur = global.currentCarMessageData;
				const sendSubscr = cur.roomId;
				cur.mType = 'O';
				cur.roomId = cur.targetRoomId;
				cur.targetRoomId = sendSubscr;
				sendMessage(cur, sendSubscr);
			} 
			callOff();
		}
	} 
	const callOff = () => {
		console.log("@@ callOff 호출", callType);
		if( callType=='finish' ) {
			return;
		}
		const state = useGlobalStore.getState();
		setCallType('finish');
		global.setIncallKey('');
		if(state.currentSendData) global.setCurrentSendData(null);
		if(state.currentReceivedData) global.setCurrentReceivedData(null);
		// if(state.currentMessageData) global.setCurrentMessageData(null);
		// const prev = global.prevProcessScreen;
		// console.log("@@ callOff prev:", prev);
		global.setProcessScreen('');
		navigation.goBack();
	}

	return (
		<View style={{
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: 'rgba(0, 0, 0, 0.5)',
		}}>
			<View style={{
				width: '100%' ,
				height: '100%',
				backgroundColor: 'rgba(0, 0, 0, 0.5)',
				alignItems: 'center',
			}}>
			<View style={{
				width: '90%',
				flex: 1,
				justifyContent: 'center',
				alignItems: 'center'
			}}>
				<View style={{
					justifyContent:'center',
					alignItems:'center',
					width: '90%',
					marginBottom: 15
				}}>
				<Text style={{fontSize: 14, 
					textAlign:'center',
					fontWeight: 'bold',
					color:'#ffffff',
				}}>
					{outText}
				</Text>
				<Image
					style={{
						marginTop:10,
						height:10
					}}
					resizeMode='contain'
					source={require('../../assets/ico_calling_dot.png')}
				/>
				</View>
			</View>
			<View style={{
				width: '90%',
				alignItems: 'center',
				marginBottom: 50,
			}}>
				<TouchableOpacity style={{
					width:80,
					height:80
				}} onPress={()=>hangOff()}>
				<Image
					style={{
						width: '100%',
						height:'100%'
					}}
					source={require('../../assets/btn_call_finish.png')}
				/>
				</TouchableOpacity>
			</View>
			</View>
		</View>
	
	);

};

const styles = StyleSheet.create({

});

export default CallingScreen;
