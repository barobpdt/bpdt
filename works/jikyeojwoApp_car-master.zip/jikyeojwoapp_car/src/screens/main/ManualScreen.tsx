import React, { useEffect, useRef, useState } from "react";
import { FlatList, Image,  StyleSheet, Dimensions, Text, TouchableOpacity, View ,  NativeSyntheticEvent, NativeScrollEvent, StatusBar} from "react-native";
import { ManualInfo, RootStackParamList, ManualListResponse, ApiImageFields } from "../../types/common";
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { useGlobalStore, apiCallGet} from '../../store/global';
import ApiInfo from "../../gvar/ApiInfo";
import { ScrollView } from "react-native-gesture-handler";
import { SafeAreaView } from 'react-native-safe-area-context';


const ManualScreen = () => {

    const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
    const global = useGlobalStore();


    const { width, height } = Dimensions.get('window');
    
    const [currentNode, setCurrentNode] = React.useState<ManualInfo | null>(null);
    let isLoading = false ;
    
    const [activeIndex, setActiveIndex] = useState(0);
    const [tutorialImagInfoList, setTutorialImagInfoList] = useState<ApiImageFields[]>([]); 
    const flatListRef = useRef<FlatList<any>>(null); // FlatList에 대한 참조 설정



    
    const handleMomentumScrollEnd = (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      const scrollPosition = event.nativeEvent.contentOffset.x;
      const index = Math.round(scrollPosition / width);
  
      if (index !== activeIndex && index < tutorialImagInfoList.length) { // 인덱스가 변경된 경우
        setActiveIndex(index);
      }
    };

    const handlePressRight = () => {
      
      if (flatListRef.current && activeIndex < tutorialImagInfoList.length - 1) {
        const nextIndex = activeIndex + 1;
        flatListRef.current.scrollToIndex({ index: nextIndex });
        setActiveIndex(nextIndex); // 인덱스 업데이트
        console.log("change index => ", nextIndex);

      }
    };

  const handlePressLeft = () => {
    if (flatListRef.current && activeIndex > 0) {
      const prevIndex = activeIndex - 1;
      flatListRef.current.scrollToIndex({ index: prevIndex });
      setActiveIndex(prevIndex); // 인덱스 업데이트
      console.log("change index => ", prevIndex);
    }
  };

    useEffect(()  => {
      //매뉴얼리스트 출력
      getManualList();
    }, []);

    const getManualList = async() => {
      if (isLoading) return;
      
      isLoading = true;
      

      try {
        await apiCallGet(ApiInfo.manualList, {langCd:'KR'}, (type:string, obj:object) => {
          if(type=='ok') {
            var info=obj as ManualListResponse ;
            console.log("info==>", info);
            console.log("info.manualDataList==>", info.manualDataList);
            const sortedData = info.manualDataList.sort((a, b) => a.viewNum - b.viewNum); // viewNum으로 정렬
            setTutorialImagInfoList(sortedData)  ;
            // 첫 번째로 표시할 인덱스를 viewNum이 가장 작은 이미지로 설정
            const initialIndex = 0 ; //sortedData.findIndex(image => image.viewNum === Math.min(...sortedData.map(img => img.viewNum)));
            setActiveIndex(initialIndex); 
            flatListRef.current?.scrollToIndex({ index: initialIndex }); // 초기 인덱스 스크롤
            console.log("Initial viewNum:", sortedData[initialIndex].viewNum); // 초기 viewNum 출력
          } else {
              //튜토리얼 오류
          }   
        })
      } catch (error) {
        isLoading  = false;
        console.error("API 호출 중 오류 발생:", error);
      }
      isLoading  = false;
    }


    
      const renderItem = ({ item } : {item: ApiImageFields}) => (
        <Image source={{ uri: item.filePath }} style={{width: width, height: height, }}resizeMode="contain" /> // filePath 사용
      );


    return (
        <React.Fragment>
          <StatusBar
            barStyle="dark-content"
            backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
          />
      <SafeAreaView style={styles.bottomContainer}>
        <View style={styles.headerContainer}>
          <TouchableOpacity style={styles.prevButton} onPress={() => {
            if (currentNode) {
            setCurrentNode(null); // 매뉴얼얼 상세 화면에서 리스트로 돌아감
            } else {
            navigation.goBack(); // 리스트 화면이라면 뒤로 가기
            }}}>
            <Image
              source={require('../../assets/ic_arr_left.png')}
              style={styles.prevIcon}
            />
          </TouchableOpacity>

          <View style={styles.titleContainer}>
            <Text style={styles.titleText}>매뉴얼</Text>
          </View>
        </View>
        <View style={{
          flex:1,
          backgroundColor: '#fff',
          }}>
          <View style={styles.main}> 
            {currentNode ? (
              <>
                <Text style={{ fontSize: 12, color: '#888', marginBottom: 8 }}></Text>
                <Text style={{ fontSize: 16, fontWeight: 'bold', marginBottom: 12 }}></Text>
                <ScrollView style={{flex:1}}>
                  <Text style={{fontSize: 12, padding:20, height:'100%', paddingBottom:0}}>
                  </Text>
                </ScrollView>
              </>
            ) : (
                <FlatList
                  ref={flatListRef}
                  data={tutorialImagInfoList}
                  renderItem={renderItem}
                  keyExtractor={(item, index) => index.toString()}
                  horizontal
                  removeClippedSubviews={false}
                  decelerationRate="fast"
                  bounces={false}
                  snapToInterval={width}
                  pagingEnabled={true}
                  showsHorizontalScrollIndicator={false}
                  onMomentumScrollEnd={handleMomentumScrollEnd} // 스크롤이 끝날 때 인덱스 업데이트
                  scrollEventThrottle={16}
                  getItemLayout={(data, index) => (
                    {length: width, offset: width * index, index}
                  )}
                />
            )}
          </View>
          <View style={styles.navigationContainer}>
            { <View>
                <TouchableOpacity onPress={handlePressLeft} style={[styles.navButton, { display: activeIndex > 0 ? 'flex' : 'none' }]}>
                
                <Image 
                  source={require('../../assets/ic_pager_prev.png')} // 왼쪽 네비게이션 이미지
                  style={styles.navImage} 
                />
              </TouchableOpacity>  
              </View>}
    
            { activeIndex < tutorialImagInfoList.length - 1 && <TouchableOpacity onPress={handlePressRight} style={styles.navButton}>
            

            <Image 
                source={require('../../assets/ic_pager_next.png')} // 오른쪽 네비게이션 이미지
                style={styles.navImage} 
              />
            </TouchableOpacity> }
    
          </View> 
        </View>
      </SafeAreaView>
      
      </React.Fragment>
    );
}


export default ManualScreen;

const styles = StyleSheet.create({ 
  header: {
    backgroundColor: '#F08229',
    height: 60, // 헤더 높이 고정
    justifyContent: 'center', // 헤더 전체 수직 중앙 정렬
    alignItems: 'center', // 텍스트 중앙 정렬
    position: 'relative', // 자식 요소의 절대 위치 기준
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  preBtn: {
    position: 'absolute', // 헤더의 왼쪽 상단에 고정
    left: 5, // 왼쪽 여백
    top: 5, // 위쪽 여백
    width: 50,
    height: 50,
    justifyContent: 'center', // 버튼 중앙 정렬
    alignItems: 'center',
  },
  headerContainer:{
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  preBtnImgSize: {
    height: '100%',
    resizeMode: 'contain', // 이미지 비율 유지하며 크기 조정
  },
  headerTitle: {
    fontSize: 20, // 텍스트 크기
    fontWeight: 'bold', // 텍스트 두께
    color: '#fff', // 텍스트 색상
  },
  main: {
    flex: 1, // 남은 공간 차지
    padding: 10,
  },
  noDataText: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
    marginTop: 20,
  },
  iptBox:{
    justifyContent: 'center',
    borderColor: '#F08229',
    borderBottomWidth: 1,
    width:'90%',
    height: 50
  },
  listContainer: {
    paddingBottom: 20,
    width: '100%',
    alignItems: 'flex-start', // optional
  },
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    marginVertical: 5,
    borderColor: '#F08229',
    borderBottomWidth: 1,
  },
  itemTitle: {
    paddingLeft: 10,
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  itemDate: {
    fontSize: 14,
    color: '#666',
  },
  scrollContainer: {
    flex: 1,  // 여기부터 맨 아래까지 차지
    marginTop: 10,
  },
  scrollView: {
    flex: 1,
  },
  description: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
  },
    navigationContainer: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  navButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    padding: 10,
    borderRadius: 5,
  },
  navText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  navImage: {
    width: 30, // 이미지의 너비를 설정합니다.
    height: 30, // 이미지의 높이를 설정합니다.
  },

});