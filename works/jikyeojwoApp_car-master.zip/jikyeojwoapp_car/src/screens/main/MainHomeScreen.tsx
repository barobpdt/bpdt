import React, { useRef, useState, useEffect, useContext } from 'react';
import {Text, View , TouchableOpacity, StyleSheet, FlatList, Alert
	, ActivityIndicator, Platform, StatusBar
	, AppState, Vibration
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { MainHomeProps, RootStackParamList
	, ApiMainRequest, MainResponse, ListRoomMessage, FriendList
	, QrDtaiCarMsgListRequest,QrDtlCarMsgListResponse, QrPageType,  SaveFriendRequest, SaveResponse
	, MessageData, FCM_RecvData, AddFriendResponse,
	RegUseQrResponse
} from '../../types/common';
import ApiInfo from '../../gvar/ApiInfo';
import ServiceItem from '../../components/ServiceItem';
import ServiceIntro from '../../components/ServiceIntro';
import ServiceQrBox from '../../components/ServiceQrBox';
import MessageBox from '../../components/MessageBox';
import AdInfo from '../../components/AdInfo';
import BottomTabBar from '../../components/BottomTabBar';
import {apiCallPost, GlobalData, GetDate, useGlobalStore, updateMainResponse, CHAT_LIST_TYPE, callPost, GetDateDay, GetDateTime} from '../../store/global';
import { SocketStompContext  } from '../../utils/WebSocketManager';
import Sound from 'react-native-sound';

import HapticFeedback from 'react-native-haptic-feedback';
// import { playSampleSound } from 'react-native-notification-sounds';
import { SafeAreaView } from 'react-native-safe-area-context';

let prevAppState = '';

const callPageInfo = { 
	isVibrating: false,
	isSound: false,
	fcmCallSeq: '',
	callSeq: '',
	messageType: '',
	messageData: null as MessageData|null,
	isRoomMessageChange: false,
	callingStartTime: 0,
	pageStartTime:0
}
const MainHomeScreen: React.FC<MainHomeProps> = () => {

	//상위 네비게이션 값을 받음
	//const navigation = useNavigation();  //스택이동하기위한 네비게이션 정보 
	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); 

	//소켓 연결
	const { disconnect, reconnect, isconnected, startLocationUpdates, stopLocationUpdates, sendAddFriendMessage, receiveDataProcess } = useContext(SocketStompContext);

	// QR생성 팝업 뛰우기 상태값
	const [isPopQrCall, setIsPopQrCall] = useState<boolean>(false);  // 전화 또는 문자시 QR선택 화면 뛰이기
	
	//const [listAdView, setListAdView] = useState<ListAdView[]>([]) ;	
	const [isMsgOut, setIsMsgOut] = useState(false);  // QR등록전 서비스 선택정보 화면 뛰이기
	const [msgCount, setMsgCount] = useState(0);  // QR등록전 서비스 선택정보 화면 뛰이기
	const [qrClickStatus, setQrClickStatus] = useState(CHAT_LIST_TYPE.QR_DIALOG); // QR클릭 여  10 : qr클릭안함, 20 : qr클릭 메세재, 30 : qr클릭 친구
	const [isLoading, setIsLoading] = useState(false); // 로딩시 사용==> 현재 car 호출 처리
	
	//const [qrClickData, setQrClickData] = useState<QrClickType>({ qrNo: '', serviceTypeCd: '' });

	const flatListRef = useRef<FlatList<any>>(null); // FlatList의 스크롤을 맨위로 올리기 위한 함수로직

	//const [isAddShowBox, setIsAddShowBox] = useState(false);
	
	const imageRef = useRef(null); // 이미지의 참조
	
	const [selRoomNo, setSelRoomNo] = useState('');
	const [selFriendNo, setSelFriendNo] = useState('');

	// 차빼줘 페이징
	const [qrCarCallInfo, setQrCarCallInfo] = useState<QrPageType>({ searchChatSeq: '', totalSize: GlobalData.gridSize , lastChatSeq: '', preSearchChatSeq: ''});

	const [callQrNo, setCallQrNo] = useState('');
	/*
	const [callTargetQrNo, setCallTargetQrNo] = useState('');
	const [isSelCallMsgPop, setIsSelCallMsgPop] = useState(false);  // QR 친구추가

	//qr정보 수정
	const [selectedQrItem, setSelectedQrItem] = useState(null);
	const [isUpdateModalVisible, setIsUpdateModalVisible] = useState(false); 
	const [isLocation, setIsLocation] = useState(false);  // 권한이 허용되었을 시 true;
	*/

	const global = useGlobalStore();  
	const checkAppActive = () => {
		console.log("@@ checkAppActive prevAppState", prevAppState);
		if( prevAppState=='inactive' ) {
			setTimeout(checkAppActive, 1000);
		} else if( prevAppState=='background' ) {
			global.setAppActive(false);
			disconnect();
		} 
	}
	//const [serviceTypeCd, setServiceTypeCd] = useState('');	
	useEffect(() => {
		callPageInfo.pageStartTime = new Date().getTime();
		const subscription = AppState.addEventListener('change', nextAppState => {
			const state = useGlobalStore.getState();
			console.log('@@ appState.current ======> ', prevAppState, nextAppState, state.launchModule)
			if( state.launchModule == '' ) {				
				if ( prevAppState.match(/inactive|background/) && nextAppState === 'active' ) {
					reconnect();
					global.setAppActive(true);
				} else if ( nextAppState === 'inactive' || nextAppState === 'background' ) {
					if( Platform.OS == 'ios' ) {
						setTimeout(checkAppActive, 2000);
					}
					const dist = new Date().getTime() - callPageInfo.pageStartTime;
					if( nextAppState === 'background' && dist > 1000 ) {
						global.setAppActive(false);
						global.setMapMode(false);
						startLocationUpdates();
						disconnect();
					}
				}
				prevAppState = nextAppState;
			}			
		});

		const backgroundSyncInterval = setInterval(() => syncDataInBackground(), 50000 ) // Execute every 50 sec
 
		//메인 호출
		mainApiData();

		setTimeout(()=>{
			startLocationUpdates();
			notificationCheck();
			global.setAppActive(true);
		}, 1000);

		return () => {
			subscription.remove(); 
			clearInterval(backgroundSyncInterval);
			disconnect();
		};
	}, []);

	useEffect(() => {
		console.log("@@ useEffect notification data => ", global.notificationData, global.notificationTick);
		if( global.notificationData && global.notificationTick > 0  ) {
			if( !global.isAppActive ) {
				const distStart = new Date().getTime() - callPageInfo.pageStartTime;
				if( distStart < 2000) {
					// 페이지시작시 푸시는 무시한다 (시작 useEffect에서 노티확인)
					console.log("@@ useEffect notification data distStart", distStart);
					return;
				}
			}
			const dist = global.notificationTick ? new Date().getTime() - global.notificationTick : 0;
			console.log("@@ notificationCheck dist", dist);
			if( dist < 50000 ) {
				notificationCheck();
			}
		}
	}, [global.notificationData]);

	//메세지 정보 보여주는 데이타
	useEffect(() => {
		console.log("@@ global.listRoomMessage ...");		
		global.filterRoomMessage(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
		global.filterFriendList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
		setMsgCount(global.listRoomMessage.length);
	}, [global.listRoomMessage]);

	// 채팅방에 없을때 메시지 온경우
	useEffect(() => {
		const dist = new Date().getTime() - callPageInfo.pageStartTime;
		if( dist < 10000) return;
		console.log("@@ global.updateRoomMessageTick", global.updateRoomMessageTick, global.processScreen);
		if( global.popupPageId == 'CallingCarPopup' ) {
			callPageInfo.callingStartTime = 0;
			callPageInfo.isSound = false;
			callPageInfo.isVibrating = false;
		} else if( global.processScreen !== 'Chat' ) {
			callPageInfo.isRoomMessageChange = true;
			setCallAlaram()
		}
	}, [global.updateRoomMessageTick]);

	//QR이 추가되거나 정보가 변경되어지면 이벤트 발생처리함
	useEffect(() => {
		global.setListMyQrCurrent(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
	}, [global.listMyQr]);

	// 클릭한 QR 정보 change
	useEffect(() => {
		console.log("@@ qrClickData", global.qrClickData);
		viewDataSetting();
	}, [global.qrClickData]);

	useEffect(() => {
		console.log("@@ listMyQrCurrent", global.listMyQrCurrent);
		if (global.listMyQrCurrent.length > 0) {
			setIsMsgOut(false);
		} else {
			setIsMsgOut(true);
		} 
	}, [global.listMyQrCurrent]);

	// 팝업 페이지 close 체크
	useEffect(() => {
		console.log("@@ popupPageId == ", global.popupPageId);		
		if( global.popupPageId == 'CallingCarPopup' ) {
			const cur = global.currentCarMessageData;
			if( cur && cur.mType == 'M' ) {
				setCallAlaram();
			}
		} else if( global.popupPageId == 'ReceiveCallPop' || global.popupPageId == 'CallingPopup' ) {
			if( global.popupPageId == 'ReceiveCallPop') {
				setCallAlaram();
			} else {
				console.log("@@ callingPopup", global.selectedRoomMessage);
			}
		} else {
			if( global.popupPageId == '' ) {
				if( global.currentScanInfo.viewType ) {
					global.setCurrentScanQrCode('');
					global.setCurrentScanInfo({serviceTypeCd: '', qrNo: '', viewType: '', myQrNo: ''});
				}
			}
			callPageInfo.callingStartTime = 0;
			callPageInfo.isSound = false;
			callPageInfo.isVibrating = false;
		}
	}, [global.popupPageId]);

	// 스캔 정보 처리
	useEffect(() => {
		if( global.currentScanQrCode == '' ) return;
		console.log("@@ currentScanQrCode == ", global.currentScanQrCode, global.popupPageId, global.currentScanInfo, 'callQrNo=='+callQrNo );
		// 스캔 팝업 페이지 
		if( global.popupPageId == 'ScanPopup' ) {
			const scanInfo = global.currentScanInfo;
			scanInfo.qrNo = global.currentScanQrCode
			if( scanInfo.viewType == 'CallScanner' ) {				// 전화 콜 처리
				callingPopup()
			} else if( scanInfo.viewType == 'AddFriend' ) {			// 친구추가 처리
				handleQRFriendRead(global.currentScanQrCode, scanInfo.myQrNo);
				global.setPopupPageId('');
			} else if( scanInfo.viewType == 'Home' || scanInfo.viewType == 'MyQrListPop' ) { 	// QR 등록 처리
				if( scanInfo.serviceTypeCd == 'Car' || scanInfo.serviceTypeCd == 'Protect' ) {
					scanQrCheck(global.currentScanQrCode);					
				}
			} 
		}
	}, [global.currentScanQrCode]);


	useEffect(() => {
		console.log("location data ", global.listAlert);
		if (global.listAlert.length > 0) {
			global.setPopupPageId('LocationRequestListPop');
		}
	}, [global.listAlert]);


	useEffect(() => {
		if (global.qrClickData.qrNo == "") {
			if (global.listRoomMessage.length > 0) {
				setIsMsgOut(false);
			} else {
				setIsMsgOut(true);
			} 
		} else {
			setIsMsgOut(false);
		}
		console.log("msg status=>", isMsgOut);
	}, [msgCount]);
	
	// scan 호출 팝업 처리
	const callingPopup = async () => {
		const myQrNo = global.currentScanInfo.myQrNo;
		const msgData = await global.getMessageData('Call', myQrNo, global.currentScanQrCode);	
		// console.log("@@ callingPopup myQrNo", myQrNo, global.currentScanInfo, msgData);
		global.setCurrentScanQrCode('');
		if( msgData.mType=='E' ) {
			if( global.popupPageId == 'ScanPopup' ) {
				global.setPopupPageId('');
			}
			Alert.alert("오류", msgData.msgDesc);
			return;
		}
		if( msgData.serviceTypeCd=='Car' ) {
			global.setCurrentCarMessageData(msgData);
			global.setCarRoomType('send');
			global.setPopupPageId('CallingCarPopup');
		} else {
			global.setCurrentMessageData(msgData);
			global.setPopupPageId('CallingPopup');
		}
		
	}

	const viewDataSetting = () => {
		//console.log("data set chagned");
		// 서비스, qr, messsage, friendlist , callList
		if (flatListRef.current) {
			flatListRef.current.scrollToOffset({ animated: true, offset: 0 });
		}
		qrCarCallInfo.lastChatSeq = '';
		qrCarCallInfo.preSearchChatSeq = '';
		qrCarCallInfo.searchChatSeq = '';
		
		
		//console.log(" data setting start search data", global.qrClickData);
		//QRList 출력
		//global.setListMyQrCurrent(global.qrClickData.serviceTypeCd, '');
		global.setListMyQrCurrent('', '');

		//console.log(" data setting qr data  listMyQr", global.listMyQr);
		//console.log(" data setting qr data listMyQrCurrent",  global.listMyQrCurrent);

		//커런트 메세지 초기화
		global.initCurrentRoomMessage();

		//원 메세지 필터를 통해 커런트에 넣어줌
		global.filterRoomMessage(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);

		//친구 목록 필터 처리
		global.filterFriendList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
		//console.log(" data setting msg listFriend", global.listFriend)
		//console.log(" data setting msg list filterFriendList", global.listFriendCurrent)

		//그룹 목록 필터 처리
		global.filterGroupList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);

		if (global.qrClickData.serviceTypeCd == "Car") {
		//   console.log("car data call");
			qrCarCallInfo.lastChatSeq = '';
			global.initCarMsgList();
			searchQrCarMsgData();
			setQrClickStatus(CHAT_LIST_TYPE.QR_CAR_CALL);
		} else {
			// if (global.qrClickData.qrNo == '')	{
			// 	setQrClickStatus(CHAT_LIST_TYPE.DIALOG_LIST);
			// } else {
				setQrClickStatus(CHAT_LIST_TYPE.QR_DIALOG);
			//}
		}
	}

	const mainApiData = async() => {
		const params = { deviTpCd:GlobalData.deviTpCd, langCd:GlobalData.langCd } as ApiMainRequest;
		const info = await callPost(ApiInfo.mainInfo, params) as MainResponse;
		console.log("@@ home start :", params, info);
		if('errors' in info || info.code !== '200' ) {
			updateMainResponse({} as MainResponse);
			return Alert.alert(info.message);
		}
		updateMainResponse(info); 
		
		global.updateQrClickData({serviceTypeCd: '' , qrNo: ''});		
		setQrClickStatus(CHAT_LIST_TYPE.QR_DIALOG);
		//viewDataSetting();
	}

	const syncDataInBackground = () => {
		if( global.isAppActive && !isconnected() ) {
			console.log("@@ syncDataInBackground reconnect call");
			reconnect();
		}
	}
 
	// push 데이타 처리
	const getMessageData = (fcmData: FCM_RecvData) => {
		const msgData : MessageData = {
			mType: fcmData.mType,
			mykey: fcmData.mykey,
			msgDesc: fcmData.msgDesc,
			langCd: GlobalData.langCd,
			qrNo: fcmData.qrNo,
			currentDate: GetDate(),
			callSeq: fcmData.callSeq,
			membNo: GlobalData.membNo,
			roomId: fcmData.roomId,
			targetRoomId: fcmData.targetRoomId,
			onOff: 'Y',
			writeMembNo: fcmData.writeMembNo,
			serviceTypeCd: fcmData.serviceTypeCd,
			fileImgUrl: fcmData.fileImgUrl,
			filePath: fcmData.filePath,
			counterPart: fcmData.counterPart,
			msgTypeCd: fcmData.msgTypeCd
		} as MessageData;
		return msgData;
	}

	const notificationCheck = async () => {
		const state = useGlobalStore.getState();
		const notificationData = state.notificationData;
		console.log("@@ notificationCheck notificationData >> ", notificationData, state.notificationTick);
		if( notificationData ) {
			const fcmData = notificationData.data as FCM_RecvData;
			const msgData = getMessageData(fcmData);
			await receiveDataProcess(msgData);
		}
	}
	// 문자에 대한 진동 처리 
	const startCallSound = () => {
		let sound: Sound | null = null;
		let playStart : NodeJS.Timeout|null = null;
		let playStop : NodeJS.Timeout|null = null;
		let ok = false;

		const stop = () => {
			if( playStart ) {
				clearInterval(playStart)
				playStart = null;
			}
			if( playStop ) {
				clearInterval(playStop)
				playStop = null;
			}
			if (sound) {
				sound.stop()
				sound.release()
				sound = null;
			}
			callPageInfo.isRoomMessageChange = false;
			callPageInfo.callingStartTime = 0
			callPageInfo.isSound = false;
		}

		if( callPageInfo.isSound ) {
			stop(); // 이미 재생 중이면 중지하고 다시 시작
			return;
		}

        // 사운드 파일 로드
		const settingInfo = GlobalData.SettingData
		const oneCall = callPageInfo.isRoomMessageChange;
		let interTime = 1000 * Number(settingInfo.alarmIntervalCd) // settingInfo.alarmIntervalNm 
		if( isNaN(interTime) || interTime < 1000 ) interTime = 5000;
		const soundItem = { url: 'calling.mp3'}; // settingInfo.alarmSoundNm }
		if( settingInfo.alarmSoundNm == '차빼줘' ) {
			soundItem.url = 'calling.mp3';
		} else {
			soundItem.url = 'protect.mp3';
		}
		const endDuration = 60000 
		callPageInfo.isSound = true;
		console.log("@@ startCallSound", soundItem );

		const play = () => {
			if( callPageInfo.callingStartTime==0 || oneCall ) return stop()
			if (sound) {
				sound.play((success) => ok=success)
				console.log("@@ play start", ok, oneCall,  callPageInfo.callingStartTime);
				playStart = setTimeout(()=>play(), interTime)
			}
		}

		sound = new Sound( soundItem.url, Sound.MAIN_BUNDLE, (error) =>  {
			if(error) return stop();
			sound?.play((success) => ok=success)			
			playStart = setTimeout(()=>play(), interTime)
			playStop = setTimeout(() => stop(), endDuration); // 10000ms = 10초
		})
    };

	const startVibration = () => {
		if (callPageInfo.isVibrating) return; // 이미 진동 중이면 아무 작업도 하지 않음	 
		const settingInfo = GlobalData.SettingData
		const oneCall = callPageInfo.isRoomMessageChange;
		// console.log("@@ settingInfo", settingInfo);
		let interTime = 1000 * Number(settingInfo.alarmIntervalCd) // settingInfo.alarmIntervalNm 
		if( isNaN(interTime) || interTime < 1000 ) interTime = 5000;
		const endDuration = 60000 
		callPageInfo.isVibrating = true
		let playStart : NodeJS.Timeout|null = null
		let playStop : NodeJS.Timeout|null = null
		console.log('@@ [ start vibration ] ', interTime)
		if( Platform.OS == 'ios' ) {
			HapticFeedback.trigger('impactLight');
			playStart = setTimeout(()=>playIos(), interTime)
		} else {
			Vibration.vibrate(1000)
			playStart = setTimeout(()=>playAndroid(), interTime)
		}
		playStop = setTimeout(() => stop(), endDuration)
		
		const playIos = () => {			
			if( callPageInfo.callingStartTime==0 || oneCall ) return stop()
			HapticFeedback.trigger('impactLight')
			playStart = setTimeout(()=>playIos(), interTime)
		}
		const playAndroid = () => {
			if( callPageInfo.callingStartTime==0 || oneCall ) return stop()
			Vibration.vibrate(1000)
			playStart = setTimeout(()=>playAndroid(), interTime)
		}
		const stop = () => {
			if( playStart ) {
				clearInterval(playStart)
			}
			if( playStop ) {
				clearInterval(playStop)
			}
			callPageInfo.isRoomMessageChange = false;
			callPageInfo.callingStartTime = 0;
			callPageInfo.isVibrating = false
		}
    }
	const getAlaramType = () => {
		const settingInfo = GlobalData.SettingData
		// console.log('set audio setting type ==> ', audioMode, settingInfo, global.settingInfo )
		return ( global.audioMode == "Silent" ) ? 0 :
		 	( global.audioMode == "Vibrate" ) ? 1 :
			( settingInfo.alarmSoundYn == "Y" && settingInfo.alarmVibYn == "Y" ) ? 3 :
			( settingInfo.alarmSoundYn == "Y" && settingInfo.alarmVibYn != "Y" ) ? 2 :
 			( settingInfo.alarmSoundYn != "Y"  && settingInfo.alarmVibYn == "Y") ? 1 : 1
	}

	const setCallAlaram = () => {
		const alaramType = getAlaramType()
		callPageInfo.callingStartTime = new Date().getTime();
		console.log("@@ setCallAlaram alaramType", alaramType, callPageInfo);
		if( alaramType == 1) {  // 진동
			startVibration() ;
		} else if ( alaramType == 2) {  // 소리
			startCallSound();
		} else if ( alaramType == 3 ) {  // 진동 + 소리
			startCallSound();
			startVibration();
		}
	}
	
	
	// 문자 클릭시 값 전달 받아 화면 전환 처리한다.
	const callMsgStack = async (jobCd: string, msgInfo: ListRoomMessage | null, friInfo: FriendList| null,  groupInfo: ListRoomMessage| null) => {
		// jobCd  = D   relNo : roonNo   etcInfo callSeq  차빼줘 내역 삭제  delMessage
		// jobCd  = T   relNo : roonNo   etcInfo serviceTypeCd  채팅창으로 이동 ( 차빼줘, 지켜줘)
		console.log("@@ callMsgStack 호출", jobCd, msgInfo);
		if (jobCd == "D") {
			// 삭제  Api 호출하고 다시 재조회 처리 한다.
			if (msgInfo == null ) return;
			const params = {
				serviceTypeCd:'Car',
				roomNo:msgInfo.roomNo,
				chatSeq:msgInfo.chatSeq,
				qrNo:msgInfo.qrNo,
				currentDate:GetDate(),
				langCd:GlobalData.langCd
			}
			const info = await callPost(ApiInfo.delMessage, params) as SaveResponse
			if( "errors" in info ) {
				Alert.alert("메세지 삭제 오류", info.message);
			} else {
				if( info.code == "20005") { //삭제 성공
					// global.removeCarMsgList(msgInfo.chatSeq);
					global.qrClickData.serviceTypeCd = 'Car'
					setQrClickStatus(CHAT_LIST_TYPE.QR_CAR_CALL);
					viewDataSetting();
					console.log("@@ callMsgStack removeCarMsgList", global.qrClickData, qrClickStatus);
				} else {
					Alert.alert("메세지 삭제 오류", info.message);
				}
			}
		} else if (jobCd == "F") {  //친구 프로필 이동
			if (friInfo == null ) return;
			global.setCurrentFriendProfile(friInfo.roomNo, friInfo.friendNo);
			global.setPopupPageId('FriendCallProfilePop');
			/*
			setSelRoomNo(friInfo.roomNo);
			setSelFriendNo(friInfo.friendNo);
			setIsFriendProfile(true);
			*/
		} else if (jobCd == "FK") {  //친구 프로필 이동
			console.log("@@ callMsgStack messagebox mainhome", msgInfo);
			if (msgInfo == null ) return;
			/*
			setSelRoomNo(msgInfo.roomNo);
			setSelFriendNo(msgInfo.membNo);
			setIsFriendProfile(true);	
			*/
			global.setCurrentFriendProfile(msgInfo.roomNo, msgInfo.membNo);
			global.setPopupPageId('FriendCallProfilePop');
		} 
		else if (jobCd == "G") {  //그룹정보 이동
			if (groupInfo == null ) return;
			navigation.navigate("Group",{roomNo: groupInfo.roomNo} )
		} else if (jobCd == "GK") {  //그룹정보 이동
			if (msgInfo == null ) return;
			navigation.navigate("Group",{roomNo: msgInfo.roomNo} )		
		}
		else if (jobCd == "T") {  //
			if (msgInfo == null ) return;
			const msgData = await global.getRoomClickMessageData('Call', msgInfo);
			
			console.log("@@ callMsgStack msgData", msgData);
			if( msgInfo.serviceTypeCd == 'Car' ) {
				if( msgInfo.writeMembNo == 'Web' ) return;				
				global.setCurrentCarMessageData(msgData);
				global.setPopupPageId('CallingCarPopup');
			} else {
				global.setCurrentMessageData(msgData);
				global.setProcessScreen('Chat');
			}			
		} else if (jobCd == "A") {  //
			console.log('group chat ', groupInfo);
			if (groupInfo === null ) return;
			const msgData = await global.getChatMessageData(groupInfo?.serviceTypeCd, groupInfo?.roomNo, []);
			console.log('@@ dwkim 1 Add Friend  msgData', msgData);
			global.setCurrentMessageData(msgData);		
			global.setProcessScreen('Chat');			
		} else if (jobCd == "FC") {  //
			if (friInfo == null ) return;
			//const msgData = await global.getRoomClickMessageData('Call', msgInfo);
			const msgData = await global.getMessageData('CALL', friInfo.membQrNo || '', friInfo.friendQrNo || '');
			global.setCurrentMessageData(msgData);
			global.setProcessScreen('Chat');
		} 
	}

//맨 아래 QR 전화 문자 하기 스캔 화면 오픈
	const bottonCall = (jobType:string) => {
		//jobType Q : 스캔  ,H : home 
		// const filteredList = global.listMyQr.filter(item => item.serviceTypeCd === 'Protect');
		console.log("@@ bottonCall filteredList", jobType);
		if (jobType == "H") {
			mainApiData()
		}
	}

	//QR추가 이벤트
	const searchQrCarMsgData = () => {
		//console.log( "api call ", qrCarCallInfo.gridPage,qrCarCallInfo.totalSize)
		if ( qrCarCallInfo.lastChatSeq != '')
		{
			console.log("더이상 호출 안해도 됨 ")
			return ;
		}		
		setIsLoading(true);
		
		const qrCarMsgReqParam = () => {
			const node = {} as QrDtaiCarMsgListRequest
				node.qrNo=global.qrClickData.qrNo
				node.langCd=GlobalData.langCd
				node.gridSize =GlobalData.gridSize
				node.searchChatSeq = qrCarCallInfo.searchChatSeq
				node.pagingYn = "Y"
			return node;
		}
		apiCallPost(ApiInfo.qrCarMsgList, qrCarMsgReqParam(), (type:string, obj:object) => {
			if( type=='ok' ) {
				const info = obj as QrDtlCarMsgListResponse
				// console.log("@@ searchQrCarMsgData", info);
				global.updateCarMsgList(info.qrCarCallList); 
				
				//조회 데이타 세팅
				if (info.qrCarCallList.length < GlobalData.gridSize) {
					qrCarCallInfo.lastChatSeq = info.lastChatSeq;
				}
				qrCarCallInfo.searchChatSeq = info.lastChatSeq;
				setQrClickStatus(CHAT_LIST_TYPE.QR_CAR_CALL);
				setIsLoading(false);
			} else {
				console.error("API 호출 중 오류 발생:", type, obj);
				setIsLoading(false);
			}
		})
	}

	// 차빼줘  페이징 처리
	const handlePagginCall = () => {
		if ( qrCarCallInfo.preSearchChatSeq != '' && qrCarCallInfo.searchChatSeq == qrCarCallInfo.preSearchChatSeq) {
			console.log("top scroll call return");
			return ;
		  } else {
			console.log("top scroll call process", qrCarCallInfo.preSearchChatSeq , qrCarCallInfo.searchChatSeq);
			qrCarCallInfo.preSearchChatSeq = qrCarCallInfo.searchChatSeq;  // 마지막 순번 같은거 부르면 호출에서 제외 하기위해 넣음
			searchQrCarMsgData();
		  }
	}

	// qr내역에서 친구 클릭시
	const handleFriendClick = () => {
		setQrClickStatus(CHAT_LIST_TYPE.QR_FRIEND);
	} 

// qr내역에서 대화 클릭시
	const handleQrMsgClick = () => {
		//화면만 이동하면 됨.. 이미 서비스코드와 큐알코드가 변경데이 현 데이타는 변경된 상태임
		setQrClickStatus(CHAT_LIST_TYPE.QR_DIALOG);


	}  

	// 친구추가 시 QR오픈
	const handleQRFriendRead = async (scanQrCode:string, myQrNo:string ) => {	
		const param = {
			serviceTypeCd : "Protect",
			qrNo: myQrNo,
			friendQrNo: scanQrCode,
			currentDate: GetDate(),
			langCd:GlobalData.langCd
		} as SaveFriendRequest
		const info = await callPost(ApiInfo.addFriendQr, param ) as AddFriendResponse
		global.showToast('');
		if( "errors" in info ) {
			global.showToast("친구추가 오류:"+info.message);
		}
		console.log('info value =>', info);
		if( info.code == "20006") {
			if( info.addFriendInfo ) {
				if (info.addMyYn === 'Y') {
					global.addFriend(info.addFriendInfo)
					global.filterFriendList(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
				}

				if (info.addFriendYn === 'Y') {
					//info.friendSubScr 로 전송처리함
					const param = {} ;
					param["transData"] = 'F' ;  
					param["transData1"] = info.addFriendInfo.membQrNo
					param["transData2"] = info.addFriendInfo.friendQrNo;  
					param["transData3"] = '';  
		
					sendAddFriendMessage(param, info.friendSubScr);

				}
				handleFriendClick();
			}
		} else {
			global.showToast("친구추가 오류:"+info.message);
		}	 
	};

	const scanQrCheck = async (scanQrCode:string) => {
		const param = {
			qrNo: scanQrCode,
			serviceTypeCd: global.currentScanInfo.serviceTypeCd ?? global.qrClickData.serviceTypeCd,
			langCd:GlobalData.langCd
		}	
		const info = await callPost(ApiInfo.regUseQr, param) as RegUseQrResponse 
		console.log("@@ scanQrCheck info", info);
		global.showToast('');
		if( "errors" in info ) {
			return global.showToast("QR등록 오류:"+info.message);
		}
		if( info.code !== "200") {
			return global.showToast("QR등록 오류:"+info.message);		
		}
		// 오류 없을시 등록 화면 이동처리
		const state = useGlobalStore.getState();
		console.log("@@ state.currentErrorMessage == ", state.currentErrorMessage);
		if( state.currentErrorMessage =='' ) {
			global.setPopupPageId('WriteQrInfoPop');
		}
	}
	

	return (
		<React.Fragment>
			<StatusBar
			barStyle="dark-content"
			backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
			/>
			<SafeAreaView style={styles.bottomContainer}>		
				{/* 서비스 리스트 출력 */ }
				<View style={styles.serviceContainer}>
					<View style={{ width: 60 }}>
						{/*global.listService.map((item, index) => {*/}
						{Array.isArray(global.listService) && global.listService.map((item, index) => {
							if (item.useYn !== 'Y') return null;
							const isSelected = item.serviceCd === global.qrClickData.serviceTypeCd;
							const color = isSelected ? '#87CEEB' : '#F7F8FA';
							return (
								<ServiceItem
									key={index}
									navigation={navigation}
									backgroundColor={color}
									imageUri={item.filePath}
									label= {item.serviceNm}
									serviceTypeCd={item.serviceCd}
								/>
							);
						})}
					</View>
					<View style={{flex:1}}>
						{/* 서비스 QR 리스트 출력 -- QR이 없거나 대화 리스트가 없으면 서비스 이미지 출력함   <ServiceIntro imageUri={introImgUrl}/>*/ }
						<ServiceQrBox /> 
					</View>
				</View>

				{isMsgOut && GlobalData.introImgUrl && <ServiceIntro/>}

				{/* 대화 내역 리스트  */ }
				{ !isMsgOut && qrClickStatus == CHAT_LIST_TYPE.DIALOG_LIST && 
					<View style={{ flex: 1 }}>
						<View style={styles.text_total}>
							<Text style={styles.text_detail_bold}>전체알림</Text>
							<Text style={styles.text_detail}>미응답: {global.notReadCnt}    </Text>
							<Text style={styles.text_detail}>응답완료: {global.readCnt}</Text>
						</View>
						{ global.listRoomCurrent.length == 0 ? 
						<View style={styles.emptyState}>
							<Text style={styles.noData}> 대화 내역이 없습니다. </Text>
						</View> : 
						<FlatList 
								showsVerticalScrollIndicator={false}
								removeClippedSubviews={false}
								data={global.listRoomCurrent} 
								renderItem={({ item }) => (
									<MessageBox blDelType={false} msgItem={item} friendItem={null} groupItem={null} callMsgStack={callMsgStack} />
							)}
							keyExtractor={item => item.chatSeq}
						/> }
					</View>
				}

				{/*  QR 대화 내역 리스트  */ }
				{ !isMsgOut && qrClickStatus == CHAT_LIST_TYPE.QR_DIALOG && 
				<View style={{ flex: 1 }}>
					<View style={styles.qrTotoal}>
						<View style={styles.qrDataInfo}>
							{/* <TouchableOpacity onPress={handleGroupClick} style={styles.groupButton}>
								<Text style={styles.text_detail}>그룹: {global.groupCnt}</Text>
							</TouchableOpacity> */}
							<TouchableOpacity onPress={handleFriendClick} style={styles.groupButton}>
								<Text style={styles.text_detail}>친구: {global.friendCnt}</Text>
							</TouchableOpacity>
							<TouchableOpacity onPress={handleQrMsgClick} style={styles.groupButton}>
								<Text style={styles.text_detail_bold}>채팅: {global.friendMsgCnt}</Text>
							</TouchableOpacity>
						</View>
						 
					</View>
					{ global.listRoomCurrent.length == 0 ? 
					<View style={styles.emptyState}>
						<Text style={styles.noData}> 대화 내역이 없습니다. </Text>
					</View> : 
					<FlatList 
						showsVerticalScrollIndicator={false}
						removeClippedSubviews={false}
						data={global.listRoomCurrent} 
						renderItem={({ item }) => (
							<MessageBox blDelType={true} msgItem={item} friendItem={null} groupItem={null} callMsgStack={callMsgStack} />
						)}
						keyExtractor={item => item.chatSeq}
					/> }
				</View> 
				}

				{/*  QR 친구 내역 리스트  */ }
				{ !isMsgOut &&  qrClickStatus == CHAT_LIST_TYPE.QR_FRIEND && 
				<View style={{ flex: 1 }}>
					<View style={styles.qrTotoal}>
						<View style={styles.qrDataInfo}>
							{/* <TouchableOpacity onPress={handleGroupClick} style={styles.groupButton}>
								<Text style={styles.text_detail}>그룹: {global.groupCnt}</Text>
							</TouchableOpacity> */}
							<TouchableOpacity onPress={handleFriendClick} style={styles.groupButton}>
								<Text style={styles.text_detail_bold}>친구: {global.friendCnt}</Text>
							</TouchableOpacity>
							<TouchableOpacity onPress={handleQrMsgClick} style={styles.groupButton}>
								<Text style={styles.text_detail}>채팅: {global.friendMsgCnt}</Text>
							</TouchableOpacity>
						</View>
						 
					</View>

					{ global.listFriendCurrent.length == 0 ? 
						<View style={styles.emptyState}>
							<Text style={styles.noData}>등록된 친구 내역이 없습니다.</Text>
						</View> : 
						<FlatList 
								showsVerticalScrollIndicator={false}
								removeClippedSubviews={false}
								data={global.listFriendCurrent} 
								renderItem={({ item }) => (
									<MessageBox blDelType={true} msgItem={null} friendItem={item} groupItem={null} callMsgStack={callMsgStack} />
							)}
							keyExtractor={item => item.roomNo}
						/> 
					}
				</View>
				}

				{/*  QR 그룹 내역 리스트  */ }
				{ !isMsgOut &&  qrClickStatus == CHAT_LIST_TYPE.QR_GROUP && <View style={{ flex: 1 }}>
					<View style={styles.qrTotoal}>
							<View style={styles.qrDataInfo}>
								{/* <TouchableOpacity onPress={handleGroupClick} style={styles.groupButton}>
									<Text style={styles.text_detail_bold}>그룹: {global.groupCnt}</Text>
								</TouchableOpacity> */}
								<TouchableOpacity onPress={handleFriendClick} style={styles.groupButton}>
									<Text style={styles.text_detail}>친구: {global.friendCnt}</Text>
								</TouchableOpacity>
								<TouchableOpacity onPress={handleQrMsgClick} style={styles.groupButton}>
									<Text style={styles.text_detail}>채팅: {global.friendMsgCnt}</Text>
								</TouchableOpacity>
							</View>
						</View>

						{ global.groupCnt == 0 ? 
							<View style={styles.emptyState}>
								<Text style={styles.noData}>등록된 그룹 내역이 없습니다.</Text>
							</View> : 
							<FlatList 
									showsVerticalScrollIndicator={false}
									removeClippedSubviews={false}
									data={global.listGroupCurrent} 
									renderItem={({ item }) => (
										<MessageBox blDelType={true} msgItem={null} friendItem={null} groupItem={item} callMsgStack={callMsgStack} />
								)}
								keyExtractor={item => item.roomNo}
							/> 
						}
					</View>
				}

				{/*  QR 차빼줘 내역 리스트  */ }
				{ !isMsgOut &&  qrClickStatus == CHAT_LIST_TYPE.QR_CAR_CALL && <View style={{ flex: 1 }}>
					<View style={styles.text_total}>
							<Text style={styles.text_detail_bold}>차빼줘</Text>
					</View>
					{ global.carMsgList.length == 0 ? 
						<View style={styles.emptyState}>
							<Text style={styles.noData}>호출 내역이 없습니다.</Text>
						</View> : 
						<FlatList 
							showsVerticalScrollIndicator={false}
							removeClippedSubviews={false}
							data={global.carMsgList} 
							renderItem={({ item }) => (
								<MessageBox blDelType={true} msgItem={item} friendItem={null} groupItem={null} callMsgStack={callMsgStack} />
							)}
							keyExtractor={item => item.chatSeq}
							onEndReached={handlePagginCall} // 스크롤이 끝에 도달할 때 호출
							onEndReachedThreshold={0.1} // 얼마의 거리에서 호출할지
							ListFooterComponent={isLoading ? <ActivityIndicator size="large" color="#0000ff" /> : null}
						/> 
					}
					</View>
				}
				
			
			{/* 광고 영역 표시*/ }
			{ global.isAdViewYn('AM') && <AdInfo/>}

			{ <BottomTabBar  navigation={navigation} bottonCall={bottonCall} /> }

		</SafeAreaView>
	</React.Fragment>
	);
};

// 스타일 정의
const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	scrollView: {
		flexGrow: 1,
	},
	imageContainer: {
		width: '100%', // 컨테이너의 너비
		alignItems: 'center', // 이미지 중앙 정렬
	},
	image: {
		width: '100%', // 화면 너비에 맞추기
		height: 900, // 높이는 비율에 따라 자동 조정됨
		aspectRatio: 1,
	},
	bottomContainer: {
		flex:1, width: '100%', height: '100%', justifyContent: 'flex-end', backgroundColor: '#F7F8FA',
	},
	serviceContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between', // 아이템 간의 간격 조정
		height: 120, // 적절한 높이를 설정 (예: 100)
	},
	text_total: {
		fontSize: 12,
		marginTop: 5,
		flexDirection: 'row',
		justifyContent: 'flex-start',
		padding: 10,
	},
	text_detail:{
		fontFamily: 'NotoSansKr',
		fontSize: 17,
		color: '#8A8D90'
	},
	text_detail_bold:{
		fontFamily: 'NotoSansKr',
		fontSize: 18,
		textDecorationLine: 'underline',
		fontWeight: 'bold',
		color: 'black',
		marginRight: 10,
	},
	qrTotoal: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		padding: 16,
		alignItems: 'center',
	},
	qrDataInfo: {
		flexDirection: 'row',
	},
	addFriendImage:{
		width: 24,
	height: 24,
	},
	groupButton: {
		marginRight: 16,
	},
	addbox: {
		position: 'absolute', // 절대 위치를 사용
		backgroundColor: 'white',
		borderRadius: 10,
		padding: 10,
		shadowColor: '#000',
		shadowOpacity: 0.25,
		shadowRadius: 4,
		shadowOffset: {
			height: 2,
			width: 0,
		},
		elevation: 5,
	},
	addboxContent: {
		padding: 10,
		alignItems: 'center',
	},
	addboxText: {
		fontSize: 16,
		marginVertical: 5,
	},
	addCloseButton: {
		position: 'absolute',
		top: 5,
		right: 5,
		zIndex: 10, // 다른 요소보다 위에 배치
	},
	noData: {
		fontSize: 18,             // 글자 크기 설정
		textAlign: 'center',      // 텍스트 중앙 정렬
		color: '#888',            // 글자 색상 설정 (원하는 색상으로 수정 가능)
	},
	emptyState: {
		flex: 1,                  // 가능한 전체 공간을 차지
		justifyContent: 'center', // 수직 중앙 정렬
		alignItems: 'center',     // 수평 중앙 정렬
	},
});
	

export default MainHomeScreen ;