import React, { useEffect, useRef, useState } from "react";
import { FlatList, Image,  StyleSheet, Text, TouchableOpacity, View , ActivityIndicator, StatusBar} from "react-native";
import { FaqInfo, RootStackParamList, FaqListResponse } from "../../types/common";
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { useGlobalStore,  GlobalData, apiCallGet} from '../../store/global';
import ApiInfo from "../../gvar/ApiInfo";
import { ScrollView } from "react-native-gesture-handler";
import { SafeAreaView } from 'react-native-safe-area-context';


 
const FAQScreen = () => {

    const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
    const global = useGlobalStore();

    
    const [faqList, setFaqList] = useState<FaqInfo[]>([]) ; //메세지 정보    

    const [currentNode, setCurrentNode] = React.useState<FaqInfo | null>(null);
    let isLoading = false ;
    
    const [isCall, setIsCall] = useState(true) ; //메세지 정보    

    const clickNode = (node: FaqInfo) => {
      console.log("click faq item => ", node);
      setCurrentNode(node);
    };
    

    useEffect(()  => {
      //공지 리스트 출력
      getFaqList();
    }, []);

    
    // 차빼줘  페이징 처리
	const handlePagginCall = () => {
    if (isCall) {
      getFaqList();
    }
	}

    const getFaqList = async() => {
      if (isLoading) return;
      
      isLoading = true;
      

      try {
        await apiCallGet(ApiInfo.info_faqList, {langCd:'KR'}, (type:string, obj:object) => {
          if( type=='ok' ) {
            const info = obj as FaqListResponse
            console.log("info =>" , info);
              setFaqList(info.faqInfoList as FaqInfo[]);
              setIsCall(false);
          }
          isLoading  = false;
        })
      } catch (error) {
        isLoading  = false;
        console.error("API 호출 중 오류 발생:", error);
      }
      isLoading  = false;
    }

    const RenderNode = ({ node, index }: RenderNodeProps) => (
      <TouchableOpacity
        onPress={() => clickNode(node)} // 변경됨
        key={index}
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          paddingVertical: 15,
          marginVertical: 5,
          borderColor: '#F08229',
          borderBottomWidth: 1,
          width: '90%',
          alignSelf: 'center',
        }}>
        <Text
          style={{
            flex: 1,
            paddingLeft: 10,
            fontWeight: '500',
            color: '#555',
          }}>
        <Text style={{ color: '#aaa' }}>{/*node.addDt*/} </Text> 
          {node.faqSubject}
        </Text>
        <Image
          style={{ width: 16, height: 27, resizeMode: 'contain' }}
          source={require('@/assets/icon_next_bf.png')}
        />
      </TouchableOpacity>
    );

    type RenderNodeProps = {
      node: FaqInfo
      index: number
    }


    return (
      <React.Fragment>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
      />
      <SafeAreaView style={styles.bottomContainer}>
        <View style={styles.headerContainer}>
          <TouchableOpacity style={styles.prevButton} onPress={() => {
            if (currentNode) {
            setCurrentNode(null); // 매뉴얼얼 상세 화면에서 리스트로 돌아감
            } else {
            navigation.goBack(); // 리스트 화면이라면 뒤로 가기
            }}}>
            <Image
              source={require('../../assets/ic_arr_left.png')}
              style={styles.prevIcon}
            />
          </TouchableOpacity>

          <View style={styles.titleContainer}>
            <Text style={styles.titleText}>FAQ</Text>
          </View>
        </View>
        <View style={{
          flex:1,
          backgroundColor: '#fff',
          }}>
          <View style={[styles.main, ]}> 
            {currentNode ? (
              <>
                <View style={{flex:1, }}>
                    <Text style={{ fontSize: 16, fontWeight: 'bold', marginBottom: 12 }}>{currentNode.faqSubject}</Text>
                    <ScrollView style={{flex:1, }}>
                        <Text style={{ fontSize: 12, padding:20, lineHeight: 22}}>
                            {currentNode.faqDesc}
                        </Text>
                    </ScrollView>
                </View>
              </>
            ) : (
              <FlatList
                data={faqList}
                keyExtractor={(item) => item.faqNo.toString()}
                renderItem={({ item, index }) => <RenderNode node={item} index={index} />}
                contentContainerStyle={styles.listContainer}
                removeClippedSubviews={false}
                onEndReached={handlePagginCall} // 스크롤이 끝에 도달할 때 호출
                onEndReachedThreshold={0.1} // 얼마의 거리에서 호출할지
                ListFooterComponent={isLoading ? <ActivityIndicator size="large" color="#0000ff" /> : null}
              />
            )}
          </View>
        </View>
      </SafeAreaView>
      </React.Fragment>
    );
}


export default FAQScreen;

const styles = StyleSheet.create({ 
  header: {
    backgroundColor: '#F08229',
    height: 60, // 헤더 높이 고정
    justifyContent: 'center', // 헤더 전체 수직 중앙 정렬
    alignItems: 'center', // 텍스트 중앙 정렬
    position: 'relative', // 자식 요소의 절대 위치 기준
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  preBtn: {
    position: 'absolute', // 헤더의 왼쪽 상단에 고정
    left: 5, // 왼쪽 여백
    top: 5, // 위쪽 여백
    width: 50,
    height: 50,
    justifyContent: 'center', // 버튼 중앙 정렬
    alignItems: 'center',
  },
  headerContainer:{
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  preBtnImgSize: {
    height: '100%',
    resizeMode: 'contain', // 이미지 비율 유지하며 크기 조정
  },
  headerTitle: {
    fontSize: 20, // 텍스트 크기
    fontWeight: 'bold', // 텍스트 두께
    color: '#fff', // 텍스트 색상
  },
  main: {
    flex: 1, // 남은 공간 차지
    padding: 10,
    alignContent:'center',
    alignItems:'center'
  },
  noDataText: {
    fontSize: 16,
    color: '#555',
    textAlign: 'center',
    marginTop: 20,
  },
  iptBox:{
    justifyContent: 'center',
    borderColor: '#F08229',
    borderBottomWidth: 1,
    width:'90%',
    height: 50
  },
  listContainer: {
    paddingBottom: 20,
    width: '100%',
    alignItems: 'flex-start', // optional
  },
  listItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 15,
    marginVertical: 5,
    borderColor: '#F08229',
    borderBottomWidth: 1,
  },
  itemTitle: {
    paddingLeft: 10,
    fontSize: 16,
    fontWeight: '500',
    color: '#333',
  },
  itemDate: {
    fontSize: 14,
    color: '#666',
  },
  scrollContainer: {
    flex: 1,  // 여기부터 맨 아래까지 차지
    marginTop: 10,
  },
  scrollView: {
    flex: 1,
  },
  description: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
  },
});