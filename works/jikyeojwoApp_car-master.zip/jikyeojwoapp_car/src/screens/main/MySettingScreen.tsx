import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Modal,
  FlatList,
  ScrollView,
  StatusBar
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList, MembSettingRequest,SaveResponse } from '../../types/common';
import { useGlobalStore, GlobalData, apiCallPost, GetDate} from '../../store/global';
import ApiInfo from '../../gvar/ApiInfo';
import { SafeAreaView } from 'react-native-safe-area-context';


const optionsList = {
  bell: ['차빼줘', '지켜줘'],
  language: ['KR', 'EN', 'JP', 'CH'],
  stealTime: ['5', '10', '15'],
};

const MySettingScreen = () => {
  const [sound, setSound] = useState(GlobalData.SettingData.alarmSoundYn === 'Y' ? true : false );
  const [vibration, setVibration] = useState(GlobalData.SettingData.alarmVibYn === 'Y' ? true : false);
  const [voiceTalk, setVoiceTalk] = useState(GlobalData.SettingData.callPhoneYn === 'Y' ? true : false);
  const [messageHide, setMessageHide] = useState(GlobalData.SettingData.hideMsgYn == 'Y' ? true : false);
  const [locationAllow, setLocationAllow] = useState(GlobalData.SettingData.locationYn === 'Y' ? true : false);
  const [bell, setBell] = useState(GlobalData.SettingData.alarmSoundNm);
  const [language, setLanguage] = useState(GlobalData.SettingData.langCd);
  const [stealTime, setStealTime] = useState(GlobalData.SettingData.alarmIntervalCd);

  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
  const global = useGlobalStore();

  const isFirstView = false;
 
  useEffect(() => {
        
    if (sound)   {
      if (GlobalData.SettingData.alarmSoundYn == 'Y') {
        return;
      } 
      GlobalData.SettingData.alarmSoundYn = 'Y';
    } else {
      if (GlobalData.SettingData.alarmSoundYn == 'N') {
        return;
      }
      GlobalData.SettingData.alarmSoundYn = 'N';
    }
    saveSetting('30', GlobalData.SettingData.alarmSoundYn);
  }, [sound]);

  useEffect(() => {
    if (vibration)   {
      if (GlobalData.SettingData.alarmVibYn == 'Y') {
        return;
      } 
      GlobalData.SettingData.alarmVibYn = 'Y';
    } else {
      if (GlobalData.SettingData.alarmVibYn == 'N') {
        return;
      } 
      GlobalData.SettingData.alarmVibYn = 'N';
    }
    saveSetting('50', GlobalData.SettingData.alarmVibYn);
  }, [vibration]);

  useEffect(() => {
    if (voiceTalk)   {
      if (GlobalData.SettingData.callPhoneYn == 'Y') {
        return;
      }
      GlobalData.SettingData.callPhoneYn = 'Y';
    } else {
      if (GlobalData.SettingData.callPhoneYn == 'N') {
        return;
      }
      GlobalData.SettingData.callPhoneYn = 'N';
    }
    saveSetting('60', GlobalData.SettingData.callPhoneYn);
  }, [voiceTalk]);

  useEffect(() => {
    if (messageHide)   {
      if (GlobalData.SettingData.hideMsgYn == 'Y') {
        return;
      }
      GlobalData.SettingData.hideMsgYn = 'Y';
    } else {
      if (GlobalData.SettingData.hideMsgYn == 'N') {
        return;
      }
      GlobalData.SettingData.hideMsgYn = 'N';
    }
    saveSetting('80', GlobalData.SettingData.hideMsgYn);
  }, [messageHide]);

  useEffect(() => {
    if (locationAllow)   {
      if (GlobalData.SettingData.locationYn == 'Y') {
        return;
      }
      GlobalData.SettingData.locationYn = 'Y';
    } else {
      if (GlobalData.SettingData.locationYn == 'N') {
        return;
      }
      GlobalData.SettingData.locationYn = 'N';
    }
    saveSetting('90', GlobalData.SettingData.locationYn);
  }, [locationAllow]);

  useEffect(() => {
      if (GlobalData.SettingData.alarmSoundNm == bell) {
        return;
      }
      GlobalData.SettingData.alarmSoundNm = bell;
      saveSetting('40', GlobalData.SettingData.alarmSoundNm);
  }, [bell]);

  useEffect(() => {
    if (GlobalData.SettingData.langCd == language) {
      return;
    }
    GlobalData.SettingData.langCd = language;
    saveSetting('100', GlobalData.SettingData.langCd);
  }, [language]);

  useEffect(() => {
    if (GlobalData.SettingData.alarmIntervalCd == stealTime) {
      return;
    }
    GlobalData.SettingData.alarmIntervalCd = stealTime;
    saveSetting('20', GlobalData.SettingData.alarmIntervalCd);
  }, [stealTime]);
  

  const handleBack = () => {
    navigation.goBack();
  };

  const handleGoHome = () => {
    global.updateQrClickData({serviceTypeCd: '' , qrNo: ''});
    navigation.navigate('MainHome');
  };

  const updateSetting = (type:string, values:string) => {
    console.log("sett data : " , type, values);
  }

  
  const saveSetting = (jobTypeCd:string, changeData:string) => {
    if (isFirstView) { return;}
    const settingRequest = () => {
                const node = {} as MembSettingRequest
                node.jobTypeCd = jobTypeCd;
                node.changeData = changeData;
                node.langCd = GlobalData.langCd;
                node.currentDate = GetDate();
                return node;
              }
        
    try {
      apiCallPost(ApiInfo.saveSetting, settingRequest(), (type:string, obj:object) => {
        if( type=='ok' ) {
          const info = obj as SaveResponse
          if (info.code !== '20001') {
            console.log("설정 저장 실패했습니다.");
          }
        }
      })
      } catch (error) {
          console.error("API 호출 중 오류 발생:", error);
      }
  }

  

  return (
    <React.Fragment>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
      />
    <SafeAreaView style={styles.bottomContainer}>
        <View>{/*상단바*/}
            <View style={styles.headerContainer}>
                <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                    <Image
                    source={require('../../assets/ic_arr_left.png')}
                    style={styles.prevIcon}
                    />
                </TouchableOpacity>
            
                <View style={styles.titleContainer}>
                    <Text style={styles.titleText}>설정</Text>
                </View>
            
                <TouchableOpacity style={styles.homeButton} onPress={handleGoHome}>
                    <Image
                    source={require('../../assets/ic_home_copy.png')}
                    style={styles.homeIcon}
                    />
                </TouchableOpacity>
            </View>
        </View>
        
    <ScrollView style={styles.container}>

        
      <SettingItem label="소리" value={sound} onValueChange={setSound} />
      <SettingItem label="진동" value={vibration} onValueChange={setVibration} />
      <SettingItem label="보이스톡" value={voiceTalk} onValueChange={setVoiceTalk} />
      <SettingItem label="메시지 숨김처리" value={messageHide} onValueChange={setMessageHide} />
      <CustomDropdown label="벨소리 설정" value={bell} onChange={setBell} options={optionsList.bell} />
      <CustomDropdown label="언어설정" value={language} onChange={setLanguage} options={optionsList.language} />
      <CustomDropdown label="알림설정" value={stealTime} onChange={setStealTime} options={optionsList.stealTime} />
      <SettingItem label="위치허용" value={locationAllow} onValueChange={setLocationAllow} />
    </ScrollView>
    </SafeAreaView>
    </React.Fragment>
  );
};

// ✅ 토글 스위치 커스텀
const SettingItem = ({ label, value, onValueChange }: any) => (
    <View style={styles.settingItem}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity
        onPress={() => onValueChange(!value)}
        style={[
          styles.toggleWrapper,
          value ? styles.toggleOn : styles.toggleOff,
        ]}
        activeOpacity={0.8}
      >
        <View
          style={[
            styles.toggleCircle,
            value ? styles.circleOn : styles.circleOff,
          ]}
        />
      </TouchableOpacity>
    </View>
  );

// ✅ 커스텀 드롭다운
const CustomDropdown = ({ label, value, onChange, options }: any) => {
  const [visible, setVisible] = useState(false);

  return (
    <View style={styles.dropdownRow}>
      <Text style={styles.label}>{label}</Text>
      <TouchableOpacity
        style={styles.dropdownBox}
        onPress={() => setVisible(true)}
      >
        <Text style={styles.dropdownText}>{value}</Text>
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} onPress={() => setVisible(false)}>
          <View style={styles.modalContent}>
            <FlatList
              data={options}
              keyExtractor={(item) => item}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.optionItem}
                  onPress={() => {
                    onChange(item);
                    setVisible(false);
                  }}
                >
                  <Text style={styles.optionText}>{item}</Text>
                </TouchableOpacity>
              )}
            />
          </View>
        </TouchableOpacity>
      </Modal>
    </View>   
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f2f7fcff',
    padding: 16,
  },
  sectionTitle: {
    backgroundColor: '#EFEFEF',
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontWeight: 'bold',
    color: '#333',
    fontSize: 14,
    marginTop: 20,
  },
  settingItem: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
    marginBottom:3,
  },
  label: {
    fontSize: 15,
    color: '#222',
  },
  switchImage: {
    width: 50,
    height: 30,
    resizeMode: 'contain',
  },
  dropdownRow: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomColor: '#eee',
    borderBottomWidth: 1,
    marginBottom:3,
  },
  dropdownBox: {
    backgroundColor: '#f5f5f5',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  dropdownText: {
    fontSize: 14,
    color: '#333',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: '#00000077',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    borderRadius: 8,
    width: 200,
    paddingVertical: 10,
  },
  optionItem: {
    padding: 12,
    borderBottomColor: '#ddd',
    borderBottomWidth: 1,
  },
  optionText: {
    fontSize: 14,
    color: '#333',
  },
  saveButton: {
    backgroundColor: '#FF7A00',
    marginTop: 32,
    borderRadius: 8,
    paddingVertical: 14,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },toggleWrapper: {
    width: 50,
    height: 28,
    borderRadius: 14,
    padding: 2,
    justifyContent: 'center',
  },
  toggleOn: {
    backgroundColor: '#FF7A00', // 주황색 (켜짐)
    alignItems: 'flex-end',
  },
  toggleOff: {
    backgroundColor: '#ccc', // 회색 (꺼짐)
    alignItems: 'flex-start',
  },
  toggleCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#fff',
    elevation: 2, // Android 그림자
    shadowColor: '#000', // iOS 그림자
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
  },
  circleOn: {
    transform: [{ translateX: 0 }],
  },
  circleOff: {
    transform: [{ translateX: 0 }],
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  headerContainer: {
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default MySettingScreen;
