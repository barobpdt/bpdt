import React, { useRef, useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, Image,Alert, Keyboard, TouchableWithoutFeedback, StatusBar, BackHandler, ToastAndroid } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation , CommonActions} from '@react-navigation/native';
import { RootStackParamList, ConnectRequest, ConnectResponse} from '../../types/common';
import { apiCallPost, GetDate, GlobalData, useGlobalStore} from '../../store/global';
import ApiInfo from '../../gvar/ApiInfo';
import RNFS from 'react-native-fs';  // deviId 값 가져오기 위해 사용
import messaging from '@react-native-firebase/messaging';
import { SafeAreaView } from 'react-native-safe-area-context';

const ConnectScreen = () => {
  
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const FILE_PATH = `${RNFS.DocumentDirectoryPath}/jikyeojwoDevi.txt`; 
  const global = useGlobalStore();
  // const { 
  //     versionInfo
  //   } = useGlobalStore();

  const [nickname, setNickname] = useState('');
  const [code, setCode] = useState(['', '', '', '']);
  const [pinNo, setPinNo] = useState('');
  const [saveBtnUse, setSaveBtnUse] = useState(false);
  
  
  useEffect(() => {

      // navigation.dispatch(
      //   CommonActions.reset({
      //     index: 0,
      //     routes: [{ name: 'Home' }], // 원하는 화면으로 초기화
      //   })
      // );

      // //받기용 인지 거는용인지 판단 필요
      // const backAction = () => {
      //   // 뒤로 가기 막기 (반드시 true 반환)
      //   return true;
      // };
  
      // const backHandler = BackHandler.addEventListener(
      //   'hardwareBackPress',
      //   backAction,
      // );
  
      // return () => backHandler.remove();
      }, []);

  const inputRefs = [
    useRef<TextInput>(null),
    useRef<TextInput>(null),
    useRef<TextInput>(null),
    useRef<TextInput>(null),
  ];
  // 기본정보 변경 활성화
  const [isEditable, setIsEditable] = useState(true);
 
  useEffect(() => {
    //받기용 인지 거는용인지 판단 필요
    enableSaveBtn();
  }, [nickname, pinNo]);


  //버튼 활성화 처리 기능
const enableSaveBtn = () => {    
  if (nickname.length < 1 ) {
    setSaveBtnUse (false) ;
    return;
  }
  if (pinNo.length !== 4) {
    setSaveBtnUse (false) ;
    return;
  }

  setSaveBtnUse (true) ;
}    

  const handleCodeChange = (text: string, index: number) => {
    if (!/^\d?$/.test(text)) return;

    const newCode = [...code];
    newCode[index] = text;
    setCode(newCode);

    setPinNo(newCode.join(''));
    
    console.log("pin data chk ", pinNo);

    if (text && index < 3) {
      inputRefs[index + 1].current?.focus();
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    if (e.nativeEvent.key === 'Backspace') {
      const newCode = [...code];
      if (index > 0) {
        inputRefs[index - 1].current?.focus();
      }
      newCode[index] = '';
      setCode(newCode);
    }
  };


  const handleConnect = () => {

    if (nickname.length < 1) {
      if (Platform.OS === 'android') {
        ToastAndroid.show('닉네임을 입력해주세요!', ToastAndroid.SHORT);
      } else {
        Alert.alert("닉네임을 입력해주세요!")
      }
      return;
    }
    
    if (pinNo.length !== 4) {
      if (Platform.OS === 'android') {
        ToastAndroid.show('PIN 번호 4자리를 입력해주세요!', ToastAndroid.SHORT);
      } else {
        Alert.alert("PIN 번호 4자리를 입력해주세요!")
      }
      setSaveBtnUse (false) ;
      return;
    }
   
    connectApp();
  }

  const connectParam = () => {
    //setCasList
    const node = {} as ConnectRequest
    node.nickNm = nickname
    node.pinNo=pinNo
    node.deviId=GlobalData.uniqueId
    node.deviOsVer = GlobalData.deviOsVer
    node.appVer=GlobalData.appVer
    node.deviTpCd=GlobalData.deviTpCd
    node.langCd=GlobalData.langCd
    node.currentDate=GetDate();
    return node;
  }

  const connectApp = () => {     
    try {
      console.log("connect request ", connectParam());
      apiCallPost(ApiInfo.connectApp, connectParam(), (type:string, obj:object) => {
        if( type=='ok' ) {
          const info = obj as ConnectResponse
           console.log('create info => ', info)
          if (info.code === '200') {
             // 접속성공
             successMovepage(info);
          } else {
            if (Platform.OS === 'android') {
              ToastAndroid.show(info.message, ToastAndroid.SHORT);
            } else {
              Alert.alert("오류",info.message);
            }
          }
        }
      })
      } catch (error) {
          console.error("API 호출 중 오류 발생:", error);
      }

  }

  const  successMovepage = (info: ConnectResponse) => {
    
    global.updateNoorijaToken(info.appKey);
    
    // global.updateFcmToken(global.fcmToken);
    
    GlobalData.membNo = info.membNo ;    
    
    writeFile();
    
    navigation.navigate("MainHome");
  }

  //파일 접속 정보 
  const writeFile = async () => {
    //const fileExists = await RNFS.exists(FILE_PATH);
    try {
      const token = await messaging().getToken();
      global.updateFcmToken(token);
      console.log('@@ FCM Token:', token);

			const userData = {
			  nickNm : nickname,
			  autoConnectYn: isEditable ? 'Y': 'N',
			  deviId : GlobalData.uniqueId
			};
      
			await RNFS.writeFile(FILE_PATH, JSON.stringify(userData), 'utf8');
      
    } catch (error) {
      console.log("file save error");
    }

  }

  return (
      <React.Fragment>
    
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
      />
    <SafeAreaView style={{flex:1, backgroundColor: '#fff',}}>
      <View style={styles.closeButton}>
        <TouchableOpacity /*onPress={{}}*/>
          {/*<Image 
              source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
          /> */}
          <Text style={{color:'white', fontSize:30,}}>X</Text>
        </TouchableOpacity>
      </View>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} // Android height 모드로 변경
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0} // iOS에서 위치 조정
      >
        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', width: '100%', }}>
            <Text style={styles.title}>로그인</Text>
            <View style={{width:'70%', marginBottom:20}}>
              <Text style={{paddingHorizontal:5, marginBottom:5, fontSize: 18,}}>닉네임을 입력해 주세요.</Text>
              <TextInput
                style={styles.nicknameInput}
                placeholder="닉네임을 입력해 주세요"
                value={nickname}
                onChangeText={setNickname}
              />

              <Text style={{paddingHorizontal:5, marginBottom:5, fontSize: 18,}}>PIN번호 4자리를 입력해주세요</Text>
              <View style={styles.codeContainer}>
                  {code.map((digit, index) => (
                  <TextInput
                    key={index}
                    style={styles.codeInput}
                    keyboardType="number-pad"
                    maxLength={1}
                    ref={inputRefs[index]}
                    value={digit ? '*' : ''}
                    onChangeText={(text) => handleCodeChange(text, index)}
                    onKeyPress={(e) => handleKeyPress(e, index)}
                  />
                  ))}
              </View> 
            </View>
            <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom:10}}>
              <Text style={{ marginRight: 10 , fontSize:16 }}>자동접속</Text>
              <TouchableOpacity onPress={() => {setIsEditable(prev => !prev);}} >
                  <Image
                  source={
                      isEditable
                      ? require('../../assets/check.png')    // 체크된 상태 이미지
                      : require('../../assets/check_disable.png')  // 체크 해제 이미지
                  }
                  style={{ width: 20, height: 20, marginRight: 8 }}
                  />
              </TouchableOpacity>
            </View>
            <TouchableOpacity style={[styles.button, saveBtnUse ? styles.saveButton : styles.saveUnEnableButton ]} onPress={handleConnect}>
              <Text style={[styles.buttonText, saveBtnUse?{color:'white'}:{color:'black'}]}>로그인</Text>
            </TouchableOpacity>
          </View>
        </TouchableWithoutFeedback>
      </KeyboardAvoidingView>
    </SafeAreaView>
      </React.Fragment>
  );
};

export default ConnectScreen;

const styles = StyleSheet.create({
  container: {
    
    position:'relative',
    flex: 1,
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 26,
    marginBottom: 30,
  },
  nicknameInput: {
    height: 50,
    borderColor: '#FF851D',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom:10,
    fontSize: 16,
  },
  codeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  codeInput: {
    width: 50,
    height: 50,
    borderColor: '#FF851D',
    borderWidth: 1,
    borderRadius: 10,
    textAlign: 'center',
    fontSize: 20,
    backgroundColor:'white'
  },
  button: {
    position:'absolute',
    bottom:20,
    width:'70%',
    backgroundColor: '#FF851D',
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 10,
  },
  buttonText: {
    fontSize: 18,
    textAlign:'center',
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor:'withe',
    borderRadius: 50,
    padding: 10,
  },
  saveButton: {
    backgroundColor: '#FF851D', // 저장 버튼 색상
  },
saveUnEnableButton: {
    backgroundColor: '#F1F1F1', // 저장 버튼 색상
  },
});