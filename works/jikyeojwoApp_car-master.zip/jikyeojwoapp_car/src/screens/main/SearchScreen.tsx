import React, { useState, useEffect  } from 'react';
import {
  View,
  Text,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  FlatList,
  ActivityIndicator,
  Alert,
  ScrollView,
  TextInput,
  TouchableOpacity,
  Image,
  Keyboard,
  Modal,
  StatusBar
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import MessageBox from '../../components/MessageBox.tsx';
import { useGlobalStore} from '../../store/global';
import FriendProfilePop from '../../components/FriendProfilePop.tsx';
import {
  ListRoomMessage,
  RootStackParamList,
  FriendList,
} from '../../types/common.tsx';
const SearchScreen = () => {
    const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
    const global = useGlobalStore();

    const [searchText, setSearchText] = useState(''); // <- 여기에 해당됨
    const [searchFriendList, setSearchFriendList] = useState<FriendList[]>([]);

    const [selRoomNo, setSelRoomNo] = useState(''); // <- 여기에 해당됨
    const [selFriendNo, setSelFriendNo] = useState(''); // <- 여기에 해당됨
    const [isFriendProfile, setIsFriendProfile] = useState(false); // <- 여기에 해당됨
    const [selectedOption, setSelectedOption] = useState('');

    const SelectOption = (option:string) => {
      setSelectedOption(option);

    }
    useEffect(() => {
       // 
    }, []);


  const handleBack = () => {
    navigation.goBack();
  };
    
      
  const searchCall = () => {
        Keyboard.dismiss();
        
        // if (searchText.length == 0) {
        //   return ;
        // }
        console.log("frind cnt " , global.listFriend);
        setSearchFriendList(global.listFriend.filter(m => m.nickNm.includes(searchText)));
        

  }

  
    const callMsgStack = async (jobCd: string, msgInfo: ListRoomMessage | null, friInfo: FriendList| null,  groupInfo: ListRoomMessage| null) => {
      if (friInfo == null ) return;
			setSelRoomNo(friInfo.roomNo);
			setSelFriendNo(friInfo.friendNo);
			setIsFriendProfile(true);
    };

    const closeFriendCall = (callType:string, roomNo: string) => {  // C Call 전화통화 M Msg 문자  Q qr 코드
      setIsFriendProfile(false);
    }
  
    return (
      
      <>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
      />
      <SafeAreaView style={styles.bottomContainer}>
        <KeyboardAvoidingView
          style={styles.container}
          behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <View>
              <View style={styles.headerContainer}>
                    <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
                      <Image
                        source={require('../../assets/ic_arr_left.png')}
                        style={styles.prevIcon}
                      />
                    </TouchableOpacity>
              
                    <View style={styles.titleContainer}>
                      <Text style={styles.titleText}>검색</Text>
                    </View>
                  </View>
            </View>
  
            {/* 검색창 영역 */}
            <View style={styles.searchContainer}>
              <View style={styles.searchBox}>
                <TextInput
                  style={styles.input}
                  value={searchText}
                  onChangeText={setSearchText}
                  placeholder="검색어 닉네임을 입력하세요"
                  placeholderTextColor="#aaa"
                  returnKeyType="search" // 또는 "done"도 가능
                  onSubmitEditing={searchCall}
                />
                {searchText.length > 0 && (
                  <TouchableOpacity onPress={() => setSearchText('')} style={styles.clearButton}>
                    <Text style={styles.clearText}>×</Text>
                  </TouchableOpacity>
                )}
  
                <View style={styles.iconArea}>
                  <TouchableOpacity onPress={() => searchCall()}>
                    <Image
                      style={{ width: 28, height: 28 }}
                      source={require('../../assets/ic_search.png')}
                    />
                  </TouchableOpacity>
                </View>
              </View>
            </View>
            <View style={{flexDirection:'row', gap:10, marginHorizontal:20, marginTop:10}}>
              <TouchableOpacity style={[{ paddingHorizontal:5, }, selectedOption==='friend'&&{borderBottomWidth:1, borderColor:'black'}]} onPress={() => SelectOption('friend')}>
                <Text style={[{fontSize:16, color:'#333'}, selectedOption==='friend'&&{color:'black', fontWeight:'bold',}]}>친구</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[{ paddingHorizontal:5}, selectedOption==='chat'&&{borderBottomWidth:1, borderColor:'black'}]} onPress={() => SelectOption('chat')}>
                <Text style={[{fontSize:16, color:'#333'}, selectedOption==='chat'&&{color:'#black', fontWeight:'bold',}]}>채팅</Text>
              </TouchableOpacity>
            </View>
            {/* 검색 결과 */}
            <View style={styles.resultArea}>
              <Text style={styles.resultText}>지켜줘 검색결과 {searchFriendList.length} 건</Text>
                <View style={styles.groupArea}>
                    <FlatList
                        showsVerticalScrollIndicator={false}
                        data={searchFriendList}
                        contentContainerStyle={{ paddingBottom: 50 }}
                        removeClippedSubviews={false}
                        renderItem={({ item, index }) => {
                          return (
                            <View>
                                { index == 0 ? <Text style={styles.titleText}>{item.nickNm}</Text> : item[index - 1] !== item[index] ? <Text style={styles.titleText}>{item.nickNm} </Text>: ''}
                                <MessageBox blDelType={true} msgItem={null} friendItem={item} groupItem={null} callMsgStack={callMsgStack} />
                            </View>
                        );
                        }}
                        keyExtractor={item => item.roomNo}
                    />
                </View>
            </View>            
        </KeyboardAvoidingView>

        {/* 친구 프로필*/}
			{ <Modal
				visible={isFriendProfile}
				animationType="slide"
				transparent={false} // 전체 화면 모달로 설정
			>
				<FriendProfilePop  roomNo={selRoomNo} friendNo={selFriendNo} closeFriendCall={closeFriendCall} />
		</Modal> }
      </SafeAreaView>
      
		</>
    );
  };
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollViewContent: {
    padding: 10,
    paddingBottom: 100,
  },
  searchContainer: {
    marginHorizontal:10,
    marginVertical: 10,
  },
  searchBox: {
    marginTop:10,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 25,
    borderWidth: 1,
    borderColor:'#FF851D',
    backgroundColor: '#f2f2f2',
    paddingHorizontal: 15,
    paddingVertical: 10,
  },
  input: {
    flex:1,
    height:28,
    fontSize: 14,
    padding: 0,
    color: '#000',
  },
  clearButton: {
  },
  clearText: {
    fontSize: 18,
    color: '#999',
  },
  groupArea:{
    marginVertical:10,
  },
  iconArea: {
    marginLeft: 10,
    width: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    backgroundColor: '#F7F8FA',
  },
  resultText: {
    fontSize: 18,
    fontWeight: 'bold',
    paddingVertical: 15,
  },
  emptyResult: {
    fontSize: 16,
    color: 'red',
    textAlign: 'center',
    marginTop: 40,
  },
  resultArea:{
    padding:10,
    marginHorizontal:10,
    marginBottom:40,
    flex:1,
  },
  headerContainer: {
    height: 60,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default SearchScreen;
