import React, { useRef, useState , useEffect} from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, Image, Alert, StatusBar, TouchableWithoutFeedback, Keyboard, BackHandler, ToastAndroid } from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList, ApiCasFields, DupNickNmRequest, NickNmAvailableResponse,ApiCreateSgRes, ApiCreateSg, ApiCasReg } from '../../types/common';
import { apiCallPost, GetDate, GlobalData, useGlobalStore} from '../../store/global';
import ApiInfo from '../../gvar/ApiInfo';
import { ScrollView } from 'react-native-gesture-handler';
import { useKeyboard } from '@react-native-community/hooks'; // 추가
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { SafeAreaView } from 'react-native-safe-area-context';


const RegConnectInfoScreen = ({ route }) => {       
  const insets = useSafeAreaInsets();
  const keyboard = useKeyboard(); // 키보드 높이 감지 훅 추가
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
  const { 
		versionInfo
	} = useGlobalStore();

  const [nickname, setNickname] = useState('');
  const [pinNo, setPinNo] = useState('');
  const [cPinNo, setCPinNo] = useState('');
  const [code, setCode] = useState(['', '', '', '']);
  const [codeRe, setCodeRe] = useState(['', '', '', '']);
  const [isUseNickYn, setIsUseNickYn] = useState(false);
  const [saveBtnUse, setSaveBtnUse] = useState(false);
  const [inconsistencyShow, setInconsistencyShow] = useState(false);
  
  
  const [casList, setCasList] = useState<ApiCasFields[]>([]);  // 메세지 내용
  // 기본정보 변경 활성화
  const [isEditable, setIsEditable] = useState(false);

  //뒤로가기 버튼 이벤트
  const backPressCount = useRef(0);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const handleBlur = () => enableSaveBtn();
  
    const goToConnect = () => {
      navigation.navigate("Connect");
    }
  useEffect(() => {
    //받기용 인지 거는용인지 판단 필요
    setCasList(route.params.casList);
  }, []);

  useEffect(() => {
    setIsUseNickYn(false);
    enableSaveBtn();
  }, [nickname]);

  useEffect(() => {
    console.log("test chk", isUseNickYn, pinNo, cPinNo);
    enableSaveBtn();

    //불일치 경고창 반영
    setInconsistencyShow(false)

     if(pinNo.length == 4 && cPinNo.length == 4){
      if(pinNo!=cPinNo){
        setInconsistencyShow(true)

      }else if(pinNo==cPinNo){
        setInconsistencyShow(false)
      }
    }
  }, [isUseNickYn, pinNo, cPinNo]);
  
const inputRefs = [
  useRef<TextInput>(null),
  useRef<TextInput>(null),
  useRef<TextInput>(null),
  useRef<TextInput>(null),
];
  const inputRefsRe = [
  useRef<TextInput>(null),
  useRef<TextInput>(null),
  useRef<TextInput>(null),
  useRef<TextInput>(null),
];
   

//버튼 활성화 처리 기능
const enableSaveBtn = () => {    
  
  console.log("===> isUseNickYn" , isUseNickYn, pinNo, cPinNo);

  if (!isUseNickYn) {
    setSaveBtnUse (false) ;
    return;
  }
  
  if (pinNo.length !== 4) {
    setSaveBtnUse (false) ;
    return;
  }

  if (pinNo === cPinNo) {
    setSaveBtnUse (true) ;
  } else {
    setSaveBtnUse (false) ;
  }
 
}        
  
 const handleCodeChange = (text: string, index: number) => {
     if (!/^\d?$/.test(text)) return;
 
     const newCode = [...code];
     newCode[index] = text;
     console.log("kien in new code", newCode);
     setCode(newCode);
     console.log("kien in code", code);

     setPinNo(newCode.join(''));
     console.log("pin No ", pinNo);
 
     if (text && index < inputRefs.length - 1) {
       inputRefs[index + 1].current?.focus();
     }
   };
 
   const handleKeyPress = (e: any, index: number) => {
     if (e.nativeEvent.key === 'Backspace') {
       const newCode = [...code];
       if (index > 0) {
         inputRefs[index - 1].current?.focus();
       }
       newCode[index] = '';
       setCode(newCode);
     }
   };
 
   
   const handleCodeChangeRe = (text: string, index: number) => {
     if (!/^\d?$/.test(text)) return;
 
     const newCode = [...codeRe];
     newCode[index] = text;
     console.log("kien in newCode", newCode);
     setCodeRe(newCode);
     console.log("kien in code", code);
     setCPinNo(newCode.join(''));
     if (text && index < 3) {
       inputRefsRe[index + 1].current?.focus();
     }
    

  };
 
   const handleKeyPressRe = (e: any, index: number) => {
     if (e.nativeEvent.key === 'Backspace') {
       const newCode = [...codeRe];
       if (index > 0) {
         inputRefsRe[index - 1].current?.focus();
       }
       newCode[index] = '';
       setCodeRe(newCode);
     }
   };

   const dubNickNmChk = () => {
    // 여기에 저장 로직 구현
    if (nickname.length > 0) {
       //중복체크로직
       dupchkNickNmData();
    } else {
      if (Platform.OS === 'android') {
        ToastAndroid.show('닉네임을 입력해주세요!', ToastAndroid.SHORT);
      } else {
        Alert.alert("닉네임을 입력해주세요!")
      }
    }
  }

    //닉네임 중복 체크
    
    const dupchkNickNmData = () => {
      
      const qrDupNickNmParam = () => {
          const node = {} as DupNickNmRequest
          node.nickNm= nickname
          node.langCd=GlobalData.langCd
          return node;
        }
  
      try {
        apiCallPost(ApiInfo.chkNickNm, qrDupNickNmParam(), (type:string, obj:object) => {
          if( type=='ok' ) {
            const info = obj as NickNmAvailableResponse
            console.log(info);
            if (info.availableYn === 'Y') {
              setIsUseNickYn(true);              
              if (Platform.OS === 'android') {
                ToastAndroid.show('사용가능한 닉네입입니다.', ToastAndroid.SHORT);
              } else {
                Alert.alert("사용가능한 닉네입입니다.");
              }
            } else {
              setIsUseNickYn(false);             
              if (Platform.OS === 'android') {
                ToastAndroid.show('이미 사용중인 닉네임입니다.', ToastAndroid.SHORT);
              } else {
                Alert.alert("이미 사용중인 닉네임입니다.");
              }
            }
          }
        })
        } catch (error) {
            console.error("API 호출 중 오류 발생:", error);
        }
    }

    const handleSave = () => {

      if (!isUseNickYn) {        
        if (Platform.OS === 'android') {
          ToastAndroid.show('중복체크를 해주세요!', ToastAndroid.SHORT);
        } else {
          Alert.alert("중복체크를 해주세요!")    
        }
        return;
      }
      
      if (pinNo.length !== 4) {
        if (Platform.OS === 'android') {
          ToastAndroid.show('PIN 번호 4자리를 입력해주세요!', ToastAndroid.SHORT);
        } else {
          Alert.alert("PIN 번호 4자리를 입력해주세요!")     
        }
        setSaveBtnUse (false) ;
        return;
      }
    
      if (pinNo === cPinNo) {
        setSaveBtnUse (true) ;
      } else {
        if (Platform.OS === 'android') {
          ToastAndroid.show('확인 PIN번호 입력한 PIN번호가 틀립니다.', ToastAndroid.SHORT);
        } else {
          Alert.alert("확인 PIN번호 입력한 PIN번호가 틀립니다.")   
        }
        setSaveBtnUse (false) ;
        return;
      }
     
      createSg();
    }

    const createSgParam = () => {
      //setCasList
      const node = {} as ApiCreateSg
      node.newType = versionInfo?.upRequireInfo == '10' ? '10' : '20'
      node.deviTpCd=GlobalData.deviTpCd
      node.deviId=GlobalData.uniqueId
      node.deviOsVer = GlobalData.deviOsVer
      node.appVer=GlobalData.appVer
      node.nickNm=nickname
      node.pinNo=pinNo
      node.langCd='KO'
      node.appReg=''
      node.currentDate=GetDate();
      node.casList=[] 
      for(const c of casList) {
        const cur = { casNo:c.casNo, selectYn: c.agreeYn?'Y':'N' } as ApiCasReg;
        node.casList.push(cur)
      }
      return node;
    }
  
    const createSg = () => {     
      try {
        apiCallPost(ApiInfo.create_Sg, createSgParam(), (type:string, obj:object) => {
          if( type=='ok' ) {
            const info = obj as ApiCreateSgRes
            // console.log('create info => ', info)
            if (info.code === '20003') {
              navigation.navigate("Connect");
            } else {
              if (Platform.OS === 'android') {
                ToastAndroid.show(info.message, ToastAndroid.SHORT);
              } else {
                Alert.alert("오류",info.message);
              }
            }
            // if( info.appKey ) {
            //   //GlobalData.token = info.appKey ;
            //   //GlobalData.membNo = info.membNo ;
            //   if (GlobalData.token) {
            //     //로그인 페이지 이동
            //     navigation.navigate("Connect");
            //   } else {
            //     console.log('home call 오륲:' )
            //   }
            // }
          }
        })
        } catch (error) {
            console.error("API 호출 중 오류 발생:", error);
        }
  
    }

    return (
      <React.Fragment>
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
			/>
      <SafeAreaView style={{flex:1, backgroundColor: '#fff', }}>
        <KeyboardAvoidingView
          style={{flex: 1, position:'relative',}}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'} // Android height 모드로 변경
          keyboardVerticalOffset={Platform.OS === 'ios' ? insets.bottom : 0}
        >
          <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
            <View style={{flex:1}}>
            <ScrollView
              contentContainerStyle={{
              flexGrow: 1,
              justifyContent: 'center',
              alignItems: 'center',
              paddingBottom: Platform.select({
                ios: keyboard.keyboardShown ? keyboard.keyboardHeight : 0,
                android: insets.bottom + (keyboard.keyboardShown ? keyboard.keyboardHeight : 0),
              }),}}
              keyboardShouldPersistTaps="handled"
            >
              <View style={{width:'70%',paddingVertical:50}}>
                <Text style={styles.title}>접속정보 입력</Text>
                  <View style={{marginBottom:10}}>
                    <Text style={{fontSize: 18, paddingHorizontal:5}}>닉네임을 입력해 주세요.</Text>
                    <View style={styles.inputBtnContainer}>
                      <TextInput
                        style={[styles.input, isUseNickYn?{backgroundColor:'#ededed', borderColor: 'gray',}:{backgroundColor:'white', borderColor: '#FF851D',}]}
                        maxLength={10}
                        placeholder="닉네임 입력(최대 10자리)"
                        value={nickname}
                        //editable={!isUseNickYn}
                        onChangeText={setNickname}
                        //onFocus={handleFocus}
                        onBlur={handleBlur}
                      />
                      <TouchableOpacity style={[styles.dupButton, isUseNickYn?{backgroundColor:'#ededed'}:{backgroundColor:'#FF851D'}]} onPress={dubNickNmChk}>
                        <Text style={[styles.dupButtonText, isUseNickYn?{color:'#777'}:{color:'white'}]}>중복체크</Text>
                      </TouchableOpacity>
                    </View>
                    <Text style={[{paddingHorizontal:5, color:'red', }, true&&{display:'none'}]}>중복체크 해주세요</Text>
                  </View>
                  <View style={{ marginBottom:20}}>
                    <Text style={{fontSize: 18, paddingHorizontal:5, marginBottom:3}}>PIN번호를 입력해 주세요.</Text>
                    <View style={styles.codeContainer}>
                      {code.map((digit, index) => (
                        <TextInput
                          key={index}
                          style={styles.codeInput}
                          keyboardType="number-pad"
                          maxLength={1}
                          ref={inputRefs[index]}
                          value={digit ? '*' : ''}
                          //value={digit} // 실제 값 사용
                          //secureTextEntry={true} // 보안 입력 활성화
                          onChangeText={(text) => handleCodeChange(text, index)}
                          onKeyPress={(e) => handleKeyPress(e, index)}
                          onBlur={handleBlur}
                        />
                      ))}
                    </View> 
                    <Text style={{fontSize: 18, paddingHorizontal:5, marginBottom:3}}>PIN번호를 확인해주세요.</Text>
                    <View style={styles.codeContainer}>
                      {codeRe.map((digit, index) => (
                      <TextInput
                        key={index}
                        style={styles.codeInput}
                        keyboardType="number-pad"
                        maxLength={1}
                        ref={inputRefsRe[index]}
                        value={digit ? '*' : ''}
                        onChangeText={(text) => handleCodeChangeRe(text, index)}
                        onKeyPress={(e) => handleKeyPressRe(e, index)}
                        onBlur={handleBlur}
                      />
                      ))}
                    </View> 
                    <Text style={[{paddingHorizontal:5, color:'red', }, inconsistencyShow? {display:'flex'} : {display:'none'}]}>PIN번호가 일치하지 않습니다.</Text>
                  </View>
                  <View>
                    <Text style={{fontSize:18, textAlign:'center'}}>계정이 있으신가요?</Text>
                    <TouchableOpacity onPress={goToConnect}>
                      <Text style={{color:'#FF815D', fontSize: 18, textAlign:'center',textDecorationLine: 'underline' }}>로그인</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </ScrollView>
              <TouchableOpacity style={[styles.button, saveBtnUse ? styles.saveButton : styles.saveUnEnableButton, {  bottom: Platform.select({
                ios: keyboard.keyboardShown 
                  ? keyboard.keyboardHeight + 20 // insets 제거
                  : 50 + insets.bottom, // 하단 safe area 반영
                android: keyboard.keyboardShown 
                  ? 20 // Android는 키보드 높이 자동 반영
                  : 50,
                })} ]}  onPress={handleSave}>
                <Text style={[styles.buttonText, saveBtnUse ? {color: '#fff',} : {color: 'black',} ]}>가입하기</Text>
              </TouchableOpacity>
            </View>
          </TouchableWithoutFeedback>
        </KeyboardAvoidingView>
      </SafeAreaView>
		</React.Fragment>
    );
  };

export default RegConnectInfoScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 26,
    marginBottom: 20,
    textAlign:'center',
  },
  codeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  codeInput: {
    width: 50,
    height: 50,
    borderWidth: 1,
    borderColor:'#FF851D',
    color:'black',
    borderRadius: 10,
    textAlign: 'center',
    fontSize: 20,
    backgroundColor:'white'
  },
  button: {
    width: '70%',
    height: 50,
    borderRadius: 10,
    position: 'absolute',
    alignSelf: 'center', // 가로 중앙 정렬 강제
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    fontSize: 18,
    textAlign:'center',
  },
  inputBtnContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom:0,
  },
  label: {
    fontSize: 16,
    marginBottom:  10,
    color: '#26282B'
  },
  input: {
    flex: 1,
    height: 45,
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginVertical: 3,
    fontSize: 15,
  },
  dupButton: {
    marginLeft: 10,
    borderRadius: 4,
    padding: 10,
  },
dupButtonText: {
    color: 'white',
    fontSize: 18,
  },
  saveButton: {
    backgroundColor: '#FF851D', // 저장 버튼 색상
  },
saveUnEnableButton: {
    backgroundColor: '#ddd', // 저장 버튼 색상
  },
});
