import React, {useState, useEffect, useRef} from "react";
import { Image, KeyboardAvoidingView, StyleSheet, Text, TextInput, TouchableOpacity, View, Alert, Platform, ScrollView, TouchableWithoutFeedback, Keyboard, Dimensions, Animated, LayoutChangeEvent, LayoutAnimation, StatusBar, ToastAndroid, FlatList } from "react-native";
import { RootStackParamList, AskRequest, SaveResponse } from "../../types/common";
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { useGlobalStore, GetDate, GlobalData, apiCallPost} from '../../store/global';
import ApiInfo from "../../gvar/ApiInfo";
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
type props = {
    top:number;
    width: number;
    height: number;
}
const InquriyScreen = () => {

    const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
    const global = useGlobalStore();

    const [isButtonVisible, setButtonVisible] = useState(false);
    
    const [inputEmail, setInputEmail] = React.useState('');
    const [inputTitle, setInputTitle] = React.useState('');
    const [inputContent, setInputContent] = React.useState(''); // 내용 상태 추가
    const [saveBtnUse, setSaveBtnUse] = useState(false);


    const [originalHeight, setOriginalHeight] = useState(0);
    const animatedHeight = useRef(new Animated.Value(0)).current;


    const [errEmail, setErrEmail] = React.useState('');
    const [errTitle, setErrTitle] = React.useState('');
    const [errContent, setErrContent] = React.useState(''); // 내용 상태 추가



    const handleFocus = () => enableSaveBtn();
    const handleBlur = () => enableSaveBtn();
    
const initialHeight = useRef<number>(0);
  const measurementRef = useRef<View>(null);

  // 1. 초기 높이 측정
  const captureInitialHeight = () => {
    measurementRef.current?.measure((x, y, width, height) => {
      initialHeight.current = height; // 실제 렌더링 높이 저장
    });
  };

  // 2. 키보드 닫힘 이벤트 핸들러
  const handleKeyboardClose = () => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    
    // 3. 강제 높이 재설정
    measurementRef.current?.setNativeProps({
      style: { height: initialHeight.current }
    });
  };

  //높이관련

  const insets = useSafeAreaInsets();
  const windowHeight = Dimensions.get('window').height;
  const [contentHeight, setContentHeight] = useState(windowHeight);
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    const insetsHeight = insets.bottom ? insets.bottom : 20;
        console.log("@@ insetsHeight", insets, windowHeight);
        setContentHeight(windowHeight - insetsHeight );
        
        const keyboardDidShowListener = Keyboard.addListener(
          Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow',
          (e) => {
            const hh = (Platform.OS === 'ios' ? -15: 0);
            setContentHeight(windowHeight - insetsHeight - e.endCoordinates.height - hh);
            setTimeout(() => {
              flatListRef.current?.scrollToEnd({ animated: true });
            }, 100);
          }
        );
        const keyboardWillHide = Keyboard.addListener(
          Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide',
          () => {
            setContentHeight(windowHeight - insetsHeight);
          }
        );
    
        return () => {
          keyboardDidShowListener.remove();
          keyboardWillHide.remove();
        };
  }, []);
    
  // View 크기 측정해서 저장
    const handleLayout = (e: LayoutChangeEvent) => {
      const height = e.nativeEvent.layout.height;
      if (originalHeight === 0) {
        setOriginalHeight(height);
        animatedHeight.setValue(height);
      }
    };

     useEffect(() => {
        enableSaveBtn();
      }, [inputEmail, inputTitle, inputContent]);
    

    const handleCancel = () => {
      navigation.goBack();
    }

   
    const handleSave = () => {
      if( !inputEmail ) {
        //Alert.alert('메일주소가 등록되지 않았습니다')
        if (Platform.OS === 'android') {
          ToastAndroid.show('메일주소가 등록되지 않았습니다.', ToastAndroid.SHORT);
        } else {
          Alert.alert('알림', '메일주소가 등록되지 않았습니다.');
        }
          return;
      }
      if( !inputTitle ) {
        //Alert.alert('제목이 등록되지 않았습니다')
        if (Platform.OS === 'android') {
          ToastAndroid.show('제목이 등록되지 않았습니다.', ToastAndroid.SHORT);
        } else {
          Alert.alert('알림', '제목이 등록되지 않았습니다.');
        }
        return;
      }
      if( !inputContent ) {
        //Alert.alert('내용이 등록되지 않았습니다')
        if (Platform.OS === 'android') {
          ToastAndroid.show('내용이 등록되지 않았습니다.', ToastAndroid.SHORT);
        } else {
          Alert.alert('알림', '내용이 등록되지 않았습니다.');
        }
          return;
      }
      if (saveBtnUse) {
        sendASk();
      }
    }

    const sendASk = () => {
        const AskRequestParam = () => {
          const node = {} as AskRequest
          node.email = inputEmail;
          node.askSubject = inputTitle;
          node.askDesc = inputContent;
          node.langCd = GlobalData.langCd;
          node.currentDate = GetDate();
          return node;
        }

      try {
        apiCallPost(ApiInfo.sendAsk, AskRequestParam(), (type:string, obj:object) => {
          if( type=='ok' ) {
            const info = obj as SaveResponse
            if (info.code === '30007') {
                //저장 성공  
                navigation.goBack();
            } else {
              //Alert.alert(info.message);
              if (Platform.OS === 'android') {
                ToastAndroid.show(info.message, ToastAndroid.SHORT);
              } else {
                Alert.alert(info.message);
              }
            }
          }
        })
        } catch (error) {
            console.error("API 호출 중 오류 발생:", error);
        }
    }


    const enableSaveBtn = () => {        
      // console.log("btn chk event", dupNickNmChk, nickName, pinNo, pinNo.length) ;
      if (inputEmail) {
        if (!isValidEmail(inputEmail)) {
           setSaveBtnUse(false);
           return ;
        } 
      }

      if( inputEmail && inputTitle && inputContent ) {
        setSaveBtnUse(true);
      } else {
        setSaveBtnUse(false);
      }
    
    }  

    const isValidEmail = (email) => {
      const emailRegex = /^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/;
      return emailRegex.test(email);
    };

    return (
        <React.Fragment>
          <StatusBar
            barStyle="dark-content"
            backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
          />
        <SafeAreaView style={{flex:1 , height: contentHeight, backgroundColor: '#fff' }}>
            <View style={styles.headerContainer}>
                <TouchableOpacity style={styles.prevButton} onPress={() =>navigation.goBack()}>
                    {<Image
                    source={require('../../assets/ic_arr_left.png')}
                    style={styles.prevIcon}
                    />}
                </TouchableOpacity>
                <View style={styles.titleContainer}>
                    <Text style={styles.titleText}>문의메일</Text>
                </View>
            </View>
            {/* 본문 입력 영역 */}
              <KeyboardAvoidingView
                style={{ flex: 1 }}
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'} // Android는 height
                keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0} // 필요시 조절
              >
              <View 
                ref={measurementRef}
                onLayout={captureInitialHeight} // 초기 렌더링 시 높이 캡처
                style={{ flex: 1 }}>
                <ScrollView
                  style={{ flex: 1 }}
                  contentContainerStyle={{ flexGrow: 1 }}
                  keyboardShouldPersistTaps="always"  // "always"로 변경하면 텍스트 입력 터치 시 onPress가 가로채지 않음.
                >
            <View style={[styles.iptArea, {flex:1}]}>
                <View style={styles.iptBox}>
                <TextInput
                    style={styles.textIpt}
                    onChangeText={setInputEmail}
                    placeholder="이메일"
                    value={inputEmail}
                    onBlur={handleBlur}
                />
                </View>
                

                <View style={styles.iptBox}>
                <TextInput
                    style={styles.textIpt}
                    onChangeText={setInputTitle}
                    placeholder="제목"
                    value={inputTitle}
                    onBlur={handleBlur}
                />
                </View>

                <View style={[styles.iptContent, {flex:1}]}>
                <Text style={styles.contentInq}>내용</Text>
                <TextInput
                    style={[styles.textIpt, styles.textArea]}
                    onChangeText={setInputContent}
                    multiline
                    numberOfLines={20}
                    value={inputContent}
                    onBlur={handleBlur}
                />
                </View>
            </View>
                    
            <View style={[styles.buttonContainer, isButtonVisible && styles.buttonVisible]}>
                <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={handleCancel}>
                  <Text style={styles.buttonText}>취소</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.button, saveBtnUse ? styles.saveButton : styles.saveUnEnableButton ]} onPress={handleSave}>
                  <Text style={styles.buttonText}>보내기</Text>
                </TouchableOpacity>
              </View>


              </ScrollView>
            </View>
            </KeyboardAvoidingView>
        </SafeAreaView>
        </React.Fragment>
    );
};

export default InquriyScreen;

const styles = StyleSheet.create({
    headerContainer: {
      height: 60,
      backgroundColor: '#f2f7fcff',
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 10,
    },
    prevButton: {
      width: 40,
      alignItems: 'center',
      justifyContent: 'center',
    },
    prevIcon: {
      width: 17,
      height: 17,
      resizeMode: 'contain',
    },
    titleContainer: {
      flex: 1,
      alignItems: 'center',
    },
    titleText: {
      fontSize: 16,
      fontWeight: 'bold',
      color: '#333',
    },
    iptArea: {
        alignItems: 'center',
        paddingVertical: 20,
        gap: 15,
    },
    iptBox: {
      justifyContent: 'center',
      borderColor: '#F08229',
      borderBottomWidth: 1,
      width: '90%',
      height: 50,
    },
    textIpt: {
      fontSize: 14,
      color: '#333',
      paddingHorizontal: 5,
      paddingVertical: 10,
    },
    contentInq: {
      alignSelf: 'flex-start',
      paddingLeft: '5%',
      marginBottom: 5,
      fontSize: 14,
      fontWeight: 'bold',
      color: '#555',
    },
    iptContent: {
      width: '90%',
    },
    textArea: {
      borderWidth: 1,
      borderColor: '#F08229',
      borderRadius: 6,
      padding: 10,
      minHeight: 150,
      textAlignVertical: 'top',
      fontSize: 14,
      color: '#333',
      flex:1
    },
    btnBox: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      paddingHorizontal: '5%',
      paddingVertical: 20,
    },
    btnSquareCancel: {
      flex: 1,
      backgroundColor: '#ddd',
      marginRight: 10,
      borderRadius: 6,
      justifyContent: 'center',
      alignItems: 'center',
      height: 48,
    },
    btnSquareOk: {
      flex: 1,
      backgroundColor: '#F08229',
      marginLeft: 10,
      borderRadius: 6,
      justifyContent: 'center',
      alignItems: 'center',
      height: 48,
    },
    btnCancelText: {
      color: '#333',
      fontWeight: 'bold',
      fontSize: 16,
    },
    btnOkText: {
      color: '#fff',
      fontWeight: 'bold',
      fontSize: 16,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between', // 버튼을 양 끝으로 배치
        width: '100%', // 가로 공간을 모두 차지하게 함
        backgroundColor: 'white', // 배경 색상
        borderTopWidth: 1,
        borderTopColor: 'lightgray',
        // 여백을 없앰
        padding: 0,
        bottom:0
    },
    button: {
        flex: 1,
        padding: 15,
      },
      cancelButton: {
        backgroundColor: '#F1F1F1', // 취소 버튼 색상
    },
    saveButton: {
        backgroundColor: '#FF851D', // 저장 버튼 색상
    },
    saveUnEnableButton: {
        backgroundColor: '#F1F1F1', // 저장 버튼 색상
    },
    buttonText: {
        textAlign: 'center',
        color: 'black',
        fontWeight: 'bold',
        fontSize: 16,
    },
    buttonVisible: {
        position: 'absolute', // 포커스하면 버튼이 위쪽으로 올라오게 설정
        bottom: 20,
    },
    bottomContainer: {
        flex:1
    },
});
  