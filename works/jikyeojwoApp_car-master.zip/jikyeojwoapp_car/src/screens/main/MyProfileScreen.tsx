import React, { useState, useEffect, useContext } from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet, ScrollView, Modal, PermissionsAndroid, Platform, Alert, StatusBar, ToastAndroid } from 'react-native';
import BottomTabBar from '../../components/BottomTabBar';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import {RootStackParamList, SendType, MainResponse, InfoSetting} from '../../types/common.tsx'
import { useGlobalStore, updateMainResponse, GlobalData} from '../../store/global';
import WriteMyProfilePop from '../../components/WriteMyProfilePop.tsx';
import QrSelectViewPop from '../../components/QrSelectViewPop.tsx';
import CallScannerPop from '../../components/CallScannerPop.tsx';
import SelectCallMsgPop from '../../components/SelectCallMsgPop.tsx';
import Geolocation from 'react-native-geolocation-service';
import { check, PERMISSIONS, request, RESULTS } from 'react-native-permissions';
import { SafeAreaView } from 'react-native-safe-area-context';
import { SocketStompContext  } from '../../utils/WebSocketManager';
import RNFS from 'react-native-fs';  // deviId 값 가져오기 위해 사용


const MyProfileScreen = () => {
   
   const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
   const global = useGlobalStore();  
   const FILE_PATH = `${RNFS.DocumentDirectoryPath}/jikyeojwoDevi.txt`; 
   
   const [nickname, setNickname] = useState('');  
   const [introductionInfo, setIntroductionInfo] = useState('');
   const [imgFileUrl, setImgFileUrl] = useState(''); 
   const [isModifyProfile, setIsModifyProfile] = useState(false);  // QR 전화 문자 스캔

   //전화통화 문자 를 위한 스캔 처리
   const [callQrNo, setCallQrNo] = useState('');
   const [callScannerView, setCallScannerView] = useState(false);  // QR 전화 문자 스캔
   const [isPopQrCall, setIsPopQrCall] = useState<boolean>(false);  // 전화 또는 문자시 QR선택 화면 뛰이기
   const [isSelCallMsgPop, setIsSelCallMsgPop] = useState<boolean>(false);  // 전화 또는 문자 선택
   const [callTargetQrNo, setCallTargetQrNo] = useState(''); // 전화대상 qr

   const { disconnect } = useContext(SocketStompContext);
   
   useEffect(() => {
      console.log("my data ", global.globalData.appMenuList);
      requestLocationPermission();
      setNickname(global.membInfo.nickNm);
      setIntroductionInfo(global.membInfo.introductinInfo);  
      setImgFileUrl(global.membInfo.imgFileUrl);
   }, []);
   
   //맨 아래 QR 전화 문자 하기 스캔 화면 오픈
  const bottonCall = (jobType:string) => {
    const filteredList = global.listMyQr.filter(item => item.serviceTypeCd === 'Protect');
    //jobType Q : 스캔  ,H : home 
        if (jobType == "Q"){
          if (filteredList.length == 1) {
            setCallQrNo(filteredList[0].qrNo);
            // global.setCurrentScanType('CallScanner');
            global.setPopupPageId('ScanPopup');
            global.setCurrentScanInfo({serviceTypeCd: '', qrNo: '', viewType: 'CallScanner', myQrNo: ''});
          } else if (filteredList.length > 1) {
              //t선택 팝업이 오픈해야함
            console.log("qr select pop")	;
            setIsPopQrCall(true);
          } else {
            if (Platform.OS === 'android') {
              ToastAndroid.show('지켜줘 등록한 QR이 없습니다. QR등록후 실행해주세요!', ToastAndroid.SHORT);
            } else {
              Alert.alert('호출불가','지켜줘 등록한 QR이 없습니다. QR등록후 실행해주세요!')
            }
          }
        } else if (jobType == "H") {
          global.updateQrClickData({serviceTypeCd: '' , qrNo: ''});
          navigation.navigate("MainHome");
        }    
  } 


  const closeWriteProfile = () => {
    console.log("closeWriteProfile           ");
    setNickname(global.membInfo.nickNm);
    setIntroductionInfo(global.membInfo.introductinInfo);  
    setImgFileUrl(global.membInfo.imgFileUrl);
    setIsModifyProfile(false);
  }

  const goModifyProfile = () => {
    setIsModifyProfile(true);
    //getLocation();
  }

  const getLocation = () => {
    Geolocation.getCurrentPosition(
      position => {
        console.log(position);
        if (Platform.OS === 'android') {
          ToastAndroid.show( `Lat: ${position.coords.latitude}, Lon: ${position.coords.longitude}`, ToastAndroid.SHORT);
        } else {
          Alert.alert("Location", `Lat: ${position.coords.latitude}, Lon: ${position.coords.longitude}`);
        }
      },
      error => {
        console.warn(error.message);
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 10000,
      }
    );
  };


  const requestLocationPermission = async () => {
    try {
      if (Platform.OS === 'android') {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          console.log('Location permission granted');
        } else {
          console.log('Location permission denied');
        }
      } else {
        const result = await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE);
        if (result === RESULTS.GRANTED) {
          console.log('Location permission granted');
        } else {
          console.log('Location permission denied');
        }
      }
    } catch (err) {
      console.warn(err);
    }
  };
 
  const onOpenMyQrList = () => {
    global.setPopupPageId('MyQrListPop');
  }

  const goToMenu = (appMenuNo:string) => {
    
    if (appMenuNo == "AP2005") {  // 설정
      navigation.navigate("MySetting");
    } else if (appMenuNo == "AP2001") {  //공지사항
      navigation.navigate("Notice");
    } else if (appMenuNo =="AP2004") { //메뉴얼
      navigation.navigate("Manual");
    } else if (appMenuNo == "AP2002") {  //FAQ
      navigation.navigate("Faq");
    } else if (appMenuNo == "AP2003") {  // 1:1 문의
      navigation.navigate("Inquiry");
    }
  }

  const onQrSelectViewClose = (qrNo: string) => {
    setIsPopQrCall(false);
    console.log("select data qr ", qrNo);
    if (qrNo != '' && qrNo != 'close') {
      setCallQrNo(qrNo);
      setCallScannerView(true);  //dwkim  파라메타 전달하여 오픈해야함
    }
  }

  const onCallQRRead = (data: string) => {
		//Alert.alert("==" + data + "==" + scannerServiceTypeCd);
		//setSelQrNo(data); //추가할 QR 번호
		setCallScannerView(false);
		setCallTargetQrNo(data);
		//API 호출하여 구독 정보를 제공한다. 전송할 구독 정보 -- roomNo, 
		setIsSelCallMsgPop(true);  
		//Alert.alert("전화걸기 위한 QR정보 처리 " , data); 
	};

  const closeCallScanner = () => {
		setCallScannerView(false); //스캔팝업 오픈
	};

  const onSelType = (callProcData: SendType) => {
      // const callProcData: SendType = {
      // 		roomNo: sendData?.roomNo || '', // 기본값을 사용하거나 처리 방법을 정합니다
      // 		roomNm: sendData?.roomNm || '',
      // 		serviceTypeCd: sendData?.serviceTypeCd || '',
      // 		sendSubscr: sendData?.subScr || '',
      // 		sendMothod: mothodType,
      // 	  };
      setIsSelCallMsgPop(false);
  
      if (callProcData.sendMothod == "B") {
        //보이스톡
      } else if (callProcData.sendMothod == "C") {
        // 채팅
      }
  
    }

    const logOut = () => {       
      writeFile();
      global.setProcessScreen('Connect');
      navigation.navigate("Connect");
    }

    const writeFile = async () => {
      //const fileExists = await RNFS.exists(FILE_PATH);
      try {
        
        const userData = {
          nickNm : '',
          autoConnectYn: 'N'
        };
        
        await RNFS.writeFile(FILE_PATH, JSON.stringify(userData), 'utf8');
        
      } catch (error) {
        console.log("file save error");
      }
  
    }

    const handleLogout=()=>{
      Alert.alert(
            '로그아웃 확인',
            '로그아웃 하시겠습니까?',
            [
              {
                text: '취소',
                style: 'cancel',
              }, {
                text: '확인',
                style: 'destructive',
                onPress: () => logOut()
              }
            ],
            { cancelable: true }
          );
    }

  return (
    <React.Fragment>
  
    <StatusBar
      barStyle="dark-content"
      backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
    />
    <SafeAreaView style={styles.bottomContainer}>
        <View style={styles.headerContainer}>
            <TouchableOpacity style={styles.prevButton} onPress={() =>navigation.goBack()}>
                <Image
                source={require('../../assets/ic_arr_left.png')}
                style={styles.prevIcon}
                />
            </TouchableOpacity>

            <View style={styles.titleContainer}>
                <Text style={styles.titleText}>MY</Text>
            </View>
        </View>


        <ScrollView style={styles.container}>
        {/* 프로필 */}
        <TouchableOpacity  onPress={()=>goModifyProfile()} > 
            <View style={styles.profileBox}>
                <View>
                <Text style={styles.profileTitle}>{nickname}</Text>
                <Text style={styles.profileSubtitle}>{introductionInfo}</Text>
                </View>
                <View style={styles.profileImageWrapper}>
                {imgFileUrl ? (
                              <Image
                                  source={{uri: imgFileUrl} } 
                                  style={styles.profileImage}
                              /> ) : ('')} 
                </View>
            </View>
        </TouchableOpacity>
        {/* QR 모아보기 QrList*/}
        <TouchableOpacity style={styles.qrBox} onPress={() => onOpenMyQrList()} > 
            <View style={styles.qrLeft}>
            <Image
                source={require('../../assets/qr.png')}
                style={styles.qrIcon}
            />
            <View>
                <Text style={styles.qrTitle}>QR 모아보기</Text>
                <Text style={styles.qrSubtitle}>등록한 QR을 한번에 확인하세요!</Text>
            </View>
            </View>
            <Image
                source={require('../../assets/icon_next_bf.png')}
            style={styles.arrowIcon}
            />
        </TouchableOpacity>

        {/* 메뉴 리스트 */}
      {global.globalData.appMenuList.map((item, idx) => (
        <TouchableOpacity
          key={item.appMenuNo}
          style={styles.menuItem}
          onPress={() => goToMenu(item.appMenuNo as never)} // <== 여기에 연결
        >
          <Text style={styles.menuText}>{item.appMenuNm}</Text>
          <Image
            source={require('../../assets/icon_next_bf.png')}
            style={styles.arrowIcon}
          />
        </TouchableOpacity>
      ))}        
      {/* 로그아웃 버튼 추가 */}  
      <TouchableOpacity
        style={{ marginTop: 20, borderColor: '#eee', marginRight:20}}
        onPress={handleLogout} // 이건 나중에 직접 구현
      >
        <Text style={[{ fontSize:16, color: '#FF851D', fontWeight: 'bold', textAlign:'right' }]}>로그아웃</Text>
      </TouchableOpacity>

        </ScrollView>


        { <BottomTabBar  navigation={navigation} bottonCall={bottonCall} /> }

       
    

    { <Modal
        visible={isModifyProfile}
        animationType="slide"
        transparent={false} // 전체 화면 모달로 설정
      >
        <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
          <WriteMyProfilePop closeWriteProfile={closeWriteProfile}  />
        </SafeAreaView>
    </Modal> }
    
    { isPopQrCall && ( <QrSelectViewPop popVisible={isPopQrCall} onQrSelectViewClose={onQrSelectViewClose}  />) }

    { <Modal
				visible={callScannerView}
				animationType="slide"
				transparent={false} // 전체 화면 모달로 설정
			>
				<CallScannerPop callQrNo={callQrNo} onCallQRRead={onCallQRRead} closeCallScanner={closeCallScanner} />
				
		</Modal> }

    {/* 통화 문자 선택 팝업*/}
		{ <Modal
				visible={isSelCallMsgPop}
				animationType="slide"
				transparent={true} // 전체 화면 모달로 설정
			>
				<SelectCallMsgPop  callQrNo={callQrNo} targetQrNo={callTargetQrNo} onSelType={onSelType} />
		</Modal> }
    </SafeAreaView>
    </React.Fragment>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
    padding: 12,
  },
  headerContainer:{
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'flex-end',
    backgroundColor: '#F7F8FA',
  },
  profileBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFE7BD',
    paddingVertical: 18,
    paddingHorizontal: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 12,
  },
  profileTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 4,
  },
  profileSubtitle: {
    fontSize: 13,
    color: '#666',
  },
  profileImageWrapper: {
    backgroundColor: '#fff',
    borderRadius: 999,
    borderColor:'#ddd',
    borderWidth:1,
    overflow:'hidden',
    position:'relative',
    width: 60,
    height: 60,
    
  },
  profileImage: {
    position:'absolute',
    left:0,
    right:0,
    top:0,
    bottom:0,
    resizeMode: 'cover',
  },
  qrBox: {
    backgroundColor: '#fff9f3',
    borderColor:'#FF851D',
    borderWidth:1,
    borderRadius: 10,
    padding: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  qrLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  qrIcon: {
    width: 32,
    height: 32,
    resizeMode: 'contain',
    marginRight: 12,
  },
  qrTitle: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#000',
  },
  qrSubtitle: {
    fontSize: 12,
    color: '#888',
    marginTop: 4,
  },
  arrowIcon: {
    width: 18,
    height: 18,
    resizeMode: 'contain',
  },
  menuItem: {
    backgroundColor: '#fff9f3',
    borderBottomWidth:2,
    borderColor:'gray',
    paddingVertical: 16,
    paddingHorizontal: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  menuText: {
    fontSize: 15,
    color: '#222',
  },
});

export default MyProfileScreen;

