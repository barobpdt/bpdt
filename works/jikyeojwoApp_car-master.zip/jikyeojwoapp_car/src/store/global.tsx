import { create } from 'zustand';
import { useContext} from 'react';
import { Alert, NativeModules, Platform, ToastAndroid } from 'react-native';
import NetInfo, { NetInfoState, NetInfoStateType } from "@react-native-community/netinfo";
import DeviceInfo from 'react-native-device-info'; 
import { ApiVersionInfo, ApiError, ApiCreateSgRes, ListService, ListAdView, InfoSetting, ListAppMenu, FCM_RecvData
	  , NotificationData, ListRoom, MainResponse, ListRoomMessage, FriendList, QrDtlFriendListResponse
	  , QrDtailMsgListRequest, QrDtlMsgListResponse, QrDtlCarMsgListResponse, ListSubscr, ListMyQr, QrClickType, 
	  MessageData, NetworkType, MessageLocation, FriendLocation, RoomChatMsgInfo, MessageSendRead,
	  ListAlert,
	  MembLocation,
	  ChkRoomInfoResponse,
	  ChkRoomInfoRequest,
	  CallSeqResponse, ChatFriendInfo, ChangeRoomInfoRequest, RemoveData} from '../types/common';


// Chat list type constants
export const CHAT_LIST_TYPE = {
	DIALOG_LIST: '10',      // 대화내역리스트 - 전체
	QR_DIALOG: '20',        // Qr대화내역 
	QR_FRIEND: '30',        // Qr친구내역
	QR_CAR_CALL: '40',       // Qr차호출내역
	QR_GROUP: '50'        // QR그룹
};

export const OPEN_LIST_TYPE = {
	SPLASH: '10',
	TUTORIAL: '20',
	MAIN: '30',	
	REG: '40',	
};

const packageJson = require('../../package.json');
const serverMode : boolean = false // 개발:dev,  운영:server 로 설정

import RNFS from 'react-native-fs';  // deviId 값 가져오기 위해 사용
import * as Keychain from 'react-native-keychain'; // ios 키값 가져오기
import ApiInfo from '../gvar/ApiInfo';
import { useAppsStore } from './apps';

const { DeviceInfoModule } = NativeModules;
const FILE_PATH = `${RNFS.DocumentDirectoryPath}/jikyeojwoDevi.txt`; 
const log = console.log



export const GlobalData = {
	changeType: '', // 어떤내용이 변경되었는지 체크
	callUrl:  serverMode ? 'https://call.jikyeojo.com' : 'https://kosk.co.kr',
	infoUrl:  serverMode ? 'https://info.jikyeojo.com' : 'https://info.kosk.co.kr',
	sockUrl:  '/signaling',
	langCd: 'KR',
	token: '',
	storeUrl: '',
	uniqueId: '',
	deviTpCd: '',
	deviOsVer: '',
	appVer: '',
	currentDate: '',
	networkIsConnect: false,
	networkType: '',
	pageInfo: '',
	chatRoomNo: '',  // pageInfo Chat일경우 chatRoomNo 넣어줘야함
	membNo: '',
	introImgUrl: '',
	serviceList: [] as ListService[],
	adViewList: [] as ListAdView[],
	SettingData: {} as InfoSetting,
	appMenuList: [] as ListAppMenu[],
	listRoomInfo: [] as ListRoom [],
	//listAlert: [] as ListAlert[],
	messageMap: {},
	gridSize: 15,
	chatGridSize: 15,
	socketConnectYn: 'N',
	myKey: '',
	isPeerConnect: false,  // webRtc 연결여부
	webRtcStatus: '',  // 통화 중인지 여부 판단  Calling, Called 통화 요청을 받을 경우 통화중 메세지 전송 처리함
	nickNm: '',
	autoConnectYn: 'N',
	colLocationTime: 10
}

export const MembInfo = {
	nickNm : '',
	introductinInfo: '',
	imgFileUrl: ''
}

export const apiCallGet = (apiurl:string, params = {}, callback = (type:string, obj:object)=>{}) => {
	const queryParameters = new URLSearchParams({...params}) ;
	const url=`${GlobalData.infoUrl}${apiurl}?${queryParameters}`;
	console.log("API GET URL:"+url, params);
	fetch(url, {
		method: 'GET',
		headers: {
			'Authorization': 'Bearer ' + GlobalData.token, // 헤더 설정
			'Content-Type': 'application/json', // 요청의 콘텐츠 타입 설정 (선택 사항)
		},
	}).then(res=> res.json() ).then(json=>callback('ok',json)).catch(err=>callback('error',err))
}; 

export const apiCallPost = (apiurl:string, params = {}, callback = (type:string, obj:object)=>{}) => {
	var callUrl = GlobalData.infoUrl + apiurl; 
	var node = params instanceof FormData ? {
		method: 'POST',
		headers: {
			'Authorization': 'Bearer ' + GlobalData.token,
			'Content-Type':  'multipart/form-data',
		},
		body: params
	} : {
		method: 'POST',
		headers: {
			'Authorization': 'Bearer ' + GlobalData.token, // 헤더 설정 ==========================versionInfo로 변경할지 아니면 해당 값을 넣을지 판단 필요
			'Content-Type': 'application/json', // 요청의 콘텐츠 타입 설정
		},
		body: JSON.stringify(params),
	}
	console.log("@@ apiCallPost node : ", callUrl, node);
	fetch(callUrl, node).then(res=> res.json()).then(json=>callback('ok',json)).catch(err=>callback('error',err))
}

export const apiFileCallPost = (apiurl:string, params:FormData, callback = (type:string, obj:object)=>{}) => {
	var callUrl = GlobalData.infoUrl + apiurl ;  
	
	console.log("trans params : " , params);
	
	fetch(callUrl, {
		method: 'POST',
		headers: {
		'Authorization': 'Bearer ' + GlobalData.token, // 헤더 설정
		'Content-Type': 'multipart/form-data', // 요청의 콘텐츠 타입 설정
	},
	body: params,
	}).then(res=> res.json() ).then(json=>callback('ok',json)).catch(err=>callback('error',err))
}

export const callPost = async (url:string, params:object) => {
	return new Promise((resolve, reject) =>  apiCallPost(url, params, (type, response) => type === 'ok' ? resolve(response): reject(response)) )
}
export const callGet = async (url:string, params:object) => {
	return new Promise((resolve, reject) =>  apiCallGet(url, params, (type, response) => type === 'ok' ? resolve(response): reject(response)) )
}

export const GetDate = (date=new Date): string => {	
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	const seconds = String(date.getSeconds()).padStart(2, '0');
	return `${year}${month}${day}${hours}${minutes}${seconds}`;
}

export const GetDateDay = (date=new Date): string => {	
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');
	return `${year}.${month}.${day}`;
}

export const GetDateTime = (date=new Date): string => {	
	const hours = String(date.getHours()).padStart(2, '0');
	const minutes = String(date.getMinutes()).padStart(2, '0');
	const seconds = String(date.getSeconds()).padStart(2, '0');
	return `${hours}:${minutes}:${seconds}`;
}

export type ApiResult = {
	code:string;
	message:string;
	appKey:string;
	status?:number;
	path?:string;
	error?:object;
	isAlert?:string;
	regQr?:string;
	errors?:ApiError[]
}

async function getSecureValue(key: string): Promise<string> {
	const result = await Keychain.getInternetCredentials(key);
	if (result) {
		return result.password;
	}
	return '';
}

function setSecureValue(key: string, val:string) {
	Keychain.setInternetCredentials(key, key, val)
}

const getJikyeojwoKey = async () : Promise<string> => {
	let saDeviId = "";
	try {
		saDeviId  = await DeviceInfoModule.getJikyeojwoKey() ; //await DeviceInfoModule.getJikyeojwoKey();
		
	} catch (error) {
		console.error("Error fetching noorija key:", error);
		
	}
	return saDeviId ;
};

export const selectGrobalData = async() => {
	console.log("selectGrobalData");
	const fileExists = await RNFS.exists(FILE_PATH);
	let uuid = '';
	
	const systemName = DeviceInfo.getSystemName().toString();
	//GlobalData.uniqueId = (await DeviceInfo.getUniqueId());
	GlobalData.deviOsVer = DeviceInfo.getSystemVersion();
	GlobalData.appVer = packageJson.version;

	if (systemName == "Android") {
		GlobalData.deviTpCd = "SA" ;
	} else if (systemName == "iOS") {
		GlobalData.deviTpCd = "SI" ;
	} else {
		GlobalData.deviTpCd = "" ;
	}
	

	if (fileExists) {  //파일이 존재할경우
		const fileContent  = await RNFS.readFile(FILE_PATH, 'utf8');
		
		try {
			const userData = JSON.parse(fileContent);
			console.log("file contentx ======================>", userData);

			if (userData) {
				GlobalData.nickNm = userData.nickNm;
				GlobalData.autoConnectYn = userData.autoConnectYn;
				uuid = userData.deviId;
				console.log("file data content ", fileContent, userData, GlobalData);
			} 
		} catch (error) {
			console.log("file errro json");
		}
		
        
		if (uuid) {
			GlobalData.uniqueId = uuid ;
		} else {
			if (GlobalData.deviTpCd == "SI") {
				uuid = await getSecureValue('JIKYEOJWO_DEVICE_ID')

				if( uuid && uuid != GlobalData.uniqueId ) {
					GlobalData.uniqueId=uuid
				} else if(GlobalData.uniqueId) {
					setSecureValue('JIKYEOJWO_DEVICE_ID', GlobalData.uniqueId)
					uuid = await getSecureValue('JIKYEOJWO_DEVICE_ID')
					if(uuid) {
						GlobalData.uniqueId=uuid
					}
				}
			} else  {
				GlobalData.uniqueId = await getJikyeojwoKey();  //await DeviceInfo.getAndroidId() ; //await getJikyeojwoKey(); 
			}
			console.log("file exist context null: " , uuid);
			try {
				const userData = {
				  nickNm : GlobalData.nickNm,
				  autoConnectYn: GlobalData.autoConnectYn,
				  deviId : GlobalData.uniqueId
				};
				await RNFS.writeFile(FILE_PATH, JSON.stringify(userData), 'utf8');
			  } catch (error) {
				//Alert.alert('파일 저장 오류', error.message);
			  }
		}

	} else {  // 파일이 없을 경우 최초 설치임
		
		console.log("devi typ value==>" , GlobalData.deviTpCd);
		if (GlobalData.deviTpCd == "SI") {
			uuid = await getSecureValue('JIKYEOJWO_DEVICE_ID')

			if( uuid && uuid != GlobalData.uniqueId ) {
				GlobalData.uniqueId=uuid
			} else if(GlobalData.uniqueId) {
				setSecureValue('JIKYEOJWO_DEVICE_ID', GlobalData.uniqueId)
				uuid = await getSecureValue('JIKYEOJWO_DEVICE_ID')
				if(uuid) {
					GlobalData.uniqueId=uuid
				}
			}
		} else  {
			GlobalData.uniqueId = await getJikyeojwoKey();  //await DeviceInfo.getAndroidId() ; //await getJikyeojwoKey(); 
		}
		console.log("file not exist : " , uuid);
		try {
			const userData = {
			  nickNm : GlobalData.nickNm,
			  autoConnectYn: GlobalData.autoConnectYn,
			  deviId : GlobalData.uniqueId
			};
			await RNFS.writeFile(FILE_PATH, JSON.stringify(userData), 'utf8');
		  } catch (error) {
			console.log("file save error");
		  }
	}
	
	//dwkim test deviid
	// if (systemName == "Android") {
	// 	console.log("systemName ==> ", systemName);
	// 	GlobalData.uniqueId = '961f93975e7e16f9';
	// }
	
	//console.log("GlobalData.deviTpCd Name:", GlobalData.deviTpCd); // 추가한 로그
}

// Define the store state type
interface GlobalStore {
	globalData: typeof GlobalData;
	membInfo: typeof MembInfo;
	versionInfo: ApiVersionInfo | null;
	tokenInfo: ApiCreateSgRes | null;
	notificationData: NotificationData | null;
	notificationTick: number;
	fcmToken: string; // FCM 토큰 
	noorijaToken?: string; // 누리자 API 토큰 
	selectedRoomMessage: ListRoomMessage | null;	// 클릭된 방 메시지 정보
	listRoomCurrent: ListRoomMessage[]; // 방 메시지 목록
	listRoomMessage: ListRoomMessage[]; // 방 메시지 목록
	listAlert: ListAlert[];
	listService: ListService[]; // 서비스 목록
	listAdView: ListAdView[]; // 광고 뷰 목록
	friendList: FriendList[]; // 친구 목록
	listFriendCurrent: FriendList[]; //출력중인 친구목록
	friendCnt: number; // 친구 수
	friendMsgCnt: number; // 친구 메시지 수
	qrMsgCnt: number; // QR 메시지 수
	notReadCnt: number;
	readCnt: number
	qrMsgList: ListRoomMessage[]; // QR 메시지 목록
	lastChatSeq: string; // 마지막 채팅 시퀀스
	startChatSeq: string; // 첫번째 채팅 시퀀스
	currentFcmRecvData: FCM_RecvData|null; // 현재 받은 푸시 메시지 정보
	incallKey: string; // 현재 통화 중인 키
	listMyQr: ListMyQr[]; // 내 QR 목록
	listMyQrCurrent: ListMyQr[]; // 내 QR 목록 현재값
	//listMyQrProtect: ListMyQr[]; // 지켜줘QR 리스트
	//listMyQrCar: ListMyQr[]; // 차빼줘QR 리스트
	qrClickData: QrClickType;
	networkStatus: NetworkType;
	isActive: boolean;
	isAppActive: boolean;
	listLocation: FriendLocation[];
	listRoomChatMsg:RoomChatMsgInfo[];
	listRoomFriend:ChatFriendInfo[];
	infoLocation: MembLocation;
	processScreen: string; // 현재 프로세스 화면
	prevProcessScreen: string; // 이전 프로세스 화면
	currentRoomInfo: {roomNo: string, roomNm: string, roomImg: string}; // 현재 방 번호
	setCurrentRoomInfo: (roomNo: string, roomNm: string, roomImg: string)=>void; // 현재 방 번호
	currentItem: {
		jobCd: string;
		msgInfo: ListRoomMessage | null;
		friInfo: FriendList | null;
	} | null; // 현재 선택된 아이템 정보
	audioMode: string;
	setAudioMode: () => void;
	setProcessScreen: (screen: string) => void; // 프로세스 화면 설정 함수
	setCurrentItem: (item: { jobCd: string; msgInfo: ListRoomMessage | null; friInfo: FriendList | null; } | null) => void; // 현재 아이템 설정 함수
	setCurrentFcmRecvData: (data: FCM_RecvData|null) => void;
	getMessageData: (mType: string, myQrNo: string, targetQrNo: string) => Promise<MessageData>;
	getChatMessageData: (serviceTypeCd: string, chatNo: string, gridInsertData: ChatFriendInfo[]) => Promise<MessageData>;
	getRoomClickMessageData: (mType:string, roomInfo : ListRoomMessage) => Promise<MessageData>;
	sockJsData: {
		messageList: MessageData[];
		connectionStatus: 'connected' | 'disconnected' | 'connecting';
		error: string | null;
	};	
	setHomeActive: (isActive: boolean) => void;
	setAppActive: (isActive: boolean) => void;
	updateSockJsConnection: (status: 'connected' | 'disconnected' | 'connecting', error?: string) => void;
	addSockJsMessage: (message: MessageData) => void;
	clearSockJsMessages: () => void;
	updateGlobalData: (data: Partial<typeof GlobalData>) => void;
	updateMembInfo: (data: Partial<typeof MembInfo>) => void;
	updateVersionInfo: (data: ApiVersionInfo) => void;
	updateNotificationData: (data: NotificationData) => void;
	updateFcmToken: (token: string) => void;
	updateNoorijaToken: (token: string) => void;
	getVersion:	() => Promise<boolean>;
	createSg: () => Promise<ApiCreateSgRes>;
	resetStore: () => void;
	// 메시지 관련 함수
	initCurrentRoomMessage: () => void;
	setCurrentRoomMessage: (etcInfo:string) => void;
	addRoomMessage: (message: ListRoomMessage) => void;
	removeRoomMessage: (chatSeq: string) => void;
	updateRoomMessage: (message: ListRoomMessage) => void;
	filterRoomMessage: (serviceTypeCd:string, qrNo:string) => void;
	// 서비스 관련 함수
	addService: (service: ListService) => void;
	removeService: (serviceCd: string) => void;
	updateService: (service: ListService) => void;
	// 광고 뷰 관련 함수
	addAdView: (adView: ListAdView) => void;
	removeAdView: (adCd: string) => void;
	updateAdView: (adView: ListAdView) => void;
	isAdViewYn: (adCd: string) => boolean; // 광고 사용 여부 확인 함수
	// 친구 목록 관련 함수
	updateFriendList: (FriendList: FriendList[]) => void;
	filterFriendList: (serviceTypeCd:string, qrNo:string) => void;
	removeFriendList: (serviceTypeCd:string, friendQrNo:string, qrNo:string) => void;

	addFriend: (friend: FriendList) => void;
	removeFriend: (friendNo: string) => void;
	updateFriend: (friend: FriendList) => void;
	//changeLocationFriend: (friend: FriendList) => void;

	// 그룹 목록 관련 함수
	updateGroupList: (GroupList: ListRoomMessage[]) => void;
	filterGroupList: (serviceTypeCd:string, qrNo:string) => void;
	addGroup: (group: ListRoomMessage) => void;
	removeGroup: (groupNo: string) => void;
	updateGroup: (group: ListRoomMessage) => void;

	// QR 메시지 관련 함수
	updateQrMsgList: (response: QrDtlMsgListResponse) => void;
	setListMyQrCurrent: (serviceTypeCd:string, qrNo:string) => void;
	addQrMessage: (message: ListRoomMessage) => void;
	// 차빼줘 QR info
	carMsgList: ListRoomMessage[];
	carMsgCnt: number;
	initCarMsgList: () => void;
	updateCarMsgList: (carCallSearchList: ListRoomMessage[]) => void;
	removeCarMsgList: (chatSeq: string) => void;
	addCarMessage: (message: ListRoomMessage) => void;
	removeCarMessage: (chatSeq: string) => void;
	updateCarMessage: (message: ListRoomMessage) => void;
	// 	지켜줘 메시지 관련 함수
	carRoomType: string;
	listCarRoomChat: RoomChatMsgInfo[];
	initCarRoomChat: () => void;
	updateCarRoomChat: (list: RoomChatMsgInfo[]) => void;
	removeCarRoomChat: (chatSeq: string) => void;
	addCarRoomChat: (messageData: MessageData, isMyText: boolean) => void;
	setCarRoomType: (carRoomType: string) => void;
	updateListRoomMessage: (roomNo: string, message: string, incrCount: boolean) => void;
	addRoomChatMsg:(messageData: MessageData, isMyText: boolean) => void;
	// 지켜줘 정보관리 함수
	listFriend: FriendList[]; // 친구 목록

	listSubscr: ListSubscr[]; // 구독 목록
	updateSubscrList: (response: { listSubscr: ListSubscr[] }) => void;
	addSubscr: (subscr: ListSubscr) => void;
	//removeSubscr: (subscrNo: string) => void;
	//updateSubscr: (subscr: ListSubscr) => void;
	// 내 QR 목록 관련 함수
	updateMyQrList: (response: { listMyQr: ListMyQr[] }) => void;
	addMyQr: (myQr: ListMyQr) => void;
	removeMyQr: (qrNo: string) => void;
	updateMyQr: (myQr: ListMyQr) => void;
	findMyQr: (qrNo: string) => ListMyQr;

	//serviceTypeCd, qr클리시 변동 
	updateQrClickData: (qrClickData: QrClickType) => void;
	updateNetworkStatus: (networkStatus: NetworkType) => void;
	updateListLocation: (info: FriendLocation) => void;

	updateListRoomChatMsg: (chatList: RoomChatMsgInfo[]) => void;
	updateListRoomFriend: (friList: ChatFriendInfo[]) => void;
	addListRoomFriend: (friList: ChatFriendInfo) => void;
	removeListRoomFriend: (friendNo: string) => void;
	readListRoomChatMsg: (chatInfo: MessageSendRead) => void;
	removeListRoomChatMsg: (chatSeq: string) => void;
	removeMultiListRoomChatMsg: (chatSeq: string[]) => void;
	removeAllListRoomChatMsg: () => void;

	updateInfoLocation: (infoLoc: MembLocation) => void;
	initLocation: () => void;
	popupPageId: string;
	currentReceivedData: MessageData|null;
	currentSendData: MessageData | null; 		// 현재 소켓에 보낸 메시지 데이터
	currentMessageData: MessageData | null; 	// RT 메시지 받기전 전달메시지 정보 OR 차빼줘 전송 메시지 정보
	currentCarMessageData: MessageData | null; 	// 차빼줘 전송 메시지 정보
	setPopupPageId: (popup: string) => void;
	setCurrentReceivedData: (data: MessageData|null) => void;
	setCurrentSendData: (data: MessageData|null) => void;
	setCurrentMessageData: (data: MessageData|null) => void;
	setCurrentCarMessageData: (data: MessageData|null) => void;
	setIncallKey: (key: string) => void; // 현재 통화 중인 키 설정 함수
	showToast: (message: string) => void;

	listGroup: ListRoomMessage[]; // 그룹 목록
	listGroupCurrent: ListRoomMessage[]; // 그룹 메시지	filter 된 목록
	groupCnt: number; // 그룹 멤버수
	currentLocationRequest: MessageData | null;
	setCurrentLocationRequest: (data: MessageData|null) => void;
	setLocationStatus: (myFrType:string, msgData: MessageData, statusCd: string, statusNm: string) => void;  // myFrType ==> M 내꺼수정, F 친구거 수정
	setReqLocationStatus: (myFrType:string|null, membNo:string|null , membQrNo:string|null , friendNo: string|null, friendQrNo: string|null, statusCd: string, statusNm: string) => void;
	removeListAlert: ( membQrNo:string, friendNo: string, friendQrNo:string) => void;
	mySelectQr: string;
	targetSelectQr: string;
	setMySelectQr: (qr: string) => void;
	setTargetSelectQr: (qr: string) => void;
	launchModule: string;
	currentErrorMessage: string;
	setLaunchModule: (module: string) => void;
	currentQrItem: ListMyQr | null;						// 현재 수정할 QR 정보
	setCurrentQrItem: (item: ListMyQr | null) => void;
	currentScanQrCode: string;
	currentScanInfo: {serviceTypeCd: string, qrNo: string, viewType: string, myQrNo: string};					// 스캔 정보
	setCurrentScanQrCode: (qr: string) => void;
	setCurrentScanInfo: (info: {serviceTypeCd: string, qrNo: string, viewType: string, myQrNo: string}) => void;
	locationFriendItem:FriendList | null;
	setLocationFriendItem: (data: FriendList|null) => void;
	chgRoomType: string;
	setChgRoomType: (mType: string) => void;
	updateRoomMessageTick: number;	// 메세지 변경 tick 처리
	deletGpListRoomMessage: (roomNo:string) => void;
	deletQrListRoomMessage: (qrNo:string) => void;
	removeTypeData: RemoveData | null;
	setRemoveTypeData: (item: RemoveData | null) => void;
	mapMode: boolean;	// 지도 show 여부
	setMapMode: (mode: boolean) => void;
	updateRoomChatMessage: (message: ListRoomMessage) => void;
	setUpdateRoomMessageTick: () => void;
	currentFriendProfile: {roomNo: string, friendNo: string};
	setCurrentFriendProfile: (roomNo: string, friendNo: string) => void;
}
// #def store
// Create the store
export const useGlobalStore = create<GlobalStore>((set) => {
	// Get app store actions
	const setLoading = useAppsStore.getState().setLoading;
	const showModal = useAppsStore.getState().showModal;

	return {
		globalData: GlobalData,
		membInfo: MembInfo,
		versionInfo: null,
		tokenInfo: null,
		notificationData: null,
		notificationTick: 0,
		selectedRoomMessage: null,
		fcmToken: '', // FCM 토큰 초기값
		listRoomMessage: [], // 방 메시지 목록 초기화
		listAlert: [],
		listFriend: [], // 친구 목록 초기화		
		listRoomCurrent: [], // 방 메시지 목록 필터된값
		listService: [], // 서비스 목록 초기화
		listAdView: [], // 광고 뷰 목록 초기화
		friendList: [], // 친구 목록 초기화
		listFriendCurrent: [], // 친구 현재 출력중인 목록
		friendCnt: 0, // 친구 수 초기화
		friendMsgCnt: 0, // 메시지 수 초기화
		qrMsgCnt: 0, // QR 메시지 수 초기화
		notReadCnt: 0,
		readCnt: 0,
		qrMsgList: [], // QR 메시지 목록 초기화	
		startChatSeq: '', // 첫번째 채팅 시퀀스 초기화
		lastChatSeq: '', // 마지막 채팅 시퀀스 초기화
		listSubscr: [], // 구독 목록 초기화
		listMyQr: [], // 내 QR 목록 초기화
		listMyQrCurrent: [], // 내QR 현재 값
		//listMyQrProtect: [], // 지켜줘QR
		//listMyQrCar: [], // 차빼줘QR
		audioMode: '',	
		listGroup: [],
		listGroupCurrent: [],
		groupCnt: 0, // 그룹 멤버수
		async setAudioMode() {
			try {
				if( GlobalData.deviTpCd=='SA') {
					const { AudioModeModule } = NativeModules				
					if( AudioModeModule ) {
						const mode= await AudioModeModule.getAudioMode()
						set(state=>({audioMode:mode}))
					}
				} else {
					const { AudioStatusModule } = NativeModules
					//console.log('set audio mode ios => ', AudioStatusModule)
					if( AudioStatusModule ) {
						const mode= await AudioStatusModule.getAudioMode()
						set(state=>({audioMode:mode}))
					}
				}
			} catch (err) {
				console.log("@@ setAudioMode error", err);
			}			
		},
		currentFcmRecvData: null,	// 현재 받은 푸시 메시지 정보
		qrClickData: {serviceTypeCd:'', qrNo:''} as QrClickType,
		networkStatus: {isConnected:false, type: 'none'} as NetworkType,
		listLocation: [],
		listRoomChatMsg:[],  
		listRoomFriend:[],
		infoLocation: {latitude: 0, longitude: 0 },
		popupPageId: '',
		currentRoomInfo: {roomNo: '', roomNm: '', roomImg: ''}, // 현재 방 번호
		setCurrentRoomInfo: (roomNo: string, roomNm: string, roomImg: string) => set(state=>({ currentRoomInfo : {roomNo, roomNm, roomImg} })),		
		currentReceivedData: null,
		currentSendData: null,
		currentMessageData: null,
		currentCarMessageData: null,
		processScreen: '', // 현재화면
		prevProcessScreen: '', // 이전화면
		currentItem: null, // 현재 선택된 아이템 초기값		
		setProcessScreen: (screen: string) => set(state=>({ prevProcessScreen: state.processScreen, processScreen: screen })),		
		setCurrentItem: (item) => set({ currentItem: item }),
		setCurrentFcmRecvData: (data: FCM_RecvData|null) => set({ currentFcmRecvData: data }),
		getMessageData: async (mType: string, myQrNo: string, targetQrNo: string) => {
			const params : ChkRoomInfoRequest = {
				scanQrNo:targetQrNo,
				myQrNo: myQrNo,
				currentDate:GetDate(),
				langCd:GlobalData.langCd
			} as ChkRoomInfoRequest 
			
			const sendData: ChkRoomInfoResponse = await callPost(ApiInfo.scanAppChkSend, params) as ChkRoomInfoResponse;
			
			if( 'errors' in sendData ) {
				return {mType: 'E', msgDesc: sendData.message} as MessageData;
			}
			if(  sendData.code !== '200' ) {
				return {mType: 'E', msgDesc: sendData.message} as MessageData;
			}
			//const roomNo = sendData.serviceTypeCd === 'Car' ? sendData.qrNo : sendData.roomNo;
			const roomNo = sendData.serviceTypeCd === 'Car' ? targetQrNo : sendData.roomNo;
			if( sendData.serviceTypeCd == 'Car' ) {
				set((state) => ({ currentRoomInfo: {roomNo:'', roomNm:'', roomImg:''}}));
			} else {
				set((state) => ({ currentRoomInfo: {roomNo: roomNo || '', roomNm: sendData.nickNm || '', roomImg: sendData.profileImgFileUrl}}));
			}
			return '' in sendData ? {} as MessageData : {
				mType: mType,
				mykey: GlobalData.myKey,
				msgDesc: '',
				langCd: GlobalData.langCd,
				qrNo: sendData.qrNo,	// 상대방 QR 번호
				currentDate: GetDate(),
				callSeq: '',
				membNo: sendData.membNo,
				//roomId: sendData.serviceTypeCd === 'Car' ? targetQrNo : sendData.sendSubScr,	// 상대방 번호
				roomId: sendData.sendSubScr,  //sendData.serviceTypeCd === 'Car' ? sendData.sendSubScr : sendData.sendSubScr,	// 상대방 번호
				targetRoomId: sendData.mySubScr || '',	// 내 번호
				onOff: 'Y',
				writeMembNo: sendData.writeMembNo,
				serviceTypeCd: sendData.serviceTypeCd,
				fileImgUrl: '',
				filePath: '',
				writeNickNm: sendData.nickNm,					// 상대방 스캔 닉네임
				writeImgFileUrl: sendData.profileImgFileUrl,	// 상대방 스캔 프로필 이미지
				counterPart: sendData.roomNo,
				roomNm: sendData.nickNm,
				roomImg:sendData.profileImgFileUrl,
			} as MessageData;
		},
		getChatMessageData: async (serviceTypeCd: string, chatNo:string, gridInsertData: ChatFriendInfo[]) => {
			const params : ChangeRoomInfoRequest = {
				serviceTypeCd: serviceTypeCd,
				roomNo: chatNo,
				langCd: GlobalData.langCd,
				currentDate: GetDate(),
				gridInsertData: gridInsertData,
			} as ChangeRoomInfoRequest 

			//const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
			const sendData: ChkRoomInfoResponse = await callPost(ApiInfo.chgGroupChat, params) as ChkRoomInfoResponse;
			console.log("@@ global getMessageData sendData",  sendData);
			if( 'errors' in sendData ) {
				return {mType: 'E', msgDesc: sendData.message} as MessageData;
			}
			if(  sendData.code !== '200' ) {
				return {mType: 'E', msgDesc: sendData.message} as MessageData;
			}
			
			set((state) => ({ currentRoomInfo: {roomNo: sendData.roomNo || '', roomNm: sendData.msgReDesc || '', roomImg: sendData.profileImgFileUrl }}));
			
			return '' in sendData ? {} as MessageData : {
				mType: 'CALL',
				mykey: GlobalData.myKey,
				msgDesc: '',
				langCd: GlobalData.langCd,
				qrNo: sendData.qrNo,	// 상대방 QR 번호
				currentDate: GetDate(),
				callSeq: '',
				membNo: sendData.membNo,
				roomId: sendData.roomNo,	// 상대방 번호
				targetRoomId: sendData.roomNo || '',	// 내 번호
				onOff: 'Y',
				writeMembNo: sendData.writeMembNo,
				serviceTypeCd: sendData.serviceTypeCd,
				fileImgUrl: '',
				filePath: '',
				writeNickNm: sendData.nickNm,					// 상대방 스캔 닉네임
				writeImgFileUrl: sendData.profileImgFileUrl,	// 상대방 스캔 프로필 이미지
				counterPart: sendData.roomNo,
			} as MessageData;
		},
		getRoomClickMessageData: async (mType:string, roomInfo : ListRoomMessage) => {
			//const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
			//QR 번호로 해당 QR이미지 가져오기
			console.log("@@ Room Info ", roomInfo);
			const state = useGlobalStore.getState()
			const qrInfo =  state.listMyQr.find(item => item.qrNo === roomInfo.qrNo);
			console.log("@@ Room Info qr info", qrInfo);

			const roomNo = roomInfo.serviceTypeCd === 'Car' ? roomInfo.qrNo : roomInfo.roomNo;
			const msgData : MessageData = {
				mType: mType,
				mykey: GlobalData.myKey,
				msgDesc: roomInfo.msgDesc,
				langCd: GlobalData.langCd,
				qrNo: roomInfo.qrNo,	// my QR 번호
				currentDate: GetDate(),
				callSeq: '',
				membNo: roomInfo.membNo,
				roomId: roomInfo.sendSubScr,		// 상대방 번호
				targetRoomId: roomInfo.mySubScr,	// 내 번호
				onOff: 'Y',
				writeMembNo: GlobalData.membNo,
				serviceTypeCd: roomInfo.serviceTypeCd,
				fileImgUrl: '',
				filePath: '',
				counterPart: roomNo,
				roomNm: roomInfo.nickNm,
				roomImg: roomInfo.profileImgFileUrl,
				writeNickNm: qrInfo.nickNm,
				writeImgFileUrl: qrInfo?.imgFileUrl
			

			} as MessageData;
			console.log("@@ Room Info msgData  ", msgData)
			set((state) => ({ selectedRoomMessage: roomInfo, currentRoomInfo: {roomNo: roomNo, roomNm: roomInfo.nickNm, roomImg: roomInfo.profileImgFileUrl} }));
			return msgData;
		},
		
		updateGlobalData: (data) => 
			set((state) => ({
				globalData: { ...state.globalData, ...data }
			})),
		updateMembInfo: (data) =>
			set((state) => ({
				membInfo: { ...state.membInfo, ...data }
			})),
		updateVersionInfo: (data) =>
			set(() => ({
				versionInfo: data
			})),
		updateNotificationData: (data) =>
			set(() => ({
				notificationTick: new Date().getTime(),
				notificationData: {...data}
			})),
		updateFcmToken: (token) => {
			if (GlobalData.uniqueId) {
				const params = {
					deviId: GlobalData.uniqueId,
					appReg: token,
					langCd: GlobalData.langCd
				} 			
				set(() => ({ fcmToken: token }))
				console.log('@@ update FCM Token:', params)
				if (GlobalData.token) {
					apiCallPost('/api/sett/save-appReg', params)
				}
			}
		},
		updateNoorijaToken: (token: string) => {
			console.log("updateNoorijaToken==============", token);
			GlobalData.token = token;
			set(() => ({ noorijaToken: token }));
		},
		
		// 버전 정보 조회
		getVersion: async () => {
			setLoading(true);
			const params = {
				deviTpCd : GlobalData.deviTpCd,
				deviId : GlobalData.uniqueId,
				deviOsVer : GlobalData.deviOsVer,
				appVer : GlobalData.appVer,
				langCd : GlobalData.langCd,
				nickNm : GlobalData.nickNm,
				currentDate : GetDate()
			}
			const info = await callPost(ApiInfo.get_version, params) as ApiVersionInfo;
			console.log("@@ GetVersion info", info);
			if( 'errors' in info && 'message' in info ) {
				Alert.alert("알림", info.message as string);
				return false;
			}
			set({ versionInfo: info as ApiVersionInfo });
			return  true;
		},
		// 토큰 생성
		createSg: async () => {
			setLoading(true);
			const params = {
				deviTpCd: GlobalData.deviTpCd,
				deviId: GlobalData.uniqueId,
				deviOsVer: GlobalData.deviOsVer,
				appVer: GlobalData.appVer,
				langCd: GlobalData.langCd,
				currentDate: GetDate()
			};
			
			return new Promise<ApiCreateSgRes>((resolve, reject) => {
				apiCallPost(ApiInfo.create_Sg, params, (type, response) => {
					setLoading(false);
					if (type === 'ok') {
						const sgResponse = response as ApiCreateSgRes;
						set({ tokenInfo: sgResponse });
						resolve(sgResponse);
					} else {
						showModal('error');
						reject(response);
					}
				});
			});
		},
		// 스토어 초기화
		resetStore: () => {
			set(() => ({
				globalData: GlobalData,
				membInfo: MembInfo,
				versionInfo: null,
				tokenInfo: null
			}));
		},
		// 메시지 추가
		initCurrentRoomMessage: () => 
			set((state) => ({
				listRoomCurrent: []
			})),
		setCurrentRoomMessage: (etcInfo:string) => 
			set((state) => ({
				listRoomCurrent: state.listRoomMessage.filter(item => item.chatSeq === etcInfo)
			})),
		addRoomMessage: (message) => 
			set((state) => ({
				listRoomMessage: [message,...state.listRoomMessage]
			})),
		
		// 메시지 삭제
		removeRoomMessage: (chatSeq) => 
			set((state) => ({
				listRoomMessage: state.listRoomMessage.filter(
					msg => msg.chatSeq !== chatSeq
				)
			})),
		
		// 메시지 업데이트 --안씀
		updateRoomMessage: (message) => 
			set((state) => {
				const filteredList = state.listRoomMessage.filter(
					item => (item.roomNo !== message.roomNo));			
				
				return {
					listRoomMessage: [message, ...filteredList]
				};
			}),

		filterRoomMessage: (serviceTypeCd: string, qrNo: string) =>
			set((state) => {
				const roomMessage = state.listRoomMessage.sort((a, b) => b.chatSeq.localeCompare(a.chatSeq));
				const filteredList = roomMessage.filter(
					item => (serviceTypeCd === '' || item.serviceTypeCd === serviceTypeCd) &&
							(qrNo === '' || item.qrNo === qrNo)
				);			
				// notReadYn별 카운트
				let notCnt = 0; // not read count
				let rCnt = 0;  // read count (혹은 다른 의미)
				let fCnt = 0 ;
			
				filteredList.forEach(item => {					
					notCnt += item.notReadCnt;
					// if (item.notReadYn === 'N') {
					// 	notCnt += item.notReadCnt;
					// } else if (item.notReadYn === 'Y') {
					// 	rCnt += 1;
					// }
				});

				//notReadCnt
			
				return {
					listRoomMessage: roomMessage,
					listRoomCurrent: filteredList,
					readCnt: rCnt,
					notReadCnt: notCnt,
					friendMsgCnt: notCnt
				};
			}),
		// 서비스 관련 함수
		addService: (service) => 
			set((state) => ({
				listService: [...state.listService, service]
			})),
		
		removeService: (serviceCd) => 
			set((state) => ({
				listService: state.listService.filter(
					svc => svc.serviceCd !== serviceCd
				)
			})),
		
		updateService: (service) => 
			set((state) => ({
				listService: state.listService.map(
					svc => svc.serviceCd === service.serviceCd ? service : svc
				)
			})),

		// 광고 뷰 관련 함수
		addAdView: (adView) => 
			set((state) => ({
				listAdView: [...state.listAdView, adView]
			})),
		
		removeAdView: (adCd) => 
			set((state) => ({
				listAdView: state.listAdView.filter(
					ad => ad.adCd !== adCd
				)
			})),
		
		updateAdView: (adView) => 
			set((state) => ({
				listAdView: state.listAdView.map(
					ad => ad.adCd === adView.adCd ? adView : ad
				)
			})),

		// 광고 사용 여부 확인 함수  dwkim
		isAdViewYn: (adCd) => {
			const state = useGlobalStore.getState();
			const adView = state.listAdView?.find(item => item.adCd === adCd);
			return adView ? adView.useYn === 'Y' : false;
		},

		// 친구 목록 관련 함수
		updateFriendList: (friendList) => set((state) => ({	listFriend: friendList	})),
		filterFriendList: (serviceTypeCd: string, qrNo: string) =>
			set((state) => {
				console.log("filter start", state.listFriend.length);
				const filteredList = state.listFriend.filter(
					item => (serviceTypeCd === '' || item.serviceTypeCd === serviceTypeCd) &&
							(qrNo === '' || item.membQrNo === qrNo)
				);			
				const sortedList = [...filteredList].sort((a, b) => a.nickNm.localeCompare(b.nickNm));
				// notReadYn별 카운트
				let fCnt = filteredList.length;
			
				return {
					listFriendCurrent: sortedList,
					friendCnt: fCnt
				};
			}),
		removeFriendList: (friendNo: string, friendQrNo:string, qrNo: string) =>
			set((state) => {
				
				const filteredList = state.listFriend.filter(
					item => (!(item.friendNo === friendNo && item.friendQrNo ===friendQrNo && item.membQrNo === qrNo)) 
				);			
				const sortedList = [...filteredList].sort((a, b) => a.nickNm.localeCompare(b.nickNm));
				// notReadYn별 카운트
				let fCnt = filteredList.length;
			
				return {
					listFriend: filteredList,
					listFriendCurrent: sortedList,
					friendCnt: fCnt
				};
			}),			
		addFriend: (friend) => 
			set((state) => ({
				listFriend: [...state.listFriend, friend],
				friendCnt: state.friendCnt + 1
			})),
		removeFriend: (friendNo) => 
			set((state) => ({
				listFriend: state.listFriend.filter(
					f => f.friendNo !== friendNo
				),
				friendCnt: state.friendCnt - 1
			})),

		updateFriend: (friend) => 
			set((state) => ({
				listFriend: state.listFriend.map(
					f => f.friendNo === friend.friendNo ? friend : f
				)
			})),
		// changeLocationFriend: (friend) => 
		// 	set((state) => ({
		// 		listFriend: state.listFriend.map(
		// 			f => f.friendNo === friend.friendNo ? friend : f
		// 		)
		// 	})),


		// 친구 목록 관련 함수
		updateGroupList: (groupList) => set((state) => ({listGroup: groupList})),
		filterGroupList: (serviceTypeCd: string, qrNo: string) =>
			set((state) => {
				console.log("filter start group");
				if ( state.listGroup != null && state.listGroup.length > 0) {
					console.log("filter start", state.listGroup.length);
					const filteredList = state.listGroup.filter(
						item => (serviceTypeCd === '' || item.serviceTypeCd === serviceTypeCd) &&
								(qrNo === '' || item.qrNo === qrNo)
					);			
					const sortedList = [...filteredList].sort((a, b) => a.nickNm.localeCompare(b.nickNm));
					// notReadYn별 카운트
					let fCnt = filteredList.length;
					return {
						listGroupCurrent: sortedList,
						groupCnt: fCnt
					};
				} else {
					return {
						listGroupCurrent: [],
						groupCnt: 0
					};
				}
			}),
		addGroup: (group) => 
			set((state) => ({
				listGroup: [...state.listGroup, group],
				groupCnt: state.groupCnt + 1
			})),
		removeGroup: (roomNo) => 
			set((state) => ({
				listGroup: state.listGroup.filter(
					f => f.roomNo !== roomNo
				),
				groupCnt: state.groupCnt - 1
			})),

		updateGroup: (group) => 
			set((state) => ({
				listGroup: state.listGroup.map(
					f => f.roomNo === group.roomNo ? group : f
				)
			})),   



		// QR 메시지 관련 함수
		updateQrMsgList: (response) => 
			set((state) => ({
				qrMsgList: response.qrMsgList,
				friendCnt: response.friendCnt,
				qrMsgCnt: response.msgCnt
			})), 

		addQrMessage: (message) => 
			set((state) => ({
				qrMsgList: [...state.qrMsgList, message],
				msgCnt: state.qrMsgCnt + 1
			})),

		// 차빼줘 QR info
		carMsgList: [],
		carMsgCnt: 0, // 차량 메시지 수
		initCarMsgList: () => 
			set((state) => ({
				carMsgList: [],
			})),
		updateCarMsgList: (carCallSearchList) => {
			set((state) => ({
				carMsgList: [...state.carMsgList, ...carCallSearchList],
				
			}))
		},
		removeCarMsgList: (chatSeq) => 
			set((state) => ({
				carMsgList: state.listRoomMessage.filter(
					msg => msg.chatSeq !== chatSeq
				)
			})),
		addCarMessage: (message) => 
			set((state) => ({
				carMsgList: [...state.carMsgList, message],
				carMsgCnt: state.carMsgCnt + 1
			})),

		removeCarMessage: (chatSeq) => 
			set((state) => ({
				carMsgList: state.carMsgList.filter(
					msg => msg.chatSeq !== chatSeq
				),
				carMsgCnt: state.carMsgCnt - 1
			})),

		updateCarMessage: (message) => 
			set((state) => ({
				carMsgList: state.carMsgList.map(
					msg => msg.chatSeq === message.chatSeq ? message : msg
				)
			})),

		//  차빼줘 메시지 관련 함수
		updateListRoomMessage: (roomNo, message, incrCount) => {
			set((state) => ({
				listRoomMessage: state.listRoomMessage.map(msg => 
					msg.roomNo === roomNo ? { ...msg, 
						msgDesc: message=='' ? msg.msgDesc : message, 
						notReadCnt: incrCount ? msg.notReadCnt + 1 : 0, 
						notReadYn: incrCount? 'Y' : 'N' } : msg
				)
			}))
		},
		listCarRoomChat: [], // 차량 메시지 목록 초기화
		carRoomType: '',
		setCarRoomType: (carRoomType: string) => set((state) => ({carRoomType: carRoomType})),
		initCarRoomChat: () => set((state) => ({listCarRoomChat: []})),
		updateCarRoomChat: (list) => set((state) => ({listCarRoomChat: [...state.listCarRoomChat, ...list]})),
		removeCarRoomChat: (chatSeq) =>  set((state) => ({listCarRoomChat: state.listCarRoomChat.filter(msg => msg.chatSeq !== chatSeq)})), 
		addCarRoomChat: (messageData: MessageData, isMyText: boolean) => 
			set((state) => ({
				listCarRoomChat: [...state.listCarRoomChat, {
					roomNo: state.currentRoomInfo.roomNo,
					chatSeq: messageData.callSeq,
					msgDesc: messageData.msgDesc,
					notReadCnt: 1,
					msgTypeCd: 'T',
					notReadYn: 'N',
					serviceTypeCd: messageData.serviceTypeCd,
					qrNo: messageData.qrNo,
					writeMembNo: messageData.writeMembNo,
					myTextYn: isMyText ? 'Y' : 'N',
					roomTypeCd: '',
					msgReDesc: '',
					profileImgFileUrl: state.membInfo.imgFileUrl,
					nickNm: state.membInfo.nickNm,
					addDt: GetDateDay(),
					addTime: GetDateTime(),
					callStatCd: '10',
					roomImgUrl: '',
					readChatSeq: messageData.callSeq
				} as RoomChatMsgInfo]
			})),
		addRoomChatMsg: (messageData, isMyText) => {
			console.log("@@ addRoomChatMsg messageData : ", messageData);
			// 단건글 추가
			set((state) => ({
				listRoomChatMsg: [...state.listRoomChatMsg, {
					roomNo: state.currentRoomInfo.roomNo,
					chatSeq: messageData.callSeq,
					msgDesc: messageData.msgDesc,
					notReadCnt: isMyText ? state.listRoomFriend.length : state.listRoomFriend.length - 1,
					msgTypeCd: messageData.msgTypeCd,
					notReadYn: 'N',
					serviceTypeCd: messageData.serviceTypeCd,
					qrNo: messageData.qrNo,
					writeMembNo: messageData.writeMembNo,
					myTextYn: isMyText ? 'Y' : 'N',
					roomTypeCd: '',
					msgReDesc: '',
					profileImgFileUrl: messageData.writeMembNo == GlobalData.membNo ? state.membInfo.imgFileUrl : messageData.writeImgFileUrl,
					nickNm: messageData.writeMembNo == GlobalData.membNo ? state.membInfo.nickNm : messageData.writeNickNm,
					addDt: GetDateDay(),
					addTime: GetDateTime(),
					callStatCd: '10',
					roomImgUrl: messageData.fileImgUrl,
					readChatSeq: messageData.callSeq,
					writeNickNm: messageData.writeNickNm,
					writeImgFileUrl: messageData.writeImgFileUrl,
				} as RoomChatMsgInfo]
			}))
		},
		// 구독 목록 관련 함수
		updateSubscrList: (response) =>
			set((state) => ({
				listSubscr: response.listSubscr
			})),

		addSubscr: (subscr) => 
			set((state) => ({
				listSubscr: [...state.listSubscr, subscr]
			})),

		// removeSubscr: (subscrNo) => 
		// 	set((state) => ({
		// 		listSubscr: state.listSubscr.filter(
		// 			s => s.subscrNo !== subscrNo
		// 		)
		// 	})),

		// updateSubscr: (subscr) => 
		// 	set((state) => ({
		// 		listSubscr: state.listSubscr.map(
		// 			s => s.subscrNo === subscr.subscrNo ? subscr : s
		// 		)
		// 	})),
		setListMyQrCurrent: (serviceTypeCd:string, qrNo:string) => 
			set((state) => ({
				// listMyQrCurrent: state.listMyQr.filter(
				// 	item => (serviceTypeCd == '' || item.serviceTypeCd === serviceTypeCd )
				// 	        && (qrNo == '' || item.qrNo == qrNo)
				//   ),
				listMyQrCurrent: state.listMyQr
			})),
		// 내 QR 목록 관련 함수
		updateMyQrList: (response) =>
			set((state) => ({
				listMyQr: response.listMyQr
			})),
		findMyQr: (qrNo) => {
			const state = useGlobalStore.getState()
			return state.listMyQr.find(item => item.qrNo === qrNo);
		},
		addMyQr: (myQr) => 
			set((state) => ({
				listMyQr: [...state.listMyQr, myQr],
				//listMyQrProtect: myQr.serviceTypeCd == 'Protect' ? [...state.listMyQrProtect, myQr] : [...state.listMyQrProtect] ,
				//listMyQrCar: myQr.serviceTypeCd == 'Car' ? [...state.listMyQrCar, myQr] : [...state.listMyQrCar] 
			})),

		removeMyQr: (qrNo) => 
			set((state) => ({
				listMyQr: state.listMyQr.filter(
					qr => qr.qrNo !== qrNo
				)
			})),

		updateMyQr: (myQr) =>			
			set((state) => ({				
				listMyQr: state.listMyQr.map(					
					qr => qr.qrNo === myQr.qrNo ? myQr : qr
				)
			})),
		updateQrClickData: (qrClickData: QrClickType) => 
			set((state) => ({
				qrClickData: qrClickData
			})),
		updateNetworkStatus: (networkStatus: NetworkType) => 
			set((state) => ({
				networkStatus: networkStatus
			})),
		sockJsData: {
			messageList: [],
			connectionStatus: 'disconnected',
			error: null
		},
		setHomeActive: (isActive: boolean) => set(() => ({ isActive })),
		setAppActive: (isAppActive: boolean) => set(() => ({ isAppActive })),
		// 네트워크 상태 관리 함수
		
		// SockJS 구독 관리 함수
		addSockJsMessage: (message: MessageData) =>
			set((state) => ({
				sockJsData: {
					...state.sockJsData,
					messageList: [...state.sockJsData.messageList, message]
				}
			})),
		clearSockJsMessages: () =>
			set((state) => ({
				sockJsData: {
					...state.sockJsData,
					messageList: []
				}
			})),
		updateSockJsConnection: (status, error = '') =>
			set((state) => ({
				sockJsData: {
					...state.sockJsData,
					connectionStatus: status,
					error
				}
			})),
		isActive: false,
		isAppActive: false,
		updateListLocation: (infoLocation) => 
			set((state) => {
				const cur = state.listLocation.find(loc => loc.membNo === infoLocation.membNo);
				console.log('@@ updateListLocation ===', cur,  state.listLocation)
				
				if (cur) {
					const upFriLocInfo = {
						membNo: cur.membNo,
						latitude: infoLocation.latitude,
						longitude: infoLocation.longitude, 
						curDate: infoLocation.curDate,
						nickNm: cur.nickNm,
						profileImgFileUrl: cur.profileImgFileUrl
					}
					return {
						listLocation: state.listLocation.map(
							svc => svc.membNo === upFriLocInfo.membNo ? upFriLocInfo : svc
						)
					}
				} else {
					const friendInfo = state.listFriend.find(fri => fri.friendNo === infoLocation.membNo);
					if (friendInfo) {
						const newFriLocInfo = {
							membNo: infoLocation.membNo,
							latitude: infoLocation.latitude,
							longitude: infoLocation.longitude, 
							curDate: infoLocation.curDate,
							nickNm: friendInfo.nickNm,
							profileImgFileUrl: friendInfo.imgFileUrl
						}
						return {	
							listLocation: [...state.listLocation, newFriLocInfo],
						}
					}
				}
				return {};
			}),
		
		updateListRoomChatMsg: (chatList) => // 리스트 추가
			set((state) => ({
				listRoomChatMsg : state.listRoomChatMsg.length > 0 ?   [...chatList, ...state.listRoomChatMsg ] :  [...chatList ],
			})),
		updateListRoomFriend: (friList) => // 리스트 추가
			set((state) => ({
				listRoomFriend : [...friList]
			})),
		addListRoomFriend: (friInfo) => // 리스트 추가
			set((state) => ({
				listRoomFriend : [...state.listRoomFriend, friInfo],
			})),
		removeListRoomFriend: (friendNo) => // 리스트 추가
			set((state) => ({
				listRoomFriend: state.listRoomFriend.filter(
					fri => fri.membNo !== friendNo
				)
			})),	
		readListRoomChatMsg: (chatInfo) => // 읽음업데이트
			set((state) => {
				   const chatSeqArr = chatInfo.chatSeq ? chatInfo.chatSeq.split(',') : [];
				   const updatedListRoomChatMsg = state.listRoomChatMsg.map((row) => {
						if (chatSeqArr.includes(row.chatSeq)) {
						// notReadCnt를 1씩 줄이고 음수가 되면 0으로 설정
						const newNotReadCnt = row.notReadCnt > 0 ? row.notReadCnt - 1 : 0;
						return {
							...row,
							notReadCnt: newNotReadCnt,
							notReadYn: 'N'
						};
						}
						// 조건에 해당하지 않으면 변경 없음
						return row;
				  });
				  return {
					listRoomChatMsg: updatedListRoomChatMsg,
				  };
				
			}),
		removeListRoomChatMsg: (chatSeq) => // 단건글 삭제 ==> 서버 호출하여 db삭제하고 통신받으면 삭제처리함
			set((state) => ({
				listRoomChatMsg: state.listRoomChatMsg.filter(
					msg => msg.chatSeq !== chatSeq
				)
			})),	
		removeMultiListRoomChatMsg: (chatSeqArr) => // 단건글 삭제 ==> 서버 호출하여 db삭제하고 통신받으면 삭제처리함
			set((state) => ({
				listRoomChatMsg: state.listRoomChatMsg.filter(
					msg => !chatSeqArr.includes(msg.chatSeq.toString())
				)
			})),
		removeAllListRoomChatMsg: () => // 초기화
			set((state) => ({
				listRoomChatMsg: [],
			})),	
		updateInfoLocation: (infoLoc: MembLocation) => 
			set((state) => ({
				infoLocation: {...infoLoc}
			})),
		initLocation: () => 
			set((state) => ({
				listLocation: [] as FriendLocation[]
			})),
		setPopupPageId: (popup: string) => set({ popupPageId: popup }),
		setCurrentReceivedData: (data) => set({ currentReceivedData: data }),
		setCurrentSendData: (data) => set({ currentSendData: data }),
		setCurrentMessageData: (data) => set({ currentMessageData: data }),
		setCurrentCarMessageData: (data) => set({ currentCarMessageData: data }),
		incallKey: '', // 현재 통화 중인 키 초기값
		setIncallKey: (key) => set({ incallKey: key }),
		showToast: (message: string) => {
			set(() => ({ currentErrorMessage: message }));
			if( message == '' ) {
				return;
			}
			const pos = message.indexOf(':');
			if( pos > 0 ) {
				const title = message.substring(0, pos);
				const msg = message.substring(pos + 1);
				Alert.alert(title, msg);
			} else {			 
				if (Platform.OS === 'android') {
					ToastAndroid.show(message, ToastAndroid.SHORT);
				} else {
					Alert.alert("알림", message);
				}
			} 

		},
		currentLocationRequest: null,
		setCurrentLocationRequest: (data) => set({ currentLocationRequest: data }),
		setLocationStatus: (myFrType, msgData,statusCd, statusNm) => {  // 함수로 데이타 리턴 - 로직있을때
			set((state) => {				
				if (myFrType === 'M') {
					const findFriend:FriendList | undefined = state.listFriend.find(
						m => m.membNo === msgData?.counterPart
						&& m.membQrNo === msgData?.writeMembNo
						&& m.friendNo === msgData?.membNo 
						&& m.friendQrNo === msgData?.qrNo);
					if (findFriend) {
						findFriend.membLocationCd = statusCd;
						findFriend.membLocationNm = statusNm;	
						state.updateFriend(findFriend);	
					}
				} else {
					const findFriend1:FriendList | undefined = state.listFriend.find(
						m => m.membNo ===  msgData?.counterPart
						&& m.membQrNo === msgData?.writeMembNo
						&& m.friendNo === msgData?.membNo 
						&& m.friendQrNo === msgData?.qrNo );
					if (findFriend1)	{
						findFriend1.friendLocationCd = statusCd;
						findFriend1.friendLocationNm = statusNm;	
						state.updateFriend(findFriend1);
					}
				}				
				return state;
			})
		},
		setReqLocationStatus: (myFrType,  membNo, membQrNo, friendNo, friendQrNo,statusCd, statusNm) => {  // 함수로 데이타 리턴 - 로직있을때
			
			set((state) => {
				const findFriend:FriendList|undefined = state.listFriend.find(
					m => m.membNo === membNo
					&& m.membQrNo === membQrNo
					&& m.friendNo === friendNo
					&& m.friendQrNo === friendQrNo);
				console.log("@@ LocationStatus findFriend", findFriend);
				if (findFriend) {
					if (myFrType === 'M') {
						findFriend.membLocationCd = statusCd;
						findFriend.membLocationNm = statusNm;	
					} else {
						findFriend.friendLocationCd = statusCd;
						findFriend.friendLocationNm = statusNm;	
					}
					state.updateFriend(findFriend);
				}
				return state;
			})
		},
		removeListAlert: (membQrNo, friendNo, friendQrNo) => {  //하나의 로직일때
			set((state) => ({
				listAlert: state.listAlert.filter(
					loca => loca.membQrNo !== membQrNo && loca.friendNo !== friendNo && loca.friendQrNo !== friendQrNo
				)
			}))
		},
		mySelectQr: '',
		targetSelectQr: '',
		setMySelectQr: (qr) => set({ mySelectQr: qr }),
		setTargetSelectQr: (qr) => set({ targetSelectQr: qr }),
		launchModule: '',
		setLaunchModule: (module) => set({ launchModule: module }),
		currentErrorMessage: '',
		currentQrItem: null,
		setCurrentQrItem: (item) => set({ currentQrItem: item }),
		currentScanQrCode: '',		// 스캔 코드
		currentScanInfo: {serviceTypeCd: '', qrNo: '', viewType: '', myQrNo: ''},	// 스캔 정보
		setCurrentScanInfo: (info) => set({ currentScanInfo: info }),	// 스캔 정보 설정
		setCurrentScanQrCode: (qr) => set({ currentScanQrCode: qr }),	// 스캔 코드 설정

		locationFriendItem: null,
		setLocationFriendItem: (data) => set({ locationFriendItem: data }),
		chgRoomType: '',
		setChgRoomType: (mtype) => set({ chgRoomType: mtype }),
		updateRoomMessageTick: 0,
		deletGpListRoomMessage: (roomNo: string) =>
			set((state) => {
				const filteredRoomList = state.listRoomMessage.filter(
					item => item.roomNo !== roomNo
				);	
				const filteredGroupList = state.listGroup.filter(
					item => item.roomNo !== roomNo
				);	
				
				return {
					listRoomMessage: filteredRoomList,
					listGroup: filteredGroupList,
				};
		}),
		deletQrListRoomMessage: (qrNo: string) =>
			set((state) => {
				const filteredRoomList = state.listRoomMessage.filter(
					item => item.qrNo !== qrNo
				);		
				return {
					listRoomMessage: filteredRoomList,
				};
		}),
		removeTypeData: null,
		setRemoveTypeData: (item) => set({ removeTypeData: item }),
		mapMode: false,
		setMapMode: (mode) => set({ mapMode: mode }),
		updateRoomChatMessage: (message) => {
			set((state) => ({
				listRoomMessage: state.listRoomMessage.map(item => item.roomNo === message.roomNo ? message : item), updateRoomMessageTick: new Date().getTime()
			}))
		},
		setUpdateRoomMessageTick: () => set((state) => ({updateRoomMessageTick: new Date().getTime()})),
		currentFriendProfile: {roomNo: '', friendNo: ''},
		setCurrentFriendProfile: (roomNo,friendNo) => set({ currentFriendProfile: {roomNo, friendNo} }),
	};
	// #def impl
});

export const updateMainResponse = (response: MainResponse) => {
	const { globalData, membInfo } = useGlobalStore.getState();	
	// Update global data
	/*
	membNo: 회원 번호
	introImgUrl: 인트로 이미지 URL
	SettingData: 설정 정보
	appMenuList: 앱 메뉴 목록
	listRoomInfo: 방 정보 목록
	*/
	GlobalData.membNo = response.membNo;
	GlobalData.introImgUrl = response.introImgUrl;
	GlobalData.SettingData = response.settingInfo;
	//GlobalData.listAlert = response.listAlert;
	GlobalData.appMenuList = response.listAppMenu;
	GlobalData.colLocationTime = response.colLocationTime;

	console.log("@@ 구독 리스트 정보 ", response.listSubscr) ;
	
	// useGlobalStore.getState().updateGlobalData({
	// 	membNo: response.membNo,
	// 	introImgUrl: response.introImgUrl,
	// 	SettingData: response.settingInfo,
	// 	appMenuList: response.listAppMenu,
	// 	changeType: 'updateMainResponse'
	// });
	console.log("listRoomMessage ===>" , response.listRoomMessage);
	// 방 메시지 목록 업데이트
	useGlobalStore.setState({ listRoomMessage: response.listRoomMessage });

	// 친구 목록 업데이트
	useGlobalStore.setState({ listFriend: response.listFriend });

	// 그룹 목록 업데이트
	console.log("list group ==>",response.listGroup);
	useGlobalStore.setState({ listGroup: response.listGroup });
	
	// 서비스 목록 업데이트
	useGlobalStore.setState({ listService: response.listService });

	// 광고 뷰 목록 업데이트
	useGlobalStore.setState({ listAdView: response.listAdView });

	// 구독 목록 업데이트
	useGlobalStore.setState({ listSubscr: response.listSubscr });

	// 내 QR 목록 업데이트
	useGlobalStore.setState({ listMyQr: response.listMyQr });

	//위치 알럿
	useGlobalStore.setState({listAlert: response.listAlert });

	//const protectQrList = response.listMyQr.filter(item => item.serviceTypeCd == 'Protect') ;

	//const CarQrList = response.listMyQr.filter(item => item.serviceTypeCd == 'Car') ;

	// useGlobalStore.setState({ listMyQrProtect: protectQrList });

	// useGlobalStore.setState({ listMyQrCar: CarQrList });

	

	// Update member info
	/*
	nickNm: 닉네임
	introductinInfo: 소개 정보
	imgFileUrl: 프로필 이미지 URL
	*/
	useGlobalStore.getState().updateMembInfo({
		nickNm: response.nickNm,
		introductinInfo: response.introductionInfo,
		imgFileUrl: response.imgFileUrl
	});

};
