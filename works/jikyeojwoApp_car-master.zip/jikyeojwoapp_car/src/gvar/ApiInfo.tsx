
const ApiInfo = {
    get_version: '/api/session/getJkjVersion',  // 버전정보 가져오기
    get_tutorial: '/api/session/getTutorial', // 튜토리얼 리스트 가져오기
    connectApp: '/api/session/connectApp',  // 로그인 진행
    menu_menuList: '/api/menu/menuList',  // 메뉴리스트 가져오기 -사용여부 판단 필요
    info_faqList: '/api/info/faqList',  // FAQ가져오기
    get_cas: '/api/session/getCas', //약관정보 가져오기
    create_Sg: '/api/session/createSg',
    mainInfo: '/api/main/mainInfo', // 메인 정보 초기에 가져오기
    serviceInfo: '/api/main/mainMsgInfo', // 서비스 홈 데이타 가져오기
    serviceCarInfo: '/api/main/mainCarMsgInfo', // 서비스 홈 데이타 가져오기
    serviceMyQr: '/api/main/serviceMyQr', // 서비스 마이큐알리스트
    // 삭제 qrMsgInfo: '/api/main/qrMsgInfo' , // qr메세지 출력
    nickNmAvailable: '/api/qrInfo/nickNmAvailable', // 닉네임 중복체크
    chkNickNm: '/api/session/chkNickNm', // 회원 닉네임 중복체크
    regJkjQr: '/api/qrInfo/regJkjQr' , // QR 등록
    updateJkjQr: '/api/qrInfo/updateJkjQr', // QR정보 수정
    qrFriendList: '/api/msg/qrFriendList' , // QR 친구 리스트
    qrMsgList: '/api/msg/qrMsgList' , // QR 메세지 리스트
    qrCarMsgList: '/api/msg/qrCarMsgList' , //'/api/msg/qrCarMsgList' , // QR 차빼줘 메세지   /api/msg/qrCarMsgList
    addFriendQr: '/api/room/save-friend', // 친구추가
    alarmAddFriend: '/api/room/alarm-add-friend', //친구추가시 상대방 등록 알림에 대한 정보 가져오기
    delMessage: '/api/msg/del-message', // 메세지 삭제

    infoGroup: '/api/room/info-group', // 그룹정보
    saveGroup: '/api/room/save-group', //그룹저장
    
    fileUpload: '/api/file/uploadFile', // 파일 업로드
    saveNickIntro: '/api/main/saveNickIntro', // 닉네임과 소개글 업데이트
    searchFriend: '/api/room/search-qrFriend', // 친구 검색
    friendProfile: '/api/room/info-profile-friend',
    subscrList: '/api/main/getSubscr', // 구독 리스트 가져오기 결과값 RoomListResponse
    

    annList: '/api/info/annList',
    sendAsk: '/api/info/sendAsk',
    manualList: '/api/info/getManualList',
    faqInfoList: '/api/info/faqList',

    //채팅방 api
    chatMsgList: '/api/msg/chatMsgList',
    chatIntiList:'/api/msg/chatInitList',
    getCallSeq: '/api/session/getCallSeq',
    chatMsgRoomInfo: '/api/msg/msg-room-info',
    chgGroupChat: '/api/msg/chgGroupChat',
    saveChatMsg: '/api/msg/save-msg',
    getGrpRFInfo: '/api/msg/get-group-roomFriend',
    delChatMessage : '/api/msg/del-chat-message',
    delChatPerfMessage : '/api/msg/del-chat-perf-message',

    removeData: '/api/main/removeData',
    chgRoomNm: '/api/room/chg-roomNm',
    chgFriendNm: '/api/room/chg-friendNm',

    // qr 스캔 통화 문자 처리
    scanAppChkSend: '/api/msg/scanAppChkSend' ,

    //환경세팅 
    saveSetting: '/api/sett/save-jkj-setting',
    regUseQr:'/api/qrInfo/regUseQr',

    

    sScribeMsgSend: '/topic/msgSend',
    sScribelinkChk: '/topic/linkChk',
    rtnSubscribeCandidate: '/topic/peer/iceCandidate',
    rtnSubscribeOffer: '/topic/peer/offer',
    rtnSubscribeAnswer: '/topic/peer/answer',    
    rtnSubscribeCallKey: '/topic/call/key',
    rtnSubscribeSendKey: '/topic/send/key',
    rtnSubscribeLocInfo:'/topic/locInfo',
    rtnSubscribeReadMsg:'/topic/readMsg',
    rtnSubscribeChangeInfo: '/topic/changeInfo',
    //rtnSubscribeDelMsg:'/topic/delMsg',
    

    rtnSendMsgSend: '/app/msgSend',
    rtnSendCallKey: '/app/call/key',
    rtnSendSendKey: '/app/send/key',
    rtnSendChangeInfo: '/app/changeInfo',
    
    rtnSendCandidate: '/app/peer/iceCandidate',
    rtnSendAnswer: '/app/peer/answer',
    rtnSendOffer: '/app/peer/offer',
    rtnSendLocInfo:'/app/locInfo',
    rtnSendReadMsg:'/app/readMsg',
    //rtnSendDelMsg:'/app/delMsg',
}
export default ApiInfo;