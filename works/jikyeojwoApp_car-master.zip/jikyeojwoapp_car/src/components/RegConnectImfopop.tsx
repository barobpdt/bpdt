import React, { useRef, useState } from 'react';
import { View, Text, TextInput, StyleSheet, TouchableOpacity, KeyboardAvoidingView, Platform, Image, SafeAreaView } from 'react-native';

const ConnectScreen = () => {
  const [nickname, setNickname] = useState('');
  const [code, setCode] = useState(['', '', '', '']);

  const inputRefs = [
    useRef<TextInput>(null),
    useRef<TextInput>(null),
    useRef<TextInput>(null),
    useRef<TextInput>(null),
  ];
      // 기본정보 변경 활성화
      const [isEditable, setIsEditable] = useState(false);
  

  const handleCodeChange = (text: string, index: number) => {
    if (!/^\d?$/.test(text)) return;

    const newCode = [...code];
    newCode[index] = text;
    setCode(newCode);

    if (text && index < 3) {
      inputRefs[index + 1].current?.focus();
    }
  };

  const handleKeyPress = (e: any, index: number) => {
    if (e.nativeEvent.key === 'Backspace') {
      const newCode = [...code];
      if (index > 0) {
        inputRefs[index - 1].current?.focus();
      }
      newCode[index] = '';
      setCode(newCode);
    }
  };

  return (
    <SafeAreaView style={{flex:1}}>
        <View style={styles.closeButton}>
            <TouchableOpacity /*onPress={{}}*/>
                {/*<Image 
                    source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
                /> */}
                <Text style={{color:'white', fontSize:30,}}>X</Text>
            </TouchableOpacity>
        </View>
        <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
        <Text style={styles.title}>로그인</Text>
        <View style={{width:'70%', marginBottom:20}}>
            <TextInput
                style={styles.nicknameInput}
                placeholder="닉네임을 입력하세요"
                value={nickname}
                onChangeText={setNickname}
            />

            <View style={styles.codeContainer}>
                {code.map((digit, index) => (
                <TextInput
                    key={index}
                    style={styles.codeInput}
                    keyboardType="number-pad"
                    maxLength={1}
                    ref={inputRefs[index]}
                    value={digit ? '*' : ''}
                    onChangeText={(text) => handleCodeChange(text, index)}
                    onKeyPress={(e) => handleKeyPress(e, index)}
                />
                ))}
            </View> 
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom:10}}>
            <Text style={{ marginRight: 10 , fontSize:16 }}>자동접속</Text>
            <TouchableOpacity onPress={() => {setIsEditable(prev => !prev);}} >
                <Image
                source={
                    isEditable
                    ? require('../../assets/check.png')    // 체크된 상태 이미지
                    : require('../../assets/check_disable.png')  // 체크 해제 이미지
                }
                style={{ width: 20, height: 20, marginRight: 8 }}
                />
            </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.button}>
            <Text style={styles.buttonText}>로그인</Text>
        </TouchableOpacity>
        </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default ConnectScreen;

const styles = StyleSheet.create({
  container: {
    paddingBottom:150,
    flex: 1,
    justifyContent:'center',
    alignItems: 'center',
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    marginBottom: 30,
  },
  nicknameInput: {
    height: 50,
    borderColor: '#FF851D',
    borderWidth: 1,
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom:10,
    fontSize: 16,
  },
  codeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  codeInput: {
    width: 50,
    height: 50,
    borderColor: '#FF851D',
    borderWidth: 1,
    borderRadius: 10,
    textAlign: 'center',
    fontSize: 20,
  },
  button: {
    backgroundColor: '#FF851D',
    paddingHorizontal: 40,
    paddingVertical: 12,
    borderRadius: 10,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor:'withe',
    borderRadius: 50,
    padding: 10,
  },
});
