import React, {useState, useEffect} from 'react';
import {View, Text, Modal, Button, StyleSheet, Image, TouchableOpacity, FlatList} from 'react-native';
import {QrSelectViewProps, ListMyQr} from '../types/common';
import {useGlobalStore } from '../store/global';

  
const QrSelectViewPop: React.FC<QrSelectViewProps> = ({ popVisible, onQrSelectViewClose }) => {    

    const [protectQrList, setProtectQrList] = useState<ListMyQr[]>([]); 
    const global = useGlobalStore();
    const maxTextLength = 4 ;  

    const [selServiceTypeCd, setSelServiceTypeCd] = useState('');

    useEffect(() => {
    
      const filteredList = global.listMyQr.filter(item => item.serviceTypeCd === 'Protect');
      setProtectQrList(filteredList);
    
    }, []);


    const handleClose = () => {
        console.log('QrAddViewPop close');
        onQrSelectViewClose('close') ;
    };

    const handleSelSelectData = (qrNo:string) => {
       // Alert.alert(serviceTypeCd);
       console.log('QrAddViewPop serviceTypeCd', qrNo);
       onQrSelectViewClose(qrNo) ;
    };

    return (
        <Modal
            visible={popVisible}
            transparent={true}
            animationType='slide'
            onRequestClose={handleClose} // Android의 백 버튼 처리
        >

           <View style={styles.popContainer}>
                <View style={styles.titleContainer}>
                    <View style={styles.leftContainer}>
                        <Text style={styles.text}> 연락할 QR을 선택해주세요!</Text>    
                        <Image 
                            source={require('../assets/ic_question.png') } // 임시 이미지 URL 사용
                            style={styles.questimage} 
                        /> 
                    </View>  
                    <TouchableOpacity style={{padding:5, position:'absolute', right:0, top:0}} onPress={handleClose}>
                        <Image 
                            source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
                            style={styles.closeimage} 
                        /> 
                    </TouchableOpacity>
                </View>
               
                <FlatList 
                  showsVerticalScrollIndicator={false}
                  data={protectQrList} 
                  renderItem={({ item }) => (
                    <View style={styles.flat_qr_nonSelbg}>
                      <TouchableOpacity style={styles.qr_contener} onPress={() => handleSelSelectData(item.qrNo)}>
                        <View>
                          <Image
                            source={{ uri: item.qrInfo }}
                            style={styles.qrNonSelImg}   
                          />
                        </View>
                      </TouchableOpacity>
                      <Text style={{ marginTop: 1, marginBottom: 1, fontSize: 14 , textAlign: 'center' }} numberOfLines={1}>
                        {   item.nickNm.length > maxTextLength ?   item.nickNm.substring(0,maxTextLength) + '...' : item.nickNm }
                      </Text>
                    </View>
                )}
                keyExtractor={item => item.qrNo.toString()}
                horizontal={true} // 가로 방향으로 나열
                contentContainerStyle={styles.flat_container} // 아이템의 간격을 포함할 수 있는 스타일
              />
              
            </View>


        </Modal>

    );
};

export default QrSelectViewPop ;

const styles = StyleSheet.create({
    popContainer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: '25%', // 화면의 중간까지
        backgroundColor: 'white',
        borderTopLeftRadius: 30,   // 위 왼쪽 모서리를 둥글게
        borderTopRightRadius: 30,  // 위 오른쪽 모서리를 둥글게
        borderBottomLeftRadius: 0,  // 아래 왼쪽 모서리는 각지게
        borderBottomRightRadius: 0, // 아래 오른쪽 모서리는 각지게
        
    },
    titleContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 10,
    },
    text: {
        marginTop: 25,
        fontSize: 18, // 텍스트 크기
      },
    questimage: {
        width: 25, // 이미지 너비
        height: 25, // 이미지 높이
        marginLeft: 5, // 텍스트와의 간격
        marginTop: 25,
      },
    closeimage: {
        width: 25, // 이미지 너비
        height: 25, // 이미지 높이
        marginRight: 10, // 텍스트와의 간격
        marginTop: 25,
    },
    leftContainer: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    qrList_box: {
        flex:1,
        alignItems: 'center',
        flexDirection: 'row',
      },
      flat_qr_nonSelbg: {
        paddingLeft: 10, // 양쪽에 20의 패딩을 추가
        paddingRight: 10, // 양쪽에 20의 패딩을 추가
        //borderRadius: 10,
        //backgroundColor:'white'
      },
      qr_contener: {
        justifyContent: 'center', alignItems: 'center'
       },
       qrNonSelImg: {
        width: 65, 
        height: 65, 
        borderRadius: 5, 
        marginTop: 10,
        borderColor: 'white',
      },
      flat_container: {
        paddingHorizontal: 10, // 양쪽에 20의 패딩을 추가
      },
   
});
