import React, { memo, useRef, useState } from 'react';
import { StyleSheet, Text, View, FlatList, useWindowDimensions, TouchableWithoutFeedback, Modal, Pressable, ColorValue, Image, TouchableOpacity } from 'react-native';
import Animated, {
	useSharedValue,
	useAnimatedScrollHandler,
	useAnimatedStyle,
	interpolate,
	Extrapolation,
	withSpring,
	withTiming,
	SharedValue,
	useDerivedValue,
	interpolateColor,
} from 'react-native-reanimated'; 
import { SafeAreaView} from 'react-native-safe-area-context';
import { ApiImageFields } from '../types/common';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
//import useGlobalStore from '../stores/global';

/*
  공통 컨트롤 정보

type TopTitileProps = {
	title?:string;
}
export const TopTitile = ({title}:TopTitileProps) => {
	const nav = useNavigation<StackNavigationProp<RootStackParamList>>()
	//const pageStatus = useGlobalStore(state=>state.pageStatus)
	const goBack = () => {
		console.log("go back pageStatus =>",pageStatus)		
		nav.goBack()
	}
	return (
		<View style={ {
			backgroundColor: '#F08229',
			height: 60, // 헤더 높이 고정
			justifyContent: 'center',
			alignItems: 'center',
			position: 'relative',
		  }}>
			<TouchableOpacity onPress={()=>goBack()} style={{
				position: 'absolute', // 헤더의 왼쪽 상단에 고정
				left: 5, // 왼쪽 여백
				top: 0, // 위쪽 여백
				width: 50,
				height: '100%',
				justifyContent: 'center', // 버튼 중앙 정렬
				alignItems: 'center',
			}}>
				<Image source={require('../assets/ic_arrow_prev.png')} style={ {
					width: '100%',
					height: '100%',
					resizeMode: 'contain',
				}} />
			</TouchableOpacity>
			<Text style={{
				fontSize: 20, // 텍스트 크기
				fontWeight: 'bold', // 텍스트 두께
				color: '#fff', // 텍스트 색상
			}}>
				{title}
			</Text>
		</View>
	)
}
*/
/**새로 생성한 체크박스 오브젝트 */
type CheckBoxProps = {
	isChecked: boolean;
	onCheck: (v:boolean) => void;
}

export const CheckBox = ({ isChecked, onCheck }: CheckBoxProps) => { 
	const onClick = () => { 
		console.log("Checkbox clicked. Current value:", isChecked);
		onCheck(!isChecked)
	}
	return (
	  <View  style={{width:32, height:32}}>
		<TouchableOpacity onPress={onClick}>
		  <Image
			source={
				isChecked
				? require('../assets/check.png')
				: require('../assets/check_disable.png')
			}
			style={{width:'100%', height:'100%'}} // 이미지 크기 조정
		  />
		</TouchableOpacity>
	  </View>
	);
};

export type ComboBoxOption = {
	code:string;
	value:string;
}
export type ComboBoxProps = {
	options: ComboBoxOption[];
	selectedValue?: string;
	index: number,
	onValueChange?: (val:string) => void;
}

export const ComboBox = ({ options, selectedValue='', index, onValueChange=(val)=>{} } : ComboBoxProps) => {
	const comboValue = (code:string) => {
		if(!code) {
			return options.length>0 ? options[0].value: ''
		}
		for(var cur of options) {
			if(cur.code==code) {
				return cur.value
			}
		}
		return ''
	}
	const [isDropdownOpen, setIsDropdownOpen] = useState(false);
	const [selected, setSelected] = useState(()=>comboValue(selectedValue)); // Set initial value to the first option
	React.useEffect(()=>{
		console.log("use effect selectedValue == "+selectedValue)
		setSelected(comboValue(selectedValue))
	},[selectedValue])

	return (
	<View style={{ flex:1 , zIndex:999+index }}>
		<TouchableOpacity
			style={{
				borderWidth: 1,
				borderColor: '#ccc',
				borderRadius: 5,
				padding: 10,
				backgroundColor: '#f9f9f9',
			}}
			onPress={() => setIsDropdownOpen(!isDropdownOpen)}
		>
			<Text style={{ fontSize: 16 }}>
				{selected}
			</Text>
		</TouchableOpacity>
		{isDropdownOpen && (
			<View style={{
				marginTop: 5,
				borderWidth: 1,
				borderColor: '#ccc',
				borderRadius: 5,
				backgroundColor: '#fff'
			}}>
			{options.map((option, index) => (
				<TouchableOpacity
					key={index}
					style={{
						padding: 10,
						borderBottomWidth: 1,
						borderBottomColor: '#eee',
					}}
					onPress={() => {
						setSelected(option.value); // Update selected value
						onValueChange(option.code); // Notify parent component of the change
						setIsDropdownOpen(false);
					}}
				>
				<Text style={{ fontSize: 16 }}>
					{option.value}
				</Text>
				</TouchableOpacity>
			))}
			</View>
		)}
	</View>
	)
};
 
type CustomSwitchProps = {
	value:boolean;
	onValueChange: (v:boolean) => void;
}
export const CustomSwitch = ({ value, onValueChange }: CustomSwitchProps) => {
	// value for Switch Animation
	const switchTranslate = useSharedValue(20);
	// state for activate Switch
	const [active, setActive] = useState(value);
	// Progress Value
	const progress = useDerivedValue(() => {
		return withTiming(active ? 22 : 8);
	});
	const activeColor = '#F08229'
	const inActiveColor = '#ddd'

	// useEffect for change the switchTranslate Value
	React.useEffect(() => {
		if (active) {
			switchTranslate.value = 22;
		} else {
			switchTranslate.value = 4;
		}
	}, [active, switchTranslate]);

	// Circle Animation
	const customSpringStyles = useAnimatedStyle(() => {
		return {
			transform: [
				{
					translateX: withSpring(switchTranslate.value, {
						mass: 1,
						damping: 15,
						stiffness: 120,
						overshootClamping: false,
						restSpeedThreshold: 0.001,
						restDisplacementThreshold: 0.001,
					}),
				},
			],
		};
	});

	// Background Color Animation
	const backgroundColorStyle = useAnimatedStyle(() => {
		const backgroundColor = interpolateColor(
			progress.value,
			[12, 22],
			[inActiveColor, activeColor],
		);
		return {
			backgroundColor,
		};
	});

	return (
		<TouchableWithoutFeedback
			onPress={() => {
				const chk=!active
				setActive(chk)
				onValueChange(chk)
			}}>
			<Animated.View style={[{
				width: 50,
				height: 28,
				borderRadius: 30,
				justifyContent: 'center',
				backgroundColor: '#F2F5F7',
			}, backgroundColorStyle]}>
				<Animated.View style={[{
					width: 24,
					height: 24,
					borderRadius: 30,
					backgroundColor: 'white',
					shadowColor: 'black',
					shadowOffset: {
						width: 0,
						height: 2,
					},
					shadowOpacity: 0.2,
					shadowRadius: 2.5,
					elevation: 4,
				}, customSpringStyles]} />
			</Animated.View>
		</TouchableWithoutFeedback>
	);	
};


type ResizePanelProps = {
	top:number;
	width:number;
	height:number;
	onActive?: (active:boolean) => void;
	children?: React.ReactNode;
};

export type ResizePanelRefProps = {
	scrollTo: (destination: number) => void;
	isActive: () => boolean;
};

export const ResizePanel = React.forwardRef<ResizePanelRefProps, ResizePanelProps>( ({top, width, height, onActive, children }, ref) => {
	const screenHeight = height - top
	const MAX_TRANSLATE_Y = -screenHeight + 50;
	const translateY = useSharedValue(0);
	const active = useSharedValue(false);
	// const closeResizePanel = useGlobalStore(state=>state.closeResizePanel)

	const scrollTo = React.useCallback((destination: number) => {
		'worklet';
		active.value = destination !== 0; 
		if( typeof(onActive) == 'function' ) {
			onActive(active.value)
		}
		translateY.value = withSpring(destination, { damping: 50 });
	}, []);

	const isActive = React.useCallback(() => {
		return active.value;
	}, []);

	React.useImperativeHandle(ref, () => ({ scrollTo, isActive }), [
		scrollTo,
		isActive,
	]);

	const context = useSharedValue({ y: 0 });
	const gesture = Gesture.Pan()
	.onStart(() => {
		context.value = { y: translateY.value };
	})
	.onUpdate((event) => {
		translateY.value = event.translationY + context.value.y;
		translateY.value = Math.max(translateY.value, MAX_TRANSLATE_Y);
	})
	.onEnd(() => {
		if (translateY.value > -screenHeight / 3) {
			scrollTo(0);
		} else if (translateY.value < -screenHeight / 1.5) {
			scrollTo(MAX_TRANSLATE_Y);
		}
	});

	const rResizePanelStyle = useAnimatedStyle(() => {
		const borderRadius = interpolate(
			translateY.value,
			[MAX_TRANSLATE_Y + 50, MAX_TRANSLATE_Y],
			[25, 5],
			Extrapolation.CLAMP
		);

		return {
			borderRadius,
			transform: [{ translateY: translateY.value }],
		};
	});
	// console.log("resize panel ", screenHeight, translateY.value )
	return (
	<GestureDetector gesture={gesture}>
		<Animated.View style={[{
			height: screenHeight,
			width: '100%',
			backgroundColor: 'white',
			position: 'absolute',
			top: screenHeight,
			borderRadius: 25,
			borderWidth:2,
			borderColor:'#aaa'
		}, rResizePanelStyle]}>
			<View style={{
				width: 75,
				height: 4,
				backgroundColor: 'grey',
				alignSelf: 'center',
				marginVertical: 15,
				borderRadius: 2,
			}} />
			{children}
		</Animated.View>
	</GestureDetector>
	);
});

const styles = StyleSheet.create({
	/**
     * 모달 화면 영역
     */
    modalView: {
        marginTop: 230,
        margin: 30,
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 35,
        alignItems: 'center',
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 4,
        elevation: 5,
    },
    modalTextStyle: {
        color: '#17191c',
        fontWeight: 'bold',
        textAlign: 'center',
        marginBottom: 50
    },
});
