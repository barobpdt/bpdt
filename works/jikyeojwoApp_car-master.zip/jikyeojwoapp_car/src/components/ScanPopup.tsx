import React, { useEffect, useState } from 'react';
import { View, Text, Alert, StyleSheet, Image, TouchableOpacity, Modal, TextInput, Button , Platform, StatusBar} from 'react-native';
import { Camera , CameraType} from 'react-native-camera-kit';
import { launchImageLibrary } from 'react-native-image-picker';
import QrImageReader, { DecodeOptions } from 'react-native-qr-image-reader';
import { useGlobalStore } from '../store/global';
import { SafeAreaView } from 'react-native-safe-area-context';

let lastScanTime = 0;
const SCAN_DEBOUNCE_MS = 1000;

const ScanPopup: React.FC = () => {    

	const [modalVisible, setModalVisible] = useState(false);
	const [inputValue, setInputValue] = useState('');
	const [prevQrValue, setPrevQrValue] = useState('');

	const global = useGlobalStore()
	useEffect(() => {
		console.log("@@ ScanPopup useEffect global.currentScanType", global.currentScanInfo);
		global.setCurrentScanQrCode('')
	}, []);

	//setModalVisible	

	const handleQRCodeRead = (event:any) => {
		const now = Date.now();
		if (now - lastScanTime < SCAN_DEBOUNCE_MS) return;
		lastScanTime = now;
		const { codeStringValue } = event.nativeEvent;
		const param = getQueryParams(codeStringValue);
		if( param.qrNo == '' ) return;
		if( prevQrValue != param.qrNo ) { 
			console.log("qr data==>" , param.qrNo);
			global.setCurrentScanQrCode(param.qrNo as string);
		};
		setPrevQrValue(param.qrNo as string);
	};

	const inPutQrAlert = () => {
		setModalVisible(true);
	}

	//QR을 읽어서 파라메타 값을 가져옴
	const getQueryParams = (url:string) =>  {
		const queryString = url.split('?')[1];
		const params: Record<string, string | null> = {}; // params의 타입을 명시적으로 설정		
		if (queryString) {
			const pairs = queryString.split('&');
			pairs.forEach(pair => {
				const [key, value] = pair.split('=');
				// 키와 값이 존재하는지 확인하고 디코딩
				if (key) { // key가 존재할 때만
				params[decodeURIComponent(key)] = value ? decodeURIComponent(value) : null;
			}
			});
		}
		return params;
	} 
	const handleInputConfirm = () => {
		if (inputValue) {
			setModalVisible(false); // 모달 닫기
			global.setCurrentScanQrCode(inputValue); // 부모에게 입력한 QR값 전달
		} else {
			setModalVisible(false); // 모달 닫기 
		}
	};

	const decode = async (options: DecodeOptions) => {
		const {
			result: decodeResult,
			errorCode,
			errorMessage,
		} = await QrImageReader.decode(options);

		console.log('Error Code: ' + errorCode);
		console.log('Error Message: ' + errorMessage);
		console.log('Result: ' + decodeResult);

		if (decodeResult) {
			const param = getQueryParams(decodeResult as string);
			// QR 코드 인식 후 처리
			global.setCurrentScanQrCode(param.qrNo as string); // 부모에게 QR 값 전달
		} else {
			global.showToast("QR인식에 실패하였습니다. 다시 시도해주세요!")
		}
		//setResult(decodeResult || 'undefined');
	};
	//파일로 qr읽기
	const fileCamera = () => {		
		launchImageLibrary({ mediaType: 'photo' }, async (res) => {
			// assets가 정의되어 있는지 확인
			if (res.assets && res.assets.length > 0) {
				decode({
				path: res.assets[0].uri,
				});
			} else {
				global.showToast('이미지를 선택하지 않았습니다.'); // 선택하지 않았을 때 처리
			}
		});
	}
	const closePopup = () => {
		console.log("@@ closePopup");
		setModalVisible(false);
		console.log("@@ closePopup", global.currentScanInfo.viewType);
		if( global.currentScanInfo.viewType == 'MyQrListPop' ) {
			global.setPopupPageId('MyQrListPop');
		} else {
			global.setPopupPageId('QRSelectPop');
		}
		global.setCurrentScanQrCode('');
		global.setCurrentScanInfo({serviceTypeCd: '', qrNo: '', viewType: '', myQrNo: ''});
	}

	return (
<React.Fragment>
	<StatusBar
	barStyle="dark-content"
	backgroundColor="#000" // 상태바 배경색 지정 (Android)
	/>
	<SafeAreaView style={{position: 'absolute',top: 0,left: 0, bottom:0, right: 0, backgroundColor: 'rgba(0, 0, 0, 0.7)', zIndex:2001}}>
		<Camera
			style={{flex:1}}
			onReadCode={handleQRCodeRead}
			scanBarcode={true}
			showFrame={true}
			frameColor={Platform.OS == 'ios' ? "white" : "transparent"}
			laserColor="transparent"
			flashMode="auto"
			cameraType={'back' as CameraType}
			zoomMode="on"
			zoom={0.5}
			// detectionArea={{ x: 0, y: 0, width: 1, height: 1 }} // Uncomment to use full area
		/>
		<View style={styles.overlay}>
			<View style={styles.closeButton}>
				<TouchableOpacity onPress={closePopup}>
					<Text style={{color:'white', fontSize:30, textShadowColor:'black', textShadowOffset:{width:1, height:1}, textShadowRadius:5}}>
						X
					</Text>
				</TouchableOpacity>
			</View>
			{ Platform.OS == 'ios' ? 
				<Text style={{height:'60%'}}></Text> :
				<View style={{marginBottom:40}}>
					<Image source={require('../assets/ic_bg_scanner.png')} style={styles.rectangle} />
				</View>
			}
			<Text style={styles.qrDescText}>
				QR이미지를 사각형 안에 비춰주세요.
			</Text>
			<TouchableOpacity onPress={inPutQrAlert}>
				<Text style={styles.qrLinkText}>
					QR번호로 직접 등록하기
				</Text>
			</TouchableOpacity>
			<TouchableOpacity onPress={fileCamera}>
				<Text style={styles.qrLinkText}>
					파일 검색하기
				</Text>
			</TouchableOpacity> 
			<Text style={{height:20}}></Text>
		</View>

		<Modal
			visible={modalVisible}
			transparent={true}
			animationType="slide"
			onRequestClose={() => setModalVisible(false)} // back button 클릭 시 모달 닫기
		>
			<View style={styles.modalContainer}>
				<View style={styles.modalContent}>
					<View style={{padding:24}}>
						<Text style={styles.modalTitle}>QR번호 직접 입력</Text>
						<TextInput
							style={styles.input}
							placeholder="여기에 QR번호를 입력해주세요"
							value={inputValue}
							onChangeText={setInputValue}
						/>
					</View>
					{/* 버튼 영역 - 화면 하단 고정 */}
					<View style={styles.btnBox}>
						<TouchableOpacity style={styles.btnSquareCancel} onPress={()=>setModalVisible(false)}>
						<Text style={styles.btnCancelText}>취소</Text>
						</TouchableOpacity>
						<TouchableOpacity onPress={handleInputConfirm} style={styles.btnSquareOk}>
						<Text style={styles.btnOkText}>확인</Text>
						</TouchableOpacity>
					</View>
				</View>
			</View>
		</Modal>
	</SafeAreaView> 
	</React.Fragment>
	);
};

const styles = StyleSheet.create({
	safeArea: {
		flex: 1,
	},
	container: {
		flex: 1,
		justifyContent: 'center',
	},
	preview: {
		flex: 1,
		position: 'relative',
	},
	rectangleContainer: {
		position: 'absolute',
		top: '20%',
		left: '20%',
		right: '20%',
		alignItems: 'center',
		justifyContent: 'center',
	},
	rectangle: {
		width: 250,
		height: 250, // 네모 이미지 높이 
		alignItems: 'center',
		justifyContent: 'center',
	},
	textOverlay: {
		position: 'absolute',
		color: 'white',
		backgroundColor: 'rgba(0,0,0,0.7)',
		padding: 10,
		borderRadius: 5,
	},
	closeButton: {
		position: 'absolute',
		top: Platform.OS == 'ios' ? 26 : 18,
		right: 10,
		backgroundColor:'withe',
		borderRadius: 50,
		padding: 10,
	},
	qrDescText: {
		marginTop: 10,
		fontSize: 16,
		textAlign: 'center',
		color: 'white'
	},
	qrLinkText: {
		marginTop: 15,
		fontSize: 14,
		textAlign: 'center',
		color: 'white',
		textDecorationLine: 'underline', // 밑줄 추가
	},
	overlay: {
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		backgroundColor: 'rgba(0, 0, 0, 0.3)',
		justifyContent: 'center',
		alignItems: 'center',
		zIndex: 2,
	},
	buttonContainer: {
		flexDirection: 'row',
		width: '100%', // 버튼 컨테이너 너비를 100%로 설정
	},
	button: {
		padding: 10,
		justifyContent: 'center',
		alignItems: 'center',
		borderWidth: 1,
		borderColor: 'gray', // 버튼 테두리 색상
		borderRadius: 5, // 버튼 모서리를 둥글게
	},
	buttonText: {
		fontSize: 16, // 텍스트 크기
		color: 'black', // 텍스트 색상
	},
	modalContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.6)',
	},
	modalContent: {
		width: '85%',
		backgroundColor: '#fff',
		borderRadius: 16,
		shadowColor: '#000',
		shadowOpacity: 0.2,
		shadowRadius: 10,
		elevation: 10,
	},
	modalTitle: {
		fontSize: 18,
		fontWeight: '600',
		marginBottom: 16,
		textAlign: 'center',
		color: '#333',
	},
	input: {
		height: 44,
		borderColor: '#ddd',
		borderWidth: 1,
		backgroundColor: '#fafafa',
		paddingHorizontal: 12,
		borderRadius: 8,
		fontSize: 15,
		marginBottom: 24,
	},
	btnBox: {
		flexDirection: 'row',
		justifyContent: 'space-between',
	},
	btnSquareCancel: {
		flex: 1,
		backgroundColor: '#f2f2f2',
		borderBottomLeftRadius:16,
		justifyContent: 'center',
		alignItems: 'center',
		height: 65,
	},
	btnSquareOk: {
		flex: 1,
		backgroundColor: '#F08229',
		borderBottomRightRadius:16,
		justifyContent: 'center',
		alignItems: 'center',
		height: 65,
	},
	btnCancelText: {
		color: '#666',
		fontSize: 16,
		fontWeight: '500',
	},
	btnOkText: {
		color: '#fff',
		fontSize: 16,
		fontWeight: '600',
	},
});

export default ScanPopup;