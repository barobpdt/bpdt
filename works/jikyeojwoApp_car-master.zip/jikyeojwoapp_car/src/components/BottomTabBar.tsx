import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet , Image, Alert} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import {BottomTabBarProps, RootStackParamList} from '../types/common.tsx'
import { useGlobalStore } from "../store/global.tsx";




const BottomTabBar: React.FC<BottomTabBarProps> = ({bottonCall}) => {
  const global =useGlobalStore()
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴

    const goToHomeMove = () => {
     // navigation.navigate("MainHome");
      bottonCall("H");
    }

    const goToQrPop = () => {
      //bottonCall("Q");
		  global.setPopupPageId('QRSelectPop');
    }

    const goToMyProfile = () => {
      navigation.navigate("MyProfile");
    }

    const goToSearch = () => {
      navigation.navigate("Search");
    }

   


    return (
        <View style={styles.container}>
            <TouchableOpacity style={styles.floatingButton} onPress={goToQrPop}>
            <Image
              source={require('../assets/qr_scanner.png')} 
              style={styles.iconCen} // 이미지 스타일
            />
            </TouchableOpacity>
        
            <View style={styles.bottomBar}>
                <TouchableOpacity  onPress={goToHomeMove}>
                <Image
                  source={require('../assets/ic_home.png')} 
                  style={styles.icon} // 이미지 스타일
                />
                    <Text  style={{textAlign:'center', marginBottom:2}}>Home</Text>    
                </TouchableOpacity>
                <View style={{width:35}}>{/**2번째 영역 */}</View>
                <View style={{width:50}}>{/**QR스캔 중간영역 */}</View>
                <TouchableOpacity onPress={goToSearch}  style={styles.searchTouchIcon}>
                  <Image
                    source={require('../assets/ic_search.png')} 
                    style={styles.icon} // 이미지 스타일
                  />
                  <Text style={{textAlign:'center'}}>검색</Text>    
                </TouchableOpacity>
                <TouchableOpacity onPress={goToMyProfile}  style={styles.myTouchIcon}>
                <Image
                  source={require('../assets/ic_my.png')} 
                  style={styles.icon} // 이미지 스타일
                />
                  <Text style={{textAlign:'center'}}>My</Text>    
                </TouchableOpacity>
            </View>
        </View>
    );
}

export default BottomTabBar ;

// 스타일 정의
const styles = StyleSheet.create({
  bottomBar: {
    backgroundColor: '#f2f7fcff',
    width: '100%',
    height: 60,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 5,
  },
  barItemView: {
    alignItems:'center',
    justifyContent:'flex-end',
  },
  container:{
    height:50,
    justifyContent:'flex-end',
    backgroundColor:'#F7F7F7',
    
  },
  floatingButton: {
    position:'absolute',
    alignSelf:'center',
    width: 70,
    height: 70,
    borderRadius: 25,
    zIndex: 10,
    bottom: 0,
  },
  qrButton: {
    color: '#1B6ADF',
    marginTop: 30,
    justifyContent:'center',
    fontWeight: 'bold',
  },
  Text: {
    color:'#696969',
    marginTop: 3,
  },
  icon: {
    width: 35, // 아이콘의 너비
    height: 30, // 아이콘의 높이
    justifyContent:'center',
    marginBottom: 6, // 텍스트와 아이콘 사이의 간격
  },
  iconCen: {
    width: 60, // 아이콘의 너비
    height: 60, // 아이콘의 높이
    justifyContent:'center',
    alignItems: 'center',
  },
  myTouchIcon: {
    marginRight: 10, // 텍스트와 아이콘 사이의 간격
  },
  searchTouchIcon: {
    //marginLeft: 220, // 텍스트와 아이콘 사이의 간격
  },
});