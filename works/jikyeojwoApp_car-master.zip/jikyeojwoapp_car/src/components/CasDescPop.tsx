import React,{useState, useEffect} from 'react';
import { StyleSheet, View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CompositeNavigationProp, RouteProp, useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { ApiCasFields, RootStackParamList  } from '../types/common';

// type CasDescPopProps = {
//     route: RouteProp<RootStackParamList, 'CasDesc'>; // RouteProp을 이용한 'CasDesc'의 route 타입 정의
// };

//const CasDescPop: React.FC<CasDescPopProps> = ({ route }) => {  
const CasDescPop = ({ route }) => {     
    const insets = useSafeAreaInsets(); 
    const navigation = useNavigation();
    const [casDetailInfo, setCasDetailInfo] = useState<ApiCasFields>();  //약관상세내역   
    
    useEffect(() => {
        // route.params.data가 존재할 때만 값 설정
        if (route.params.data) {
            setCasDetailInfo(route.params.data);
        }
    }, [route.params.data]); // 의존성 배열에 추가하여 데이터가 변경될 때마다 실행

    

    const onPopClose =() => {
        //navigation.goBack();
        // 모달을 닫기 위해 부모 컴포넌트의 상태를 직접 제어
        if (route.params?.onClose) {
            route.params.onClose(); // 부모에서 전달된 닫기 함수 호출
        }
    }


    return (
            <View style={{flex:1, /*paddingTop: insets.top*/}}>
                <View style={ {
                    backgroundColor: '#F08229',
                    height: 60, // 헤더 높이 고정
                    justifyContent: 'center',
                    alignItems: 'center',
                    position: 'relative',
                    }}>
                    <TouchableOpacity onPress={()=>onPopClose()} style={{
                        position: 'absolute', // 헤더의 왼쪽 상단에 고정
                        left: 5, // 왼쪽 여백
                        top: 0, // 위쪽 여백
                        width: 50,
                        height: '100%',
                        justifyContent: 'center', // 버튼 중앙 정렬
                        alignItems: 'center',
                    }}>
                        <Image source={require('../assets/ic_arrow_prev.png')} style={ {
                            width: '100%',
                            height: '100%',
                            resizeMode: 'contain',
                        }} />
                    </TouchableOpacity>
                    <Text style={{
                        fontSize: 20, // 텍스트 크기
                        fontWeight: 'bold', // 텍스트 두께
                        color: '#fff', // 텍스트 색상
                    }}>
                        {casDetailInfo?.casNm}
                    </Text>
                </View>

                <ScrollView style={{flex:1}}>
                    <Text style={{padding:8}}>
                    {casDetailInfo?.casDesc}
                    </Text>
                </ScrollView>
                
            </View>
    );
}

const styles = StyleSheet.create({
    closeButton: {
        padding: 10,
        backgroundColor: '#F08229',
        borderRadius: 5,
    },
    closeButtonText: {
        color: '#FFFFFF',
        fontSize: 16,
    },
});

export default CasDescPop;
