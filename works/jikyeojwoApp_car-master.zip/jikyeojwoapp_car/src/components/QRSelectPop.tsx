import React, { useContext, useEffect, useRef, useState } from "react";
import { BackHandler, Dimensions, FlatList, Image, Platform, StyleSheet, Text, TextInput, ToastAndroid, TouchableOpacity, View } from "react-native";
import { useGlobalStore,} from "../store/global";
import { ListMyQr } from "../types/common";

const QRSelectPop = () => {
	const global =useGlobalStore()

	const [protectQrList, setProtectQrList] = useState<ListMyQr[]>([]); 
    const maxTextLength = 4 ;  

	useEffect(() => {
        const filteredList  = global.listMyQr.filter(item => item.serviceTypeCd === 'Protect');
        setProtectQrList(filteredList); 
	}, []);

	const width = Dimensions.get('window').width
	const height = Dimensions.get('window').height
	
	const closePopup = () => {
		global.setPopupPageId('');
	}

    const friendAdd = (item: ListMyQr) => {
        console.log("@@ friendAdd item", item);
        global.setCurrentScanInfo({serviceTypeCd:'Protect', qrNo: '', viewType: 'AddFriend', myQrNo: item.qrNo});
		global.setPopupPageId('ScanPopup');
    }
    
    const jkjAdd= () => {
        global.setCurrentScanInfo({serviceTypeCd:'Protect', qrNo: '', viewType:'Home', myQrNo:''});
		global.setPopupPageId('ScanPopup');
    }
    
    const carAdd= () => {
        global.setCurrentScanInfo({serviceTypeCd:'Car', qrNo: '', viewType:'Home', myQrNo:''});
		global.setPopupPageId('ScanPopup');
    }
    
    const contact= (item: ListMyQr) => {
		global.setCurrentScanInfo({serviceTypeCd:'', qrNo: '', viewType: 'CallScanner', myQrNo: item.qrNo});
		global.setPopupPageId('ScanPopup');
    }

	return (
		<View style={{
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			height: '100%',
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: 'rgba(0, 0, 0, 0.5)',
		}}>
			<View style={{
				width: width * 0.9,
				height: protectQrList.length === 1 ? height*0.5 : height*0.8,
				backgroundColor: '#fff',
				borderRadius: 15,
			}}> 
				<View style={{paddingHorizontal: 15, paddingVertical: 10, flex:1}}>
					<TouchableOpacity style={styles.closeButton} onPress={() => closePopup()}>
						<Text style={styles.closeButtonText}>✕</Text>
					</TouchableOpacity>
                    <View style={{padding:20, flex:1, justifyContent:"center", gap:12, marginTop:20}}>
                        {/* QR스캔 섹션 */}
                        {protectQrList.length === 1 ? (
                            <TouchableOpacity style={styles.contentBtn} onPress={() => contact(protectQrList[0])}>
                                <Text style={styles.contentBtnTxt}>QR스캔</Text>
                            </TouchableOpacity>
                        ) : (
                            <View style={styles.contentBtn}>
                                <Text style={styles.contentBtnTxt}>QR스캔</Text>
                                <FlatList
                                    showsVerticalScrollIndicator={false}
                                    data={protectQrList} 
                                    renderItem={({ item }) => (
                                        <TouchableOpacity style={styles.flat_qr_nonSelbg} onPress={() => contact(item)}>
                                            <View style={styles.qr_contener}>
                                                <Image
                                                    source={{ uri: item.qrInfo }}
                                                    style={styles.qrNonSelImg}   
                                                />
                                            </View>
                                            <Text style={{ marginTop: 1, marginBottom: 1, fontSize: 14 , textAlign: 'center' }} numberOfLines={1}>
                                                {item.nickNm.length > maxTextLength ? item.nickNm.substring(0,maxTextLength) + '...' : item.nickNm}
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                    keyExtractor={item => item.qrNo.toString()}
                                    horizontal={true}
                                    contentContainerStyle={styles.flat_container}
                                />
                            </View>
                        )}

                        {/* 친구추가 섹션 */}
                        {protectQrList.length === 1 ? (
                            <TouchableOpacity style={styles.contentBtn} onPress={() => friendAdd(protectQrList[0])}>
                                <Text style={styles.contentBtnTxt}>친구추가</Text>
                            </TouchableOpacity>
                        ) : (
                            <View style={styles.contentBtn}>
                                <Text style={styles.contentBtnTxt}>친구추가</Text>
                                <FlatList
                                    showsVerticalScrollIndicator={false}
                                    data={protectQrList} 
                                    renderItem={({ item }) => (
                                        <TouchableOpacity style={styles.flat_qr_nonSelbg} onPress={() => friendAdd(item)}>
                                            <View style={styles.qr_contener}>
                                                <Image
                                                    source={{ uri: item.qrInfo }}
                                                    style={styles.qrNonSelImg}   
                                                />
                                            </View>
                                            <Text style={{ marginTop: 1, marginBottom: 1, fontSize: 14 , textAlign: 'center' }} numberOfLines={1}>
                                                {item.nickNm.length > maxTextLength ? item.nickNm.substring(0,maxTextLength) + '...' : item.nickNm}
                                            </Text>
                                        </TouchableOpacity>
                                    )}
                                    keyExtractor={item => item.qrNo.toString()}
                                    horizontal={true}
                                    contentContainerStyle={styles.flat_container}
                                />
                            </View>
                        )}
                        
                        {/* 나머지 버튼들 */}
                        <TouchableOpacity style={styles.contentBtn} onPress={jkjAdd}>
                            <Text style={styles.contentBtnTxt}>지켜줘 QR추가</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.contentBtn} onPress={carAdd}>
                            <Text style={styles.contentBtnTxt}>차빼줘 QR추가</Text>
                        </TouchableOpacity>
                    </View>
				</View>
                <TouchableOpacity style={styles.sendButton} onPress={()=>closePopup()}>
                    <Text style={styles.sendButtonText}>닫기</Text>
                </TouchableOpacity>
			</View>
		</View>
	);
};

export default QRSelectPop;

const styles = StyleSheet.create({
    contentBtn:{
        padding:20,
        borderRadius:15,
        backgroundColor:'#FFE5D0',
        borderWidth:0,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    contentBtnTxt:{
        textAlign:'center',
        fontSize:16,
        fontWeight:'bold',
        color: '#FF851D',
    },
	sendButton: {
        backgroundColor: '#ddd',
        width:'100%',
        justifyContent:'center',
        borderBottomLeftRadius:15,
        borderBottomRightRadius:15,
        paddingVertical:18,
        borderTopWidth:1,
        borderTopColor:'#eee',
	},
	sendButtonText: {
		fontSize:18,
		fontWeight: 'bold',
		textAlign:'center',
		color: '#666',
	},
	closeButton: {
		position: 'absolute',
		top: 12,
		right: 10,
		zIndex: 10,
		borderRadius: 20,
		paddingHorizontal: 12,
		paddingVertical: 4,
	},
	closeButtonText: {
		color: '#333',
		fontSize: 26,
		fontWeight: 'bold',
	},
	flat_qr_nonSelbg: {
		paddingLeft: 10,
		paddingRight: 10,
	},
	qr_contener: {
		justifyContent: 'center',
        alignItems: 'center'
	},
	qrNonSelImg: {
		width: 65, 
		height: 65, 
		borderRadius: 5, 
		marginTop: 10,
		borderColor: 'white',
	},
    flat_container: {
        paddingHorizontal: 10,
    },
});