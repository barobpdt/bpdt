import React from "react";
import { View, ScrollView, StyleSheet , Image} from 'react-native';
import { GlobalData } from "../store/global";

const ServiceIntro: React.FC = () => {
   return (
       <ScrollView 
        contentContainerStyle={styles.scrollView} 
        showsVerticalScrollIndicator={false}
        maximumZoomScale={3} // 확대/축소 가능
      >
        <View style={styles.imageContainer}>
        <Image
            // source={{ uri: "https://kosk.co.kr/scgd-file/intro/intro_jikyeojwo.png" }}
            source={{ uri: GlobalData.introImgUrl }}
            style={styles.image}
            resizeMode="contain" // 이미지 반영 비율 유지 및 공간 내에 맞추도록 설정
        />
        </View>
      </ScrollView>
     );
};

export default ServiceIntro ;

// 스타일 정의
const styles = StyleSheet.create({
    scrollView: {
        flexGrow: 1,
      },
    imageContainer: {
        width: '100%', // 컨테이너의 너비
        alignItems: 'center', // 이미지 중앙 정렬
      },
      image: {
        width: '100%', // 화면 너비에 맞추기
        height: 900, // 높이는 비율에 따라 자동 조정됨
        aspectRatio: 1,
      },
});