import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
type Props = {
    name: string;
    image: string;
    statusMsg: string;
    isSelected?: boolean;
    onToggle?: () => void;
    onRemove?: () => void;
    mode: 'select' | 'remove'; // ✅ 모드 추가
  };
  
  export default function GroupMemberItem({
    name,
    image,
    statusMsg,
    isSelected,
    onToggle,
    onRemove,
    mode,
  }: Props) {
    return (
      <View style={styles.container}>
        <Image source={require('../assets/ic_my.png')} style={styles.avatar} />
        <View style={styles.info}>
          <Text style={styles.name}>{name}</Text>
          <Text style={styles.statusMsg} numberOfLines={1} ellipsizeMode="tail">
            {statusMsg}
          </Text>
        </View>
  
        {mode === 'select' && onToggle && (
          <TouchableOpacity onPress={onToggle}>
            <Image
              source={
                isSelected
                  ? require('../assets/check.png')
                  : require('../assets/check_disable.png')
              }
              style={styles.toggleButton}
            />
          </TouchableOpacity>
        )}
  
        {mode === 'remove' && onRemove && (
          <TouchableOpacity onPress={onRemove}>
            <Image
              source={require('../assets/ico_floating_close.png')}
              style={styles.toggleButton}
            />
          </TouchableOpacity>
        )}
      </View>
    );
  }
const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#FFF6EF',
    borderRadius: 10,
    padding: 10,
    marginBottom: 8,
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    color: '#000',
    fontWeight: 'bold',
  },
  statusMsg: {
    fontSize: 12,
    color: '#888',
    flexShrink: 1,
    maxWidth: '90%',
  },
  toggleButton: {
    width: 24,
    height: 24,
    marginLeft: 8,
  },
});
