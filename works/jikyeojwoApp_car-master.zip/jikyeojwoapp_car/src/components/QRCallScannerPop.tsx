import React, { useState } from 'react';
import { View, Text, Alert, StyleSheet, Image, TouchableOpacity, Modal, TextInput, Button , SafeAreaView} from 'react-native';
import { Camera, CameraType } from 'react-native-camera-kit';
import { launchImageLibrary,Asset,MediaType } from 'react-native-image-picker';
import QrImageReader, { DecodeOptions } from 'react-native-qr-image-reader';
import {QRCallScannerPopProps} from '../types/common';

let prevQrValue = '';
//중복 생성을 사용안하고 CallScannerPop 파일 사용
const QRCallScannerPop: React.FC<QRCallScannerPopProps> = ({ closeQrCall, onQrCallRead }) => {    
  

  const [qrValue, setQrValue] = useState<string>('');
  const [modalVisible, setModalVisible] = useState(false);
  const [inputValue, setInputValue] = useState('');


  //setModalVisible

  const handleQRCodeRead = (event:any) => {
    console.log("@@ QR Code Read Event:", event.nativeEvent);
    const { codeStringValue } = event.nativeEvent;

    const param = getQueryParams(codeStringValue);
    if( param.qrNo == '' ) return;
    console.log("qr data==>" , param.qrNo);
    // QR 코드 인식 후 처리
    if( prevQrValue != param.qrNo ) {
      setQrValue(param.qrNo as string);
      onQrCallRead(param.qrNo as string); // 부모에게 QR 값 전달
      closeQrCall();
    };
    prevQrValue = param.qrNo as string;
  }

  const inPutQrAlert = () => {
    setModalVisible(true);
  }

  //QR을 읽어서 파라메타 값을 가져옴
  const getQueryParams = (url:string) =>  {
    const queryString = url.split('?')[1];
    const params: Record<string, string | null> = {}; // params의 타입을 명시적으로 설정
    
    if (queryString) {
        const pairs = queryString.split('&');
        pairs.forEach(pair => {
            const [key, value] = pair.split('=');
            // 키와 값이 존재하는지 확인하고 디코딩
            if (key) { // key가 존재할 때만
              params[decodeURIComponent(key)] = value ? decodeURIComponent(value) : null;
          }
        });
    }

    return params;
}

  const handleInputConfirm = () => {
    if (inputValue) {
      onQrCallRead(inputValue); // 부모에게 입력한 QR값 전달
      closeQrCall(); // 카메라 닫기
      setInputValue(''); // 입력 값 초기화
      setModalVisible(false); // 모달 닫기
    } else {
       setModalVisible(false); // 모달 닫기 
    }
  };

  const decode = async (options: DecodeOptions) => {
    const {
      result: decodeResult,
      errorCode,
      errorMessage,
    } = await QrImageReader.decode(options);

    console.log('Error Code: ' + errorCode);
    console.log('Error Message: ' + errorMessage);
    console.log('Result: ' + decodeResult);

    if (decodeResult) {
      const param = getQueryParams(decodeResult as string);
    // QR 코드 인식 후 처리
      setQrValue(param.qrNo as string);
      onQrCallRead(param.qrNo as string); // 부모에게 QR 값 전달
      closeQrCall();
    } else {
      Alert.alert("QR인식오류", "QR인식에 실패하였습니다. 다시 시도해주세요!")
    }

    

    //setResult(decodeResult || 'undefined');
  };
  //파일로 qr읽기
  const fileCamera = () => {
    
    launchImageLibrary({ mediaType: 'photo' }, async (res) => {
      // assets가 정의되어 있는지 확인
      if (res.assets && res.assets.length > 0) {
        decode({
          path: res.assets[0].uri,
        });
      } else {
        Alert.alert('Error', '이미지를 선택하지 않았습니다.'); // 선택하지 않았을 때 처리
      }
    });


  }


  return (
    <SafeAreaView style={styles.safeArea}>
    <View style={styles.container}>
      <Camera
        style={styles.preview}
        onReadCode={handleQRCodeRead}
        scanBarcode={true}
        showFrame={false}
        laserColor="transparent"
        frameColor="transparent"
        cameraType={'back' as CameraType}
      />
      <View style={styles.overlay}>
        <View style={styles.rectangleContainer}>          
          <Image source={require('../assets/ic_bg_scanner.png')} style={styles.rectangle} />
          <Text style={styles.qrDescText}>
              QR이미지를 사각형 안에 비춰주세요.
          </Text>
          <TouchableOpacity onPress={inPutQrAlert}>
              <Text style={styles.qrLinkText}>
                  QR번호로 직접 등록하기
              </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={fileCamera}>
          <Text style={styles.qrLinkText}>
              파일 검색하기
          </Text>
          </TouchableOpacity>
        </View>
        <View style={styles.closeButton}>
            <TouchableOpacity onPress={closeQrCall}>
              {/*<Image 
                  source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
              /> */}
              <Text style={{color:'white', fontSize:30,}}>X</Text>
            </TouchableOpacity>
        </View>
    </View>

    <Modal
        visible={modalVisible}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setModalVisible(false)} // back button 클릭 시 모달 닫기
    >
        <View style={styles.modalContainer}>
        <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>QR번호 직접 입력</Text>
            <TextInput
                style={styles.input}
                placeholder="여기에 QR번호를 입력해주세요"
                value={inputValue}
                onChangeText={setInputValue}
            />

          {/* 버튼 영역 - 화면 하단 고정 */}
          <View style={styles.btnBox}>
            <TouchableOpacity style={styles.btnSquareCancel} onPress={()=>setModalVisible(false)}>
              <Text style={styles.btnCancelText}>취소</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleInputConfirm} style={styles.btnSquareOk}>
              <Text style={styles.btnOkText}>확인</Text>
            </TouchableOpacity>
          </View>
        </View>
        </View>
    </Modal>
    


    </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
 },
  container: {
    flex: 1,
    justifyContent: 'center',
  },
  preview: {
    flex: 1,
    position: 'relative',
  },
  rectangleContainer: {
    position: 'absolute',
    top: '20%',
    left: '20%',
    right: '20%',
    bottom: '20%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rectangle: {
    width: 250,
    height: 250,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textOverlay: {
    position: 'absolute',
    color: 'white',
    backgroundColor: 'rgba(0,0,0,0.5)',
    padding: 10,
    borderRadius: 5,
  },
  closeButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    backgroundColor:'withe',
    borderRadius: 50,
    padding: 10,
  },
  qrDescText: {
    marginTop: 10,
    fontSize: 16,
    textAlign: 'center',
    color: 'white'
  },
  qrLinkText: {
    marginTop: 15,
    fontSize: 14,
    textAlign: 'center',
    color: 'white',
    textDecorationLine: 'underline', // 밑줄 추가
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)', // 모달 배경을 반투명하게 설정
  },
  modalContent: {
    width: '80%', // 모달의 너비를 화면의 80%로 설정
    padding: 20,
    backgroundColor: 'white', // 모달 내용의 배경색
    borderRadius: 10, // 모서리를 둥글게
    elevation: 5, // Android에서 그림자 효과 추가
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10, // 제목 아래 여백
  },
  input: {
    height: 40, // 입력란의 높이
    borderColor: 'gray', // 테두리 색상
    borderWidth: 1, // 테두리 두께
    marginBottom: 20, // 입력란 아래 여백
    paddingHorizontal: 10, // 입력란 안쪽 여백
    borderRadius: 5, // 모서리를 둥글게
  },
  btnBox: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  btnSquareCancel: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    marginRight: 8,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    height: 48,
  },
  btnSquareOk: {
    flex: 1,
    backgroundColor: '#F08229',
    marginLeft: 8,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    height: 48,
  },
  btnCancelText: {
    color: '#666',
    fontSize: 16,
    fontWeight: '500',
  },
  btnOkText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  
});

export default QRCallScannerPop;