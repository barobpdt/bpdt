import React, {useEffect, useState, useContext, useRef} from 'react';
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Image,
  Dimensions,
} from 'react-native';
import {useGlobalStore, GlobalData, GetDate, MembInfo} from '../store/global';
import { ListAlert, MessageData, FriendList } from '../types/common';
import { SocketStompContext  } from '../utils/WebSocketManager';

const { width, height } = Dimensions.get('window');


const LocationRequestListPop: React.FC = () => {

  const global = useGlobalStore();  
  const { sendMessage} = useContext(SocketStompContext);
  const [isPopQrView, setIsPopQrView] = useState<boolean>(false);   
  const requestCount = 2;

  // 추가된 상태 관리
  const flatListRef = useRef<FlatList>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [maxIndex, setMaxIndex] = useState(0);
  
  // 스크롤 가능 여부 계산
  const canScrollUp = currentIndex > 0;
  const canScrollDown = currentIndex < maxIndex;
  const isButtonsVisible = global.listAlert.length > 1;

  
  // 상수 설정 (아이템 높이)
  const ITEM_HEIGHT = 120; // 아이템 하나의 높이 (스타일에 맞게 조정)

  // 아이템 개수 변경 시 인덱스 재계산
  useEffect(() => {
    const newMaxIndex = Math.max(0, global.listAlert.length - 1);
    setMaxIndex(newMaxIndex);
    
    // 리스트가 줄었을 때 현재 인덱스 조정
    if (currentIndex > newMaxIndex) {
      setCurrentIndex(newMaxIndex);
    }
  }, [global.listAlert.length]);

  
  // 스크롤 핸들러
  const handleScroll = (direction: 'up' | 'down') => {
    const newIndex = direction === 'up' ? currentIndex - 1 : currentIndex + 1;
    
    if ((direction === 'up' && canScrollUp) || (direction === 'down' && canScrollDown)) {
      setCurrentIndex(newIndex);
      flatListRef.current?.scrollToIndex({
        index: newIndex,
        animated: true,
      });
    }
  };
  useEffect(() => {
    setIsPopQrView(true);
  }, []);

  const onClose = () => {
    global.setPopupPageId('');
    setIsPopQrView(false);
  }

  useEffect(() => {
    if (global.listAlert.length == 0) {
      onClose();
    }
  }, [global.listAlert]);

  const onApplyLocation = (item: ListAlert, mType:string) => {

    const state = useGlobalStore.getState();
    const qrInfo = state.listMyQr?.find(qritem => qritem.qrNo === item.membQrNo);   


    const msgData = {
              mType: mType , //'AL', JL
              mykey: GlobalData.myKey,
              msgDesc: global.membInfo.nickNm,              
              qrNo: item?.membQrNo,
              langCd: GlobalData.langCd,
              currentDate: GetDate(),
              callSeq: '',
              roomId: item?.friendSubScr,
              targetRoomId: item.membSubScr,
              membNo: GlobalData.membNo,
              writeMembNo: item?.friendQrNo,
              counterPart: item?.friendNo,
              onOff: 'Y',
              serviceTypeCd: 'Protect',
              fileImgUrl: '',
              filePath: '',
              callCount: 0,
              writeNickNm: qrInfo?.nickNm ? qrInfo?.nickNm : global.membInfo.nickNm  ,
					    writeImgFileUrl:qrInfo?.imgFileUrl ? qrInfo?.imgFileUrl : global.membInfo.imgFileUrl ,
            } as MessageData;	
      sendMessage(msgData, msgData.roomId);
      global.removeListAlert(item.membQrNo, item.friendNo, item.friendQrNo);

      //내 상태값 변경
     // global.setFriendLocationStatus(item, mType == 'AL' ? '10' : '90', mType == 'AL' ? '허용' : '거절');
      global.setReqLocationStatus('M', GlobalData.membNo, item?.membQrNo, item?.friendNo, item?.friendQrNo, mType == 'AL' ? '50' : '90', mType == 'AL' ? '허용' : '거절')
      
      // const existingIndex = global.friendList.findIndex(fr => fr.friendNo === item.friendNo && fr.friendQrNo === item.friendQrNo);
      // if (existingIndex !== -1) {
      //   let chgFriendInfo = global.friendList[existingIndex] ;
      //   chgFriendInfo.friendLocationCd =  mType == 'AL' ? '50' : '90' ;
      //   chgFriendInfo.friendLocationNm =  mType == 'AL' ? '허용' : '거절' ;

      //   global.changeLocationFriend(chgFriendInfo) ;
      // }
      
  }



  const renderItem = ({ item }: { item: ListAlert }) => (
    <View style={[styles.listItem, { height: ITEM_HEIGHT }]}>
        <View style={{flex:1, }}>
            <View style={styles.messageArea}>
                <Text style={styles.messageText}>
                  {item.friendNickNm}님이 위치 허용 요청을 하였습니다.
                </Text>
            </View>
            <View style={styles.buttonRow}>
                <TouchableOpacity style={styles.rejectButton} onPress={() => onApplyLocation(item,'JL')} >
                    <Text style={styles.buttonText}>거절</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.acceptButton} onPress={() => onApplyLocation(item, 'AL')} >
                    <Text style={styles.buttonText}>승인</Text>
                </TouchableOpacity>
            </View>
        </View>
    </View>
  );

  return (
    <Modal visible={isPopQrView} transparent animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.modalContainer}>
          {/* Header */}
          <View style={styles.header}>
            <Text style={styles.title}>위치 허용 요청 ({global.listAlert.length}건)</Text>
            <TouchableOpacity style={styles.closeButton} onPress={onClose}>
              <Text style={styles.closeText}>X</Text>
            </TouchableOpacity>
          </View>

        <View style={{paddingLeft:16, paddingRight:5, height:ITEM_HEIGHT, flexDirection:'row'}}>
          {/* FlatList */}
            <FlatList
              data={global.listAlert}
              keyExtractor={(item) => item.friendNo}
              renderItem={renderItem}
              showsVerticalScrollIndicator={false}
              style={{  height: ITEM_HEIGHT, }} 
              ref={flatListRef}
              scrollEnabled={false} // 스크롤 비활성화
              getItemLayout={(data, index) => ({
                length: ITEM_HEIGHT,
                offset: ITEM_HEIGHT * index,
                index,
              })}
            />
            <View style={{justifyContent:'center', gap:5}}>
              <TouchableOpacity 
                style={[styles.scrollButton, !canScrollUp && styles.disabledButton]}
                onPress={() => handleScroll('up')}
                disabled={!canScrollUp}
              >
                <Text style={[styles.buttonIcon, {}]}>▲</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.scrollButton, !canScrollDown && styles.disabledButton]}
                onPress={() => handleScroll('down')}
                disabled={!canScrollDown}>
                <Text style={styles.buttonIcon}>▼</Text>
              </TouchableOpacity>
            </View>
    </View>
          {/* Footer Button */}
          <TouchableOpacity style={styles.bottomButton} onPress={onClose}>
            <Text style={styles.bottomButtonText}>닫기</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
};

export default LocationRequestListPop;

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContainer: {
    //height: height * 0.5,
    width: width * 0.8,
    alignSelf: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingTop: 16,
  },
  header: {
    position: 'relative',
    alignItems: 'center',
    marginBottom: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  closeButton: {
    position: 'absolute',
    right: 10,
    
    
  },
  closeText: {
    fontSize: 22,
    color: '#999',
    fontWeight:'bold'
  },
  listContainer: {
    gap: 12,
    paddingBottom: 12,
  },
  listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    alignContent:'center',
    justifyContent:'center',
    gap: 8,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
    marginTop: 4,
    alignContent:'center',
    alignItems:'center'
  },
  messageArea: {
    flex: 1,
    alignContent:'center',
    alignItems:'center',
    justifyContent:'center',
    
  },
  messageText: {
    fontSize: 16,
    textAlign:'center',
    
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent:'space-around',
    marginBottom:5
    

  },
  rejectButton: {
    backgroundColor: '#ccc',
    paddingVertical: 10,
    borderTopLeftRadius: 6,
    borderBottomLeftRadius: 6,
    flex:1, 
  },
  acceptButton: {
    backgroundColor: '#FF851D',
    paddingVertical: 10,
    borderTopRightRadius: 6,
    borderBottomRightRadius: 6,
    flex:1
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    textAlign:'center'
  },
  bottomButton: {
    backgroundColor: '#FF851D',
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    
    
  },
  bottomButtonText: {
    color: '#fff',
    fontSize: 16,
  },
  scrollButtons: {
    justifyContent: 'space-between',
    paddingVertical: 8,
    marginLeft: 8,
  },
  scrollButton: {
    width: 30,
    height: 30,
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledButton: {
    opacity: 0.3,
  },
  buttonIcon: {
    color: '#000',
    fontSize: 25,
    fontWeight: 'bold',
  },
});
