import React, {useState, useEffect} from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Animated, Modal } from 'react-native';
import { CheckBox } from '../components/nui';
import { ApiCasFields , ApiTutorialInfo } from '../types/common';
import CasDescPop from '../components/CasDescPop'
interface CasInfoPopProps {
    data: {
      casInfoList: ApiCasFields[];
    };
    slideAnim: any; // 정확한 타입을 지정해 줄 수 있음
    goStart: (agreeCasList: ApiCasFields[]) => void;
    viewCasDesc: (selData: ApiCasFields) => void; // 수정한 타입
  }


//const CasInfoPop = ({ data, slideAnim, goStart, viewCasDesc}) => {
const CasInfoPop: React.FC<CasInfoPopProps> = ({ data, slideAnim, goStart, viewCasDesc }) => {    

    const [allAgree, setAllAgree] = useState(false); 
    const [casInfoList, setCasInfoList] = useState<ApiCasFields[]>([]);
    const [nextStep, setNextStep] = useState(false); 
    const [showCasDesc, setShowCasDesc] = useState(false);
    const [selectedCas, setSelectedCas] = useState<{casDesc: string, casNm: string}>({casDesc: '', casNm: ''});
    const dataChgUseYn = "Y";
    
    useEffect(() => {
        console.log("CasInfoPop useEffect==dataChgUseYn==>", dataChgUseYn);
        if (dataChgUseYn === "Y" && data) {
            setCasInfoList(data.casInfoList);
            console.log("data chage==>:", data.casInfoList); // 데이터의 길이 출력
        }
    }, [data]);

   
    const casAllChk = (chkBool: boolean) => {
   // console.log("all chk ==>", chkBool);
       
        setCasInfoList(prevList => {
            // 상태 업데이트
            const updatedList = prevList.map(row =>
                ({ ...row, agreeYn: chkBool })
            );
            setAllAgree(chkBool);
            // 변경된 리스트로 카운트 체크
            casStartCheck(updatedList);
    
            return updatedList; // 상태를 업데이트
        });
    }

    const casAgreeChk = (casNo:string, chkBool:boolean) => {
        
        setCasInfoList(prevList => {
            // 상태 업데이트
            const updatedList = prevList.map(row =>
                row.casNo === casNo ? { ...row, agreeYn: chkBool } : row
            );

            // 모든 항목이 체크되었는지 여부 판단
            const allChecked = updatedList.every(row => row.agreeYn === true);
            setAllAgree(allChecked);
        
            // 변경된 리스트로 카운트 체크
            casStartCheck(updatedList);
    
            return updatedList; // 상태를 업데이트
        });

        // if (!chkBool) {
        //     setAllAgree(chkBool)
        // }
        
    }

    // 필수항목 체크가 완료되면 시작하기 버튼 활성화 처리함 - 하나로도 취소되면 비활성화 처리함
    const casStartCheck = (updatedList:ApiCasFields[]) => {
        let  chkCnt = 0 ;
    
        updatedList.forEach(row => {
         //   console.log("=============",row.casNo, "==", row.requiredYn, "==" , row.agreeYn);
            if (row.requiredYn === "Y" && !row.agreeYn) {
                chkCnt++; // 조건에 맞는 경우 카운트 증가
            }
        });
      //  console.log("====cnt===>", chkCnt);
        // chkCnt == 0 일경우 시작하기 버튼 활성화 처리한다.
        if (chkCnt > 0 ) {
            setNextStep(false);
        } else {
            setNextStep(true);
        }
    }

    //전문상세보기 닫기
    const agreeCasStart = () => {
        goStart(casInfoList);
        setShowCasDesc(false)
    }

    const openCasDesc = (selData:ApiCasFields) => {
        console.log("=openCasDesc===================" , selData);
        viewCasDesc(selData);
        setShowCasDesc(true)
        setSelectedCas(selData); // 선택 데이터 저장
    }


 ///   *() => handleViewDetails(row.casNo, row.casDesc)*/
    return (
        <Animated.View style={[styles.container, { bottom: slideAnim }]}>
            <View style={{ flex: 1, padding: 8 }}>
                <View style={styles.allAgreeRow}>
                    <Text style={{ fontSize: 18, fontWeight: '700', color: '#F08229', flex: 1 }}>모두 동의</Text>
                    <CheckBox isChecked={ allAgree } onCheck={ (v:boolean) => casAllChk(v) } />
                    
                </View>
                <View style={{ flex: 1 }}>
                    {    casInfoList.map((row) => (
                        <View style={styles.casRow} key={row.casNo}>
                            <View style={styles.casHeader}>
                                <Text style={styles.casText}>{row.requiredYn === 'Y' ? '[필수]' : ''} {row.casNm}</Text>
                                <TouchableOpacity onPress={ () => openCasDesc(row)} style={{ flex: 1 }}>
                                    <Text style={styles.viewText}>전문 보기</Text>
                                </TouchableOpacity>
                                <CheckBox isChecked={row.agreeYn?true:false } onCheck={(v:boolean)=>casAgreeChk(row.casNo,v)} />
                            </View>
                            <View>
                                <Text style={styles.casDesc} numberOfLines={1} ellipsizeMode="tail">
                                    {row.casDesc}
                                </Text>
                            </View>
                        </View>
                    ))}
                </View>
                <View>
                    <TouchableOpacity
                        style={[styles.startButton, { backgroundColor: nextStep ? '#F08229' : '#dcdbd7' }]}
                        onPress={agreeCasStart}>
                        <Text style={styles.startButtonText}>약관동의</Text>
                    </TouchableOpacity>
                </View>
            </View>
            <Modal
                visible={showCasDesc}
                animationType="slide"
                transparent={false} // 전체 화면 모달로 설정
                onRequestClose={() => setShowCasDesc(false)} // Android 뒤로가기 버튼 처리
            >
                <CasDescPop
                    route={{ 
                        params: { 
                            data: selectedCas,
                            onClose: () => setShowCasDesc(false) // 닫기 함수 전달
                        }
                    }}
                />
            </Modal>
           
        </Animated.View>
        
    );
};

const styles = StyleSheet.create({
    container: {
        position: 'absolute',
        width: '100%',
        height: '50%', // 화면의 절반 높이
        backgroundColor: '#fff',
        borderTopLeftRadius: 10,
        borderTopRightRadius: 10,
        overflow: 'hidden',
    },
    allAgreeRow: {
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomColor: '#ccc',
        borderBottomWidth: 1,
        height: 40,
    },
    casRow: {
        height: 80,
        marginTop: 10,
    },
    casHeader: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    casText: {
        fontSize: 16,
        fontWeight: '700',
    },
    viewText: {
        fontSize: 14,
        marginLeft: 16,
    },
    casDesc: {
        fontSize: 13,
        color: '#886',
        marginTop: 10,
        marginLeft: 8,
    },
    startButton: {
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
        borderRadius: 10,
    },
    startButtonText: {
        fontSize: 18,
        fontWeight: '800',
        color: '#fff',
    },
});

export default CasInfoPop;
