import React, { useState, useEffect } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Image,
	FlatList,
	Alert, Modal,
	StatusBar,
	ToastAndroid,
	Platform
} from 'react-native';

import { ListMyQr } from '../types/common';
import { GlobalData,  useGlobalStore} from '../store/global';
import RNFS from 'react-native-fs';
import RNFetchBlob from 'react-native-blob-util';
import Share from 'react-native-share';
import QrAddViewPop from './QrAddViewPop';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import UpdateQrInfoPop from './UpdateQrInfoPop';
import Clipboard from '@react-native-clipboard/clipboard';

const MyQrListPop: React.FC = () => { 

	const global = useGlobalStore();
	const [isCarRemoveOn, setIsCarRemoveOn] = useState(true);
	const [isProtectOn, setIsProtectOn] = useState(true);    
	const maxTextLength = 4 ;  
	const [selectedQrNo, setSelectedQrNo] = useState('');  // 선택한 QR이미지 정보
	const [carQrList, setCarQrList] = useState<ListMyQr[]>([]);  // 
	const [protectQrList, setProtectQrList] = useState<ListMyQr[]>([]); 

	const handleToggleCarRemove = () => setIsCarRemoveOn(!isCarRemoveOn);
	const handleToggleProtect = () => setIsProtectOn(!isProtectOn);

	const [isPopQrView, setIsPopQrView] = useState<boolean>(false);  // QR등록전 서비스 선택정보 화면 뛰이기
 	// QR 서비스 선택정보 전달 (차빼줘, 지켜줘)



	// 터치 이벤트 핸들러
	const handleCopy = () => {
	if (!selectedItem?.qrNo) return;
	
		//Clipboard.setString(selectedItem.qrNo.toString());
	
		if (Platform.OS === 'android') {
			ToastAndroid.show('클립보드에 복사되었습니다.', ToastAndroid.SHORT);
		} else {
			Alert.alert('알림', '클립보드에 복사되었습니다.');
		}
	};

	useEffect(() => {
		serviceQrList('Protect');
		serviceQrList('Car');
		global.setCurrentScanQrCode('');  
	}, []);

	useEffect(() => {
		console.log("===MyQrList Pop protect qr add");
	}, [protectQrList]);

	useEffect(() => {
		console.log("===MyQrList Pop Car qr add");
	}, [carQrList]);

	useEffect(() => {
		serviceQrList('Protect');
		serviceQrList('Car');
	}, [global.listMyQr]);

	
  // 모달 관련 상태 추가
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ListMyQr | null>(null);


  // 모달 열기 핸들러
  const handleOpenModal = (item: ListMyQr) => {
	
	//global.setPopupPageId('QRViewPopup')
	console.log('ssssssssss')
    setSelectedItem(item);
    setModalVisible(true);
  };


	const handleEditPress = (item) => {
		console.log("@@ handleEditPress item=>", item);
		global.setCurrentQrItem(item);
		
	};

  // 모달 닫기 핸들러
	const handleCloseModal = () => {
		setModalVisible(false);
		setSelectedItem(null);
	};


  // QR 삭제 핸들러
  const handleDeleteItem = () => {
    if (!selectedItem) return;
    
    Alert.alert(
      'QR 삭제',
      `'${selectedItem.nickNm}' QR을 삭제하시겠습니까?`,
      [
        { text: '취소', style: 'cancel' },
        { 
          text: '삭제', 
          onPress: () => {
            // 전역 상태에서 해당 항목 제거

			//
            handleCloseModal();
          }
        }
      ]
    );
  };

	const serviceQrList = (serviceTypeCd: string) => {
		const filteredList = global.listMyQr.filter(item => item.serviceTypeCd === serviceTypeCd);
		if (serviceTypeCd === 'Protect') {
			setProtectQrList(filteredList);
		} else {
			console.log("car change");
			setCarQrList(filteredList);
		}
	}

	const handleClose = () => {
			global.setPopupPageId('')  
			// closeMyQrList() ;
	}
	const goToDownload = (qrNo:string , qrInfo:string ) => {
		Alert.alert(
			'QR 이미지',
			'다운로드를 하시겠습니까?',
			[
				{
					text: '취소',
					style: 'cancel',
				},
				{ text: '다운로드', onPress: () => downloadImage(qrNo, qrInfo) }, // OK 버튼 클릭 시 downloadImage 호출
			],
			{ cancelable: false }
		);
	};

	const downloadImage = async (qrNo:string, qrInfo:string) => {
			
			// 다운로드할 파일의 경로
			if (GlobalData.deviTpCd === 'SA') {
				androidDownloadImage(qrNo, qrInfo);
			} else {
				iosDownloadImage(qrNo, qrInfo) ;
			}
	};

	const androidDownloadImage = async (qrNo:string, qrInfo:string) => {
			const { config, fs } = RNFetchBlob;
			let PictureDir = fs.dirs.DownloadDir; 
			let filePath = PictureDir + '/' + qrNo + '.png';
			
			return config({
				fileCache: true,
				addAndroidDownloads: {
					useDownloadManager: true, // Uses the Android native download manager
					notification: true,
					path: filePath,
					description: 'Image',
				},
			})
				.fetch('GET', qrInfo)
				.then(res => {
					console.log('The file saved to ', res.path());
				})
				.catch((error) => {
					console.error('Download error', error);
				});
			
	};


	// ios qr다운로드
	const iosDownloadImage = async (qrNo:string, qrInfo:string) => {
			const fileName = qrInfo.split('/').pop(); // 파일 이름 추출
			const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}`; // 다운로드 경로
	
			try {
					// 이미지 다운로드
					const res = await RNFS.downloadFile({
							fromUrl: qrInfo,
							toFile: filePath,
							background: true,
					}).promise;
	
					if (res.statusCode === 200) {
							// 공유
							await Share.open({
									url: `file://${filePath}`, // 'file://' 접두사를 추가하여 파일을 Sharing
									type: 'image/jpeg', // 이미지 파일 타입
							});
	
							Alert.alert('성공', '이미지가 공유되었습니다.');
					} else {
							Alert.alert('다운로드 실패', `상태 코드: ${res.statusCode}`);
					}
			} catch (error) {
					console.error('파일 다운로드 중 오류 발생:', error);
					Alert.alert('다운로드 오류', '파일을 다운로드하는 동안 오류가 발생했습니다.');
			}
	};


	const goToQrScanPop = () => {
		setIsPopQrView(true);
	}

	const onQrAddViewClose = (selServiceTypeCd: string) => {
		console.log('@@ selServiceTypeCd', selServiceTypeCd,  global.currentScanQrCode);
		if (selServiceTypeCd === '' || selServiceTypeCd === 'close') {
			setIsPopQrView(false);
		} else {
			setIsPopQrView(false);
			global.setCurrentScanInfo({serviceTypeCd: selServiceTypeCd, qrNo: '', viewType: 'MyQrListPop', myQrNo: ''});
			global.setPopupPageId('ScanPopup');
		}
	}
	const insets = useSafeAreaInsets();

	return ( 
		<SafeAreaView style={[{position: 'absolute',top: 0,left: 0, right: 0,  backgroundColor: '#fff'}, Platform.OS==='android' ? {bottom: 45,}:{bottom:0}]}>
			<View style={styles.mainContent}>
				{/* 상단바 */}
				<View style={styles.headerContainer}>         
					<View style={styles.titleContainer}>
						<Text style={styles.titleText}>내 QR 정보</Text>
					</View>
					<TouchableOpacity onPress={handleClose}>
						<Image 
								source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
								style={styles.closeimage} 
						/> 
					</TouchableOpacity>
				</View>

				{/* 차빼줘 영역 */}
				<View style={[styles.sectionContainer, {marginTop: 20, borderBottomColor:'#edeeee', borderBottomWidth:1, }]}>
					<View style={styles.sectionHeader}>
						<Text style={styles.sectionTitle}>차빼줘</Text>
						<TouchableOpacity onPress={handleToggleCarRemove}>
							<Image
								source={isCarRemoveOn
									? require('../assets/ic_arrow_top.png')  // "ON" 상태 이미지
									: require('../assets/ic_arrow_bottom.png') // "OFF" 상태 이미지
								}
								style={styles.switchImage}
							/>
						</TouchableOpacity>
					</View>
						{ isCarRemoveOn &&
						<View style={styles.qrList_box}>
							{carQrList.length === 0 ? (
								<View style={styles.emptyContainer}>
								<Text style={styles.emptyText}>등록된 QR이 없습니다.</Text>
								</View>
							) : (<FlatList
								showsVerticalScrollIndicator={false}
								removeClippedSubviews={false}
								data={carQrList}  // 더미 데이터 사용
								extraData={selectedQrNo}  // 상태 변화에 따른 재렌더링
								renderItem={({ item }) => (
									<View style={[styles.flat_qr_nonSelbg, selectedQrNo === item.qrNo && styles.flat_qr_selbg]}>
										<TouchableOpacity style={styles.qr_contener}
										onPress={() => handleOpenModal(item)}>
												<View>
												<Image
														source={{ uri: item.qrInfo }}
														style={[styles.qrNonSelImg, selectedQrNo === item.qrNo && styles.qrSelImg]}   
												/>
												</View>
										</TouchableOpacity>
										<View style={styles.container_row}>
												<Text style={{ marginTop: 5, marginBottom: 5, fontSize: 15, textAlign:'center' }} numberOfLines={1}>
												{item.nickNm.length > maxTextLength ? item.nickNm.substring(0, maxTextLength) + '...' : item.nickNm}
												</Text>
										</View>
									</View>
								)}
								keyExtractor={item => item.qrNo.toString()}
								horizontal={true} // 가로 방향으로 나열
								contentContainerStyle={styles.flat_container} // 아이템의 간격을 포함할 수 있는 스타일
							/>	
						)}			
						</View>
					}
				</View>

				{/* 지켜줘 영역 */}
				<View style={styles.sectionContainer}>
					<View style={styles.sectionHeader}>
						<Text style={styles.sectionTitle}>지켜줘</Text>
						<TouchableOpacity onPress={handleToggleProtect}>
							<Image
								source={isProtectOn
									? require('../assets/ic_arrow_top.png')  // "ON" 상태 이미지
									: require('../assets/ic_arrow_bottom.png') // "OFF" 상태 이미지
								}
								style={styles.switchImage}
							/>
						</TouchableOpacity>
					</View>
					{isProtectOn && (
						<View style={styles.qrList_box}>
							{protectQrList.length === 0 ? (
								<View style={styles.emptyContainer}>
								<Text style={styles.emptyText}>등록된 QR이 없습니다.</Text>
								</View>
							) : (
								<FlatList
								showsVerticalScrollIndicator={false}
								removeClippedSubviews={false}
								data={protectQrList}  // 더미 데이터 사용
								extraData={selectedQrNo}  // 상태 변화에 따른 재렌더링
								renderItem={({ item }) => (
										<View style={[styles.flat_qr_nonSelbg, selectedQrNo === item.qrNo && styles.flat_qr_selbg]}>
										<TouchableOpacity style={styles.qr_contener} 
											onPress={() => handleOpenModal(item)}
										>
												<View>
												<Image
														source={{ uri: item.qrInfo }}
														style={[styles.qrNonSelImg, selectedQrNo === item.qrNo && styles.qrSelImg]}   
												/>
												</View>
										</TouchableOpacity>
										<TouchableOpacity 
											style={styles.container_row}
											onPress={() => handleEditPress(item)}
										>
											<Text style={{ marginTop: 5, marginBottom: 5, fontSize: 15, textAlign:'center' }} numberOfLines={1}>
											{item.nickNm.length > maxTextLength ? item.nickNm.substring(0, maxTextLength) + '...' : item.nickNm}
											</Text>
										</TouchableOpacity>
										</View>
								)}
								keyExtractor={item => item.qrNo.toString()}
								horizontal={true} // 가로 방향으로 나열
								contentContainerStyle={styles.flat_container} // 아이템의 간격을 포함할 수 있는 스타일
								/>
								)}
						</View>
					)}
				</View>
			</View>

			{/* QR 등록 버튼 */}
			<View style={styles.qrButtonContainer}>
				<TouchableOpacity style={styles.qrButton} onPress={() => goToQrScanPop()}>
					<Text style={styles.qrButtonText}>QR등록</Text>
				</TouchableOpacity>
			</View>

			{ isPopQrView && ( <QrAddViewPop popVisible={isPopQrView} onQrAddViewClose={onQrAddViewClose}  />) }

			<Modal
				animationType="fade"
				transparent={true}
				visible={modalVisible}
				onRequestClose={handleCloseModal}
			>
				<View style={modalStyles.centeredView}>
					<View style={modalStyles.modalView}>
						<TouchableOpacity onPress={handleCloseModal} style={{paddingHorizontal:8, paddingVertical:0 ,position:'absolute', right:20, top:15}}>
							<Text style={{fontSize:22, textAlign:'center'}}>X</Text>
						</TouchableOpacity>
						{/* 닉네임 표시 */}
						<Text style={modalStyles.nicknameText}>
						{selectedItem?.nickNm}
						</Text>
						{/* QR 번호 */}
						{selectedItem && (
							<TouchableOpacity onPress={handleCopy}>
								<Text>{selectedItem?.qrNo}</Text>
							</TouchableOpacity>
						)}
						

						{/* QR 바코드 이미지 */}
						{selectedItem && (
						<Image
							source={{ uri: selectedItem.qrInfo }}
							style={modalStyles.qrImage}
							resizeMode="contain"
						/>
						)}
						{/* QR 다운로드드 이미지 */}
						{selectedItem && (
						<TouchableOpacity style={styles.qr_contener} onPress={() => goToDownload(selectedItem.qrNo, selectedItem.qrInfo)}>
							<View>
								<Image
									source={require('../assets/ic_download.png')}
									style={modalStyles.down_image}
								/>
							</View>
						</TouchableOpacity>
						)}
						
						<View style={{flexDirection:'row', }}>
							{/* 삭제 버튼 */}
							<TouchableOpacity 
							style={modalStyles.deleteButton}
							onPress={handleDeleteItem}
							>
							<Text style={modalStyles.deleteButtonText}>삭제</Text>
							</TouchableOpacity>
							
							{/* 닫기 버튼 */}
							<TouchableOpacity 
							style={modalStyles.closeButton}
							onPress={handleCloseModal}
							>
							<Text style={modalStyles.closeButtonText}>닫기</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>
			</Modal>	
			
			</SafeAreaView>
			
			 
	);
};

const styles = StyleSheet.create({
	bottomContainer: {
		flex: 1,
		width: '100%',
		height: '100%',
		backgroundColor: '#fff',
	},
	mainContent: {
		flex: 1,
		paddingBottom: 80, // QR 버튼을 위해 여백 추가
	},
	headerContainer: {
		height: 60,
		backgroundColor: '#fff',
		flexDirection: 'row',
		alignItems: 'center',
		paddingHorizontal: 10,
	},
	prevButton: {
		width: 40,
		alignItems: 'center',
		justifyContent: 'center',
	},
	homeButton: {
		width: 40,
		alignItems: 'center',
		justifyContent: 'center',
	},
	prevIcon: {
		width: 17,
		height: 17,
		resizeMode: 'contain',
	},
	homeIcon: {
		width: 30,
		height: 30,
		resizeMode: 'contain',
	},
	titleContainer: {
		flex: 1,
		alignItems: 'center',
	},
	titleText: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#333',
	},
	sectionContainer: {
		paddingHorizontal: 16,
		backgroundColor: '#fff',
		borderRadius: 8,
		shadowColor: '#000',
		shadowOffset: { width: 0, height: 2 },
		shadowOpacity: 0.1,
		shadowRadius: 4,
	},
	sectionHeader: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		paddingVertical: 16,
	},
	sectionTitle: {
		fontSize: 18,
		fontWeight: 'bold',
		color: '#FF851D',
	},
	flatListContainer: {
	},
	ListContainer:{
		paddingVertical: 10,
		marginVertical:10,
		backgroundColor: '#f4f4f4',
		borderRadius: 8,},
	itemContainer: {
		marginRight: 16,
		padding: 12,
		marginHorizontal:5,
	},
	itemText: {
		fontSize: 14,
		color: '#333',
	},
	qrButtonContainer: {
		position: 'absolute',
		bottom: 0,
		width: '100%',
		paddingHorizontal: 16,
		paddingBottom: 20,  
	},
	qrButton: {
		backgroundColor: '#FF851D',
		borderRadius: 8,
		paddingVertical: 14,
		justifyContent: 'center',
		alignItems: 'center',
	},
	qrButtonText: {
		fontSize: 16,
		fontWeight: 'bold',
		color: '#fff',
	},
	switchImage: {
		width: 40,
		height: 24,
		resizeMode: 'contain',
	},
	qrList_box: {
		width: '94%',
		alignItems: 'center',
		padding: 10,
		flexDirection: 'row',
		backgroundColor: '#f4f4f4',
		borderRadius:8,
		marginBottom:10,
	},
	flat_qr_nonSelbg: {
		paddingLeft: 10, // 양쪽에 20의 패딩을 추가
		paddingRight: 10, // 양쪽에 20의 패딩을 추가
		borderColor: 'white',
	},
	flat_qr_selbg: {
		paddingLeft: 10, // 양쪽에 20의 패딩을 추가
		paddingRight: 10, // 양쪽에 20의 패딩을 추가
		borderColor: '#FF851D',
	},
	qr_contener: {
		justifyContent: 'center', alignItems: 'center'
	},
	qrNonSelImg: {
		width: 65, 
		height: 65, 
		borderRadius: 5, 
		marginTop: 10,
		borderColor: 'white',
	},
	qrSelImg: {
		width: 65, 
		height: 65, 
		borderRadius: 20, 
		marginTop: 10,
		borderColor: '#FF851D',
	},
	container_row: {
		flexDirection: 'row', // 가로 방향으로 배치
		justifyContent: 'center', // 각 텍스트 사이에 여백을 추가
		
	},
	
	
	flat_container: {
		paddingHorizontal: 10, // 양쪽에 20의 패딩을 추가
	},
	flat_view: {
		paddingLeft: 10, // 양쪽에 20의 패딩을 추가
		paddingRight: 10, // 양쪽에 20의 패딩을 추가
	},
	closeimage: {
		width: 25, // 이미지 너비
		height: 25, // 이미지 높이
		marginRight: 10, // 텍스트와의 간격
		marginTop: 25,
	},
	emptyContainer: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		paddingVertical: 20
	},
	emptyText: {
		color: '#888',
		fontSize: 14
	}
});
const modalStyles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalView: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingTop: 25,
	
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  down_image: {
		width: 40,
		height: 40,
		marginTop: 0, 
		marginBottom: 30, 
	},
  nicknameText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  qrImage: {
    width: 200,
    height: 200,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#eee',
  },
  deleteButton: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
	flex:1,
	borderBottomLeftRadius:12,
	borderWidth:1,
	borderColor:'#ededed'
  },
  deleteButtonText: {
    color: 'red',
    fontWeight: 'bold',
    fontSize: 16,
  },
  closeButton: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
	flex:1,
	borderBottomRightRadius:12,
	borderWidth:1,
	borderColor:'#ededed'
  
  },
  closeButtonText: {
    color: 'gray',
    fontWeight: 'bold',
	fontSize: 16,
  },
});
export default MyQrListPop;