import React, { useState, useEffect, useContext } from 'react';
import { View, Text, Alert, StyleSheet, Image, TouchableOpacity, Modal } from 'react-native';
import { useGlobalStore, GlobalData, GetDate, callPost, callGet, GetDateTime , GetDateDay} from '../store/global';
import { SocketStompContext } from '../utils/WebSocketManager';
import { MessageData, SaveResponse, CallSeqResponse, MessageRoomInfoRequest, ListRoomMessage, MessageRoomInfoResponse} from '../types/common'
import ApiInfo from '../gvar/ApiInfo';




const ReceiveCallPop: React.FC = () => {
	const { sendMessage } = useContext(SocketStompContext);
	const global = useGlobalStore();

	useEffect(() => {
		const cur = global.currentReceivedData;
		if( cur && cur.targetRoomId ) {
			console.log("@@ ReceiveCallPop useEffect cur => target:", cur.roomId, global.popupPageId );
		} else {
			console.log("@@ ReceiveCallPop useEffect currentReceivedData is null");
			// closePop();
		}
		global.setIncallKey('');
	}, []);

	useEffect(() => {
		console.log("@@ useEffect global.incallKey : ", global.incallKey);
		if ( global.incallKey ==='O') {
			closePop();
		}
	}, [global.incallKey]);	


	const closePop = () => {
		if( global.currentReceivedData ) {
			global.setCurrentReceivedData(null);
		}
		global.setIncallKey('');
		global.setPopupPageId('');
	}
	const callProcess = () => {
		const cur = global.currentReceivedData;
		if ( cur ) {
			cur.mType = 'BC';
			console.log('@@ callProcess', cur);
			cur.msgDesc = '통화 수신';
			cur.writeMembNo = GlobalData.membNo;
			sendMessage(cur, cur.roomId);
			sendCallOutPring(cur);
			global.setProcessScreen('Calling');

		} else {
			console.log("@@ callProcess currentReceivedData is null");
		}
		global.setPopupPageId('');
	}
	// 거절 처리 closePopup 에서 global.currentReceivedData 초기화 해줘야함
	const callReject = () => {
		const cur = global.currentReceivedData;
		if ( cur ) {
			cur.mType = 'BJ';
			console.log('@@ callReject', cur);
			cur.msgDesc = '통화 거절';
			cur.writeMembNo = GlobalData.membNo;
			sendCallOutPring(cur);
			sendMessage(cur, cur.roomId);
		} else {
			console.log("@@ callReject currentReceivedData is null");
		}
		closePop();
	}

 

	const sendCallOutPring =async (msgData:MessageData) => {
		console.log("@@call out print data aaaaaa", msgData);
		if( msgData.serviceTypeCd !== 'Car' )  {
			const state = useGlobalStore.getState();
			//if (msgData.writeMembNo === GlobalData.membNo) return;
			let isChatRoomOpen = false;
	
			if (msgData.mType === 'BC') {
				msgData.msgDesc = '통화 수신';
			} else if (msgData.mType === 'BJ') {
				msgData.msgDesc = '통화 거절';
			} 
			msgData.currentDate = GetDate();
			console.log("@@call out print data bbbbbb", msgData);

			const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
			msgData.callSeq = data.callSeq;

			const info = await callPost(ApiInfo.saveChatMsg, msgData) as SaveResponse;
			console.log("@@call out print data ccccc", info);
			//let incrNum = true
			if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo === msgData.counterPart ) {
				//incrNum = false;
				console.log("@@call out print data 4444", msgData);
				
				global.addRoomChatMsg(msgData, true);
				isChatRoomOpen = true;
			} 
	
			// listRoomMessage에 데이타 존재하는지 여부 확인해서 업데이트
			// 내가 받은qr번호, 내가 받은 구독번호	해당룸의 멤버수
			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			console.log("@@call out print data 5555", findListMessage);
			if( findListMessage) {
				if( !findListMessage.nickNm ) {
					const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
					console.log("@@ receiveDataProcess friend", friend);
					if( friend ) {
						findListMessage.nickNm = friend.nickNm;
					}
				}
				findListMessage.msgDesc = msgData.msgDesc;
				findListMessage.notReadYn = 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				findListMessage.addDt = GetDateDay();
				findListMessage.addTime = GetDateTime();	
				findListMessage.chatSeq = msgData.callSeq;				 
				// if (isChatRoomOpen) {
				// 	findListMessage.notReadCnt = 0 ;
				// } else {
					findListMessage.notReadCnt = findListMessage.notReadCnt ; // + 1;
				//}
				console.log("@@ receiveDataProcess findListMessage", findListMessage);
				global.updateRoomChatMessage(findListMessage);
			} else {
				//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
				const msgRoomInfoRequest = () => {
					const node = {} as MessageRoomInfoRequest
					node.serviceTypeCd=msgData.serviceTypeCd
					node.roomNo=msgData.counterPart
					return node;
				}
				const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
				if(info.hasOwnProperty('errors')) return global.showToast(info.message);
				const updateListRoomMessage:ListRoomMessage = {
					roomNo: msgData.counterPart,
					profileImgFileUrl: '',
					nickNm: '',
					msgDesc: msgData.msgDesc,
					notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
					notReadCnt: 1,
					addDt: GetDateDay(),
					addTime: GetDateTime(),
					msgTypeCd: msgData.msgTypeCd,
					roomTypeCd: '',
					chatSeq: msgData.callSeq,
					msgReDesc: '',
					callStatCd: '' ,
					serviceTypeCd: msgData.serviceTypeCd,
					qrNo: msgData.roomId,  //내QR
					membNo: GlobalData.membNo,
					writeMembNo: msgData.writeMembNo,
					sendSubScr: msgData.targetRoomId,
					targetMembNo: msgData.roomId,
					mySubScr: msgData.roomId,
					roomMembCnt: 0,
				}
				if (info) {
					updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
					updateListRoomMessage.nickNm = info.roomNm;
				}
				console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
				global.addRoomMessage(updateListRoomMessage);
			}
	
		}
	}

	return (
		<Modal transparent={true} animationType="fade">
			<View style={styles.overlay}>
				<View style={styles.modalContainer}>
					<View style={styles.titleContainer}>
						<Text style={[styles.headText]}>통화 호출이 왔습니다.!</Text>    
					</View>
					<View style={{flexDirection:'row', paddingHorizontal:40,paddingVertical:20, gap: 40}}>
						<TouchableOpacity 
							style={{backgroundColor: '#77DD77', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
							onPress={callProcess}
						>
							<Text style={{fontSize:10}}>통화</Text>
						</TouchableOpacity>
						<TouchableOpacity 
							style={{backgroundColor: '#FFDAB9', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
							onPress={callReject}
						>
							<Text style={{fontSize:10}}>거절</Text> 
						</TouchableOpacity>
					</View>  
				</View>
			</View>
		</Modal>
	);
};

const styles = StyleSheet.create({
	overlay: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0,0,0,0.5)',
	},
	modalContainer: {
		backgroundColor: 'white',
		borderRadius: 10,
		overflow: 'hidden',
		justifyContent: 'center',
		alignItems: 'center',
		paddingBottom: 20,
	},
	titleContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		paddingHorizontal: 10,
	},
	leftContainer: {
	flexDirection: 'row',
	alignItems: 'center',
	},
	headText: {
	fontSize: 18, // 텍스트 크기
	marginBottom:10,
	},
	closeimage: {
		width: 25, // 이미지 너비
		height: 25, // 이미지 높이
		//marginRight: 5, // 텍스트와의 간격
		marginTop: 10,
	},


});

export default ReceiveCallPop;