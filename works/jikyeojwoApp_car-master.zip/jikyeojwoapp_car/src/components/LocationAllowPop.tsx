import React, { useContext, useEffect, useState } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Image,
	Dimensions,
	Alert,
} from 'react-native';
import { MessageData } from '../types/common'; 
import { SocketStompContext } from '../utils/WebSocketManager';
import { useGlobalStore, GlobalData, MembInfo, GetDate } from '../store/global';


const { width, height } = Dimensions.get('window');

const LocationAllowPop: React.FC = () => {
	const [item, setItem] = useState<MessageData|null>(null);
	const { sendMessage } = useContext(SocketStompContext);
	const global = useGlobalStore();
	const [titleText, setTitleText] = useState('');
	const [cancelBtnText, setCancelBtnText] = useState('');
	const [procBtnText, setProcBtnText] = useState('');
	const [alertText, setAlertText] = useState('');
	

	useEffect(() => {
		console.log("@@ LocationAllowPop", global.currentLocationRequest);
		if (global.currentLocationRequest) {
			
			if (global.currentLocationRequest.mType === 'RL') {
				setTitleText('위치 허용 요청');
				setAlertText(global.currentLocationRequest.writeNickNm + ' 님이 위치 허용 요청을 하였습니다') ;
				setProcBtnText('승인');
				setCancelBtnText('거절');
			} else if (global.currentLocationRequest.mType === 'CL') {
				setTitleText('위치 허용 취소');
				setAlertText(global.currentLocationRequest.writeNickNm + ' 님에게 위치허용 취소하시겠습니까') ;
				setProcBtnText('허용취소');
				setCancelBtnText('취소');
			}
		}

		setItem(global.currentLocationRequest);
		console.log("@@ locat req org data", global.currentLocationRequest);
		console.log("@@ locat req data", item);

	}, []);


	const sendMsgSetting = (procType: string) => {   // procType 승인 AL, 거절 JL

		if (!item) return;
		const state = useGlobalStore.getState();
		const qrInfo = state.listMyQr?.find(qritem => qritem.qrNo === item.qrNo);

		const msgData = {
					mType: procType , //'AL', JL, CL
					mykey: GlobalData.myKey,
					msgDesc: item?.writeNickNm,              
					qrNo:   item?.writeMembNo,// procType === 'CL' ? item.qrNo : item?.writeMembNo,
					langCd: GlobalData.langCd,
					currentDate: GetDate(),
					callSeq: '',
					roomId:  item?.targetRoomId,
					targetRoomId:  item?.roomId,
					membNo: item.counterPart, //procType === 'CL' ? item.membNo :item.counterPart,
					writeMembNo: item?.qrNo, //procType === 'CL' ? item.writeMembNo :
					counterPart: item?.membNo, //procType === 'CL' ? item.counterPart : 
					onOff: 'Y',
					serviceTypeCd: 'Protect',
					fileImgUrl: '',
					filePath: '',
					callCount: 0,
					writeNickNm: qrInfo?.nickNm ? qrInfo?.nickNm : global.membInfo.nickNm  ,
					writeImgFileUrl:qrInfo?.imgFileUrl ? qrInfo?.imgFileUrl : global.membInfo.imgFileUrl ,
				} as MessageData;	
		sendMessage(msgData, procType === 'CL' ? msgData?.roomId : msgData.roomId);
	}

	if( item==null ) return null;

	const pressReject = () => {
		if( item ) {
			if (item.mType !== 'CL') {
				item.mType = 'JL';
				//sendMessage(item, item.roomId);
				sendMsgSetting('JL');
				global.setReqLocationStatus('M', item.counterPart, item.writeMembNo, item.membNo, item.qrNo,  '90', '거절');
			}
		}
		global.setCurrentLocationRequest(null);
		global.setPopupPageId('');
		
	}

	const pressAccept = () => {
		if( item ) {
			if (item.mType === 'CL') {
				item.mType = 'CL';
				sendMsgSetting('CL');
				global.setReqLocationStatus('M',  item.counterPart, item.writeMembNo, item.membNo, item.qrNo,  '10', '미허용');
			} else {
				item.mType = 'AL';
				sendMsgSetting('AL');
				global.setReqLocationStatus('M', item.counterPart, item.writeMembNo, item.membNo, item.qrNo,  '50', '허용');
			}
		}
		global.setCurrentLocationRequest(null);
		global.setPopupPageId('');
	}
	const onClose = () => {
		global.setCurrentLocationRequest(null);
		global.setPopupPageId('');
	}

	return (
	<View style={{
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		height: '100%',
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
		
	}}>
		<View style={{
			width: width * 0.9,
			height: 250,
			backgroundColor: '#fff',
			borderRadius: 15,
			paddingTop: 10
		}}>  
			<View style={styles.header}>
				<Text style={styles.title}>{titleText}</Text>
				<TouchableOpacity style={styles.closeButton} onPress={onClose}>
					<Text style={styles.closeText}>X</Text>
				</TouchableOpacity>
			</View>
			<View style={{alignContent:'center', alignItems:'center', flex:1}}>
				{ item.writeImgFileUrl && <Image source={{ uri: item.writeImgFileUrl }} style={[styles.avatar, {borderColor:'#FF851D', borderWidth:1}]} />}
				<View style={{flex:1, justifyContent:'center', alignItems:'center', }}>
					<View style={styles.messageArea}>
						<Text style={styles.messageText}>
						{alertText}
						</Text>
					</View>
					<View style={styles.buttonRow}>
						<TouchableOpacity style={styles.rejectButton} onPress={() => pressReject()}>
							<Text style={styles.buttonText}>{cancelBtnText}</Text>
						</TouchableOpacity>
						<TouchableOpacity style={styles.acceptButton} onPress={() => pressAccept()}>
							<Text style={styles.buttonText}>{procBtnText}</Text>
						</TouchableOpacity>
					</View>
				</View>
			</View>
		</View>
	</View>
	);
};

export default LocationAllowPop;

const styles = StyleSheet.create({
overlay: {
	flex: 1,
	justifyContent: 'center',
	backgroundColor: 'rgba(0,0,0,0.5)',
},
modalContainer: {
	//height: height * 0.5,
	width: width * 0.8,
	alignSelf: 'center',
	backgroundColor: '#fff',
	borderRadius: 12,
	paddingTop: 16,
	paddingBottom: 8,
	paddingHorizontal: 16,
},
header: {
	position: 'relative',
	alignItems: 'center',
	marginBottom: 12,
},
title: {
	fontSize: 22,
	fontWeight: 'bold',
},
closeButton: {
	position: 'absolute',
	right: 15,
	
},
closeText: {
	fontSize: 22,
	color: '#999',
},
listContainer: {
	gap: 12,
	paddingBottom: 12,
},
listItem: {
	flexDirection: 'row',
	alignItems: 'center',
	alignContent:'center',
	gap: 8,
	paddingVertical: 8,
	height:80,
},
avatar: {
	width: 80,
	height: 80,
	borderRadius: 40,
	marginTop: 4,
	alignContent:'center',
	alignItems:'center'
},
messageArea: {
	flex: 1,
	alignContent:'center',
	alignItems:'center',
	justifyContent:'center',
	
},
messageText: {
	fontSize: 16,
	textAlign:'center',

},
buttonRow: {
	flexDirection: 'row',
	justifyContent:'space-around',
	
	

},
rejectButton: {
	backgroundColor: '#ccc',
	paddingVertical: 15,
	borderBottomLeftRadius: 15,
	flex:1, 
},
acceptButton: {
	backgroundColor: '#FF851D',
	paddingVertical: 15,
	borderBottomRightRadius: 15,
	flex:1
},
buttonText: {
	color: '#fff',
	fontSize: 17,
	textAlign:'center'
},
bottomButton: {
	backgroundColor: '#FF851D',
	borderRadius: 8,
	alignItems: 'center',
	justifyContent: 'center',
	paddingVertical: 10,
	marginTop: 16,
},
bottomButtonText: {
	color: '#fff',
	fontSize: 16,
},
});
