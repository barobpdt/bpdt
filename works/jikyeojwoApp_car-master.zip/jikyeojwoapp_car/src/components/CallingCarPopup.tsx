import React, { useContext, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, Dimensions, FlatList, Image, Platform, StyleSheet, Text, TextInput, ToastAndroid, TouchableOpacity, View } from "react-native";
import { GlobalData, useGlobalStore, callPost , callGet, GetDate} from "../store/global";
import { CallSeqResponse, ItemOption, QrPageType, RoomChatInitResponse, RoomChatMsgInfo, RoomChatMsgListRequest } from "../types/common";
import Clipboard from '@react-native-clipboard/clipboard';
import ApiInfo from "../gvar/ApiInfo";
import { SocketStompContext } from "../utils/WebSocketManager";
import CallingPopup from "./CallingPopup";

const CallingCarPopup = () => {
	const global =useGlobalStore()
	const flatListRef = useRef<FlatList>(null);
	const [title, setTitle] = React.useState('')
	const [isLoading, setIsLoading] = React.useState(false);
	const [msgReqList, setMsgReqList] = React.useState([
		{code:'1',value:'차를 이동해주세요', selected:false}, 
		{code:'2',value:'여기 주차하시면 안됩니다.', selected:false}, 
		{code:'3',value:'급합니다. 빨리 차를 이동해주세요', selected:false}, 
		{code:'4',value:'차에 문제있어보입니다.', selected:false}
	] as ItemOption[])
	const [msgAnsList, setMsgAnsList] = React.useState([
		{code:'1',value:'바로 이동 조치 하겠습니다.', selected:false}, 
		{code:'2',value:'문자로 보내주세요!', selected:false}, 
		{code:'3',value:'죄송합니다. 잠시만 기다려주세요!', selected:false}, 
		{code:'4',value:'금방 가겠습니다.', selected:false}
] as ItemOption[])
const [msgList, setMsgList] = React.useState([] as ItemOption[])
	const width = Dimensions.get('window').width
	const height = Dimensions.get('window').height
	const [qrCarCallInfo, setQrCarCallInfo] = useState<QrPageType>({ searchChatSeq: '', totalSize: 1 , lastChatSeq: '', preSearchChatSeq: ''});
	const [msgText, setMsgText] = React.useState('')
	const { sendMessage } = useContext(SocketStompContext);
	const [callBtnUse, setCallBtnUse] = React.useState(false);
	const [scrollTime, setScrollTime] = React.useState(0)

	useEffect(()=>{
		qrCarCallInfo.searchChatSeq = '' ;
		qrCarCallInfo.lastChatSeq = '' ;
		qrCarCallInfo.preSearchChatSeq = '' ;
		qrCarCallInfo.totalSize = GlobalData.gridSize; 
		const cur = global.currentCarMessageData;
		if( cur == null ) return;
		if( cur.mType == 'Call' ) {
			setTitle('차빼줘 메시지 호출')
			setMsgList(msgReqList);
			global.setCarRoomType('send');
			setCallBtnUse(true);
		} else {
			setTitle('호출이 왔습니다.')
			setMsgList(msgAnsList);
			global.setCarRoomType('receive');
			setCallBtnUse(false);
		} 
		for(const item of msgList) {
			item.selected = false
		}
		getCarChatMsgList();
	}, [])

	const handleOnSelect = async (methodType: string) => {
		const state = useGlobalStore.getState();
		const msgData = state.currentCarMessageData;
		if( msgData==null ) {
			if (Platform.OS === 'android') {
				ToastAndroid.show('데이터가 준비되지 않았습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert("오류", "데이터가 준비되지 않았습니다.");
			}
			return;
		}		 
		if (!msgData.roomId ) {
			if (Platform.OS === 'android') {
				ToastAndroid.show('데이터가 준비되지 않았습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert("오류", "데이터가 준비되지 않았습니다.");
			}
			return;
		}
		console.log("@@ callingCarPopup handleOnSelect:", msgData);
		if(methodType=='B') {	
			// 전화	
			msgData.mType = 'RC';
			console.log("=calling Rc============================>", msgData);
			sendMessage(msgData, msgData.roomId);
			global.setCurrentMessageData(msgData);
			global.setProcessScreen('Calling');
			global.setPopupPageId('');
		} else if(methodType=='C' ) {	
			msgData.mType = 'M';
			getCarChatMsgList();
			setCallBtnUse(false);
		}		
	};
		//대화 변경 이벤트
	useEffect(() => {
		console.log("@@ listCarRoomChat useEffiect",  global.listCarRoomChat.length );
		if ( global.listCarRoomChat.length > 0 ) {
			if( scrollTime > 0 ) {
				const dist = new Date().getTime() - scrollTime;
				if( dist < 100 ) return;
				console.log("@@ scrollTime", dist);
			}
			setTimeout(()=>{
				if( flatListRef.current ) {
					flatListRef.current.scrollToEnd({ animated: true });
					setScrollTime(new Date().getTime());
				}
			}, 500);			
		}
	}, [global.listCarRoomChat]);

	const setOption = (cur:ItemOption) => {        
		for(const item of msgList) {
			item.selected = item.code==cur.code
		}
		setMsgText(cur.value)
		global.setUpdateRoomMessageTick();
	} 

	const sendChatMessage = async () => {
		global.setUpdateRoomMessageTick();
		if( !msgText ) {
			if (Platform.OS === 'android') {
				ToastAndroid.show('전송할 메시지가 없습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert('전송할 메시지가 없습니다.')
			}
			return
		}
		const msgData = global.currentCarMessageData 
		if( msgData ) {
			setCallBtnUse(false)
			const info = await callGet(ApiInfo.getCallSeq, { langCd: GlobalData.langCd }) as CallSeqResponse;
			msgData.mType = 'M';
			msgData.callSeq = info.callSeq;
			msgData.msgDesc = msgText;
			msgData.currentDate = GetDate();
			msgData.writeMembNo = GlobalData.membNo;
			// //차주 , 호출자 구분한다.
			if (msgData.membNo === GlobalData.membNo) {
				//차주
				sendMessage(msgData, msgData.targetRoomId);
				//msgData.roomId = 
			} else {
				//호출자
				sendMessage(msgData, msgData.roomId);
			}
			
			global.addCarRoomChat(msgData, true);
		}
	} 

	const getCarChatMsgList = async() => { 
		const msgData = global.currentCarMessageData 
		if( msgData == null) return;
		console.log("cal call msgData", msgData);
		const param =  {
			serviceTypeCd:'Car',
			roomNo:msgData?.roomId || '',
			gridSize:GlobalData.gridSize,
			searchChatSeq:'',
			pagingYn:'Y',        
			langCd:GlobalData.langCd
		} as RoomChatMsgListRequest
		//const info = await callPost(ApiInfo.chatIntiList, param) as RoomChatInitResponse;
		const info = await callPost(ApiInfo.chatMsgList, param) as RoomChatInitResponse;
		if('errors' in info) return global.showToast('차빼줘 메시지오류:'+info.message);
		global.updateCarRoomChat(info.chatMsgList);
		qrCarCallInfo.searchChatSeq = info.lastChatSeq ;
		if( flatListRef.current ) {
			flatListRef.current.scrollToEnd({ animated: true });
			setScrollTime(new Date().getTime());
		}
	}
	// 스크롤 이벤트 핸들러
	const handleScroll = (event) => {
		const offsetY = event.nativeEvent.contentOffset.y;    
		if (offsetY <= 0) {
			// 맨 위 도달시 로드
			if ( qrCarCallInfo.preSearchChatSeq != '' && qrCarCallInfo.searchChatSeq == qrCarCallInfo.preSearchChatSeq) {
				console.log("top scroll call return");
				return ;
			} else {
				console.log("top scroll call process");
				qrCarCallInfo.preSearchChatSeq = qrCarCallInfo.searchChatSeq;  // 마지막 순번 같은거 부르면 호출에서 제외 하기위해 넣음
				getCarChatMsgList();
			}
		}
		setScrollTime(new Date().getTime())
	};

	const renderItem = ({ item }: { item: RoomChatMsgInfo }) => {	
		if (item.myTextYn === 'Y') {
			return (
				<View style={styles.myMessageContainer}>
					<View style={styles.myMessageBox}>
						<Text>{item.msgDesc}</Text>
					</View>
					<View style={styles.myMsgOption}>
					{item.msgTypeCd === 'T' && (
						<TouchableOpacity
							onPress={()=>{Clipboard.setString(item.msgDesc ?? '')
								if (Platform.OS === 'android') {
									ToastAndroid.show('클립보드에 복사되었습니다.', ToastAndroid.SHORT);
								} else {
									Alert.alert('알림', '클립보드에 복사되었습니다.');
								}
							}}>
							<Image style={styles.msgBtn} source={require('../assets/ico_edit_d9d9d9.png')}/>
						</TouchableOpacity>            )}
						{item.msgTypeCd !== 'D' && (
						<TouchableOpacity
							onPress={()=>handleDelete(item.chatSeq)}
							>
							<Image style={styles.msgBtn} source={require('../assets/ic_del.png')}/>
						</TouchableOpacity> )}
						<Text style={styles.timeText}>{item.addDt} {item.addTime}</Text>    
					</View>
				</View>
			); 
		} else {
			return (
				<View style={styles.otherMessageContainer}>
					{ item.profileImgFileUrl  && <Image source={{ uri: item.profileImgFileUrl }} style={styles.profileImg} /> }
					<View style={{ flex: 1 }}>
						{ item.nickNm && <Text style={styles.nickname}>{item.nickNm}</Text> }
						<View style={styles.otherMessageContent}>
							<View style={styles.otherMessageBox}>
								<Text>{item.msgDesc}</Text>
							</View>
							<View style={{ marginLeft: 6 }}>
								<TouchableOpacity
									onPress={()=>{Clipboard.setString(item.msgDesc ?? '')
										if (Platform.OS === 'android') {
											ToastAndroid.show('클립보드에 복사되었습니다.', ToastAndroid.SHORT);
										} else {
											Alert.alert('알림', '클립보드에 복사되었습니다.');
										}
									}}>
									<Image style={styles.msgBtn} source={require('../assets/ico_edit_d9d9d9.png')}/>
								</TouchableOpacity>
								<Text style={styles.timeText}>{item.addDt} {item.addTime}</Text>
							</View>
						</View>
					</View>
				</View>
			);
		}
	};

	const handleDelete = (msgId) => {
		Alert.alert(
			'삭제 확인',
			'정말 삭제하시겠습니까?',
			[
				{
					text: '취소',
					style: 'cancel',
				}, {
					text: '확인',
					style: 'destructive',
					onPress: () => removeDelMsg(msgId)
				}
			],
			{ cancelable: true }
		);
	};

	//메세지 삭제처리
	const removeDelMsg = (chatSeq) => {
		const cur = global.currentCarMessageData 
		if( cur ) {
			cur.mType = 'DM';
			global.removeCarRoomChat(chatSeq);            
			sendMessage(cur, cur.roomId);
		}
	}

	const closePopup = () => {
		global.initCarRoomChat();
		global.setCarRoomType('');
		global.setPopupPageId('');
		global.setCurrentMessageData(null);
		global.setCurrentCarMessageData(null);
	}

	return (
		<View style={{
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			height: '100%',
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: 'rgba(0, 0, 0, 0.5)',
		}}>
			<View style={{
				width: width * 0.9,
				height: height*0.7,
				backgroundColor: '#fff',
				borderRadius: 15,
			}}> 
				<View style={{paddingHorizontal: 15, paddingVertical: 10, flex:1}}>
					<Text style={[{ marginTop: 10, fontSize:20, fontWeight:700,  textAlign: 'center'}]}>
						{title}
					</Text>
					<TouchableOpacity style={styles.closeButton} onPress={() => closePopup()}>
						<Text style={styles.closeButtonText}>✕</Text>
					</TouchableOpacity>
					<View style={{
						width: '100%',
						height: 2,
						backgroundColor: 'black',
						marginTop: 5,
					}}/> 
					{ callBtnUse &&
					<View style={{ }}>
						<View style={{flexDirection:'row', padding:20, gap: 20, }}>
							<TouchableOpacity 
								style={{backgroundColor: '#77DD77', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
								onPress={()=>handleOnSelect('B')}
							>
								<Image 
									source={require('../assets/ic_phone_img_white.png') } // 임시 이미지 URL 사용
									style={{width:80, height:80,}}
								/> 
								<Text style={{fontSize:22,color:'white', fontWeight:'bold', }}>통 화</Text>
								
							</TouchableOpacity>
							<TouchableOpacity 
								style={{backgroundColor: '#FFDAB9', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
								onPress={()=>handleOnSelect('C')}
							>
								<Image 
									source={require('../assets/ic_msg_img_white.png') } // 임시 이미지 URL 사용
									style={{width:80, height:80, }} 
								/> 
								<Text style={{fontSize:22,color:'white', fontWeight:'bold', }}>문 자</Text>
							</TouchableOpacity>
						</View>
					</View>  
					}
					{ callBtnUse==false &&
					<View style={{flex:1, borderWidth:1, borderColor:'#FF851D', marginTop:10}}>
						{/*<View style={{position:'absolute', top:10, right:10}}>
							<TouchableOpacity style={{}}>
								<Image style={{width:30, height:30}} source={require('../assets/ic_phone_img.png')}/>
							</TouchableOpacity>
						</View>*/}
						<FlatList
							data={global.listCarRoomChat}
							removeClippedSubviews={false}
							ref={flatListRef}
							keyExtractor={(item, index) =>`chat-${item.chatSeq}-${index}`}
							renderItem={renderItem}
							contentContainerStyle={{ paddingBottom: 30,  }}
							showsVerticalScrollIndicator={false}
							onScroll={handleScroll}   // 아래 설정은 스크롤이 맨 위로 갔을데 데이타 가져오는 로직
							scrollEventThrottle={16} // 이벤트 호출 빈도 조절
							ListFooterComponent={isLoading ? <ActivityIndicator size="large" color="#0000ff" /> : null}
							ListEmptyComponent={<Text style={{textAlign:'center', fontSize:16, fontWeight:'bold', color:'black', marginVertical: 5}}>메시지가 없습니다.</Text>}
								style={{flex:1, marginTop: 10}}
							/>
					</View>
					}					
					<View style={{marginTop:5, flex:1, }}>
						{ msgList.map( cur => (
							<TouchableOpacity onPress={()=>setOption(cur)} key={cur.code} style={{flexDirection:'row', alignItems:'center', gap:8, marginBottom: 8}}>
								<Image source={ cur.selected ? require('../assets/btn_radio_select.png'):require('@/assets/btn_radio_none.png')} style={{
									width:24, height:24, resizeMode:'cover'
								}}/>
								<Text style={{ fontSize:16, fontWeight:'bold', color:'black', marginVertical: 5}}>
									{cur.value}
								</Text>
							</TouchableOpacity>
						))}
					</View>
					<View style={styles.footer}>
						<TextInput style={styles.msgInput} placeholder="전송 문자를 입력해 주세요" value={msgText} onChangeText={text=>setMsgText(text)}/>
					</View> 
				</View>
				<View>						
					<TouchableOpacity style={styles.sendButton} onPress={()=>sendChatMessage()}>
						<Text style={styles.sendButtonText}>전송</Text>
					</TouchableOpacity>
				</View>
			</View>
		</View>
	);
};

export default CallingCarPopup;

const styles = StyleSheet.create({
	footer: {
		alignItems: 'center',
		marginTop: 10,
	},
	myMessageContainer: {
		alignItems: 'flex-end',
		paddingHorizontal: 10,
		marginVertical: 4,
	},
	myMessageBox: {
		backgroundColor: '#ffcc80',
		borderRadius: 12,
		padding: 8,
		maxWidth: '80%',
	},
	profileImg: {
		width: 36,
		height: 36,
		borderRadius: 18,
		marginRight: 8,
	},
	nickname: {
		fontSize: 12,
		fontWeight: 'bold',
		color: '#333',
	},
	otherMessageContainer: {
		flexDirection: 'row',
		paddingHorizontal: 10,
		marginVertical: 4
	},
	otherMessageContent: {
		flexDirection: 'row',
	},
	otherMessageBox: {
		backgroundColor: '#eee',
		borderRadius: 12,
		padding: 4,
		maxWidth: '80%',
	},
	msgInput: {
		fontWeight:'bold',
		paddingVertical: 4,
		fontSize: 20,
		color: '#333',
		width:'100%',
		borderBottomWidth: 2,
		borderColor: '#cccccc',
		margin:15
	},
	sendButton: {
		backgroundColor: '#FF851D',
		width:'100%',
		justifyContent:'center',
		borderBottomLeftRadius:15,
		borderBottomRightRadius:15,
		paddingVertical:20,
	},
	sendButtonText: {
		color: '#fff',
		fontSize:18,
		fontWeight: 'bold',
		textAlign:'center'
	},
	closeButton: {
		position: 'absolute',
		top: 12,
		right: 10,
		zIndex: 10,
		borderRadius: 20,
		paddingHorizontal: 12,
		paddingVertical: 4,
	},
	closeButtonText: {
		color: '#333',
		fontSize: 26,
		fontWeight: 'bold',
	},
	myMsgOption:{
		flexDirection:'row',
		justifyContent:'flex-end',
	},
	msgBtn:{
		width: 15,
		height: 15,
		marginRight:5,
	},
	timeText: {
		fontSize: 10,
		color: '#999',
		marginTop: 2,
	},
});