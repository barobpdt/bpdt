import React, { useState, useEffect, useRef } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TextInput,
	TouchableOpacity,
	Button,
	KeyboardAvoidingView,
	Platform,
	Alert,
	Keyboard,
	ScrollView,
	Image,
	TouchableWithoutFeedback,
	StatusBar,
	ToastAndroid
} from 'react-native';
import {SaveResponse, RemoveDataRequest, QrMembJKJUpdateRequest, QrJKJUpdateResponse, ImageAsset, FileUploadRequest, FileResponse} from '../types/common'
//import { text } from 'stream/consumers';
import {apiCallPost, apiFileCallPost, callPost, GetDate, GlobalData, useGlobalStore} from '../store/global';
import ApiInfo from '../gvar/ApiInfo';
import { SafeAreaView } from 'react-native-safe-area-context';
import { launchImageLibrary } from 'react-native-image-picker';
import RNFS from 'react-native-fs';
import Share from 'react-native-share';
import RNFetchBlob from 'react-native-blob-util';


const UpdateQrInfoPop: React.FC = () => {
		const global = useGlobalStore();
		const item = global.currentQrItem;

		if (!item) return null;

		//버튼 활성화 여부 체크
		const [isButtonVisible, setButtonVisible] = useState(false);

		const [nickName, setNickName] = useState(item.nickNm || '');
		const [carInfo, setCarInfo] = useState(item.carInfo || '');
		const [makerCar, setMakerCar] =  useState(item.makerCar || '');
		const [parkText, setParkText] = useState(item.parkText || '잠시 주차중입니다.');
		const [introductionInfo, setIntroductionInfo] =  useState(item.introductionInfo || '');
		//const [imgFileUrl, setImgFileUrl] = useState('');

		//서비스타입에따른 데이타 활성화 처리
		const [jobCarView, setJobCarView] = useState(item.serviceTypeCd === 'Car' ? true :false);

		//const [dupNickNmChk, setDupNickNmChk] = useState(item.serviceTypeCd === 'Car' ? true :false);
		const [saveBtnUse, setSaveBtnUse] = useState(false);


		//인풋 공란체크
		const inputRefs = useRef<{ [key: string]: TextInput | null }>({});

		
		// const handleFocus = () => enableSaveBtn();
		const handleBlur = () => enableSaveBtn();

		const [keyboardVisible, setKeyboardVisible] = useState(false);

		// 기본정보 변경 활성화
		//const [isEditable, setIsEditable] = useState(false);

		useEffect(() => {
			enableSaveBtn();
		}, [nickName, carInfo, parkText, introductionInfo]);
		


		useEffect(() => {
			console.log("service write QR useEffect", item.serviceTypeCd, jobCarView);
			console.log('====item==========:', item);
		
		}, []);

		

	//QR번호 복사사	
	const handleCopy = () => {
		if (!item.qrNo) return;		
			//Clipboard.setString(selectedItem.qrNo.toString());
			global.showToast('클립보드에 복사되었습니다.');
		};
		
		//버튼 활성화 처리 기능
		const enableSaveBtn = () => {   
			if (item.serviceTypeCd === 'Car') {
				if (nickName && carInfo && parkText) {
					setSaveBtnUse(true);
				} else {
					setSaveBtnUse(false);
				}
			} else {
				console.log("@@ chk " , nickName , introductionInfo);
				if (nickName && introductionInfo) {
					setSaveBtnUse(true);
				} else {
					setSaveBtnUse(false);
				}
			}
		}  


		//팝업 닫기
		const handleClose = () => {
			console.log('QrAddViewPop close');
			global.setPopupPageId('');
		};

		// 취소 버튼 클릭
		const handleCancel = () => {
			global.setPopupPageId('');
		};
		
		//저정 버튼 클릭
		const handleSave = () => {
			Keyboard.dismiss;
			//입력값 체크 
			if (item.serviceTypeCd === 'Protect') {
				if (!nickName) {
					global.showToast("닉네임을 입력해주세요!");
					return;
				}	
				if (!introductionInfo) {
					global.showToast("소개글을 입력해주세요!");
					return;
				}	
			} else {  //Car
				if (!nickName) {
					global.showToast("닉네임을 입력해주세요!");
					return;
				}	
				if (!carInfo) {
					global.showToast("차량번호를 입력해주세요!");
					return;
				}	
				if (!parkText) {
					global.showToast("주차문구를 입력해주세요!");
					return;
				}	
			}
			saveQrInfo(); 
		};
 
		

  // 이미지 교체
	const chagneProfileImg = () => {
		launchImageLibrary(
		{
			mediaType: 'photo',
			maxWidth: 512,
			maxHeight: 512,
			quality: 0.5,
			includeBase64: true
		}, 
		(response) => {
			if (response.didCancel) {
			console.log('User cancelled image picker');
			} else if (response.assets && response.assets.length > 0) {
				const asset = response.assets[0]; 
				const imageAsset: ImageAsset = {
				uri: asset.uri, // string 타입 안전하게 할당
				type: asset.type, // type은 선택적이므로 사용
				fileName: asset.fileName || 'myProfile.jpg', // fileName이 없으면 기본값 사용
				};
			// setSelectedImage(imageAsset);      
			// console.log("selectimg ", selectedImage)    ;
				uploadImage(imageAsset) ;
			} else {
			console.warn('An unexpected error occurred or no assets were returned');
			} 
			
		})
	}

	const uploadImage = async (imageAss : ImageAsset) => {
	
		console.log("uploadImage ", imageAss)    ;
		const fileReqParam = () => {
				const node = {} as FileUploadRequest
				node.fileType="QF"
				node.currentDate=GetDate()
				node.langCd=GlobalData.langCd
				node.roomNo=''
				node.qrNo=item.qrNo
				node.multipartFile={
				uri: imageAss?.uri, // URI를 적절히 할당
				type: imageAss?.type || "image/jpeg", // MIME 타입 (기본값 설정)
				fileName: imageAss?.fileName || "myProfile.jpg", // 파일명 (기본값 설정)
			}
				return node;
			}
		console.log( "reqeust : ", fileReqParam());
		
		const formData = new FormData();
		formData.append('multipartFile', {
			uri: imageAss?.uri,
			type: imageAss?.type || 'image/jpeg', // MIME 타입
			name: imageAss?.fileName|| 'photo.jpg', // 파일 이름
		});

		formData.append('fileType', 'QF')
		formData.append('qrNo', item.qrNo)
		formData.append('currentDate', GetDate())
		formData.append('langCd', GlobalData.langCd)
		formData.append('roomNo', '')
		console.log('@@ formData ', formData);
		try {
		apiFileCallPost(ApiInfo.fileUpload,formData, (type:string, obj:object) => {
			if( type=='ok' ) {
				var info=obj as FileResponse
				console.log("file info", info);
				item.imgFileUrl = info.downUrl;

				let imgQrInfo = global.listMyQr?.find(orgItem => orgItem.qrNo === item.qrNo);

				if (imgQrInfo) {
					imgQrInfo.imgFileUrl = info.downUrl;
					imgQrInfo.imgFilePath = info.fileNo;
					global.updateMyQr(imgQrInfo);
				}

			}
		}) 
		} catch (error) {
		console.error(error);
		}
	};



		const saveQrInfo = async () => {
			//QrMembJKJRegRequest, QrJKJRegResponse
			const QrMembJKJUpdateParam = () => {
					const node = {} as QrMembJKJUpdateRequest
					node.qrNo = item.qrNo;
					node.serviceTypeCd = item.serviceTypeCd;
					node.nickNm = nickName;
					node.pinNo = '';
					node.chgPinNo = '';
					node.reUseYn = 'N';
					node.parkText = parkText;
					node.introductionInfo = introductionInfo;
					node.makerCar = makerCar;
					node.carInfo = carInfo;
					node.langCd = GlobalData.langCd;
					node.currentDate = GetDate();
					return node;
			}
			const info = await callPost(ApiInfo.updateJkjQr, QrMembJKJUpdateParam()) as QrJKJUpdateResponse;
			console.log("@@ saveQrInfo info",info);
			if( 'errors' in info ) {
				global.showToast(info.message);
				return;
			}
			if (info.code === '30005') { 
				global.showToast('QR 정보 수정 완료');
				global.updateMyQr(info.addQrInfo);
				console.log("이동처리");
				//global.setListMyQrCurrent(global.qrClickData.serviceTypeCd, global.qrClickData.qrNo);
				handleClose();
		} else {
			Alert.alert(info.message);
		} 
	}

	const goToDownload = (qrNo:string , qrInfo:string ) => {
		Alert.alert(
			'QR 이미지',
			'다운로드를 하시겠습니까?',
			[
				{
					text: '취소',
					style: 'cancel',
				},
				{ text: '다운로드', onPress: () => downloadImage(qrNo, qrInfo) }, // OK 버튼 클릭 시 downloadImage 호출
			],
			{ cancelable: false }
		);
	};

	const downloadImage = async (qrNo:string, qrInfo:string) => {
	//	console.log("downloadImage==>", qrNo, qrInfo, qrImgInfo);
		// 다운로드할 파일의 경로
		if (GlobalData.deviTpCd === 'SA') {
			androidDownloadImage(qrNo, qrInfo);
		} else {
			iosDownloadImage(qrNo, qrInfo) ;
		}
	};

	const androidDownloadImage = async (qrNo:string, qrInfo:string) => {
		const { config, fs } = RNFetchBlob;
		let PictureDir = fs.dirs.DownloadDir; 
		let filePath = PictureDir + '/' + qrNo + '.png';
		
		return config({
			fileCache: true,
			addAndroidDownloads: {
				useDownloadManager: true, // Uses the Android native download manager
				notification: true,
				path: filePath,
				description: 'Image',
			},
		})
			.fetch('GET', qrInfo)
			.then(res => {
				console.log('The file saved to ', res.path());
			})
			.catch((error) => {
				console.error('Download error', error);
			});
		
	};


	// ios qr다운로드
	const iosDownloadImage = async (qrNo:string, qrInfo:string) => {
		const fileName = qrInfo.split('/').pop(); // 파일 이름 추출
		const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}`; // 다운로드 경로

		try {
				// 이미지 다운로드
				const res = await RNFS.downloadFile({
						fromUrl: qrInfo,
						toFile: filePath,
						background: true,
				}).promise;

				if (res.statusCode === 200) {
						// 공유
						await Share.open({
								url: `file://${filePath}`, // 'file://' 접두사를 추가하여 파일을 Sharing
								type: 'image/jpeg', // 이미지 파일 타입
						});

						global.showToast('이미지가 공유되었습니다.');
				} else {
						Alert.alert('다운로드 실패', `상태 코드: ${res.statusCode}`);
				}
		} catch (error) {
				console.error('파일 다운로드 중 오류 발생:', error);
				Alert.alert('다운로드 오류', '파일을 다운로드하는 동안 오류가 발생했습니다.');
		}
	};

	// QR 삭제 핸들러
		const handleDeleteItem = () => {
			
			Alert.alert(
				'QR 삭제',
				`'${nickName}' QR을 삭제하시겠습니까?`,
				[
					{ text: '취소', style: 'cancel' },
					{ 
						text: '삭제', 
						onPress: () => {
							requestDeleteQr();
						}
					}
				]
			);
		};
		const requestDeleteQr = async () => {
			console.log("@@ requestDeleteQr selectedItem=>", item);
			if (!item) return;
			const node = {} as RemoveDataRequest
				node.removeType='Q'
				node.myQrNo=item.qrNo
				node.serviceTypeCd=item.serviceTypeCd
				node.friendQrNo=''
				node.friendNo=''
				node.langCd=GlobalData.langCd
	
			console.log("Delete Friend 222", node);
			const info = await callPost('/api/main/removeData', node) as SaveResponse;
			if( info.code == '20005' ) {
				global.showToast('QR 삭제 되었습니다.');
				//QR리스트에서 제거함
				global.removeMyQr(item.qrNo);
				//state.setRemoveTypeData(null);
				//onClose();
				global.setCurrentQrItem(null);
			} else {
				global.showToast('친구 삭제 실패:' + info.message);
			}
	
		}
	// 
	return (
		<SafeAreaView style={{position: 'absolute',top: 0,left: 0, bottom:0, right: 0, backgroundColor:'#fff'}}>
			<View style={styles.titleContainer}>
				<View style={styles.leftContainer}>
					<Text style={styles.headText}> QR 정보 수정</Text>    
				</View>  
				<TouchableOpacity style={{position:'absolute', padding:15, right:0, top:0}} onPress={handleClose}>
					<Image 
						source={require('../assets/ic_close.png') } 
						style={styles.closeimage} 
					/> 
				</TouchableOpacity>
			</View>
			<KeyboardAvoidingView 
				style={{flex: 1}}
				behavior={Platform.OS === 'ios' ? 'padding' : undefined}
				keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
			> 
				<View style={{flex: 1}}>
					<ScrollView 
						style={{flex: 1}}
						contentContainerStyle={{ 
							paddingBottom: Platform.OS === 'ios' ? 100 : 80
						}}
						keyboardShouldPersistTaps="handled"
						showsVerticalScrollIndicator={true}
						bounces={true}
					>
						<View style={{ paddingVertical:10, paddingHorizontal:20}}>
							{jobCarView && <View style={styles.inputContainer}>
								<TouchableOpacity style={{marginBottom:10}} onPress={handleCopy}>
									<Text style={{fontSize: 15, textAlign:'center', color: '#333',}}>{item.qrNo}</Text>
								</TouchableOpacity>
								<View style={{
									marginBottom: 10,
									justifyContent:'center',
									alignContent:'center',
									alignItems:'center'}}>
									<TouchableOpacity style={{
										overflow:'hidden',
										marginTop: 10,
										position:'relative',
										width:90, 
										height:90,
										borderWidth:1,
										borderColor:'#ddd',
										borderRadius:45,}} onPress={() => chagneProfileImg()}>
										<Image  
											source={{uri: item.imgFileUrl} } 
											style={{position:'absolute', left:0, right:0, top:0, bottom:0, resizeMode: 'cover',}} // 이미지 스타일
											/>
									</TouchableOpacity>
								</View>
								<Text style={styles.label}>닉네임 (최대 10자리)*</Text>
								<View style={styles.inputBtnContainer}>
									<TextInput
										style={[styles.input]}
										ref={(el) => (inputRefs.current['nickName'] = el)}
										maxLength={10}
										placeholder="닉네임 입력"
										value={nickName}
										onChangeText={setNickName}
										// onFocus={handleFocus}
										onBlur={handleBlur}
										//editable={isEditable} // 에딧 활성화시 활성화
									/>
								</View>
								
								<Text style={styles.label}>차종</Text>
								<TextInput
									style={[styles.input]}
									ref={(el) => (inputRefs.current['makerCar'] = el)}
									maxLength={10}
									placeholder="차종 입력"
									value={makerCar}
									onChangeText={setMakerCar}
									//onFocus={handleFocus}
									onBlur={handleBlur}
									//editable={isEditable} // 에딧 활성화시 활성화
								/>
								<Text style={styles.label}>차량번호*</Text>
								<TextInput
									style={[styles.input]}
									maxLength={10}
									placeholder="차량번호 입력"
									ref={(el) => (inputRefs.current['carInfo'] = el)}
									value={carInfo}
									onChangeText={setCarInfo}
									//onFocus={handleFocus}
									onBlur={handleBlur}
									//editable={isEditable} // 에딧 활성화시 활성화
								/>
								<View style={styles.inputContainer}>
									<Text style={styles.label}>주차문구 (최대 30자리)*</Text>
									<TextInput
										style={[styles.input]}
										maxLength={30}
										placeholder="소개글 입력"
										ref={(el) => (inputRefs.current['parkText'] = el)}
										value={parkText}
										onChangeText={setParkText}
										//  onFocus={handleFocus}
										onBlur={handleBlur}
										//editable={isEditable} // 에딧 활성화시 활성화
									/>
								</View>
							</View> }
							{!jobCarView && <View style={styles.inputContainer}>
								<View style={styles.topInputContainer}>
									<TouchableOpacity style={{marginBottom:10}} onPress={handleCopy}>
										<Text style={{fontSize: 15,
										textAlign:'center',
											color: '#333',}}>{item.qrNo}</Text>
									</TouchableOpacity>
									<View style={{
										marginBottom: 10,
										justifyContent:'center',
										alignContent:'center',
										alignItems:'center'}}>
										<TouchableOpacity style={{
											overflow:'hidden',
											marginTop: 10,
											position:'relative',
											width:90, 
											height:90,
											borderWidth:1,
											borderColor:'#ddd',
											borderRadius:45,}} onPress={() => chagneProfileImg()}>
											<Image  
												source={{uri: item.imgFileUrl} } 
												style={{position:'absolute', left:0, right:0, top:0, bottom:0, resizeMode: 'cover',}} // 이미지 스타일
												/>
										</TouchableOpacity>
									</View>
									<Text style={styles.label}>닉네임 (최대 10자리)*</Text>
									<View style={styles.inputBtnContainer}>
										<TextInput
											style={[styles.input]}
											maxLength={10}
											placeholder="닉네임 입력"
											value={nickName}
											onChangeText={setNickName}
											// onFocus={handleFocus}
											onBlur={handleBlur}
											//editable={isEditable} // 에딧 활성화시 활성화
										/>
									</View>
								</View>
								<Text style={styles.label}>소개글 (최대 30자리)*</Text>
								<TextInput
									style={[styles.input, ]}
									maxLength={30}
									placeholder="소개글 입력"
									ref={(el) => (inputRefs.current['introductionInfo'] = el)}
									value={introductionInfo}
									onChangeText={setIntroductionInfo}
									//onFocus={handleFocus}
									onBlur={handleBlur}
								/>
							</View> }
							<View style={{justifyContent:'center', alignContent:'center', alignItems:'center',  }}>
								{/* QR 바코드 이미지 */}
								<View style={{}}>
									<Image
										source={{ uri: item.qrInfo }}
										style={styles.qrImage}
										resizeMode="contain"
									/>
									<View style={{flexDirection:'row', justifyContent:'space-between'}}>
										<TouchableOpacity style={{backgroundColor:'#ddd',flex:1, alignItems: 'center',paddingVertical:10,}} onPress={handleDeleteItem}>
											<Text style={{fontSize:15, color:'#444'}}>삭제</Text>
										</TouchableOpacity>
										<TouchableOpacity style={{flex:1, backgroundColor:'#FF851D',alignItems: 'center',paddingVertical:10,}} onPress={() => goToDownload(item.qrNo, item.qrInfo)}>
											<Text style={{fontSize:15, color:'white'}}>다운로드</Text>
										</TouchableOpacity>
									</View>
								</View>
							</View>
						</View>
					</ScrollView>
					<View style={[styles.buttonContainer]}>
						<TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={handleCancel}>
							<Text style={styles.buttonText}>취소</Text>
						</TouchableOpacity>
						<TouchableOpacity style={[styles.button, saveBtnUse ? styles.saveButton : styles.saveUnEnableButton ]} onPress={handleSave}>
							<Text style={[styles.buttonText, saveBtnUse?{color:'white'}:{color:'black'}]}>저장</Text>
						</TouchableOpacity>
					</View>
				</View>
			</KeyboardAvoidingView>
		</SafeAreaView> 
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
	},
	inputBtnContainer: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	bottomContainer: {
		flex: 1,
		backgroundColor: '#F7F8FA',
	},
	titleContainer: {
		flexDirection: 'row',
		justifyContent: 'center',
		alignItems: 'center',
		paddingVertical:17,
		paddingHorizontal:10,
	},
	leftContainer: {
		flexDirection: 'row',
		alignItems: 'center',
		
	},
	qrImage:{
		width: 250,
		height: 250,
		marginVertical: 10,
		borderWidth: 1,
		borderColor: '#eee',
	},
	headText: {
		fontSize: 18, // 텍스트 크기
	},
	questimage: {
		width: 25, // 이미지 너비
		height: 25, // 이미지 높이
		marginLeft: 5, // 텍스트와의 간격
		},
	closeimage: {
		width: 25, // 이미지 너비
		height: 25, // 이미지 높이
	},
	buttonContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		width: '100%',
		backgroundColor: 'white',
		borderTopWidth: 1,
		borderTopColor: 'lightgray',
		paddingBottom: Platform.OS === 'ios' ? 20 : 0,
		position: 'absolute',
		bottom: 0,
		left: 0,
		right: 0,
	},
	buttonVisible: {
			position: 'absolute', // 포커스하면 버튼이 위쪽으로 올라오게 설정
			bottom: 20,
		},
	button: {
		flex: 1,
		padding: 15,
	},
	cancelButton: {
		backgroundColor: '#F1F1F1', // 취소 버튼 색상
	},
	buttonText: {
		textAlign: 'center',
		color: 'black',
		fontWeight: 'bold',
		fontSize: 16,
	},
	saveButton: {
		backgroundColor: '#FF851D', // 저장 버튼 색상
	},
	saveUnEnableButton: {
		backgroundColor: '#F1F1F1', // 저장 버튼 색상
	},
	scrollViewContent: {
		flexGrow: 1,
		
	},

	label: {
		fontSize: 12,
		color: '#26282B',
		marginLeft:3,
	},
	labelbold: {
		fontSize: 18,
		marginBottom:  5,
		fontWeight: 'bold',
		color: '#26282B'
	},
	topInputContainer: {
		marginBottom: 2,
		justifyContent:'center',
	},
	inputContainer: {
		marginTop: 5,
		marginBottom: 2,
		justifyContent:'center',
		
	},
	input: {
		flex: 1,
		height: 40,
		borderColor: 'gray',
		borderWidth: 1,
		borderRadius: 5,
		paddingHorizontal: 10,
		marginVertical: 5,
		backgroundColor:'white'
	},
	dupButton: {
		marginLeft: 10,
		backgroundColor: '#007BFF',
		borderRadius: 4,
		padding: 10,
	},
	dupButtonText: {
		color: 'white',
	},
	touchableArea: { // 추가된 스타일
		flex: 1, // 확장을 위해 스타일 설정
	},
	disabledInput: { //비활성된 input
		backgroundColor: '#f0f0f0', // 비활성화일 때 회색 배경
		color: '#888',              // 비활성화일 때 흐린 텍스트
	},
	errorText: {
		color: 'red',
		fontSize: 12,
		marginTop: 4,
	},
		
});

export default UpdateQrInfoPop;
