import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Button,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Image,
  StatusBar,
  ToastAndroid
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import {RootStackParamList, ImageAsset, FileResponse, FileUploadRequest, SaveMembNickNmRequest, SaveResponse, WriteMyProfilePopProps} from '../types/common.tsx'
import {apiCallPost,apiFileCallPost, GetDate, GlobalData, MembInfo, useGlobalStore} from '../store/global.tsx';
import ApiInfo from '../gvar/ApiInfo.tsx';
import { launchImageLibrary } from 'react-native-image-picker';
import { SafeAreaView } from 'react-native-safe-area-context';



const WriteMyProfilePop: React.FC<WriteMyProfilePopProps> = ({ closeWriteProfile }) => {  

  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
   const global = useGlobalStore();
  
  const [nickname, setNickname] = useState('');  
  const [introductionInfo, setIntroductionInfo] = useState('');
  const [imgFileUrl, setImgFileUrl] = useState('');
  const [nicknameError, setNicknameError] = useState(false);
  const [isButtonVisible, setButtonVisible] = useState(false);

  const [selectedImage, setSelectedImage] = useState<ImageAsset | null>(null);
  

  const handleFocus = () => setButtonVisible(true);
  const handleBlur = () => setButtonVisible(false);

  const handleSave = async () => {
    // 여기에 저장 로직 구현
    //Alert.alert('Saving data...', `Nickname: ${nickname}, introductionInfo: ${introductionInfo}`);    
    
    //공란이면 저장로직 수행안하고 리턴 0513이웅희
    // if (nickname.trim() === '') {
    //   return;
    // }

      let rtData: SaveResponse;
      try {  
          rtData = await saveProfile(); 
          if (rtData.code == "20001") { //저장 실패시
              global.membInfo.introductinInfo = introductionInfo;
              global.membInfo.nickNm = nickname;
              console.log("저장 되었습니다.", rtData )
              closeWriteProfile();
          } else {
            if (Platform.OS === 'android') {
              ToastAndroid.show('메세지 삭제 오류', ToastAndroid.SHORT);
            } else {
              Alert.alert("메세지 삭제 오류", rtData.message);
            }
          }
      } catch (error) {
          console.error("메세지 삭제 실패했습니다:", error);
      }

  };

  const handleCancel = () => {
    //navigation.goBack(); // 이전 화면으로 이동
    closeWriteProfile();
  };

  useEffect(() => {
    console.log("img path",global.membInfo.imgFileUrl);
    setNickname(global.membInfo.nickNm);
    setIntroductionInfo(global.membInfo.introductinInfo);  
    setImgFileUrl(global.membInfo.imgFileUrl);
    }, []);


    useEffect(() => {
      console.log("profile file change", imgFileUrl);
      }, [imgFileUrl]);

  // 이미지 교체
  const chagneProfileImg = () => {
    launchImageLibrary(
      {
        mediaType: 'photo',
        maxWidth: 512,
        maxHeight: 512,
        quality: 0.5,
        includeBase64: true
      }, 
      (response) => {
        if (response.didCancel) {
          console.log('User cancelled image picker');
        } else if (response.assets && response.assets.length > 0) {
            const asset = response.assets[0]; 
            const imageAsset: ImageAsset = {
              uri: asset.uri, // string 타입 안전하게 할당
              type: asset.type, // type은 선택적이므로 사용
              fileName: asset.fileName || 'myProfile.jpg', // fileName이 없으면 기본값 사용
            };
           // setSelectedImage(imageAsset);      
           // console.log("selectimg ", selectedImage)    ;
            uploadImage(imageAsset) ;
        } else {
          console.warn('An unexpected error occurred or no assets were returned');
        } 
        
     })
  }

  const uploadImage = async (imageAss : ImageAsset) => {
   
    console.log("uploadImage ", imageAss)    ;
    const fileReqParam = () => {
            const node = {} as FileUploadRequest
            node.fileType="PF"
            node.currentDate=GetDate()
            node.langCd=GlobalData.langCd
            node.roomNo=''
            node.qrNo=''
            node.multipartFile={
              uri: imageAss?.uri, // URI를 적절히 할당
              type: imageAss?.type || "image/jpeg", // MIME 타입 (기본값 설정)
              fileName: imageAss?.fileName || "myProfile.jpg", // 파일명 (기본값 설정)
          }
            return node;
          }
    console.log( "reqeust : ", fileReqParam());
    
    const formData = new FormData();
    formData.append('multipartFile', {
        uri: imageAss?.uri,
        type: imageAss?.type || 'image/jpeg', // MIME 타입
        name: imageAss?.fileName|| 'photo.jpg', // 파일 이름
    });

    formData.append('fileType', 'PF')
    formData.append('currentDate', GetDate())
    formData.append('langCd', GlobalData.langCd)
    formData.append('qrNo','')
    formData.append('roomNo', '')

    try {
      apiFileCallPost(ApiInfo.fileUpload,formData, (type:string, obj:object) => {
        if( type=='ok' ) {
          var info=obj as FileResponse
          console.log("file info", info);
          setImgFileUrl(info.downUrl);
          global.membInfo.imgFileUrl = info.downUrl ;
        }
      }) 
    } catch (error) {
      console.error(error);
    }
  };

  const saveProfile = async (): Promise<SaveResponse> => {
    let info: SaveResponse = { code: '', message: '' }; // 기본값 할당
    const saveNickIntroReqParam = () => {
      const node = {} as SaveMembNickNmRequest
      node.nickNm=nickname
      node.introductionInfo=introductionInfo
      node.currentDate=GetDate()
      node.langCd=GlobalData.langCd
      return node;
    }
    console.log("qrDeleteMsgReqParam==>", saveNickIntroReqParam());
    try {
      info = await new Promise<SaveResponse>((resolve, reject) => {
        apiCallPost(ApiInfo.saveNickIntro, saveNickIntroReqParam(), (type:string, obj:object) => {
          if (type === 'ok') {
              resolve(obj as SaveResponse); // 성공적으로 응답 시 resolve
              
          } else {
              reject(new Error('API 호출 실패')); // 실패 시 reject
          }
      });
    })
    } catch (error) {
        console.error("API 호출 중 오류 발생:", error);
        return { code: '500', message: 'API 호출 중 오류 발생' };
    }
  
    return info ;
  }
 

  return (
    <React.Fragment>
      <StatusBar
      barStyle="dark-content"
      backgroundColor="#ffffff" // 상태바 배경색 지정 (Android)
      />
    <SafeAreaView style={styles.bottomContainer}>
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={styles.header}>
          <Text style={styles.title}>내 프로필</Text>
          <TouchableOpacity style={{position:'absolute', top:0, right:5, padding:15 }} onPress={handleCancel}>
            <Text style={{fontSize:18}}>X</Text>
          </TouchableOpacity>
      </View>
      
      <ScrollView contentContainerStyle={styles.scrollViewContent}>
        <View style={styles.inputContainer}>
           <TouchableOpacity style={{
              overflow:'hidden',
              marginTop: 30,
              marginBottom: 10,
              position:'relative',
              width:80, 
              height:80,
              borderWidth:1,
              borderColor:'#ddd',
              borderRadius:40,}} onPress={() => chagneProfileImg()}>
            <Image  
                source={{uri: global.membInfo.imgFileUrl} } 
                style={{position:'absolute', left:0, right:0, top:0, bottom:0, resizeMode: 'cover',}} // 이미지 스타일
                />
          </TouchableOpacity>
          <Text style={{fontSize: 18,textAlign:'center'}}>{nickname}</Text>
        </View>

        <Text style={styles.pinlabel}>소개글(최대 20자리)</Text>
        <View style={styles.pinContainer}>
          <TextInput
            style={styles.pinInput}
            maxLength={20}
            placeholder="내 상태 알림 입력"
            value={introductionInfo}
            onChangeText={setIntroductionInfo}
            onFocus={handleFocus}
            onBlur={handleBlur}
          />
        </View>
      </ScrollView>

      <View style={[styles.buttonContainer, isButtonVisible && styles.buttonVisible]}>
        <TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={handleCancel}>
          <Text style={styles.buttonText}>취소</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.button, styles.saveButton]} onPress={handleSave}>
          <Text style={[styles.buttonText, {color:'white'}]}>저장</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
    </SafeAreaView>
    </React.Fragment>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor:'#FFF9F3'
  },
  header: {
    flexDirection: 'row', // 수평으로 나열
    alignItems: 'center', // 가운데 정렬
    padding: 10,
    justifyContent:'center',
    alignContent:'center'
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    flex: 1, // 텍스트가 가능한 공간을 차지하게 함
    marginLeft: 10,
    color: '#FF851D',
    textAlign:'center'
  },
  profileImage: {
    width: 50,
    height: 50,
    marginRight: 10,
    borderRadius: 40, // 원형 이미지로 만들고 싶을 때 사용
  },
  scrollViewContent: {
    padding: 20,
    flexGrow: 1, // ScrollView가 내용을 담아서 스크롤 가능하게
    //paddingBottom: 100, // 버튼을 위한 공간 마련
  },
  inputContainer: {
    marginTop: 30,
    marginBottom: 20,
    justifyContent:'center',
    alignContent:'center',
    alignItems:'center'
  },
  label: {
    fontSize: 16,
    marginBottom:  3,
    color: '#26282B'
  },
  pinlabel: {
    fontSize: 16,
    marginBottom:  3,
    color: '#26282B'
  },
  nicknameContainer: {
    alignItems: 'center', // 수직 방향으로 가운데 정렬
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    overflow: 'hidden', // 자식 요소가 테두리 바깥으로 넘어가지 않게 함
    marginBottom: 20,
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 10,
    marginVertical: 5,
  },
  errorText: {
    color: 'red',
    marginTop: 4,
    marginLeft: 4,
    fontSize: 13,
  },
  pinInput: {
    flex: 1, // 입력란이 가능한 공간을 전부 차지함
    height: 40,
    paddingHorizontal: 10,
    backgroundColor:'white'
  },
  pinContainer: {
    flexDirection: 'row', // 수평 방향으로 배치
    alignItems: 'center', // 수직 방향으로 가운데 정렬
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    overflow: 'hidden', // 자식 요소가 테두리 바깥으로 넘어가지 않게 함
    marginBottom: 20,
    marginVertical: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between', // 버튼을 양 끝으로 배치
    width: '100%', // 가로 공간을 모두 차지하게 함
    backgroundColor: 'white', // 배경 색상
    borderTopWidth: 1,
    borderTopColor: 'lightgray',
    // 여백을 없앰
    padding: 0,
  },
  button: {
    flex: 1,
    padding: 15,
  },
  cancelButton: {
    backgroundColor: '#F1F1F1', // 취소 버튼 색상
  },
  saveButton: {
    backgroundColor: '#FF851D', // 저장 버튼 색상
  },
  buttonText: {
    textAlign: 'center',
    color: 'black',
    fontWeight: 'bold',
    fontSize: 16,
  },
  buttonVisible: {
    position: 'absolute', // 포커스하면 버튼이 위쪽으로 올라오게 설정
    bottom: 20,
  },
  bottomContainer: {
    flex:1, width: '100%', height: '100%', justifyContent: 'flex-end', backgroundColor: '#F7F8FA',
  },
});

export default WriteMyProfilePop;
