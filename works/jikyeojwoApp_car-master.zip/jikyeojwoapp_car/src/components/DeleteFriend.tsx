import React, { useContext, useEffect, useState } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Image,
	Dimensions,
	Alert,
} from 'react-native';
import { FriendList, SaveResponse, RemoveDataRequest, MainResponse, ApiMainRequest } from '../types/common';  
import { useGlobalStore, GlobalData, callPost, updateMainResponse } from '../store/global';
import ApiInfo from '../gvar/ApiInfo';


const { width, height } = Dimensions.get('window');


const DeleteFriend: React.FC = () => {
	const global = useGlobalStore();
	const [item, setItem] = useState<FriendList|null>(global.locationFriendItem); 

	useEffect(() => {
	}, []);

	if( item==null ) return null;


	// const pressDelete = () => {
	// 	console.log('삭제진행')
	// 	Alert.alert(
	// 		'QR 삭제', `'${item?.friendNm}'님을 삭제하시겠습니까?`,
	// 		[
	// 			{ text: '취소', style: 'cancel' }, 
	// 			{ text: '삭제', onPress: () => requestDelete() }
	// 		]
	// 	);
	// }

	const requestDelete = async () => { 
		const node = {} as RemoveDataRequest
			node.removeType='F'
			node.myQrNo=item.membQrNo
			node.serviceTypeCd=item.serviceTypeCd
			node.friendQrNo=item.friendQrNo
			node.friendNo=item.friendNo
			node.langCd=GlobalData.langCd

		console.log("Delete Friend 222", node);
		const info = await callPost('/api/main/removeData', node) as SaveResponse;
		if( info.code == '20005' ) {
			global.showToast('친구 삭제 되었습니다.');
			//친구리스트에서 제거함
			global.removeFriendList(item.friendNo, item.friendQrNo, item.membQrNo);
			onClose();
		} else {
			global.showToast('친구 삭제 실패:' + info.message);
		}
	}

	const onClose = () => {
		global.setLocationFriendItem(null);
		global.setPopupPageId('');
	}

	return (
	<View style={{
		position: 'absolute',
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		height: '100%',
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
	}}>
		<View style={{
			width: width * 0.9,
			height: 250,
			backgroundColor: '#fff',
			borderRadius: 15,
			paddingTop: 10
		}}>  
			<View style={[styles.header, {paddingHorizontal: 20,}]}>
				<Text style={styles.title}>친구삭제</Text>
				<TouchableOpacity style={styles.closeButton} onPress={onClose}>
					<Text style={styles.closeText}>X</Text>
				</TouchableOpacity>
			</View>
			<View style={{alignContent:'center', alignItems:'center', flex:1}}>
				{ item.introductionInfo && <Image source={{ uri: item.imgFileUrl }} style={[styles.avatar, {borderColor:'#FF851D', borderWidth:1}]} />}
				<View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
					<View style={styles.messageArea}>
						<Text style={styles.messageText}>
						{item.nickNm}님을 친구에서 삭제하시겠습니까?
						</Text>
					</View>
					<View style={[styles.buttonRow, ]}>
						<TouchableOpacity style={styles.rejectButton} onPress={() => onClose()}>
							<Text style={styles.buttonText}>취소</Text>
						</TouchableOpacity>
						<TouchableOpacity style={styles.acceptButton} onPress={() => requestDelete()}>
							<Text style={styles.buttonText}>삭제</Text>
						</TouchableOpacity>
					</View>
				</View>
			</View>
		</View>
	</View>
	);
};

export default DeleteFriend;

const styles = StyleSheet.create({
overlay: {
	flex: 1,
	justifyContent: 'center',
	backgroundColor: 'rgba(0,0,0,0.5)',
},
modalContainer: {
	width: width * 0.8,
	alignSelf: 'center',
	backgroundColor: '#fff',
	borderRadius: 12,
	paddingTop: 16,
	paddingBottom: 8,
	paddingHorizontal: 16,
},
header: {
	position: 'relative',
	alignItems: 'center',
	marginBottom: 12,
},
title: {
	fontSize: 22,
	fontWeight: 'bold',
},
closeButton: {
	position: 'absolute',
	right: 10,
	
},
closeText: {
	fontSize: 18,
	color: '#999',
},
listContainer: {
	gap: 12,
	paddingBottom: 12,
},
listItem: {
	flexDirection: 'row',
	alignItems: 'center',
	alignContent:'center',
	gap: 8,
	paddingVertical: 8,
	height:80,
},
avatar: {
	width: 80,
	height: 80,
	borderRadius: 40,
	marginTop: 4,
	alignContent:'center',
	alignItems:'center'
},
messageArea: {
	flex: 1,
	alignContent:'center',
	alignItems:'center',
	justifyContent:'center',
	
},
messageText: {
	fontSize: 17,
	textAlign:'center',
	
},
buttonRow: {
	flexDirection: 'row',
	justifyContent:'space-around',
	

},
rejectButton: {
	backgroundColor: '#ccc',
	paddingVertical: 15,
	flex:1,
	borderBottomLeftRadius:15 
},
acceptButton: {
	backgroundColor: '#FF851D',
	paddingVertical: 15,
	flex:1,
	borderBottomRightRadius:15
},
buttonText: {
	color: '#fff',
	fontSize: 17,
	textAlign:'center'
},
bottomButton: {
	backgroundColor: '#FF851D',
	borderRadius: 8,
	alignItems: 'center',
	justifyContent: 'center',
	paddingVertical: 10,
	marginTop: 16,
},

});
