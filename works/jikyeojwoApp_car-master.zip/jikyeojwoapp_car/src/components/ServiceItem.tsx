import React from "react";
import { View, Text, TouchableOpacity, StyleSheet , Image, Alert} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList, ServiceItemProps } from '../types/common';
import { useGlobalStore  } from '../store/global';


const ServiceItemMain: React.FC<ServiceItemProps> = ({  backgroundColor, imageUri,  serviceTypeCd }) => {
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
  const global = useGlobalStore();

  const goToServiceMove = (serviceTypeCd:string) => {
   // onChangeService(serviceTypeCd); 글로벌 데이타를 변경처리한다.
   
    global.updateQrClickData({serviceTypeCd: serviceTypeCd , qrNo: ''});
  }
  
   return (
      //  <TouchableOpacity style={[styles.contener, {backgroundColor: backgroundColor}]} onPress={() => goToServiceMove(serviceTypeCd)}>
       <View style={[styles.contener, {backgroundColor: backgroundColor}]}>
         <Image
           source={{ uri: imageUri }}
           style={{ width: 45, height: 45, borderRadius: 5, }}
         />
       </View>
      //  </TouchableOpacity>
     );
};

export default ServiceItemMain ;

// 스타일 정의
const styles = StyleSheet.create({
  contener: {
    flex: 1, justifyContent: 'center', alignItems: 'center',
    //paddingVertical:10
  },
});