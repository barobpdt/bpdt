import React from "react";
import { View, Text, TouchableOpacity, Image, Linking} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';


const AdInfo: React.FC<{}> = ({}) => {

    const linkUrl = () => {
        Linking.openURL("https://www.jikyeojwo.com")
    }

   return (
       <TouchableOpacity onPress={linkUrl}>
       <View>
         <Image
           source={{ uri: "https://kosk.co.kr/scgd-file/ad/ad_1.png" }}
           style={{ width: '100%', height: 56, borderRadius: 5, marginTop: 2 }}
         />
       </View>
       </TouchableOpacity>
     );
};

export default AdInfo ;

