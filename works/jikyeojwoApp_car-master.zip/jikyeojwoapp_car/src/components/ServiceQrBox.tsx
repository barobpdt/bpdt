import React, { forwardRef, useState, useEffect, useImperativeHandle } from "react";
import { View, Text, TouchableOpacity, StyleSheet , Image, FlatList,Alert, Modal, Platform, ToastAndroid} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { Route } from '@react-navigation/native'; // 경로 가져오기
import {GlobalData, apiCallPost, useGlobalStore, callPost} from '../store/global';
import ApiInfo from "../gvar/ApiInfo";
import RNFS from 'react-native-fs';
import { ServiceQrBoxProps, RootStackParamList, MyQrResponse, ListMyQr, MyQrRequest, RemoveDataRequest , SaveResponse } from '../types/common';
import Share from 'react-native-share';

//import {hasAndroidPermission} from '../utils/getCheckPermission' ;
import RNFetchBlob from 'react-native-blob-util';


const ServiceQrBox : React.FC = () => {

	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴 
	const maxTextLength = 5 ;  
	// 이미지와 리스트의 표시 여부를 관리하기 위한 상태 변수   
	const [addQRimageSource, setAddQRImageSource] = useState(require('../assets/addQR.png'));
	const [qrImgInfo, setQrImgInfo] = useState<ListMyQr[]>([]);  // 메세지 내용 
	//const [selQrInfo, setSelQrInfo] = useState<string>();  // QR선택된 이미지 정보
	const [selQrFileNo, setSelQrFileNo] = useState<string>();  // QR선택된 이미지 파일 번호
	
	const handleEditPress = (item) => {
		console.log("@@ handleEditPress item=>", item);
		global.setCurrentQrItem(item);
		global.setPopupPageId('UpdateQrInfoPop');
	};
	
	const global = useGlobalStore();
	//이미지 크게 보기 
	//const [modalVisible, setModalVisible] = useState(false);



	// 모달 관련 상태 추가
	const [modalVisible, setModalVisible] = useState(false);
	const [selectedItem, setSelectedItem] = useState<ListMyQr | null>(null);

	
	 
	// 터치 이벤트 핸들러
	const handleCopy = () => {
		if (!selectedItem?.qrNo) return;
	
		//Clipboard.setString(selectedItem.qrNo.toString());
	
		if (Platform.OS === 'android') {
			ToastAndroid.show('클립보드에 복사되었습니다.', ToastAndroid.SHORT);
		} else {
			Alert.alert('알림', '클립보드에 복사되었습니다.');
		}
	};

  // 모달 닫기 핸들러
	const handleCloseModal = () => {
		setModalVisible(false);
		setSelectedItem(null);
	};

	// QR 삭제 핸들러
	const handleDeleteItem = () => {
		if (!selectedItem) return;
		
		Alert.alert(
			'QR 삭제',
			`'${selectedItem.nickNm}' QR을 삭제하시겠습니까?`,
			[
				{ text: '취소', style: 'cancel' },
				{ 
					text: '삭제', 
					onPress: () => {
						requestDeleteQr();
					}
				}
			]
		);
	};
	const requestDeleteQr = async () => {
		console.log("@@ requestDeleteQr selectedItem=>", selectedItem);
		if (!selectedItem) return;
		const node = {} as RemoveDataRequest
			node.removeType='Q'
			node.myQrNo=selectedItem.qrNo
			node.serviceTypeCd=selectedItem.serviceTypeCd
			node.friendQrNo=''
			node.friendNo=''
			node.langCd=GlobalData.langCd

		console.log("Delete Friend 222", node);
		const info = await callPost('/api/main/removeData', node) as SaveResponse;
		if( info.code == '20005' ) {
			global.showToast('QR 삭제 되었습니다.');
			//QR리스트에서 제거함
			global.removeMyQr(selectedItem.qrNo);
			//state.setRemoveTypeData(null);
			//onClose();
			handleCloseModal();
		} else {
			global.showToast('친구 삭제 실패:' + info.message);
		}

	}

  // 모달 열기 핸들러
  const handleViewQrModModal = (item: ListMyQr) => {
	
	//global.setPopupPageId('QRViewPopup')
	console.log('ssssssssss')
	setSelectedItem(item);
	setModalVisible(true);
  };


	useEffect(() => {
		console.log("@@ useEffect global.qrClickData=>", global.qrClickData);
	}, []);


	const goToDownload = (qrNo:string , qrInfo:string ) => {
		Alert.alert(
			'QR 이미지',
			'다운로드를 하시겠습니까?',
			[
				{
					text: '취소',
					style: 'cancel',
				},
				{ text: '다운로드', onPress: () => downloadImage(qrNo, qrInfo) }, // OK 버튼 클릭 시 downloadImage 호출
			],
			{ cancelable: false }
		);
	};

	const downloadImage = async (qrNo:string, qrInfo:string) => {
		console.log("downloadImage==>", qrNo, qrInfo, qrImgInfo);
		// 다운로드할 파일의 경로
		if (GlobalData.deviTpCd === 'SA') {
			androidDownloadImage(qrNo, qrInfo);
		} else {
			iosDownloadImage(qrNo, qrInfo) ;
		}
	};

	const androidDownloadImage = async (qrNo:string, qrInfo:string) => {
		const { config, fs } = RNFetchBlob;
		let PictureDir = fs.dirs.DownloadDir; 
		let filePath = PictureDir + '/' + qrNo + '.png';
		
		return config({
			fileCache: true,
			addAndroidDownloads: {
				useDownloadManager: true, // Uses the Android native download manager
				notification: true,
				path: filePath,
				description: 'Image',
			},
		})
			.fetch('GET', qrInfo)
			.then(res => {
				console.log('The file saved to ', res.path());
			})
			.catch((error) => {
				console.error('Download error', error);
			});
		
	};


	// ios qr다운로드
	const iosDownloadImage = async (qrNo:string, qrInfo:string) => {
		const fileName = qrInfo.split('/').pop(); // 파일 이름 추출
		const filePath = `${RNFS.DocumentDirectoryPath}/${fileName}`; // 다운로드 경로

		try {
				// 이미지 다운로드
				const res = await RNFS.downloadFile({
						fromUrl: qrInfo,
						toFile: filePath,
						background: true,
				}).promise;

				if (res.statusCode === 200) {
					// 공유
					await Share.open({
							url: `file://${filePath}`, // 'file://' 접두사를 추가하여 파일을 Sharing
							type: 'image/jpeg', // 이미지 파일 타입
					});
					if (Platform.OS === 'android') {
						ToastAndroid.show('이미지가 공유되었습니다.', ToastAndroid.SHORT);
					} else {
						Alert.alert('성공', '이미지가 공유되었습니다.');
					}
				} else {
					if (Platform.OS === 'android') {
						ToastAndroid.show(`상태 코드: ${res.statusCode}`, ToastAndroid.SHORT);
					} else {
						Alert.alert('다운로드 실패', `상태 코드: ${res.statusCode}`);
					}
				}
		} catch (error) {
			console.error('파일 다운로드 중 오류 발생:', error);
			if (Platform.OS === 'android') {
				ToastAndroid.show('파일을 다운로드하는 동안 오류가 발생했습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert('다운로드 오류', '파일을 다운로드하는 동안 오류가 발생했습니다.');
			}
		}
};

	const handleOpenModal = (qrNo:string, serviceTypeCd:string) => {
		console.log("@@ QrClickData handleOpenModal serviceTypeCd=>", serviceTypeCd, qrNo);
		global.updateQrClickData({serviceTypeCd: serviceTypeCd , qrNo: qrNo});		
	};

	// QR추가 이벤트 처리
	const handleAddQR = () => {
		//부모에 QR추가 이벤트 전달함
		// props.onAddQR(serviceTypeCd);
		const state = useGlobalStore.getState();
		global.showToast('')
		if( state.qrClickData.serviceTypeCd == '' ) {
			return global.showToast('QR추가 서비스를 선택하세요');
		}

		global.setCurrentScanInfo({serviceTypeCd: global.qrClickData.serviceTypeCd, qrNo: '', viewType: 'Home',myQrNo: ''});
		global.setPopupPageId('ScanPopup');
	};

	const renderItem = ({ item }: { item: ListMyQr }) => {
		return (
			<View style={[styles.flat_qr_nonSelbg, global.qrClickData.qrNo === item.qrNo && styles.flat_qr_selbg]}>
				<View style={styles.container_row}>
					<TouchableOpacity style={[styles.qr_contener]} onLongPress={()=>handleEditPress(item)} onPress={() => handleOpenModal(item.qrNo, item.serviceTypeCd)}>
						<Image
							source={{ uri: item.imgFileUrl }}
							style={[styles.qrNonSelImg, global.qrClickData.qrNo === item.qrNo && styles.qrSelImg]}   
						/>
						<Text style={{ marginTop: 1, marginBottom: 1, fontSize: 16 , textAlign: 'left', paddingLeft: 3, }} numberOfLines={1}>
							{   item.nickNm.length > maxTextLength ?   item.nickNm.substring(0,maxTextLength) + '...' : item.nickNm }
						</Text>
					</TouchableOpacity>
				</View>
			</View>
		);
	};
	
	return (
		<View style={styles.container}>
			<View style={[styles.qrList_box, { backgroundColor: global.qrClickData.serviceTypeCd === '' ? '#F7F8FA' : '#FFEBD9'}]}>
				<FlatList 
					showsVerticalScrollIndicator={false}
					data={global.listMyQrCurrent} 
					renderItem={renderItem}
					keyExtractor={item => item.qrNo.toString()}
					horizontal={true} // 가로 방향으로 나열
					contentContainerStyle={styles.flat_container} // 아이템의 간격을 포함할 수 있는 스타일
				/>
				{/* <View style={styles.flat_view}>
					<TouchableOpacity style={styles.qr_contener} onPress={() => handleAddQR()}>
						<View>
							<Image
								source={addQRimageSource}
								style={{ width: 50, height: 50, borderRadius: 30 }}
							/>
						</View>
					</TouchableOpacity>
				</View> */}
			</View>
			{/* QR 상세 모달 */}
			<Modal
				animationType="fade"
				transparent={true}
				visible={modalVisible}
				onRequestClose={handleCloseModal}
			>
				<View style={modalStyles.centeredView}>
					<View style={modalStyles.modalView}>
						<TouchableOpacity onPress={handleCloseModal} style={{position:'absolute', right:20, top:15}}>
							<Text style={{fontSize:22, }}>X</Text>
						</TouchableOpacity>
						{/* 닉네임 표시 */}
						<Text style={modalStyles.nicknameText}>
						{selectedItem?.nickNm}
						</Text>
					
						{/* QR 번호 */}
						{selectedItem && (
							<TouchableOpacity onPress={handleCopy}>
								<Text>{selectedItem?.qrNo}</Text>
							</TouchableOpacity>
						)}
						{/* QR 바코드 이미지 */}
						{selectedItem && (
						<Image
							source={{ uri: selectedItem.qrInfo }}
							style={modalStyles.qrImage}
							resizeMode="contain"
						/>
						)}
						{/* QR 다운로드드 이미지 */}
						{selectedItem && (
						<TouchableOpacity style={styles.qr_contener} onPress={() => goToDownload(selectedItem.qrNo, selectedItem.qrInfo)}>
							<View>
								<Image
									source={require('../assets/ic_download.png')}
									style={modalStyles.down_image}
								/>
							</View>
						</TouchableOpacity>
						)}
						
						<View style={{flexDirection:'row', }}>
							{/* 삭제 버튼 */}
							<TouchableOpacity 
							style={modalStyles.deleteButton}
							onPress={handleDeleteItem}
							>
							<Text style={modalStyles.deleteButtonText}>삭제</Text>
							</TouchableOpacity>
							
							{/* 닫기 버튼 */}
							<TouchableOpacity 
							style={modalStyles.closeButton}
							onPress={handleCloseModal}
							>
							<Text style={modalStyles.closeButtonText}>닫기</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>
			</Modal>
		</View>

	);
};

export default ServiceQrBox ;

// 스타일 정의
const styles = StyleSheet.create({
	container: {
		alignItems: 'center',
		flex:1
	},
	title_box: {
		width: '94%',
		alignItems: 'center',
		padding: 10,
		flexDirection: 'row',
		justifyContent: 'space-between',
		borderTopLeftRadius: 10,   // 위 왼쪽 모서리를 둥글게
		borderTopRightRadius: 10,  // 위 오른쪽 모서리를 둥글게
		borderBottomLeftRadius: 0,  // 아래 왼쪽 모서리는 각지게
		borderBottomRightRadius: 0, // 아래 오른쪽 모서리는 각지게		
	},
	box: {
		width: '100%',
		padding: 10,
		borderWidth: 1,
		borderColor: '#FF851D',
		justifyContent: 'center', // 수직 중앙 정렬
		alignItems: 'flex-start',   // 수평 왼쪽 정렬
	},
	title_text: {
		fontSize: 14,
		fontWeight: 'bold',
		flex: 1
	},
	down_image: {
		width: 25,
		height: 25,
	},
	qrList_box: {
		flex:1,
		alignItems: 'center',
		flexDirection: 'row',
		//backgroundColor: '#FF851D',
		
	},
	qr_contener: {
		justifyContent: 'center', alignItems: 'center',
		
	},
	flat_container: {
		paddingHorizontal: 10, // 양쪽에 20의 패딩을 추가
	},
	flat_view: {
		paddingLeft: 10, // 양쪽에 20의 패딩을 추가
		paddingRight: 10, // 양쪽에 20의 패딩을 추가
	},
	container_row: {
		flexDirection: 'row', // 가로 방향으로 배치
		justifyContent: 'space-between', // 각 텍스트 사이에 여백을 추가
	},

	modalBackground: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0, 0, 0, 0.5)',
	},
	modalContainer: {
		backgroundColor: 'white',
		padding: 20,
		borderRadius: 10,
	},
	fullImage: {
		width: 300,
		height: 300,
	},
	closeButton: {
		marginTop: 10,
		paddingVertical: 10,
		paddingHorizontal: 20,
		backgroundColor: '#FF851D',
		borderRadius: 5,
	},
	closeButtonText: {
		color: 'white',
		fontSize: 16,
		textAlign: 'center',
	},
	flat_qr_nonSelbg: {
		paddingLeft: 10, // 양쪽에 20의 패딩을 추가
		paddingRight: 10, // 양쪽에 20의 패딩을 추가
		//borderRadius: 10,
		//backgroundColor:'white'
	},
	flat_qr_selbg: {
		paddingLeft: 10, // 양쪽에 20의 패딩을 추가
		paddingRight: 10, // 양쪽에 20의 패딩을 추가
		//borderRadius: 10,
		//backgroundColor:'white'
	
	},
	qrSelImg: {
		width: 75, 
		height: 75, 
		borderRadius: 15, 
		borderColor: 'red',
		borderWidth:2,
	},
	qrNonSelImg: {
		width: 75, 
		height: 75, 
		borderRadius: 5, 
		borderColor: 'white',
	}
});

const modalStyles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalView: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingTop: 25,
	
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  down_image: {
		width: 40,
		height: 40,
		marginTop: 0, 
		marginBottom: 30, 
	},
  nicknameText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  qrImage: {
    width: 200,
    height: 200,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#eee',
  },
  deleteButton: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
	flex:1,
	borderBottomLeftRadius:12,
	borderWidth:1,
	borderColor:'#ededed'
  },
  deleteButtonText: {
    color: 'red',
    fontWeight: 'bold',
    fontSize: 16,
  },
  closeButton: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
	flex:1,
	borderBottomRightRadius:12,
	borderWidth:1,
	borderColor:'#ededed'
  
  },
  closeButtonText: {
    color: 'gray',
    fontWeight: 'bold',
	fontSize: 16,
  },
});