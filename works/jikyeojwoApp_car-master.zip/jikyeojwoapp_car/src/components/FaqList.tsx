import React, { useEffect, useRef } from "react";
import { FlatList, Image, SafeAreaView,  StyleSheet, Text, TouchableOpacity, View } from "react-native";
//import useGlobalStore from "../store/global";
import { ApiFaqList, RootStackParamList } from "../types/common";
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';


export type FaqListRef = {
	goBack: () => void;
}
 
const FaqList = 
React.forwardRef<FaqListRef, {}>( (_props, ref) => {
	const [currentNode, setCurrentNode] = React.useState<ApiFaqList | null>(null);
	const listRef = useRef<FlatList>(null);
	const clickNode = (node: ApiFaqList) => {
		console.log("click faq item => ", node);
		setCurrentNode(node);
	};
	
	const goBack = () => {
		if (currentNode) {
			setCurrentNode(null);
		} else {
			navigation.goBack();
		}
	};
/*	const setFaqInfo = useGlobalStore(state=>state.setFaqInfo)
	const faqInfo = useGlobalStore(state=>state.faqInfo)
	const usePopup = useGlobalStore(state=>state.usePopup)
	const popupClose = useGlobalStore(state=>state.popupClose )
	const [loading, setLoading] = React.useState(true)
	const [currentNode, setCurrentNode] = React.useState<ApiFaqList|null>(null) 
	const clickNode = (node:ApiFaqList) => {
		console.log("click faq item => ", node)
		setCurrentNode(node)
	}
	const goBack = () => {
		if(currentNode) {
			setCurrentNode(null)
		} else {
			popupClose('FaqList')
		}
	}
	React.useImperativeHandle(ref, () => ({goBack}), [goBack] );

	React.useEffect(()=>{
		setLoading(true)
		setFaqInfo()
	}, [usePopup])
	
	// const [data,setData] = React.useState<ApiFaqList[]>([])
	React.useEffect(()=>{
		setLoading(false)
	}, [faqInfo])
	const data = faqInfo?.faqInfoList || []
	
	type RenderNodeProps = {
		node: ApiFaqList
		index: number
	}
	const RenderNode = ({node, index}:RenderNodeProps) =>  
		<TouchableOpacity onPress={() => clickNode(node)} key={index} style={{
			flexDirection: 'row',
			justifyContent: 'space-between',
			alignItems: 'center',
			paddingVertical: 15,
			margin:"auto",
			marginVertical: 5,
			borderColor: '#F08229',
			borderBottomWidth: 1,
			width:'90%'

		}}>
			<Text style={{
				flex:1,
				paddingLeft: 10,
				fontWeight: '500',
				color: '#555'
			}}>
				{node.faqTypeNm ? '['+node.faqTypeNm+'] '+node.faqSubject: node.faqSubject}
			</Text>
			<Image
				style={{width:16, height:27, resizeMode:'contain'}}
				source={require('@/assets/icon_next_bf.png')}
			/>
		</TouchableOpacity> 
*/
	const flatListRef = useRef<FlatList<any>>(null);

	useEffect(() => {
		// ref가 null이 아닐 때만 scrollToOffset을 호출합니다.
		if (flatListRef.current) {
			setTimeout(() => {
				flatListRef.current?.scrollToEnd({ animated: false });
			  }, 80); // 키보드 올라온 후 300ms 딜레이
		}
	  }, []);

	const RenderNode = ({ node, index }: RenderNodeProps) => (
		<TouchableOpacity
			onPress={() => clickNode(node)} // 변경됨
			key={index}
			style={{
				flexDirection: 'row',
				justifyContent: 'space-between',
				alignItems: 'center',
				paddingVertical: 15,
				marginVertical: 5,
				borderColor: '#F08229',
				borderBottomWidth: 1,
				width: '90%',
				alignSelf: 'center',
			}}
		>
			<Text
				style={{
					flex: 1,
					paddingLeft: 10,
					fontWeight: '500',
					color: '#555',
				}}
			>
				{node.faqTypeNm ? `[${node.faqTypeNm}] ${node.faqSubject}` : node.faqSubject}
			</Text>
			<Image
				style={{ width: 16, height: 27, resizeMode: 'contain' }}
				source={require('@/assets/icon_next_bf.png')}
			/>
		</TouchableOpacity>
	);

	type RenderNodeProps = {
		node: ApiFaqList
		index: number
	}
	const data: ApiFaqList[] = [
		{
			faqNo: '1',
			faqTypeNm: '일반',
			faqDate: '2025.05.07',
			faqSubject: '앱 사용 방법이 궁금해요.',
			faqDesc: '앱은 메인 화면에서 기능을 선택하여 사용할 수 있습니다.',
		},
		{
			faqNo: '2',
			faqTypeNm: '결제',
			faqDate: '2025.05.09',
			faqSubject: '결제가 실패했어요.',
			faqDesc: '결제 실패 시 카드사 또는 계좌 상태를 확인해 주세요.',
		},
		{
			faqNo: '3',
			faqTypeNm: '계정',
			faqDate: '2025.05.11',
			faqSubject: '비밀번호를 잊어버렸어요.',
			faqDesc: '로그인 화면에서 비밀번호 재설정을 눌러주세요.',
		},
		{
			faqNo: '4',
			faqTypeNm: '서비스',
			faqDate: '2025.05.12',
			faqSubject: '서비스 이용시간은 어떻게 되나요?',
			faqDesc: '서비스는 연중무휴 24시간 이용 가능합니다.',
		},
		{
			faqNo: '5',
			faqTypeNm: '기타',
			faqDate: '2025.05.13',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '6',
			faqTypeNm: '기타',
			faqDate: '2025.05.15',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '7',
			faqTypeNm: '기타',
			faqDate: '2025.05.16',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '8',
			faqTypeNm: '기타',
			faqDate: '2025.05.17',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '9',
			faqTypeNm: '기타',
			faqDate: '2025.05.21',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '15',
			faqTypeNm: '기타',
			faqDate: '2025.05.22',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '25',
			faqTypeNm: '기타',
			faqDate: '2025.05.23',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '35',
			faqTypeNm: '기타',
			faqDate: '2025.05.24',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '45',
			faqTypeNm: '기타',
			faqDate: '2025.05.25',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '55',
			faqTypeNm: '기타',
			faqDate: '2025.05.26',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '65',
			faqTypeNm: '기타',
			faqDate: '2025.05.27',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '75',
			faqTypeNm: '기타',
			faqDate: '2025.05.28',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '85',
			faqTypeNm: '기타',
			faqDate: '2025.05.31',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '95',
			faqTypeNm: '기타',
			faqDate: '2025.05.32',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '115',
			faqTypeNm: '기타',
			faqDate: '2025.05.33',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
		{
			faqNo: '125',
			faqTypeNm: '기타',
			faqDate: '2025.05.34',
			faqSubject: '기타 문의는 어떻게 하나요?',
			faqDesc: '고객센터에 전화 또는 이메일로 문의 주세요.',
		},
	];


	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();
	const handleGoHome = () => {
		navigation.navigate('MainHome');
	};


	return (
		<SafeAreaView style={styles.bottomContainer}>
			<View style={styles.headerContainer}>
				<TouchableOpacity style={styles.prevButton} onPress={() => {
					if (currentNode) {
					setCurrentNode(null); // FAQ 상세 화면에서 리스트로 돌아감
					} else {
					navigation.goBack(); // 리스트 화면이라면 뒤로 가기
					}
				}}>
					<Image
					source={require('../assets/ic_arr_left.png')}
					style={styles.prevIcon}
					/>
				</TouchableOpacity>

				<View style={styles.titleContainer}>
					<Text style={styles.titleText}>FAQ</Text>
				</View>
			</View>
			<View style={{
				flex:1,
				backgroundColor: '#fff',
			}}>
				
				<View style={styles.main}> 
					{ /*loading ? (
						<ActivityIndicator size="large" color="#F08229" style={{
							position:'absolute', 
							top:(height-80)/2, left:(width-80)/2,
							width:80, height:80, 
						}}/>
					) : data.length === 0 ? (
						<Text style={ styles.noDataText}>목록이 존재하지 않습니다.</Text>
					) : (
					<>*/}
					{currentNode ? (
						<View style={{ padding: 20 }}>
							<Text style={{ fontSize: 12, color: '#888', marginBottom: 8 }}>{currentNode.faqDate}</Text>
							<Text style={{ fontSize: 16, fontWeight: 'bold', marginBottom: 12 }}>{currentNode.faqSubject}</Text>
							<Text style={{ fontSize: 14, color: '#555', lineHeight: 20 }}>{currentNode.faqDesc}</Text>
						</View>
					) : (
						<FlatList
							ref={flatListRef}
							data={data}
							keyExtractor={(item) => item.faqNo.toString()}
							renderItem={({ item, index }) => <RenderNode node={item} index={index} />}
							contentContainerStyle={styles.listContainer}
							removeClippedSubviews={false}
						/>
					)}
				</View>
			</View>
		</SafeAreaView>
	);
}

);

export default FaqList;

const styles = StyleSheet.create({ 
	header: {
	  backgroundColor: '#F08229',
	  height: 60, // 헤더 높이 고정
	  justifyContent: 'center', // 헤더 전체 수직 중앙 정렬
	  alignItems: 'center', // 텍스트 중앙 정렬
	  position: 'relative', // 자식 요소의 절대 위치 기준
	},
	bottomContainer: {
	  flex: 1,
	  width: '100%',
	  height: '100%',
	  justifyContent: 'flex-end',
	  backgroundColor: '#F7F8FA',
	},
	preBtn: {
	  position: 'absolute', // 헤더의 왼쪽 상단에 고정
	  left: 5, // 왼쪽 여백
	  top: 5, // 위쪽 여백
	  width: 50,
	  height: 50,
	  justifyContent: 'center', // 버튼 중앙 정렬
	  alignItems: 'center',
	},
	headerContainer:{
	  height: 60,
	  backgroundColor: '#f2f7fcff',
	  flexDirection: 'row',
	  alignItems: 'center',
	  paddingHorizontal: 10,
	},
	prevIcon: {
	  width: 17,
	  height: 17,
	  resizeMode: 'contain',
	},
	prevButton: {
	  width: 40,
	  alignItems: 'center',
	  justifyContent: 'center',
	},
	titleContainer: {
	  flex: 1,
	  alignItems: 'center',
	},
	titleText: {
	  fontSize: 16,
	  fontWeight: 'bold',
	  color: '#333',
	},
	homeIcon: {
	  width: 30,
	  height: 30,
	  resizeMode: 'contain',
	},
	preBtnImgSize: {
	  height: '100%',
	  resizeMode: 'contain', // 이미지 비율 유지하며 크기 조정
	},
	headerTitle: {
	  fontSize: 20, // 텍스트 크기
	  fontWeight: 'bold', // 텍스트 두께
	  color: '#fff', // 텍스트 색상
	},
	main: {
	  flex: 1, // 남은 공간 차지
	  padding: 10,
	},
	noDataText: {
	  fontSize: 16,
	  color: '#555',
	  textAlign: 'center',
	  marginTop: 20,
	},
	iptBox:{
	  justifyContent: 'center',
	  borderColor: '#F08229',
	  borderBottomWidth: 1,
	  width:'90%',
	  height: 50
	},
	listContainer: {
	  paddingBottom: 20,
	  width: '100%',
	},
	listItem: {
	  flexDirection: 'row',
	  justifyContent: 'space-between',
	  padding: 15,
	  marginVertical: 5,
	  borderColor: '#F08229',
	  borderBottomWidth: 1,
	},
	itemTitle: {
	  paddingLeft: 10,
	  fontSize: 16,
	  fontWeight: '500',
	  color: '#333',
	},
	itemDate: {
	  fontSize: 14,
	  color: '#666',
	},
});