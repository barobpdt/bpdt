import React from 'react';
import { View, TouchableOpacity, StyleSheet, Image, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';
import { RootStackParamList } from '../types/common.tsx';

type TopTabBarProps = {
  title?: string;
};

const TopTabBar: React.FC<TopTabBarProps> = ({ title }) => {
  const navigation = useNavigation<StackNavigationProp<RootStackParamList>>();

  const handleBack = () => {
    navigation.goBack();
  };

  const handleGoHome = () => {
    navigation.navigate('MainHome');
  };

  return (
    <View style={styles.headerContainer}>
      <TouchableOpacity style={styles.prevButton} onPress={handleBack}>
        <Image
          source={require('../assets/ic_arr_left.png')}
          style={styles.prevIcon}
        />
      </TouchableOpacity>

      <View style={styles.titleContainer}>
        <Text style={styles.titleText}>{title}</Text>
      </View>

      <TouchableOpacity style={styles.homeButton} onPress={handleGoHome}>
        <Image
          source={require('../assets/ic_home_copy.png')}
          style={styles.homeIcon}
        />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    height: 60,
    backgroundColor: '#f2f7fcff',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
  },
  prevButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  homeButton: {
    width: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  prevIcon: {
    width: 17,
    height: 17,
    resizeMode: 'contain',
  },
  homeIcon: {
    width: 30,
    height: 30,
    resizeMode: 'contain',
  },
  titleContainer: {
    flex: 1,
    alignItems: 'center',
  },
  titleText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
});

export default TopTabBar;
