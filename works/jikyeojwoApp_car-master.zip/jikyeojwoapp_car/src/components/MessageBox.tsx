import React, { useState, useEffect, useContext } from 'react';
import { View, Text, TouchableOpacity, StyleSheet ,ScrollView, Image, Alert, Modal} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import {MessageBoxProps, ListRoomMessage, FriendList, MessageData, ListMyQr, RemoveData} from '../types/common';
import {useGlobalStore, GlobalData, GetDate, MembInfo} from '../store/global';

import { SocketStompContext  } from '../utils/WebSocketManager';



const MessageBox: React.FC<MessageBoxProps> = ({ blDelType, msgItem, friendItem, groupItem, callMsgStack}) => {

	const global = useGlobalStore();
	const [profileImg, setProfileImg] = useState<string[]>([]);
	//const [blMsg, setBlMsg] = useState(true);

	const { sendMessage} = useContext(SocketStompContext);
	//위치요청 모달
	const [isReqLocationModal, setIsReqLocationModal] = useState(false);

	
	const today = new Date().toISOString().split('T')[0].replaceAll('-','.');


	useEffect(() => {
		//msgItem == null ? setBlMsg(false) : setBlMsg(true) ;
		
		if (friendItem ) {		
			const friendImg = friendItem?.imgFileUrl ? friendItem.imgFileUrl.split(',') : [];
			setProfileImg(friendImg);
		} 
		 if (msgItem )  {
			const imgArr = msgItem?.profileImgFileUrl ? msgItem.profileImgFileUrl.split(',') : [];
			setProfileImg(imgArr);
		} 
		 if (groupItem )  {
			//그룹일경우
			const friendImgg = groupItem?.profileImgFileUrl ? groupItem.profileImgFileUrl.split(',') : [];
			setProfileImg(friendImgg);
		}
		// console.log("=====================================");
		
		
		// console.log("@@ friendItem", friendItem, global.listFriend);
	}, []);


	useEffect(() => {

	}, [profileImg]);


	const viewProfileImg = () => {

		// console.log("profile img ", profileImg);
		const imgCnt = profileImg?.length || 0 ;
		// console.log("profile img imgCnt", imgCnt);
		const imgWidth = 60;
		if (!profileImg || imgCnt === 0) {
			return null; // or render some placeholder
		}
		const imageStyle = {
			width: imgCnt === 1 ? imgWidth : imgWidth/2,
			height: imgCnt === 1 ? imgWidth : imgWidth/2
		};
		

		if(imgCnt>2){
			const firstRow = profileImg.slice(0, 2);
			const secondRow = profileImg.slice(2, 4);

			return (      
				<View>
					{/* 첫 번째 줄 렌더링 */}
					<View style={styles.imgContainer}>
					{firstRow.map((image, index) => (
						<Image
						key={index}
						source={{ uri: image }}
						style={[styles.image, imageStyle]}
						resizeMode="cover"
						/>
					))}
					</View>
					
					{/* 두 번째 줄 렌더링 */}
					<View style={[styles.imgContainer, {justifyContent:'center'}]}>
					{secondRow.map((image, index) => {
						// 원본 배열에서의 실제 인덱스 계산 (2, 3)
						const originalIndex = index + 2;
						return (
						<Image
							key={originalIndex} // 고유 인덱스 보장
							source={{ uri: image }}
							style={[styles.image, imageStyle]}
							resizeMode="cover"
						/>
						);
					})}
					</View>
				</View>
				);
			} else{//변경할 사항없음
			return (      
				<View style={styles.imgContainer}>
					{profileImg.map((image, index) => (
						<Image
							key={index}
							source={{ uri: image }} // 이미지 URL을 설정
							style={[styles.image, imageStyle, ]}
							resizeMode="cover" // 이미지 크기 조정 방식
						/>
					))}
				</View>
			);
		}
	}


	//친구 삭제 모달 오픈
	const delFriend = ()=>{
		console.log('sssss');
		global.setLocationFriendItem(friendItem);
		global.setPopupPageId('DeleteFriend');
	}

	//위치요청 모달 오픈
	const reqLocation = () => {
		if (friendItem?.friendLocationCd == '10' || friendItem?.friendLocationCd == '90' ) {
			//setIsReqLocationModal(true);
			global.setLocationFriendItem(friendItem);
			global.setPopupPageId('LocationRequestPop');
		}
	}

	
	const allowLocation = () => {
		if (friendItem?.membLocationCd !== '30' && friendItem?.membLocationCd !== '50' ) {
			return;
		}

		if (friendItem?.membLocationCd === '30' ) {
			const findQrInfo = global.listMyQr.find(m => m.qrNo === friendItem?.membQrNo);
			if (findQrInfo) {
				global.setCurrentLocationRequest(locationMsgParam(findQrInfo, 'A'));
				global.setPopupPageId('LocationAllowPop');
			}

		} else if (friendItem?.membLocationCd === '50' ) {
			const findQrInfo = global.listMyQr.find(m => m.qrNo === friendItem?.membQrNo);
			if (findQrInfo) {
				global.setCurrentLocationRequest(locationMsgParam(findQrInfo, 'O'));
				global.setPopupPageId('LocationAllowPop');
			}
		} 

		
	}


	const locationMsgParam = (findQrInfo:ListMyQr, createType: string) => {  // C RL 전송, A 응답 처리  , O 승인취소처리 CL
		
		const msgData = {
			mType: createType === 'O' ? 'CL' : 'RL',
			mykey: GlobalData.myKey,
			msgDesc: createType === 'C' ? friendItem?.nickNm : global.membInfo.nickNm,
			qrNo: createType === 'C'  ? friendItem?.membQrNo : friendItem?.friendQrNo, //friendItem?.membQrNo,
			langCd: GlobalData.langCd,
			currentDate: GetDate(),
			callSeq: '',
			roomId: createType === 'C'  ? friendItem?.friendSubScr : findQrInfo.subScr,
			targetRoomId: createType === 'C'  ? findQrInfo.subScr : friendItem?.friendSubScr ,
			membNo: createType === 'C'  ? friendItem?.membNo : friendItem?.friendNo , //,
			writeMembNo: createType === 'C'  ? friendItem?.friendQrNo : friendItem?.membQrNo,  //,
			counterPart: createType === 'C' ? friendItem?.friendNo : GlobalData.membNo, //,
			onOff: 'Y',
			serviceTypeCd: 'Protect',
			fileImgUrl: '',
			filePath: '',
			callCount: 0,
			writeNickNm: createType === 'C'  ? findQrInfo.nickNm  : friendItem?.nickNm, 
			writeImgFileUrl:createType === 'C' ? findQrInfo.imgFileUrl : friendItem?.imgFileUrl,
			msgTypeCd:'T'
		} as MessageData;	
		
		return msgData;
	}

	const toggleModal = (act: string) => {  // act C close , R reqtuest

		global.setLocationFriendItem(friendItem);
		global.setPopupPageId('');
		// setIsReqLocationModal(false);
		// if (act === 'R') {
		// 	const findQrInfo = global.listMyQr.find(m => m.qrNo === friendItem?.membQrNo);
		// 	console.log("@@ findQrInfo", friendItem, findQrInfo);
		// 	if (findQrInfo) {
		// 		const msgData = locationMsgParam(findQrInfo,'C')	;	
		// 		console.log("@@ msgData", msgData);
		// 		sendMessage(msgData, msgData.roomId);
		// 		//로컬값 변경 
		// 		global.setReqLocationStatus('F', GlobalData.membNo, friendItem?.membQrNo?? null, friendItem?.friendNo ?? null, friendItem?.friendQrNo ?? null, '20','수락대기중');
		// 		//global.setLocationStatus(msgData, '20', '요청중');
		// 	} else {
		// 		Alert.alert('전송 실패하였습니다.');
		// 	}			
		// }
	}

	const closePop = () => {
		setIsReqLocationModal(false);
	}

	//상위에 호출하여 채팅창호출하도록 함
	const goToServiceMove = (jobCd:string) => {
		console.log("messagebox jobCd" , jobCd);
		if (jobCd === 'K') {
			if (msgItem == null ) return;
			console.log("messagebox msgItem" , msgItem);

			if (msgItem.serviceTypeCd === 'Car') {return;};

			const existGroup = global.listGroup.find(item => item.roomNo === msgItem.roomNo);
			console.log("messagebox existGroup" , existGroup);
			if (existGroup) {
				jobCd = 'GK';
			} else { 
				jobCd = 'FK';
			}
		}
		console.log("messagebox call jobCd" , jobCd);
		callMsgStack(jobCd, msgItem, friendItem, groupItem);  //채팅창열기위해 상위에 호출  
		//msgItem, friendItem
		// jobCd  = D   relNo : callSeq   etcInfo ''  차빼줘 내역 삭제  roomNm
		// jobCd  = F   relNo : roonNo   etcInfo  friendNo   친구 프로필 이동  roomNm
		// jobCd  = G   relNo : roonNo   etcInfo  friendNo   그룹 정보 이동  roomNm
		// jobCd  = T   relNo : roonNo   etcInfo  serviceTypeCd  subScr 채팅창 이동  roomNm
		// jobCd  = L   relNo : roonNo   etcInfo  friendNo   위치정보 허용 요청 등 처리  roomNm
		// jobCd  = C   relNo : roonNo   etcInfo  friendNo   차빼줘 채팅창으로 이동  roomNm		
		// jobCd  = A   relNo  : roomNo  그룹채팅방이동
		// K로 넘어오면 msgItem의 roomTypeCd가 SG이면 F, GP 이면 G로 변경
		//FC ==> 친구에서 이름 클릭시 채팅방으로 이동처리
	}  
	const friendDeleteModal = ()=>{


	}



	// 메세지 화면 구성 조건에 따라 구현 처리
	const getMsgContent = () => {
		if ( msgItem && msgItem?.serviceTypeCd == 'Car') {
			return <View style={[styles.textContainer, {paddingBottom: 15}]}>
					
						<View style={styles.container_row}>
							<Text style={styles.text_title}>{msgItem?.nickNm} {msgItem?.msgTypeCd == "T" ? '(문자호출)' : '(통화호출)'} </Text>
							<Text style={styles.text_status}>{msgItem?.notReadYn == "Y" ? '응답완료' : '미응답'} </Text>
						</View>
					
						<View style={styles.container_row}>
							<TouchableOpacity onPress={() => goToServiceMove("C")} >
									<View style={styles.textContainer}>
										<Text style={styles.text_msg} numberOfLines={2}>{msgItem?.msgDesc}</Text>
										<Text style={styles.text_remsg} numberOfLines={2}>    {msgItem?.msgReDesc}</Text>
										<Text style={styles.text_remsg}>{msgItem?.addDt}  {msgItem?.addTime}</Text>
									</View>
								</TouchableOpacity>
						{blDelType && 
							<TouchableOpacity onPress={() => goToServiceMove("D")} >
								<Image source={require('../assets/ic_del.png') } style={styles.delImg} />
							</TouchableOpacity>
						}
					</View>
			</View> ;
		} else if (msgItem &&  msgItem?.serviceTypeCd == 'Protect' && (msgItem?.msgTypeCd == "T" || msgItem?.msgTypeCd == "B")) {
			{/* 지켜줘 대화정보 텍스트 */}
			return  <View style={styles.textContainer}>
				<TouchableOpacity onPress={() => goToServiceMove("T")} >
					<View style={styles.container_row}>
						<Text 
							numberOfLines={1}
							ellipsizeMode="tail"
							style={styles.text_title}>{msgItem?.nickNm}</Text>
						{/* <Text style={styles.text_remsg}>{today === msgItem.addDt ? msgItem.addTime : `${msgItem.addDt} ${msgItem.addTime}`}</Text> */}
						<Text style={styles.text_remsg}>{msgItem.addDt} {msgItem.addTime}</Text>
					</View>
					<View style={styles.container_row}>
						<Text style={styles.text_dtlmsg} numberOfLines={2}>
							{ GlobalData.SettingData.hideMsgYn == 'Y' ? '메세지' : msgItem?.msgDesc}
						</Text>
						{ msgItem?.notReadCnt > 0 && <View style={styles.badge}>
							<Text style={styles.badgeText}>{msgItem?.notReadCnt}</Text>
						</View>  }
					</View>
				</TouchableOpacity>
			</View>;

		} else if (msgItem &&  msgItem?.serviceTypeCd == 'Protect' && msgItem?.msgTypeCd == "F")  {
			{/* 대화 파일 전송 부분 */}
			return <View style={styles.textContainer}>
					<TouchableOpacity onPress={() => goToServiceMove("T")} >
						<View style={styles.container_row}>
							<Text style={styles.text_title}>{msgItem?.nickNm}</Text>
							<Text style={styles.text_remsg}>{msgItem.addDt} {msgItem.addTime}</Text>
						</View>
						<View style={styles.container_row}>
							<Text style={styles.text_dtlmsg} numberOfLines={2}>{msgItem?.msgDesc}</Text>
							{msgItem?.notReadCnt > 0 && <View style={styles.badge}>
								<Text style={styles.badgeText}>{msgItem?.notReadCnt}</Text>
							</View> }
						</View>
					</TouchableOpacity>
				</View>;
		} else if (!msgItem &&  groupItem)  { 
			//그룹채팅 디자인
			return <View style={[styles.textContainer]}>
				<View style={{flexDirection:'row', justifyContent:'space-between'}}>
				
					<TouchableOpacity  style={{flex:1}} onPress={() => goToServiceMove("A")} >
						<Text 
							numberOfLines={1}
							ellipsizeMode="tail"
							style={[styles.text_title, {marginBottom:5}]}>{groupItem.nickNm}</Text>
						<Text style={{fontSize:12, }}>참여인원: {groupItem.roomMembCnt}명</Text>
					</TouchableOpacity>
					
				</View>
			</View>
		} else if (!msgItem && !groupItem )  {
			{/* 친구 정보 */}
			const imageSource = !(friendItem?.friendLocationCd == "10"||friendItem?.friendLocationCd == "90") ? require('../assets/ic_locat_find_enable.png') : require('../assets/ic_locat_find.png') ;
		
			return <View style={styles.textContainer}>
						<View style={styles.container_row}>
						
							<TouchableOpacity style={{flex:1}} onLongPress={()=>delFriend()} onPress={() => goToServiceMove("FC")} >
								<Text 
							numberOfLines={1}
							ellipsizeMode="tail"
							style={styles.text_title}>{friendItem?.nickNm}</Text>
								<View style={styles.container_row}>
									<Text style={styles.text_dtlmsg}
										ellipsizeMode="tail"
										numberOfLines={2}>{friendItem?.introductionInfo}
									</Text>
								</View>
							</TouchableOpacity> 
							<View>
								<TouchableOpacity style={{flexDirection:'row', justifyContent:'space-between', paddingHorizontal:7,}}  onPress={() => reqLocation()}>
									<Text style={[styles.text_title, {marginRight:10, flex:1, textAlign:'center'}]}>{friendItem?.friendLocationNm}</Text>
									<Image 
										source={imageSource} // 임시 이미지 URL 사용  ../assets/ic_locat_find.png  friendNo, membQrNo, friendQrNo ==> 친구 프로필 정보 가기 
										style={styles.locat_image} 
									/>
								</TouchableOpacity>
							
								<TouchableOpacity style={{marginTop:10}} onPress={() => allowLocation()}>
									<View style={[styles.container_locat_row, ]}>
										<View style={[(friendItem?.membLocationCd == "10"|| friendItem?.membLocationCd == "90") ?  styles.outerDisibleSelBox:styles.outerSelBox]}>
											<Text style={[styles.outerText, (friendItem?.membLocationCd == "10"|| friendItem?.membLocationCd == "90") ? {color:'black',}:{color:'white',}]}>
												{friendItem?.membLocationNm}
											</Text>
										</View>
									</View>
								</TouchableOpacity>
							</View>
						</View>
						<Modal
							visible={isReqLocationModal}
							transparent={true}
							animationType='slide'
							onRequestClose={closePop} // Android의 백 버튼 처리
						>
						<View style={styles.modalContent}>
							<Text style={styles.title}>위치요청</Text>
							<Text style={styles.message}>{friendItem?.nickNm}에게 위치 허용 요청 하시겠습니까?</Text>
							<View style={styles.buttonContainer}>
								<TouchableOpacity style={styles.button} onPress={() => { toggleModal('C')}}>
									<Text style={styles.buttonText}>취소</Text>
								</TouchableOpacity>
								<TouchableOpacity style={styles.button} onPress={() => {
									console.log('요청 Pressed');
									toggleModal('R');
								}}>
									<Text style={styles.buttonText}>요청</Text>
								</TouchableOpacity>
							</View>
						</View>
					</Modal>
				</View>;
		}
		return '';
	};

	const getImgContent = () => {
		if (msgItem) {
			return <View style={styles.container}> 
				<View style={styles.box} >
					<TouchableOpacity  onLongPress={()=>delFriend()} onPress={() => goToServiceMove("K")}>
						{viewProfileImg()}
					</TouchableOpacity>
					{getMsgContent()}
				</View>
			</View> ;
		} 
		 if(friendItem) {
			return <View style={styles.container}>
			
				<View style={[styles.box,]}>
					<TouchableOpacity  onLongPress={()=>delFriend()} onPress={() => goToServiceMove("F")}>
						{viewProfileImg()}
					</TouchableOpacity>
					{getMsgContent()}
				</View>
			</View> ;
		} 
		 if(groupItem) {
			return <View style={styles.container}>
				
				<View style={styles.box}>
					<TouchableOpacity  onLongPress={()=>delFriend()} onPress={() => goToServiceMove("G")}>
						{viewProfileImg()}
					</TouchableOpacity>
					{getMsgContent()}
				</View>
			</View> ;
		}
	};

	return getImgContent();
};

export default MessageBox ;

// 스타일 정의
const styles = StyleSheet.create({
	container: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
	},
	container_row: {
			flexDirection: 'row', // 가로 방향으로 배치
			justifyContent: 'space-between', // 각 텍스트 사이에 여백을 추가
			marginTop:6,
		},
	container_locat_row: {
			flexDirection: 'row', // 가로 방향으로 배치
			justifyContent: 'flex-end', // 각 텍스트 사이에 여백을 추가space-between
			marginTop: 5,
		},
	imgContainer: {
			flexDirection: 'row',
			flexWrap: 'wrap',
			justifyContent: 'space-between',
			marginRight:15
	},
	box: {
		width: '94%',
		maxHeight: 150,
		flexDirection: 'row',
		alignItems: 'center',
		padding: 10,
		backgroundColor: '#FFF9F3',
		borderColor: '#ffac55',
		borderWidth:1,
		borderRadius: 10,
		marginTop: 7
	},
	image: {
		borderRadius: 40, // 원형 이미지로 만들고 싶을 때 사용
		fontFamily: 'NotoSansKr'
	},
	locat_image: {
		width: 25,
		height: 25,
		
	},
	textContainer: {
		padding:5,
		flex: 1,
	},
	text_title: {
		fontSize: 16,
		marginTop: 2,
		maxWidth:170,
		fontWeight: 'bold',
		fontFamily: 'NotoSansKr', 
		overflow: 'hidden',
		flexShrink: 1, // 너무 길 경우 텍스트가 잘리게 함
	},
	text_msg: {
			fontSize: 12,
			marginTop: 2,
			paddingRight: 50,
			fontWeight: 'bold',
			fontFamily: 'NotoSansKr',
		},
	text_dtlmsg: {
		fontSize: 12,
		marginTop: 2,
		paddingRight: 50,
		fontFamily: 'NotoSansKr',
		maxWidth:250,
	},
	text_remsg: {
		fontSize: 12,
		marginTop: 2,
		fontFamily: 'NotoSansKr',
},
	text_status: {
			fontSize: 10,
			marginTop: 8,
			marginRight: 10,
			fontFamily: 'NotoSansKr',
	},
	line: {
		width: '94%', // 박스의 전체 너비 사용
		height: 1, // 선의 높이
		backgroundColor: '#72787F', // 선의 색상 (검정색)
	},
	badge: {
		backgroundColor: '#FF851D', // 주황색
		borderRadius: 15,          // 동그라미 형태 만들기
		width: 20,                 // 동그라미 너비
		height: 20,                // 동그라미 높이
		justifyContent: 'center',   // 수직 중앙 정렬
		alignItems: 'center',       // 수평 중앙 정렬
	},
	badgeText: {
		color: 'white',            // 텍스트 색상
		fontWeight: 'bold',        // 텍스트 두께
	},
	locat_box: {
		width: '100%',
		marginTop: 3, 
		padding: 5,        
		backgroundColor: '#FF851D',
		borderRadius: 10,
		justifyContent: 'center',   // 수직 중앙 정렬
		alignItems: 'center',       // 수평 중앙 정렬
	},
	outerContainer: {
		flexDirection: 'row',       // 가로 방향으로 배치
		justifyContent: 'space-between', // 각 텍스트 사이에 여백을 추가
		alignItems: 'center',        // 세로 방향에서 중앙 정렬
	},
	outerBox: {
		borderWidth: 1,             // 테두리 두께
		width: 120,
		height: 25,
		borderColor: '#FF851D',        // 테두리 색상
		padding: 3,                // 내부 여백
		borderRadius: 10,           // 모서리 둥글게
		backgroundColor: '#f0f0f0', // 배경색
	},
	outerSelBox: {
		width: 120,
		height: 25,
		padding: 3,                // 내부 여백
		borderRadius: 10,           // 모서리 둥글게
		backgroundColor: '#FF851D', // 배경색
	},
	outerDisibleSelBox: {
		width: 120,
		height: 25,
		padding: 3,                // 내부 여백
		borderRadius: 10,           // 모서리 둥글게
		backgroundColor: '#D3D3D3', // 배경색
	},
	outerText: {
		fontSize: 12,               // 텍스트 크기
		textAlign: 'center',         // 텍스트 중앙 정렬
	},
	delImg: {
		width: 20,
		height: 20,
		marginTop: 20,
		marginRight: 10,
	},
	modalContent: {
		height: 200,
		marginHorizontal: 30,
		backgroundColor: 'white',
		borderRadius: 10,
		padding: 15,
		justifyContent: 'space-between',
	},
	button: {
		flex: 1, // 50% 너비
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: '#DDD',
		marginHorizontal: 5,
		borderRadius: 5,
	},
	title: {
		fontSize: 20,
		fontWeight: 'bold',
		alignSelf: 'center',
	},
	message: {
		fontSize: 16,
		alignSelf: 'center',
		textAlign: 'center',
		flex: 1,
		marginVertical: 10,
	},
	buttonContainer: {
		flexDirection: 'row',
		width: '100%',
		height: 50,
	},
	modalWrapper: {
		justifyContent: 'center', // 화면 가운데 정렬
		margin: 0, // 화면 전체를 덮도록
	},
	buttonText: {
		fontSize: 14,
	},
});