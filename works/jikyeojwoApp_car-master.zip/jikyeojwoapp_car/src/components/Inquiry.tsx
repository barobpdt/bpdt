
import React from "react";
import { Image, KeyboardAvoidingView, SafeAreaView, StyleSheet, Text, TextInput, TouchableOpacity, View } from "react-native";
import { RootStackParamList } from "../types/common";
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';

type props = {
	top:number;
	width: number;
	height: number;
}
const InquiryEmail = () => {
	const [loading, setLoading] = React.useState(true)
	const [inputEmail, setInputEmail] = React.useState('');
	const [inputTitle, setInputTitle] = React.useState('');
	const [inputContent, setInputContent] = React.useState(''); // 내용 상태 추가

	const navigation = useNavigation<StackNavigationProp<RootStackParamList>>(); //상위 네이게이션 값 받아옴
	
	const saveEmail = () => {
		if( !inputEmail ) {
			global.alert('메일주소가 등록되지 않았습니다')
			return
		}
		if( !inputTitle ) {
			global.alert('제목이 등록되지 않았습니다')
			return
		}
		if( !inputContent ) {
			global.alert('내용이 등록되지 않았습니다')
			return
		}

	}

	return (
		<View style={{flex:1}}>
			<View style={styles.headerContainer}>
				<TouchableOpacity style={styles.prevButton} onPress={() =>navigation.goBack()}>
					{<Image
					source={require('../assets/ic_arr_left.png')}
					style={styles.prevIcon}
					/>}
				</TouchableOpacity>
				<View style={styles.titleContainer}>
					<Text style={styles.titleText}>문의메일</Text>
				</View>
			</View>

			{/* 본문 입력 영역 */}
			<KeyboardAvoidingView style={{ flex: 1 }}>
			<View style={styles.iptArea}>
				<View style={styles.iptBox}>
				<TextInput
					style={styles.textIpt}
					onChangeText={setInputEmail}
					placeholder="이메일"
					value={inputEmail}
				/>
				</View>

				<View style={styles.iptBox}>
				<TextInput
					style={styles.textIpt}
					onChangeText={setInputTitle}
					placeholder="제목"
					value={inputTitle}
				/>
				</View>

				<View style={styles.iptContent}>
				<Text style={styles.contentInq}>내용</Text>
				<TextInput
					style={[styles.textIpt, styles.textArea]}
					onChangeText={setInputContent}
					multiline
					numberOfLines={20}
					value={inputContent}
				/>
				</View>
			</View>
			</KeyboardAvoidingView>

			{/* 버튼 영역 - 화면 하단 고정 */}
			<View style={styles.btnBox}>
			<TouchableOpacity style={styles.btnSquareCancel}>
				<Text style={styles.btnCancelText}>취소</Text>
			</TouchableOpacity>
			<TouchableOpacity onPress={saveEmail} style={styles.btnSquareOk}>
				<Text style={styles.btnOkText}>확인</Text>
			</TouchableOpacity>
			</View>
		</View>
	);
};

export default InquiryEmail;

const styles = StyleSheet.create({
	headerContainer: {
	  height: 60,
	  backgroundColor: '#f2f7fcff',
	  flexDirection: 'row',
	  alignItems: 'center',
	  paddingHorizontal: 10,
	},
	prevButton: {
	  width: 40,
	  alignItems: 'center',
	  justifyContent: 'center',
	},
	prevIcon: {
	  width: 17,
	  height: 17,
	  resizeMode: 'contain',
	},
	titleContainer: {
	  flex: 1,
	  alignItems: 'center',
	},
	titleText: {
	  fontSize: 16,
	  fontWeight: 'bold',
	  color: '#333',
	},
	iptArea: {
	  alignItems: 'center',
	  paddingVertical: 20,
	  gap: 15,
	},
	iptBox: {
	  justifyContent: 'center',
	  borderColor: '#F08229',
	  borderBottomWidth: 1,
	  width: '90%',
	  height: 50,
	},
	textIpt: {
	  fontSize: 14,
	  color: '#333',
	  paddingHorizontal: 5,
	  paddingVertical: 10,
	},
	contentInq: {
	  alignSelf: 'flex-start',
	  paddingLeft: '5%',
	  marginBottom: 5,
	  fontSize: 14,
	  fontWeight: 'bold',
	  color: '#555',
	},
	iptContent: {
	  width: '90%',
	},
	textArea: {
	  borderWidth: 1,
	  borderColor: '#F08229',
	  borderRadius: 6,
	  padding: 10,
	  minHeight: 150,
	  textAlignVertical: 'top',
	  fontSize: 14,
	  color: '#333',
	},
	btnBox: {
	  flexDirection: 'row',
	  justifyContent: 'space-between',
	  paddingHorizontal: '5%',
	  paddingVertical: 20,
	},
	btnSquareCancel: {
	  flex: 1,
	  backgroundColor: '#ddd',
	  marginRight: 10,
	  borderRadius: 6,
	  justifyContent: 'center',
	  alignItems: 'center',
	  height: 48,
	},
	btnSquareOk: {
	  flex: 1,
	  backgroundColor: '#F08229',
	  marginLeft: 10,
	  borderRadius: 6,
	  justifyContent: 'center',
	  alignItems: 'center',
	  height: 48,
	},
	btnCancelText: {
	  color: '#333',
	  fontWeight: 'bold',
	  fontSize: 16,
	},
	btnOkText: {
	  color: '#fff',
	  fontWeight: 'bold',
	  fontSize: 16,
	},
  });
  