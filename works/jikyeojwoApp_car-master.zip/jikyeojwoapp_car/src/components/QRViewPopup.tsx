import React, { useState } from 'react';
import { View, Text, Image, TouchableOpacity, FlatList, Modal, StyleSheet, Dimensions, Alert } from 'react-native';

const QrListScreen = () => {
  // 상태 관리
  const [selectedQrNo, setSelectedQrNo] = useState<number | null>(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const maxTextLength = 10; // 최대 텍스트 길이

const { width, height } = Dimensions.get('window');

  // 더미 데이터 (실제 사용시 실제 데이터로 교체)



  // 모달 닫기 핸들러
  const handleCloseModal = () => {
    setModalVisible(false);
    setSelectedItem(null);
  };


  // QR 삭제 핸들러
  const handleDeleteItem = () => {
    if (!selectedItem) return;
    
    Alert.alert(
      'QR 삭제',
      `'${selectedItem.nickNm}' QR을 삭제하시겠습니까?`,
      [
        { text: '취소', style: 'cancel' },
        { 
          text: '삭제', 
          onPress: () => {
            // 전역 상태에서 해당 항목 제거

      //
            handleCloseModal();
          }
        }
      ]
    );
  };
  // 다운로드 핸들러 (기존 기능 유지)
  const goToDownload = (qrNo: number, qrInfo: string) => {
    console.log('다운로드:', qrNo, qrInfo);
  };

  return (
    <View style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
            backgroundColor: 'rgba(0, 0, 0, 0.5)',
        }}>
        <View style={{
            width: width * 0.9,
            height: 250,
            backgroundColor: '#fff',
            borderRadius: 15,
            paddingTop: 10
        }}>  
      {/* QR 목록 */}

      {/* QR 상세 모달 */}
      <Modal
              animationType="fade"
              transparent={true}
              visible={modalVisible}
              onRequestClose={handleCloseModal}
            >
              <View style={modalStyles.centeredView}>
                <View style={modalStyles.modalView}>
                  {/* 닉네임 표시 */}
                  <Text style={modalStyles.nicknameText}>
                  {selectedItem?.nickNm}
                  </Text>
                  
                  {/* QR 바코드 이미지 */}
                  {selectedItem && (
                  <Image
                    source={{ uri: selectedItem.qrInfo }}
                    style={modalStyles.qrImage}
                    resizeMode="contain"
                  />
                  )}
                  {/* QR 다운로드드 이미지 */}
                  {selectedItem && (
                  <TouchableOpacity style={styles.qr_contener} onPress={() => goToDownload(selectedItem.qrNo, selectedItem.qrInfo)}>
                    <View>
                      <Image
                        source={require('../assets/ic_download.png')}
                        style={modalStyles.down_image}
                      />
                    </View>
                  </TouchableOpacity>
                  )}
                  
                  <View style={{flexDirection:'row', }}>
                    {/* 삭제 버튼 */}
                    <TouchableOpacity 
                    style={modalStyles.deleteButton}
                    onPress={handleDeleteItem}
                    >
                    <Text style={modalStyles.deleteButtonText}>삭제</Text>
                    </TouchableOpacity>
                    
                    {/* 닫기 버튼 */}
                    <TouchableOpacity 
                    style={modalStyles.closeButton}
                    onPress={handleCloseModal}
                    >
                    <Text style={modalStyles.closeButtonText}>닫기</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </Modal>
      </View>
    </View>
  );
};

// 스타일 정의 (기존 스타일에 모달 스타일 추가)
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  flat_container: {
    paddingHorizontal: 10,
  },
  flat_qr_nonSelbg: {
    margin: 5,
    padding: 10,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
  },
  flat_qr_selbg: {
    backgroundColor: '#e3f2fd',
  },
  qr_contener: {
    alignItems: 'center',
  },
  qrNonSelImg: {
    width: 80,
    height: 80,
    borderWidth: 1,
    borderColor: '#ddd',
  },
  qrSelImg: {
    borderColor: '#2196f3',
    borderWidth: 2,
  },
  container_row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  down_image: {
    width: 20,
    height: 20,
  },
  
  // 모달 스타일
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    width: 300,
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  modalImage: {
    width: 200,
    height: 200,
    marginVertical: 15,
  },
  deleteButton: {
    marginTop: 20,
    paddingVertical: 10,
    paddingHorizontal: 30,
    backgroundColor: '#ff5252',
    borderRadius: 8,
  },
  deleteButtonText: {
    color: 'white',
    fontWeight: 'bold',
  },
});

const modalStyles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalView: {
    width: '80%',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingTop: 25,
	
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  down_image: {
		width: 40,
		height: 40,
		marginTop: 0, 
		marginBottom: 30, 
	},
  nicknameText: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 15,
    color: '#333',
  },
  qrImage: {
    width: 200,
    height: 200,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#eee',
  },
  deleteButton: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
	flex:1,
	borderBottomLeftRadius:12,
	borderWidth:1,
	borderColor:'#ededed'
  },
  deleteButtonText: {
    color: 'red',
    fontWeight: 'bold',
    fontSize: 16,
  },
  closeButton: {
    paddingVertical: 20,
    paddingHorizontal: 20,
    alignItems: 'center',
	flex:1,
	borderBottomRightRadius:12,
	borderWidth:1,
	borderColor:'#ededed'
  
  },
  closeButtonText: {
    color: 'gray',
    fontWeight: 'bold',
	fontSize: 16,
  },
});

export default QrListScreen;