import React, { useContext, useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TouchableOpacity,
    Image,
    Dimensions,
    Alert,
    ToastAndroid,
    Platform,
} from 'react-native';
import { FriendList, MessageData, ListMyQr } from '../types/common'; 
import { SocketStompContext } from '../utils/WebSocketManager';
import { useGlobalStore, GlobalData, MembInfo, GetDate } from '../store/global';


const { width, height } = Dimensions.get('window');

const RemoveItem: React.FC = () => {
    const [item, setItem] = useState<FriendList|null>(null);
    const { sendMessage } = useContext(SocketStompContext);
    const global = useGlobalStore();

    useEffect(() => {
        
        setItem(global.locationFriendItem);

    }, []);

    if( item==null ) return null;

    const pressCancel = () => {
    global.setLocationFriendItem(null);
    global.setPopupPageId('');
    }

    const pressRequest = () => {
          const findQrInfo = global.listMyQr.find(m => m.qrNo === item?.membQrNo);
          console.log("@@ findQrInfo", item, findQrInfo);
          if (findQrInfo) {
            const msgData = locationMsgParam(findQrInfo,'C')	;	
            console.log("@@ msgData", msgData);
            sendMessage(msgData, msgData.roomId);
            //로컬값 변경 
            global.setReqLocationStatus('F', GlobalData.membNo, item?.membQrNo?? null, item?.friendNo ?? null, item?.friendQrNo ?? null, '20','수락대기중');
            
          } else {
            //Alert.alert('전송 실패하였습니다.');
            if (Platform.OS === 'android') {
                ToastAndroid.show('전송 실패하였습니다.', ToastAndroid.SHORT);
            } else {
                Alert.alert('전송 실패하였습니다.');
            }
          }			

            global.setLocationFriendItem(null);
            global.setPopupPageId('');
    }

  const locationMsgParam = (findQrInfo:ListMyQr, createType: string) => {  // C RL 전송, A 응답 처리  , O 승인취소처리 CL
      
      const msgData = {
        mType: createType === 'O' ? 'CL' : 'RL',
        mykey: GlobalData.myKey,
        msgDesc: createType === 'C' || createType === 'O' ? item?.nickNm : global.membInfo.nickNm,
        qrNo: createType === 'C' || createType === 'O' ? item?.membQrNo : item?.friendQrNo, //friendItem?.membQrNo,
        langCd: GlobalData.langCd,
        currentDate: GetDate(),
        callSeq: '',
        roomId: createType === 'C' || createType === 'O' ? item?.friendSubScr : findQrInfo.subScr,
        targetRoomId: createType === 'C' || createType === 'O' ? findQrInfo.subScr : item?.friendSubScr ,
        membNo: createType === 'C' || createType === 'O' ? GlobalData.membNo : item?.friendNo , //,
        writeMembNo: createType === 'C' || createType === 'O' ? item?.friendQrNo : item?.membQrNo,  //,
        counterPart: createType === 'C' || createType === 'O' ? item?.friendNo : GlobalData.membNo, //,
        onOff: 'Y',
        serviceTypeCd: 'Protect',
        fileImgUrl: '',
        filePath: '',
        callCount: 0,
        writeNickNm: createType === 'C' || createType === 'O' ? global.findMyQr(item.membQrNo)?.nickNm  : item?.nickNm, 
        writeImgFileUrl:createType === 'C' || createType === 'O' ? global.findMyQr(item.membQrNo)?.imgFileUrl : item?.imgFileUrl,
        msgTypeCd:'T'
      } as MessageData;	
      
      return msgData;
    }


    const onClose = () => {
        global.setLocationFriendItem(null);
        global.setPopupPageId('');
    }

    return (
    <View style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        height: '100%',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
    }}>
        <View style={{
            width: width * 0.9,
            height: 250,
            backgroundColor: '#fff',
            borderRadius: 15,
            paddingTop: 10
        }}>  
            <View style={[styles.header, {paddingHorizontal: 20,}]}>
                <Text style={styles.title}>위치 허용 요청 </Text>
                <TouchableOpacity style={styles.closeButton} onPress={onClose}>
                    <Text style={styles.closeText}>X</Text>
                </TouchableOpacity>
            </View>
            <View style={{alignContent:'center', alignItems:'center', flex:1}}>
                { item.imgFileUrl && <Image source={{ uri: item.imgFileUrl }} style={[styles.avatar, {borderColor:'#FF851D', borderWidth:1}]} />}
                <View style={{flex:1, justifyContent:'center', alignItems:'center'}}>
                    <View style={styles.messageArea}>
                        <Text style={styles.messageText}>
                        {item?.nickNm}에게 위치 허용 요청 하시겠습니까?
                        </Text>
                    </View>
                    <View style={[styles.buttonRow, ]}>
                        <TouchableOpacity style={styles.acceptButton} onPress={() => pressRequest()}>
                            <Text style={styles.buttonText}>요청</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.rejectButton} onPress={() => pressCancel()}>
                            <Text style={styles.buttonText}>취소</Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </View>
    </View>
    );
};

export default RemoveItem;

const styles = StyleSheet.create({
overlay: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
},
modalContainer: {
    //height: height * 0.5,
    width: width * 0.8,
    alignSelf: 'center',
    backgroundColor: '#fff',
    borderRadius: 12,
    paddingTop: 16,
    paddingBottom: 8,
    paddingHorizontal: 16,
},
header: {
    position: 'relative',
    alignItems: 'center',
    marginBottom: 12,
},
title: {
    fontSize: 22,
    fontWeight: 'bold',
},
closeButton: {
    position: 'absolute',
    right: 10,
    
},
closeText: {
    fontSize: 18,
    color: '#999',
},
listContainer: {
    gap: 12,
    paddingBottom: 12,
},
listItem: {
    flexDirection: 'row',
    alignItems: 'center',
    alignContent:'center',
    gap: 8,
    paddingVertical: 8,
    height:80,
},
avatar: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginTop: 4,
    alignContent:'center',
    alignItems:'center'
},
messageArea: {
    flex: 1,
    alignContent:'center',
    alignItems:'center',
    justifyContent:'center',
    
},
messageText: {
    fontSize: 17,
    textAlign:'center',
    
},
buttonRow: {
    flexDirection: 'row',
    justifyContent:'space-around',
    

},
rejectButton: {
    backgroundColor: '#ccc',
    paddingVertical: 15,
    flex:1, 
    borderBottomRightRadius:15
},
acceptButton: {
    backgroundColor: '#FF851D',
    paddingVertical: 15,
    flex:1,
    borderBottomLeftRadius:15
},
buttonText: {
    color: '#fff',
    fontSize: 17,
    textAlign:'center'
},
bottomButton: {
    backgroundColor: '#FF851D',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    marginTop: 16,
},

});
