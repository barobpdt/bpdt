import React, { createContext, useState, useContext, useRef } from 'react';
import { MessageData } from '../types/common';

const PopupContext = createContext<{
    showPopup: (data: MessageData, navigation: any) => void;
    hidePopup: () => void;
    isVisible: boolean;
    popupData: MessageData | null;
    navigationRef: React.MutableRefObject<any>; // ref 객체로 변경
} | undefined>(undefined);

export const usePopup = () => {
    const context = useContext(PopupContext);
    if (!context) throw new Error('usePopup must be used within PopupProvider');
    return context;
};

export const PopupProvider = ({ children }) => {
    const [isVisible, setIsVisible] = useState(false);
    const [popupData, setPopupData] = useState<MessageData | null>(null);
    const navigationRef = useRef<any>(null); // useRef 선언

    // 팝업 호출 함수
    const showPopup = (data: MessageData, navigation) => {
        setPopupData(data);
        navigationRef.current = navigation; // ref에 저장
        setIsVisible(true);
    };

    // 팝업 종료 함수
    const hidePopup = () => {
        setIsVisible(false);
        setPopupData(null);
    };

    return (
        <PopupContext.Provider
            value={{
                showPopup,
                hidePopup,
                isVisible,
                popupData,
                navigationRef, // ref 객체 제공
            }}
        >
            {children}
        </PopupContext.Provider>
    );
};