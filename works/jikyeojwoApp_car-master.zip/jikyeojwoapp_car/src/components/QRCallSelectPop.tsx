import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Image,
  Button,
  StyleSheet,
} from 'react-native';

import {QRSelectPopupProps} from '../types/common';

// 예제 데이터
const data = [
  {
    id: '1',
    imageUrl: 'https://via.placeholder.com/50',
    imageName: 'Sample Image 1',
  },
  {
    id: '2',
    imageUrl: 'https://via.placeholder.com/50',
    imageName: 'Sample Image 2',
  },
  {
    id: '3',
    imageUrl: 'https://via.placeholder.com/50',
    imageName: 'Sample Image 3',
  },
];

const QRSelectPopup: React.FC<QRSelectPopupProps> = ({ closeSelectQr, onSelectQrRead }) => {   


  const [selectedId, setSelectedId] = useState(null);

  const handleSelectItem = (id) => {
    setSelectedId(id);
  };

  const handleConfirm = () => {
   // alert(`선택된 항목 ID: ${selectedId}`);
   // onClose(); // 선택 후 팝업 닫기
  };

  const close = () => {
    
  }

  // 각 리스트 항목 렌더 함수
  const renderItem = ({ item }) => (
    <View style={styles.itemContainer}>
      {/* 라디오버튼 */}
      <TouchableOpacity
        style={styles.radioCircle}
        onPress={() => handleSelectItem(item.id)}
      >
        {selectedId === item.id && <View style={styles.selectedRb} />}
      </TouchableOpacity>
      {/* 이미지 */}
      <Image source={{ uri: item.imageUrl }} style={styles.itemImage} />
      {/* 이미지 이름 */}
      <Text style={styles.imageName}>{item.imageName}</Text>
    </View>
  );

  return (
    <Modal transparent={true} visible={true} animationType="fade">
      <View style={styles.overlay}>
        <View style={styles.popupContainer}>
          
          {/* 헤더: 타이틀과 닫기 버튼 */}
          <View style={styles.header}>
            <Text style={styles.title}>수신 받을 QR선택</Text>
            <TouchableOpacity onPress={close} style={styles.closeBtn}>
              <Text style={styles.closeText}>×</Text>
            </TouchableOpacity>
          </View>
          
          {/* 리스트 */}
          <FlatList
            data={data}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
            style={styles.list}
            // contentContainerStyle={{ paddingBottom: 20 }} --> 필요시 사용
          />

          {/* 하단 선택 버튼 */}
          <View style={styles.footer}>
            <Button title="선택" onPress={handleConfirm} />
          </View>
        </View>
      </View>
    </Modal>
  );
};


const styles = StyleSheet.create({
    // 전체 오버레이: 배경이 검은 투명, 중앙 정렬
    overlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.4)',
      justifyContent: 'center',
      alignItems: 'center',
    },
  
    // 팝업 중앙 박스
    popupContainer: {
      width: '80%',
      height: '60%',
      backgroundColor: 'white',
      borderRadius: 10,
      padding: 16,
    },
  
    // 헤더: 타이틀과 닫기 버튼
    header: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },
  
    // 타이틀 텍스트
    title: {
      flex: 1,
      fontSize: 18,
      fontWeight: 'bold',
      textAlign: 'center',
    },
  
    // 닫기 버튼 컨테이너
    closeBtn: {
      padding: 8,
    },
  
    // 닫기 아이콘 텍스트
    closeText: {
      fontSize: 24,
      fontWeight: 'bold',
    },
  
    // 리스트 영역
    list: {
      flex: 1,
      marginVertical: 10,
    },
  
    // 각 항목 컨테이너 (가로 방향)
    itemContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 8,
    },
  
    // 라디오 버튼 스타일
    radioCircle: {
      height: 20,
      width: 20,
      borderRadius: 10,
      borderWidth: 2,
      borderColor: '#777',
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 10,
    },
  
    // 선택된 라디오 버튼 내부
    selectedRb: {
      width: 10,
      height: 10,
      borderRadius: 5,
      backgroundColor: '#555',
    },
  
    // 항목 내 이미지
    itemImage: {
      width: 50,
      height: 50,
      marginRight: 10,
    },
  
    // 이미지 이름 텍스트
    imageName: {
      flex: 1,
      fontSize: 14,
    },
  
    // 하단 버튼 영역
    footer: {
      paddingVertical: 10,
      alignItems: 'center',
    },
  });

  export default QRSelectPopup;