import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity, Modal, Image, TouchableWithoutFeedback } from 'react-native';
import { FriendList } from '../types/common.tsx';

import { useGlobalStore, GetDate, GlobalData, apiCallPost} from '../store/global';

interface MemberSelectModalProps {
  visible: boolean;
  selected: string[];
  members: FriendList[];
  onToggle: (friendNo: string) => void;
  onClose: () => void;
}

//const MemberSelectModal: React.FC<MemberSelectModalProps> = ({
//   visible,
//   selected,
//   members,
//   onToggle,
//   onClose
// }) => {

const MemberSelectModal: React.FC = () => {  

  const [searchData, setSearchData] = useState('');
  
  const [filteredMembers, setFilteredMembers] = useState<FriendList[]>([]) ;  //원본 그룹에 추가되어져 있는 대상 리스트
  const global = useGlobalStore();

  const visible = false;

  // 검색 기능
  const searchFriend = () => {
    // if (!searchData.trim()) {
    //   setFilteredMembers(members);
    //   return;
    // }
    // const filtered = members.filter(m => 
    //   m.nickNm.includes(searchData) || 
    //   m.introductionInfo.includes(searchData)
    // );
    // setFilteredMembers(filtered);
  };

  // // 검색어 변경 시 필터링
  // useEffect(() => {
  //   searchFriend();
  // }, [searchData, members]);

  const onClose = () => {

  }

  const onToggle = (friendNo:string) => {

  }

  return (
    
      <View style={modalStyles.modalOverlay}>
        <View style={modalStyles.modalContent}>
          <View style={{flex:1, padding:20}}>
            <Text style={modalStyles.title}>친구 추가</Text>
            <View style={modalStyles.searchContainer}>
              <TextInput
                style={modalStyles.searchInput}
                placeholder="검색어를 입력해주세요"
                value={searchData}
                onChangeText={setSearchData}
                placeholderTextColor="#aaa"
              />
              <TouchableWithoutFeedback onPress={searchFriend}>
                <Image 
                  source={require('../assets/ic_search.png')} 
                  style={modalStyles.searchIcon}
                />
              </TouchableWithoutFeedback>
            </View>
            <ScrollView>
              {filteredMembers.map((member) => {
                const isSelected =  false ; //selected.includes(member.friendNo);
                return (
                  <GroupMemberItem
                    key={member.friendNo}
                    friendNo={member.friendNo}
                    nickNm={member.nickNm}
                    imgFileUrl={member.imgFileUrl}
                    introductionInfo={member.introductionInfo}
                    isSelected={isSelected}
                    onToggle={() => onToggle(member.friendNo)}
                    mode="select"
                  />
                );
              })}
            </ScrollView>
          </View>
          <View style={{flexDirection:'row'}}>
            <TouchableOpacity style={modalStyles.closeButton} onPress={onClose}>
              <Text style={modalStyles.closeButtonText}>닫기</Text>
            </TouchableOpacity>
            <TouchableOpacity style={modalStyles.addButton} onPress={onClose}>
              <Text style={modalStyles.addButtonText}>추가</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    
  );
};

// 그룹 멤버 아이템 컴포넌트 (모달 내부에서 사용)
const GroupMemberItem = ({
  friendNo,
  nickNm,
  imgFileUrl,
  introductionInfo,
  isSelected,
  onToggle,
  mode,
}: {
  friendNo: string;
  nickNm:string;
  imgFileUrl: string;
  introductionInfo: string;
  isSelected?: boolean;
  onToggle?: () => void;
  mode: 'select' | 'remove';
}) => {
  return (
    <View style={itemStyles.itemContainer}>
      <Image source={{ uri: imgFileUrl}} style={itemStyles.avatar} />
      <View style={itemStyles.info}>
        <Text style={itemStyles.name}>{nickNm}</Text>
        <Text style={itemStyles.statusMsg} numberOfLines={1} ellipsizeMode="tail">
          {introductionInfo}
        </Text>
      </View>

      {mode === 'select' && onToggle && (
        <TouchableOpacity onPress={onToggle}>
          <Image 
            source={isSelected
              ? require('../assets/ic_del_circle.png')
              : require('../assets/ic_plus_circle.png')
            } 
            style={itemStyles.toggleButton} 
          />
        </TouchableOpacity>
      )}
    </View>
  );
};

// 스타일 정의
const modalStyles = StyleSheet.create({
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    width: '90%',
    backgroundColor: '#fff',
    borderRadius: 16,
    height: '70%',
  },
  title: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#FF851D',
    textAlign: 'center',
    marginBottom: 10,
  },
  searchContainer: {
    marginBottom: 15,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: '#FF851D',
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  searchInput: {
    flex: 1,
    paddingVertical: 8,
  },
  searchIcon: {
    width: 20,
    height: 20,
  },
  closeButton: {
    backgroundColor: '#ccc',
    paddingVertical: 15,
    borderBottomLeftRadius: 15,
    flex: 1,
  },
  closeButtonText: {
    color: '#fff',
    fontSize: 17,
    textAlign: 'center',
  },
  addButton: {
    backgroundColor: '#FF851D',
    paddingVertical: 15,
    borderBottomRightRadius: 15,
    flex: 1,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 17,
    textAlign: 'center',
  },
});

const itemStyles = StyleSheet.create({
  itemContainer: {
    flexDirection: 'row',
    backgroundColor: '#FFF6EF',
    borderRadius: 10,
    padding: 10,
    marginBottom: 8,
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  name: {
    fontSize: 16,
    color: '#000',
    fontWeight: 'bold',
  },
  statusMsg: {
    fontSize: 12,
    color: '#888',
    flexShrink: 1,
    maxWidth: '90%',
  },
  toggleButton: {
    width: 24,
    height: 24,
    marginLeft: 8,
  },
});

export default MemberSelectModal;