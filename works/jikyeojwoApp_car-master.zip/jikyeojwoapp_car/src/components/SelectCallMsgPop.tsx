import React, { useState, useEffect, useContext } from 'react';
import { View, Text, Alert, StyleSheet, Image, TouchableOpacity, Platform, ToastAndroid } from 'react-native';
import { SelectCallMsgPopProps, SendType } from '../types/common';
import { useGlobalStore } from '../store/global.tsx';
import { SocketStompContext } from '../utils/WebSocketManager.tsx';

const SelectCallMsgPop: React.FC<SelectCallMsgPopProps> = ({ callQrNo , targetQrNo, onSelType }) => {   
	const global = useGlobalStore();
	const { sendMessage } = useContext(SocketStompContext);
	useEffect(() => { 
		console.log("@@ SelectCallMsgPop useEffect callQrNo, targetQrNo:", callQrNo, targetQrNo);
	 }, []);
	const handleOnSelect = async (methodType: string) => {		
		const msgData = await global.getMessageData(methodType, callQrNo, targetQrNo);
		if (!msgData.roomId ) {
			if (Platform.OS === 'android') {
				ToastAndroid.show('데이터가 준비되지 않았습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert("오류", "데이터가 준비되지 않았습니다.");
			}
			return;
		}  
		if(methodType=='B') {	
			// 전화	
			msgData.mType = 'RC';
			sendMessage(msgData, msgData.roomId);
			global.setCurrentMessageData(msgData);
			// global.setIncallKey('BR');
			global.setProcessScreen('Calling');
		} else if(methodType=='C' ) {
			// 문자
			msgData.mType = 'M';
			if( msgData.serviceTypeCd === 'Car' ) {
				global.setCurrentCarMessageData(msgData);
				global.setCarRoomType('send');
				global.setPopupPageId('CallingPopup');
			} else {
				global.setCurrentMessageData(msgData);
				global.setProcessScreen('Chat');
			}
		}
		if( onSelType ) {
			onSelType({msgItem:{}, sendMothod: ''} as SendType);
		}
	};

return (
	<View style={styles.overlay}>
		<View style={styles.modalContainer}>
			<View style={{alignSelf: 'flex-end', paddingHorizontal:10}}>
				<TouchableOpacity onPress={()=>handleOnSelect('X')}>
					<Image 
						source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
						style={styles.closeimage} 
					/> 
				</TouchableOpacity>
			</View>
			<View style={styles.titleContainer}>
					<Text style={[styles.headText]}>연락 방식을 선택해주세요!</Text>    
			</View>
			<View style={{flexDirection:'row', paddingHorizontal:40,paddingVertical:20, gap: 40}}>
				<TouchableOpacity 
					style={{backgroundColor: '#77DD77', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
					onPress={()=>handleOnSelect('B')}
				>
					<Image 
						source={require('../assets/ico_popup_call_agree.png') } // 임시 이미지 URL 사용
						style={{width:120, height:120}}
					/> 
					{/**<Text>통화</Text>*/}
				</TouchableOpacity>
				<TouchableOpacity 
					style={{backgroundColor: '#FFDAB9', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
					onPress={()=>handleOnSelect('C')}
				>
					<Image 
						source={require('../assets/ico_ask_disable.png') } // 임시 이미지 URL 사용
						style={{width:120, height:120}} 
					/> 
					<Text style={{fontSize:10}}>문의에서 문자 이미지로 수정</Text>
				</TouchableOpacity>
			</View>  
			
		</View>
</View>
);
};

const styles = StyleSheet.create({
	overlay: {
		flex: 1,
		justifyContent: 'center',
		alignItems: 'center',
		backgroundColor: 'rgba(0,0,0,0.5)',
	},
	modalContainer: {
		backgroundColor: 'white',
		borderRadius: 10,
		overflow: 'hidden',
		justifyContent: 'center',
		alignItems: 'center',
		paddingBottom: 20,
	},
	titleContainer: {
		flexDirection: 'row',
		justifyContent: 'space-between',
		alignItems: 'center',
		paddingHorizontal: 10,
	},
	leftContainer: {
		flexDirection: 'row',
		alignItems: 'center',
	},
	headText: {
		fontSize: 18, // 텍스트 크기
		marginBottom:10,
	},
	closeimage: {
		width: 25, // 이미지 너비
		height: 25, // 이미지 높이
		//marginRight: 5, // 텍스트와의 간격
		marginTop: 10,
	},


});

export default SelectCallMsgPop;