import React, {useState} from 'react';
import {View, Text, Modal, Button, StyleSheet, Image, TouchableOpacity, Alert} from 'react-native';
import {QrAddViewProps} from '../types/common';

const items = [
    { imageUri: 'https://kosk.co.kr/scgd-file/intro/ic_car.png', label: '차빼줘', serviceTypeCd: 'Car', desc1: '개인정보 노출없이' , desc2: 'QR로 주차하기!' },
    { imageUri: 'https://kosk.co.kr/scgd-file/intro/ic_protect.png', label: '지켜줘', serviceTypeCd: 'Protect', desc1: '개인정보 노출없이' , desc2: '친구랑 대화하기!' },
    
  ];
  
const QrAddViewPop: React.FC<QrAddViewProps> = ({ popVisible, onQrAddViewClose }) => {    

    const [selServiceTypeCd, setSelServiceTypeCd] = useState('');

    const handleClose = () => {
        console.log('QrAddViewPop close');
        onQrAddViewClose('close') ;
    };

    const handleSelSelectData = (serviceTypeCd:string) => {
       // Alert.alert(serviceTypeCd);
       console.log('QrAddViewPop serviceTypeCd', serviceTypeCd);
       onQrAddViewClose(serviceTypeCd) ;
    };

    return (
        <Modal
            visible={popVisible}
            transparent={true}
            animationType='slide'
            onRequestClose={handleClose} // Android의 백 버튼 처리
        >

           <View style={styles.popContainer}>
                <View style={styles.titleContainer}>
                    <View style={styles.leftContainer}>
                        <Text style={styles.text}> QR등록</Text>    
                        <Image 
                            source={require('../assets/ic_question.png') } // 임시 이미지 URL 사용
                            style={styles.questimage} 
                        /> 
                    </View>  
                    <TouchableOpacity onPress={handleClose}>
                        <Image 
                            source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
                            style={styles.closeimage} 
                        /> 
                    </TouchableOpacity>
                </View>

                {items.map((item, index) => (
                    <TouchableOpacity key={index} onPress={() => handleSelSelectData(item.serviceTypeCd)}  style={styles.serviceContainer}>
                        <View  >
                            <View style={styles.box}>
                                <Image 
                                    source={{ uri: item.imageUri }} // 임시 이미지 URL 사용
                                    style={styles.serviceImage} 
                                />
                                <View style={styles.textContainer}>
                                    <View style={styles.container_row}>
                                        <Text style={styles.text_title}>{item.label} </Text>
                                    </View>
                                    <View>
                                        <Text style={styles.text_msg}>{item.desc1}</Text>
                                        <Text style={styles.text_msg}>{item.desc2}</Text>
                                    </View>
                                    
                                </View>
                            </View>
                        </View>
                     </TouchableOpacity>    
                ))}
            </View>
            

        </Modal>

    );
};

export default QrAddViewPop ;

const styles = StyleSheet.create({
    popContainer: {
        position: 'absolute',
        bottom: 0,
        left: 0,
        right: 0,
        height: '35%', // 화면의 중간까지
        backgroundColor: 'white',
        borderTopLeftRadius: 30,   // 위 왼쪽 모서리를 둥글게
        borderTopRightRadius: 30,  // 위 오른쪽 모서리를 둥글게
        borderBottomLeftRadius: 0,  // 아래 왼쪽 모서리는 각지게
        borderBottomRightRadius: 0, // 아래 오른쪽 모서리는 각지게
        borderColor: '#ccc',
        borderWidth: 1,

    },
    titleContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 10,
    },
    text: {
        marginTop: 25,
        fontSize: 18, // 텍스트 크기
      },
    questimage: {
        width: 25, // 이미지 너비
        height: 25, // 이미지 높이
        marginLeft: 5, // 텍스트와의 간격
        marginTop: 25,
      },
    closeimage: {
        width: 25, // 이미지 너비
        height: 25, // 이미지 높이
        marginRight: 10, // 텍스트와의 간격
        marginTop: 25,
    },
    leftContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    },
    serviceContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginBottom: 5
      },
    box: {
        width: '94%',
        maxHeight: 150,
        flexDirection: 'row',
        alignItems: 'center',
        padding: 10,
        borderWidth: 1,
        borderColor: '#E8EBED',
        borderRadius: 10,
        
      },
    serviceImage: {
        width: 60,
        height: 60,
        marginRight: 20,
      },
      textContainer: {
        flex: 1,
      },
      container_row: {
        flexDirection: 'row', // 가로 방향으로 배치
        justifyContent: 'space-between', // 각 텍스트 사이에 여백을 추가
      },
      text_title: {
        fontSize: 18,
        fontWeight: 'bold',
        fontFamily: 'NotoSansKr',
        marginBottom: 2
      },
      text_msg: {
        fontSize: 14,
        marginTop: 2,
        fontFamily: 'NotoSansKr',
      },
});
