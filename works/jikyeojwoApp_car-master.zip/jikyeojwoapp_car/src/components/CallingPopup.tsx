import React, { useContext, useEffect, useRef, useState } from "react";
import { ActivityIndicator, Alert, Dimensions, FlatList, Image, Platform, StyleSheet, Text, ToastAndroid, TouchableOpacity, View } from "react-native";
import { callGet, callPost, GetDate, GlobalData, useGlobalStore,GetDateDay, GetDateTime } from '../store/global';
import ApiInfo from '../gvar/ApiInfo';
import { ListRoomMessage,
	MessageData, CallSeqResponse, SaveResponse, MessageRoomInfoRequest, MessageRoomInfoResponse} from '../types/common';

import { SocketStompContext } from "../utils/WebSocketManager";

const CallingPopup = () => {
	const global =useGlobalStore()
	const [title, setTitle] = React.useState('') 
	const width = Dimensions.get('window').width 
	const { sendMessage } = useContext(SocketStompContext);

	useEffect(()=>{
		const state = useGlobalStore.getState();
		const cur = state.currentMessageData;
		if( cur==null ) {
			closePopup();
			return;
		}
		if( cur.mType == 'Call' ) {
			cur.mType = 'RC';
			global.setCurrentSendData(cur);
			setTitle('지켜줘 메시지 호출')
		} else {
			setTitle('지켜줘 호출이 왔습니다.')
		}
	}, [])  

	const handleOnSelect = async (methodType: string) => {
		const state = useGlobalStore.getState();
		const cur = state.currentSendData || state.currentReceivedData;
		if( cur==null ) {
			if (Platform.OS === 'android') {
				ToastAndroid.show('데이터가 준비되지 않았습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert("오류", "데이터가 준비되지 않았습니다.");
			}
			return;
		}		 
		if (!cur.roomId ) {
			if (Platform.OS === 'android') {
				ToastAndroid.show('데이터가 준비되지 않았습니다.', ToastAndroid.SHORT);
			} else {
				Alert.alert("오류", "데이터가 준비되지 않았습니다.");
			}
			return;
		}
		console.log("@@ callingPopup handleOnSelect:", cur);
		if( state.currentSendData ) {
			const msgData = state.currentSendData;
			if(methodType=='B') {	
				// 전화	
				msgData.mType = 'RC';
				sendMessage(msgData, msgData.roomId);
				
				saveCallData(msgData);
				global.setCurrentMessageData(msgData);

				global.setProcessScreen('Calling');
			} else if(methodType=='C' ) {				
				global.setCurrentMessageData(msgData);
				global.setProcessScreen('Chat');
			}
		}
		closePopup();
	};


	const saveCallData =async (msgData:MessageData) => {
		console.log("@@ frined call save 22222", msgData);
		const state = useGlobalStore.getState();
		
		if( msgData ) {
			const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
			msgData.callSeq = data.callSeq;

			//통화요청 저장
			msgData.mType = 'RC';
			msgData.msgDesc = '통화 호출';
			const info = await callPost(ApiInfo.saveChatMsg, msgData) as SaveResponse;

			//채팅룸에 데이타 추가및 메인에 화면 정보 저장처리함 - 바탕도 업데이트 처리함
			if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
				console.log("@@ friend call ==========================>", msgData);
				msgData.msgDesc = '통화 호출';
				global.addRoomChatMsg(msgData, true);
			}

			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			
			if( findListMessage) {
				if( !findListMessage.nickNm ) {
					const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
					console.log("@@ receiveDataProcess friend", friend);
					if( friend ) {
						findListMessage.nickNm = friend.nickNm;
					}
				}
				findListMessage.msgDesc = '통화 호출';
				findListMessage.notReadYn = 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				findListMessage.addDt = GetDateDay();
				findListMessage.addTime = GetDateTime();	
				findListMessage.chatSeq = data.callSeq;				 
				findListMessage.notReadCnt = findListMessage.notReadCnt ;				
				console.log("@@ receiveDataProcess findListMessage", findListMessage);
				global.updateRoomChatMessage(findListMessage);
			} else {
				//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
				const msgRoomInfoRequest = () => {
					const node = {} as MessageRoomInfoRequest
					node.serviceTypeCd=msgData.serviceTypeCd
					node.roomNo=msgData.counterPart
					return node;
				}
				const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
				if(info.hasOwnProperty('errors')) return global.showToast(info.message);
				const updateListRoomMessage:ListRoomMessage = {
					roomNo: msgData.counterPart,
					profileImgFileUrl: '',
					nickNm: '',
					msgDesc: '통화 호출',
					notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
					notReadCnt: 0,
					addDt: GetDateDay(),
					addTime: GetDateTime(),
					msgTypeCd: msgData.msgTypeCd,
					roomTypeCd: '',
					chatSeq: data.callSeq,
					msgReDesc: '',
					callStatCd: '' ,
					serviceTypeCd: msgData.serviceTypeCd,
					qrNo: msgData.roomId,  //내QR
					membNo: GlobalData.membNo,
					writeMembNo: msgData.writeMembNo,
					sendSubScr: msgData.targetRoomId,
					targetMembNo: msgData.roomId,
					mySubScr: msgData.roomId,
					roomMembCnt: 0,
				}
				if (info) {
					updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
					updateListRoomMessage.nickNm = info.roomNm;
				}
				console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
				global.addRoomMessage(updateListRoomMessage);
			}
		}
	}
  
	const closePopup = () => {		
		global.setPopupPageId('');
	}  

	return (
		<View style={{
			position: 'absolute',
			top: 0,
			left: 0,
			right: 0,
			bottom: 0,
			height: '100%',
			justifyContent: 'center',
			alignItems: 'center',
			backgroundColor: 'rgba(0, 0, 0, 0.5)',
		}}>
			<View style={{
				width: width * 0.9,
				height: 300,
				backgroundColor: '#fff',
				borderRadius: 15,
				paddingHorizontal: 15,
				paddingVertical: 10,
			}}> 
				<Text style={[{ marginTop: 10, fontSize:20, fontWeight:700,  textAlign: 'center'}]}>
					{title}
				</Text>
				<TouchableOpacity style={styles.closeButton} onPress={() => closePopup()}>
					<Text style={styles.closeButtonText}>✕</Text>
				</TouchableOpacity>
				<View style={{
					width: '100%',
					height: 2,
					backgroundColor: 'black',
					marginTop: 5,
				}}/>  
				<View style={{flex:1, }}>
					<View style={{flexDirection:'row', padding:20, gap: 20, }}>
						<TouchableOpacity 
							style={{backgroundColor: '#77DD77', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
							onPress={()=>handleOnSelect('B')}
						>
							<Image 
								source={require('../assets/ico_popup_call_agree.png') } // 임시 이미지 URL 사용
								style={{width:120, height:120}}
							/> 
							{/**<Text>통화</Text>*/}
						</TouchableOpacity>
						<TouchableOpacity 
							style={{backgroundColor: '#FFDAB9', aspectRatio: 1, borderRadius:10, flex:1, alignItems:'center', justifyContent:'center' }}
							onPress={()=>handleOnSelect('C')}
						>
							<Image 
								source={require('../assets/ico_ask_disable.png') } // 임시 이미지 URL 사용
								style={{width:120, height:120}} 
							/> 
						</TouchableOpacity>
					</View>
				</View>     
			</View>
		</View>
	);
};


export default CallingPopup;

const styles = StyleSheet.create({
	footer: {
		alignItems: 'center',
		marginTop: 10,
	},
	myMessageContainer: {
		alignItems: 'flex-end',
		paddingHorizontal: 10,
		marginVertical: 4,
	},
	myMessageBox: {
		backgroundColor: '#ffcc80',
		borderRadius: 12,
		padding: 8,
		maxWidth: '80%',
	},
	profileImg: {
		width: 36,
		height: 36,
		borderRadius: 18,
		marginRight: 8,
	},
	nickname: {
		fontSize: 12,
		fontWeight: 'bold',
		color: '#333',
	},
	otherMessageContainer: {
		flexDirection: 'row',
		paddingHorizontal: 10,
		marginVertical: 4
	},
	otherMessageContent: {
		flexDirection: 'row',
	},
	otherMessageBox: {
		backgroundColor: '#eee',
		borderRadius: 12,
		padding: 4,
		maxWidth: '80%',
	},
	msgInput: {
		fontWeight:'bold',
		paddingVertical: 4,
		fontSize: 20,
		color: '#333',
		width:'100%',
		borderBottomWidth: 2,
		borderColor: '#cccccc',
		margin:15
	},
	sendButton: {
		backgroundColor: '#FF851D',
		width:'100%',
		height: 50,
		justifyContent:'center',
	},
	sendButtonText: {
		color: '#fff',
		fontWeight: 'bold',
		textAlign:'center'
	},
	closeButton: {
		position: 'absolute',
		top: 12,
		right: 10,
		zIndex: 10,
		borderRadius: 20,
		paddingHorizontal: 12,
		paddingVertical: 4,
	},
	closeButtonText: {
		color: '#333',
		fontSize: 26,
		fontWeight: 'bold',
	},
	myMsgOption:{
		flexDirection:'row',
		justifyContent:'flex-end',
	},
	msgBtn:{
		width: 15,
		height: 15,
		marginRight:5,
	},
	timeText: {
		fontSize: 10,
		color: '#999',
		marginTop: 2,
	},
});