import React, { useState, useEffect } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TextInput,
	TouchableOpacity,
	Button,
	ScrollView,
	KeyboardAvoidingView,
	Platform,
	Alert,
	Keyboard,
	Image,
	TouchableWithoutFeedback,
	StatusBar
} from 'react-native';
import { QrDupNickNmRequest, NickNmAvailableResponse, QrMembJKJRegRequest, QrJKJRegResponse, CallSeqResponse, ListSubscr} from '../types/common'
//import { text } from 'stream/consumers';
import { callPost, GetDate, GlobalData, useGlobalStore} from '../store/global';
import { SafeAreaView } from 'react-native-safe-area-context';
import ApiInfo from '../gvar/ApiInfo';


const WriteQrInfoPop: React.FC = () => { 
	const global = useGlobalStore();
	const scanInfo = useGlobalStore.getState().currentScanInfo;
	//버튼 활성화 여부 체크
	const [isButtonVisible, setButtonVisible] = useState(false);

	const [nickName, setNickName] = useState('');
	const [carInfo, setCarInfo] = useState('');
	const [makerCar, setMakerCar] = useState('');
	const [parkText, setParkText] = useState('잠시 주차중입니다.');
	const [pinNo, setPinNo] = useState('');
	const [cPinNo, setCPinNo] = useState('');
	const [introductionInfo, setIntroductionInfo] = useState('');

	//서비스타입에따른 데이타 활성화 처리
	const [jobCarView, setJobCarView] = useState(scanInfo.serviceTypeCd === 'Car' ? true :false);

	//const [dupNickNmChk, setDupNickNmChk] = useState(scanInfo.serviceTypeCd === 'Car' ? true :false);
	const [saveBtnUse, setSaveBtnUse] = useState(false);

		
	const handleBlur = () => enableSaveBtn(); 

	useEffect(() => {
		console.log("@@ service write QR useEffect", scanInfo);
		setNickName(global.membInfo.nickNm);

	}, []);

	useEffect(() => {
		enableSaveBtn();
	}, [nickName, carInfo, parkText, introductionInfo ]);

	const handleChangePinText = (text:string) => {
		// 숫자만 입력 가능하도록 필터링
		const filteredText = text.replace(/[^0-9]/g, '');        
		// 4자리까지만 허용
		if (filteredText.length <= 4) {
			setPinNo(filteredText) ;
			//handlePinchk();
		}
	};

	const handleChangeCPinText = (text:string) => {
		// 숫자만 입력 가능하도록 필터링
		const filteredText = text.replace(/[^0-9]/g, '');        
		// 4자리까지만 허용
		if (filteredText.length <= 4) {
			setCPinNo(filteredText) ;
			//handlePinchk();
		}
	};

		
	//버튼 활성화 처리 기능
	const enableSaveBtn = () => {        
		// console.log("btn chk event", dupNickNmChk, nickName, pinNo, pinNo.length) ;			
		if (scanInfo.serviceTypeCd === 'Car') {
			if (nickName && carInfo && parkText) {
				setSaveBtnUse(true);
			} else {
				setSaveBtnUse(false);
			}
		} else {
			if (nickName && introductionInfo ) {
				setSaveBtnUse(true);
			} else {
				setSaveBtnUse(false);
			}
		}


		// if (pinNo === cPinNo && pinNo.length === 4) {
		// 	if (scanInfo.serviceTypeCd === 'Car') {
		// 		if (nickName) {
		// 			setSaveBtnUse(true);
		// 		} else {
		// 			setSaveBtnUse(false);
		// 		}
		// 	} else {
		// 		if (dupNickNmChk && nickName) {
		// 			setSaveBtnUse(true);
		// 		} else {
		// 			setSaveBtnUse(false);
		// 		}
		// 	}
		// } else {
		// 	setSaveBtnUse(false);
		// }
	}  


	//팝업 닫기
	const handleClose = () => {
		console.log('QrAddViewPop close');
		global.setPopupPageId('');
	};

	// 취소 버튼 클릭
	const handleCancel = () => {
		global.setPopupPageId('');
	};
	
	//저정 버튼 클릭
	const handleSave = () => {
		// 여기에 저장 로직 구현
		console.log("@@ handleSave saveBtnUse", saveBtnUse);
		if (saveBtnUse) {
			saveQrInfo();
		} else {
			global.showToast('정보를 입력해주세요.');
		}
	};


	// const dubNickNmChk = () => {
	// 	// 여기에 저장 로직 구현
	// 	if (nickName.length > 0) {
	// 		dupchkNickNmData();
	// 	}
	// };
		
	//닉네임 중복 체크
	// const dupchkNickNmData = async () => {
	// 	console.log("servicetypecd ==> ", scanInfo.serviceTypeCd);
	// 	const qrDupNickNmParam = () => {
	// 		const node = {} as QrDupNickNmRequest
	// 		node.serviceTypeCd=scanInfo.serviceTypeCd  as string
	// 		node.nickNm= nickName
	// 		node.langCd=GlobalData.langCd
	// 		return node;
	// 	}
	// 	const info = await callPost(ApiInfo.nickNmAvailable, qrDupNickNmParam()) as NickNmAvailableResponse;
	// 	if( 'errors' in info ) {
	// 		global.showToast(info.message);
	// 		return;
	// 	}
	// 	if( info.availableYn === 'Y' ) {
	// 		//setDupNickNmChk(true); 
	// 		Alert.alert("사용가능한 닉네입입니다.");
	// 	} else {
	// 		//setDupNickNmChk(false);
	// 		Alert.alert(info.message);
	// 	}
	// }

	const saveQrInfo = async () => {
		//QrMembJKJRegRequest, QrJKJRegResponse
		const QrMembJKJRegParam = () => {
			const node = {} as QrMembJKJRegRequest
			node.qrNo = scanInfo.qrNo;
			node.serviceTypeCd = scanInfo.serviceTypeCd;
			node.nickNm = nickName;
			node.pinNo = ''; //pinNo;
			node.reUseYn = 'N';
			node.introductionInfo = introductionInfo;
			node.makerCar = makerCar;
			node.carInfo = carInfo;
			node.langCd = GlobalData.langCd;
			node.currentDate = GetDate();
			return node;
		}
		const info = await callPost(ApiInfo.regJkjQr, QrMembJKJRegParam()) as QrJKJRegResponse;
		if( 'errors' in info ) {
			global.showToast(info.message);
			return;
		}
		if( info.code === '30005' ) {
			global.addMyQr(info.addQrInfo);
			global.setListMyQrCurrent(scanInfo.serviceTypeCd, scanInfo.qrNo);
			global.showToast('QR 정보 추가 ');
			global.setPopupPageId('');
			// 구독 리스트 업데이트
			const subscr = await callPost(ApiInfo.subscrList, {}) as { listSubscr: ListSubscr[] }
			global.updateSubscrList(subscr);
		} else {
			global.showToast(info.message);
		}
	}

	// 
	return (

		<SafeAreaView style={{position: 'absolute',top: 0,left: 0, bottom:0, right: 0, backgroundColor:'#fff'}}>
		
			<View style={styles.titleContainer}>
						<View style={styles.leftContainer}>
								<Text style={styles.headText}> QR등록</Text>    
								<Image 
										source={require('../assets/ic_question.png') } // 임시 이미지 URL 사용
										style={styles.questimage} 
								/> 
						</View>  
						<TouchableOpacity onPress={handleClose}>
								<Image 
										source={require('../assets/ic_close.png') } // 임시 이미지 URL 사용
										style={styles.closeimage} 
								/> 
						</TouchableOpacity>
				</View>
				<KeyboardAvoidingView 
					style={styles.container} 
					behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
					keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
				> 
				<TouchableWithoutFeedback onPress={Keyboard.dismiss}>
				<View style={styles.touchableArea}>

			<ScrollView 
				contentContainerStyle={styles.scrollViewContent} 
				keyboardShouldPersistTaps="always"
			>

				<View style={styles.topInputContainer}>
					<Text style={styles.label}>닉네임 (최대 10자리)*</Text>
						<View style={styles.inputBtnContainer}>
							<TextInput
								style={styles.input}
								maxLength={10}
								placeholder="닉네임 입력*"
								value={nickName}
								onChangeText={setNickName}
								onBlur={handleBlur}
							/>
							{/* {!jobCarView && <TouchableOpacity style={styles.dupButton} onPress={dubNickNmChk}>
									<Text style={styles.dupButtonText}>중복체크</Text>
							</TouchableOpacity>} */}
						</View>
				</View>

				{jobCarView && <View style={styles.inputContainer}>
					<Text style={styles.label}>차종</Text>
					
						<TextInput
							style={styles.input}
							maxLength={10}
							placeholder="차종 입력"
							value={makerCar}
							onChangeText={setMakerCar}
						//  onFocus={handleFocus}
							onBlur={handleBlur}
						/>
						<Text style={styles.label}>차량번호*</Text>
					
					<TextInput
						style={styles.input}
						maxLength={10}
						placeholder="차량번호 입력"
						value={carInfo}
						onChangeText={setCarInfo}
					//  onFocus={handleFocus}
						onBlur={handleBlur}
					/>
				</View> }

				{jobCarView && <View style={styles.inputContainer}>
					<Text style={styles.label}>주차문구 (최대 30자리)*</Text>
					
						<TextInput
							style={styles.input}
							maxLength={30}
							placeholder="소개글 입력*"
							value={parkText}
							onChangeText={setParkText}
						//  onFocus={handleFocus}
							onBlur={handleBlur}
						/>
					
				</View> }

				{!jobCarView && <View style={styles.inputContainer}>
					<Text style={styles.label}>소개글 (최대 30자리)*</Text>
					
						<TextInput
							style={styles.input}
							maxLength={30}
							placeholder="소개글 입력"
							value={introductionInfo}
							onChangeText={setIntroductionInfo}
						//  onFocus={handleFocus}
							onBlur={handleBlur}
						/>
					
				</View> }

				{/* <View style={styles.inputContainer}>
					<Text style={styles.label}>PIN 번호 (숫자 4자리)</Text>
					
						<TextInput
							style={styles.input}
							maxLength={4}
							placeholder="PIN 입력"
							value={pinNo}
							keyboardType="numeric"
							onChangeText={handleChangePinText}
						//  onFocus={handleFocus}
							onBlur={handleBlur}
						/>
						<Text style={styles.label}>PIN 번호(확인)</Text>
					
					<TextInput
						style={styles.input}
						maxLength={4}
						placeholder="확인 PIN 입력)"
						value={cPinNo}
						keyboardType="numeric"
						onChangeText={handleChangeCPinText}
					//  onFocus={handleFocus}
						onBlur={handleBlur}
					/>
					
				</View> */}


				{/* {jobCarView && <View style={styles.inputContainer}>
					<Text style={styles.labelbold}>차량번호 와 PIN번호는 </Text>
					<Text style={styles.labelbold}>QR삭제 후 다시 재사용을 위한 정보입니다. </Text>
				</View> }

				{!jobCarView && <View style={styles.inputContainer}>
					<Text style={styles.labelbold}>닉네임 과 PIN번호는 </Text>
					<Text style={styles.labelbold}>단말기 변경시 QR 재사용을 위한 정보입니다. </Text>
				</View> } */}
			</ScrollView>
			
			<View style={[styles.buttonContainer, isButtonVisible && styles.buttonVisible]}>
				<TouchableOpacity style={[styles.button, styles.cancelButton]} onPress={handleCancel}>
					<Text style={styles.buttonText}>취소</Text>
				</TouchableOpacity>
				<TouchableOpacity style={[styles.button, saveBtnUse ? styles.saveButton : styles.saveUnEnableButton ]} onPress={handleSave}>
					<Text style={styles.buttonText}>저장</Text>
				</TouchableOpacity>
			</View>

			</View>  
			</TouchableWithoutFeedback>
		</KeyboardAvoidingView>
	</SafeAreaView> 
	);
};

const styles = StyleSheet.create({
		container: {
			flex: 1,
		},
		inputBtnContainer: {
			flexDirection: 'row',
			alignItems: 'center',
		},
		bottomContainer: {
			flex:1, width: '100%', height: '100%', justifyContent: 'flex-end', backgroundColor: '#F7F8FA',
		},
		titleContainer: {
			flexDirection: 'row',
			justifyContent: 'space-between',
			alignItems: 'center',
			padding: 10,
		},
		leftContainer: {
				flexDirection: 'row',
				alignItems: 'center',
		},
		headText: {
			marginTop: 25,
			fontSize: 18, // 텍스트 크기
		},
		questimage: {
			width: 25, // 이미지 너비
			height: 25, // 이미지 높이
			marginLeft: 5, // 텍스트와의 간격
			marginTop: 25,
		},
		closeimage: {
			width: 25, // 이미지 너비
			height: 25, // 이미지 높이
			marginRight: 10, // 텍스트와의 간격
			marginTop: 25,
		},
		buttonContainer: {
			flexDirection: 'row',
			justifyContent: 'space-between',
			width: '100%',
			backgroundColor: 'white',
			borderTopWidth: 1,
			borderTopColor: 'lightgray',
			paddingBottom: Platform.OS === 'ios' ? 0 : 0,
		},
		buttonVisible: {
			position: 'absolute',
			bottom: Platform.OS === 'ios' ? 0 : 20,
			left: 0,
			right: 0,
		},
		button: {
				flex: 1,
				padding: Platform.OS === 'ios' ? 12 : 15,
			},
		cancelButton: {
			backgroundColor: '#F1F1F1', // 취소 버튼 색상
		},
		buttonText: {
			textAlign: 'center',
			color: 'black',
			fontWeight: 'bold',
			fontSize: 16,
		},
		saveButton: {
			backgroundColor: '#FF851D', // 저장 버튼 색상
		},
		saveUnEnableButton: {
			backgroundColor: '#F1F1F1', // 저장 버튼 색상
		},

		scrollViewContent: {
			padding: 20,
			flexGrow: 1, // ScrollView가 내용을 담아서 스크롤 가능하게
			justifyContent: 'center',
			
		},
		label: {
			fontSize: 16,
			marginBottom:  10,
			color: '#26282B'
		},
		labelbold: {
			fontSize: 18,
			marginBottom:  5,
			fontWeight: 'bold',
			color: '#26282B'
		},
		topInputContainer: {
			marginTop: 10,
			marginBottom: 2,
		},
		inputContainer: {
			marginTop: 5,
			marginBottom: 2,
		},
		input: {
			flex: 1,
			height: 40,
			borderColor: 'gray',
			borderWidth: 1,
			borderRadius: 5,
			paddingHorizontal: 10,
			marginVertical: 5,
		},
		dupButton: {
			marginLeft: 10,
			backgroundColor: '#007BFF',
			borderRadius: 4,
			padding: 10,
		},
		dupButtonText: {
			color: 'white',
		},
		touchableArea: { // 추가된 스타일
				flex: 1, // 확장을 위해 스타일 설정
		},
		
});

export default WriteQrInfoPop;
