import React, { useState, useEffect, useContext } from 'react';
import {
	View,
	Text,
	StyleSheet,
	TouchableOpacity,
	Image,
	Modal,
	FlatList,
	ScrollView,
	SafeAreaView,
	Alert,
	TextInput,
	Platform,
	ToastAndroid
} from 'react-native';
import { StackNavigationProp } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import { RootStackParamList, InfoProfileFriendRequest , FriendProfileInfoResponse
				, CallType, SendType, ListRoomMessage,
				MessageData,
				ChgFriendNmRequest,
				ChgFriendNmResponse,
				FriendList, CallSeqResponse, SaveResponse, MessageRoomInfoRequest, MessageRoomInfoResponse} from '../types/common';
import { callGet, callPost, GetDate, GlobalData, useGlobalStore,GetDateDay, GetDateTime } from '../store/global';
import ApiInfo from '../gvar/ApiInfo';
import { SocketStompContext } from '../utils/WebSocketManager';
import { useSafeAreaInsets } from 'react-native-safe-area-context';


const FriendCallProfilePop: React.FC = () => {
	const { sendMessage } = useContext(SocketStompContext);

	const [infoFriendData, setInfoFriendData] = useState<FriendProfileInfoResponse>() ;
	const global = useGlobalStore();

	//친구닉네임 수정모달
	const [isModVisible, setModVisible] = useState(false); //이미지 팝업 확대 팝업

	
	//친구닉네임 모달에 초기값 설정
	const [friendNm, setFriendNm] = useState(''); //이미지 팝업 확대 팝업

	useEffect(() => {
		friendPrfileData();
	}, []);

	const friendPrfileData = async () => {
		const cur = global.currentFriendProfile;
		if( !cur ) return;
		const params: InfoProfileFriendRequest = {friendNo: cur.friendNo, roomNo: cur.roomNo, langCd:GlobalData.langCd }
		const info: FriendProfileInfoResponse = await callPost(ApiInfo.friendProfile, params) as FriendProfileInfoResponse;
		console.log("@@ friendPrfileData info => ", info, params);
		console.log("info.addDt ", info.addDt);
		if( 'errors' in info ) {
			Alert.alert('알림', info.message)
			return;
		}
		setInfoFriendData(info);	
		// console.log("info?.nickNm", info?.nickNm);
		if(info.nickNm){
			setFriendNm(info?.nickNm)
		}
	}
		
	const handleClose = () => {
		global.setPopupPageId('');
	}

	const onHandleCall = async (callMoth:string) => {
		const state = useGlobalStore.getState();
		console.log("@@ onHandleCall callMoth => ", state.qrClickData);
		const msgData = await global.getMessageData('CALL', infoFriendData?.membQrNo || '', infoFriendData?.friendQrNo || '');
		if (!msgData.roomId ) {
			global.showToast('데이터가 준비되지 않았습니다.');
			return;
		}
		
		if (callMoth == "C") {
			global.setCurrentSendData(msgData);
			msgData.mType = 'RC';
			sendMessage(msgData, msgData.roomId);
			saveCallData(msgData);
			// global.setIncallKey('BR');
			global.setProcessScreen('Calling');
		} else if (callMoth == "M") {
			global.setCurrentMessageData(msgData);
			global.setProcessScreen('Chat');
		}
		handleClose();
	}

	const saveCallData =async (msgData:MessageData) => {
		console.log("@@ frined call save 22222", msgData);
		const state = useGlobalStore.getState();
		
		if( msgData ) {
			const data: CallSeqResponse = await callGet(ApiInfo.getCallSeq, { langCd: 'KR' }) as CallSeqResponse;
			msgData.callSeq = data.callSeq;

			//통화요청 저장
			msgData.mType = 'RC';
			msgData.msgDesc = '통화 호출';
			const info = await callPost(ApiInfo.saveChatMsg, msgData) as SaveResponse;

			//채팅룸에 데이타 추가및 메인에 화면 정보 저장처리함 - 바탕도 업데이트 처리함
			if( state.processScreen == 'Chat' && state.currentRoomInfo.roomNo == msgData.counterPart ) {
				console.log("@@ friend call ==========================>", msgData);
				msgData.msgDesc = '통화 호출';
				global.addRoomChatMsg(msgData, true);
			}

			const findListMessage = state.listRoomMessage?.find(item => item.roomNo === msgData.counterPart);
			
			if( findListMessage) {
				if( !findListMessage.nickNm ) {
					const friend = state.listFriend?.find(item => item.friendNo === msgData.writeMembNo);
					console.log("@@ receiveDataProcess friend", friend);
					if( friend ) {
						findListMessage.nickNm = friend.nickNm;
					}
				}
				findListMessage.msgDesc = '통화 호출';
				findListMessage.notReadYn = 'N' ;  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
				findListMessage.addDt = GetDateDay();
				findListMessage.addTime = GetDateTime();	
				findListMessage.chatSeq = data.callSeq;				 
				findListMessage.notReadCnt = findListMessage.notReadCnt ;				
				console.log("@@ receiveDataProcess findListMessage", findListMessage);
				global.updateRoomChatMessage(findListMessage);
			} else {
				//DB 호출하여 룹메세지 타이틀에 이미지와 닉네임 넣어서 보내줌
				const msgRoomInfoRequest = () => {
					const node = {} as MessageRoomInfoRequest
					node.serviceTypeCd=msgData.serviceTypeCd
					node.roomNo=msgData.counterPart
					return node;
				}
				const info = await callPost(ApiInfo.chatMsgRoomInfo, msgRoomInfoRequest()) as MessageRoomInfoResponse;
				if(info.hasOwnProperty('errors')) return global.showToast(info.message);
				const updateListRoomMessage:ListRoomMessage = {
					roomNo: msgData.counterPart,
					profileImgFileUrl: '',
					nickNm: '',
					msgDesc: '통화 호출',
					notReadYn: 'N' ,  // incrNum false 채팅창이 열려있으면 자동 읽음상태로  
					notReadCnt: 0,
					addDt: GetDateDay(),
					addTime: GetDateTime(),
					msgTypeCd: msgData.msgTypeCd,
					roomTypeCd: '',
					chatSeq: data.callSeq,
					msgReDesc: '',
					callStatCd: '' ,
					serviceTypeCd: msgData.serviceTypeCd,
					qrNo: msgData.roomId,  //내QR
					membNo: GlobalData.membNo,
					writeMembNo: msgData.writeMembNo,
					sendSubScr: msgData.targetRoomId,
					targetMembNo: msgData.roomId,
					mySubScr: msgData.roomId,
					roomMembCnt: 0,
				}
				if (info) {
					updateListRoomMessage.profileImgFileUrl = info.imgFileUrl;
					updateListRoomMessage.nickNm = info.roomNm;
				}
				console.log("@@ =====newlistRoomMessage===========================", updateListRoomMessage)
				global.addRoomMessage(updateListRoomMessage);
			}
		}
	}
	

	// 친구 닉네임 변경
	const handleUpdate = () => {
		//console.log(roomInfo.roomNo, msgInfo?.qrNo )
		// 여기에 API 호출 등 추가 로직 구현 가능
		setGroupNameAPI()
	};

	
	const setGroupNameAPI= async() => { 
		const state = useGlobalStore.getState();
		const roomNo = state.currentFriendProfile.roomNo;
		const param =  {
			serviceTypeCd: 'Protect',
			qrNo: infoFriendData?.membQrNo,
			friendNo: infoFriendData?.friendNo,
			friendQrNo: infoFriendData?.friendQrNo,
			nickNm: friendNm,
			currentDate: GetDate(),
			langCd: 'KR'
		} as ChgFriendNmRequest

		console.log(param)
		const info = await callPost(ApiInfo.chgFriendNm, param) as ChgFriendNmResponse;
		console.log('=======info========',info)
		if('errors' in info) return global.showToast('닉네임 변경 오류:'+info.message);
		else{
			let friendInfo: FriendList|undefined = global.listFriend.find(item => item.membQrNo == infoFriendData?.membQrNo && item.friendNo == infoFriendData?.friendNo && item.friendQrNo == infoFriendData?.friendQrNo);
			if (!friendInfo) {return;} ;
			friendInfo.nickNm = friendNm;	
			infoFriendData!.nickNm = friendNm;		
			console.log("@@ roomMessage==>infoFriendData ", infoFriendData);	
			global.updateFriend(friendInfo);
			
			let roomMessage: ListRoomMessage | undefined = global.listRoomMessage.find(item => item.roomNo == roomNo);
			console.log("@@ roomMessage==>", roomMessage);
			if (roomMessage) {				
				const newlistRoomMessage:ListRoomMessage = {
					roomNo: roomMessage.roomNo,
					profileImgFileUrl: roomMessage.profileImgFileUrl,
					nickNm: friendNm,
					msgDesc: roomMessage.msgDesc,
					notReadYn: roomMessage.notReadYn,
					notReadCnt: roomMessage.notReadCnt,
					addDt: roomMessage.addDt,
					addTime: roomMessage.addTime,
					msgTypeCd: roomMessage.msgTypeCd,
					roomTypeCd:roomMessage.roomTypeCd,
					chatSeq: roomMessage.chatSeq,
					msgReDesc: roomMessage.msgReDesc,
					callStatCd: roomMessage.callStatCd ,
					serviceTypeCd: roomMessage.serviceTypeCd,
					qrNo: roomMessage.qrNo,  //내QR
					membNo: roomMessage.membNo,
					writeMembNo: roomMessage.writeMembNo,
					sendSubScr: roomMessage.sendSubScr,
					targetMembNo: roomMessage.targetMembNo,
					mySubScr: roomMessage.mySubScr ,
					roomMembCnt: roomMessage.roomMembCnt,
				}

				console.log("@@ roomMessage change ==>", friendNm, newlistRoomMessage);
				global.updateRoomMessage(newlistRoomMessage);
			}
			
			setModVisible(false);
			global.showToast('닉네임이 변경 되었습니다.');
		}
	}
	const insets = useSafeAreaInsets();


	return (
		<SafeAreaView style={{position: 'absolute',top: insets.top,left: 0, right: 0, bottom: insets.bottom, backgroundColor: '#fff'}}>
			<View style={styles.modalWrapper}>
				{/* 상단 닫기 버튼 */}
				<TouchableOpacity style={styles.closeButton} onPress={handleClose}>
					<Image source={require('../assets/ic_close.png')} style={styles.closeIcon} />
				</TouchableOpacity>

				{/* 프로필 정보 */}
				<View style={styles.profileContainer}>
					<Image source={{ uri: infoFriendData?.imgFileUrl }} style={styles.profileImage} />
					<TouchableOpacity onPress={()=>{setModVisible(true)}}>
						<Text style={styles.nickName}>{infoFriendData?.nickNm}</Text>
					</TouchableOpacity>
					<Text style={styles.intro}>{infoFriendData?.introductionInfo}</Text>
				</View>
				
				{/* 액션 버튼 */}
				<View style={styles.buttonContainer}>
					<TouchableOpacity onPress={() => onHandleCall("M")} style={styles.actionButton}>
						<Image source={require('../assets/ic_msg_img.png')} style={styles.icon} />
						<Text style={styles.label}>문자</Text>
					</TouchableOpacity>
					<TouchableOpacity onPress={() => onHandleCall("C")} style={styles.actionButton}>
						<Image source={require('../assets/ic_phone_img.png')} style={styles.icon} />
						<Text style={styles.label}>통화</Text>
					</TouchableOpacity>
				</View>
			</View>
			<Modal visible={isModVisible} transparent animationType="fade" >
				<View style={modalStyles.modalOverlay}>
					<View style={modalStyles.modalContent}>
						<TouchableOpacity style={{position:'absolute', right:15, top:10}} onPress={()=>setModVisible(false)}>
							<Text style={{fontSize:22}}>X</Text>
						</TouchableOpacity>
						<View style={{padding:20, flex:1}}>
							<Text style={modalStyles.title}>닉네임 변경</Text>
							<View style={{flexDirection:'row', alignContent:'center', alignItems:'center', justifyContent:'space-between', gap:10, marginBottom:10}}>
								{/* 로컬 상태 사용 */}
								<TextInput
									placeholder='변경할 닉네임을 입력해주세요.'
									value={friendNm}
									maxLength={20}
									multiline={false}
									numberOfLines={1}
									onChangeText={setFriendNm}
									style={{backgroundColor:'#fff', borderWidth:1, borderColor:'#ccc', flex:1, paddingLeft:15, borderRadius:10, fontSize:16}}
								/>
								{/* 수정 버튼에 로컬 핸들러 연결 */}
								<TouchableOpacity 
									style={{backgroundColor:'#FF851D', borderRadius:10, paddingHorizontal:15, paddingVertical:10}}
									onPress={handleUpdate}>
									<Text style={{fontSize:16,color:'#fff'}}>수정</Text>
								</TouchableOpacity>
							</View>
							<ScrollView>
							</ScrollView>
						</View>
						<View style={modalStyles.buttonRow}>
							<TouchableOpacity style={{backgroundColor: '#ccc', paddingVertical: 15, flex:1,  borderBottomLeftRadius:15, borderBottomRightRadius:15}} onPress={()=>setModVisible(false)}>
							<Text style={[modalStyles.buttonText, {color:'black'}]}>닫기</Text>
							</TouchableOpacity>
						</View>
					</View>
				</View>
			</Modal>
		</SafeAreaView>
	);
};

const styles = StyleSheet.create({
	container: {
		flex: 1,
		padding: 16,
	},
	bottomContainer: {
		flex: 1,
		width: '100%',
		height: '100%',
		backgroundColor: '#FFFDF7',
		justifyContent: 'flex-end',
	},
	modalWrapper: {
		flex: 1,
		justifyContent: 'space-between',
		paddingBottom:20,
	},
	closeButton: {
		alignSelf: 'flex-end',
		marginTop: 10,
		marginRight:10,
	},
	closeIcon: {
		width: 35,
		height: 35,
	},
	profileContainer: {
		alignItems: 'center',
		marginBottom: 40,
	},
	profileImage: {
		width: 150,
		height: 150,
		borderRadius: 75,
		marginBottom: 12,
	},
	nickName: {
		fontSize: 18,
		fontWeight: 'bold',
		marginBottom: 6,

	},
	intro: {
		fontSize: 14,
		color: '#555',
		textAlign: 'center',
		marginBottom: 10,
		paddingHorizontal: 20,
	},
	addDate: {
		fontSize: 12,
		color: '#999',
	},
	buttonContainer: {
		flexDirection: 'row',
		justifyContent: 'space-around',
		
		borderColor:'#DBDBDB',
		borderTopWidth:1,
		paddingTop:20,
	},
	actionButton: {
		alignItems: 'center',
	},
	icon: {
		width: 50,
		height: 50,
		marginBottom: 6,
	},
	label: {
		fontSize: 12,
		color: '#333',
	},
});

const modalStyles = StyleSheet.create({
	modalOverlay: {
	flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center',
	},
	modalContent: {
	width: '90%', backgroundColor: '#fff', borderRadius: 16,  height: 190,
	},
	title: {
	fontSize: 17, fontWeight: 'bold', color: '#FF851D', textAlign: 'center', marginBottom: 10,
	},
	closeButton: {
	backgroundColor: '#FF851D', padding: 10, borderRadius: 8, marginTop: 16, alignItems: 'center',
	},
	closeButtonText: {
	color: '#fff', fontWeight: 'bold', fontSize: 16,
	},
	buttonRow: {
		flexDirection: 'row',
		justifyContent:'space-around',
		
	
	},
	rejectButton: {
		backgroundColor: '#ccc',
		paddingVertical: 15,
		flex:1, 
		borderBottomLeftRadius:15
	},
	acceptButton: {
		backgroundColor: '#FF851D',
		paddingVertical: 15,
		flex:1,
		borderBottomRightRadius:15
	},
	buttonText: {
		color: '#fff',
		fontSize: 17,
		textAlign:'center'
	},
});
export default FriendCallProfilePop;
