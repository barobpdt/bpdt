declare module 'react-native-webrtc' {
	class RTCIceCandidate {
		constructor(candidateInit?: RTCIceCandidateInit);
		candidate: string;
		sdpMLineIndex: number;
		sdpMid: string;
	}

	interface RTCIceCandidate {
		candidate: string;
		sdpMLineIndex: number;
		sdpMid: string;
	}

	export class RTCPeerConnection {
		// 필요한 메서드와 속성 정의
		constructor(configuration: RTCConfiguration);
		onicecandidate: (event: RTCPeerConnectionIceEvent) => void;
		ontrack: (event: RTCTrackEvent) => void; // Track 이벤트
		addTrack(track: MediaStreamTrack, stream: MediaStream): void;
		createOffer(): Promise<RTCSessionDescription>;
		oniceconnectionstatechange: () => void; // oniceconnectionstatechange 이벤트 핸들러 추가
		addIceCandidate(candidate: RTCIceCandidate): Promise<void>;
		setLocalDescription(description: RTCSessionDescription): Promise<void>;
		setRemoteDescription(description: RTCSessionDescription): Promise<void>;
		createAnswer(): Promise<RTCSessionDescription>;
		close(): void;
		iceConnectionState: string;
		// 추가적인 메서드와 이벤트 정의
	}

	export class RTCSessionDescription {
		constructor(init: { type: string; sdp: string });
	}

	export class RTCIceCandidate {
		constructor(candidateInit?: RTCIceCandidateInit);
	}

	export const mediaDevices: {
		getUserMedia(constraints: MediaStreamConstraints): Promise<MediaStream>;
	};


	// export class MediaStream {
	//     getAudioTracks(): MediaStreamTrack[];
	//   //  getVideoTracks(): MediaStreamTrack[];
	//     // 다른 메서드 및 속성...
	// }

	export class MediaStream {
		getAudioTracks(): MediaStreamTrack[];
		getVideoTracks(): MediaStreamTrack[];
		addTrack(track: MediaStreamTrack): void;
	}

	export class MediaStreamTrack {
		id: string;
		kind: string; // 'audio' 또는 'video'
		// 필요한 속성 및 메서드 추가
	}   
}