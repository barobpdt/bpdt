declare module 'stompjs' {
	export class Client {
		connect(
			headers: { [key: string]: string },
			connectCallback: (frame: any) => void,
			errorCallback?: (error: string) => void
		): void;
		disconnect(disconnectCallback: () => void): void;

		send(destination: string, headers: { [key: string]: string }, body: string): void;

		subscribe(
			destination: string,
			callback: (message: { body: string }) => void,
			headers?: { [key: string]: string }
		): { id: string };

		unsubscribe(id: string): void;
	}

	export function over(ws: any): Client;
}