import React from 'react';
import { Image } from 'react-native';
import { RouteProp, Route } from '@react-navigation/native';
import { StackNavigationProp } from '@react-navigation/stack';


export type MessageData = {
    mType: string;
    mykey: string;
    msgDesc: string;
    langCd: string; 
    qrNo: string;
    currentDate: string;
    callSeq: string;
    membNo: string;
    roomId: string;  
    targetRoomId: string;
    onOff:string;
    writeMembNo:string;
    serviceTypeCd: string;
    fileImgUrl: string;
    filePath: string;
    counterPart: string;
    callCount?: number;
    msgTypeCd: string;
    writeNickNm:string
    writeImgFileUrl:string;
    roomNm: string;
    roomImg: string;
}

export type MessageLocation = {
    mType: string;
    roomNo: string ; 
    subScr: string; //요청시 수신받을 구독정보
    membNo: string;
    targetSubScr: string;
    latitude: number;
    longitude: number; 
}

export type FriendLocation = {
    membNo: string;
    latitude: number;
    longitude: number; 
    curDate: string;
    nickNm?: string;
    profileImgFileUrl?: string;
}
export type FriendSearchLocation = {
    friendNo: string;
    latitude: number;
    longitude: number; 
    colDt: string;
    nickNm?: string;
    profileImgFileUrl?: string;
}

export type MessageSendRead = {
    mType: string;
    membNo: string;
    chatSeq: string;
    roomId: string;
}

export type ChangeInfo = {
    transData: string;
    transData1: string;
    transData2: string;
    transData3: string;
}

export type MessageRecieveRead = {
    mType: string;
    roomId: string;
    membNo: string;
    chatSeq: string;  // ,로 여러건 존재할수 잇음
}
/*
{ messageId: '1735794664235669',
  data: 
   { mType: 'M',
     qrNo: 'A-241111-00087-QR',
     callSeq: 'CS250102000006408',
     msgDesc: '차를 이동해주세요',
     mykey: '0n3geshmi',
     fcm_options: { image: 'https://kosk.co.kr/scgd-file/imgData/jikyeojwo_push.png' } },
  mutableContent: true,
  notification: { body: '차를 이동해주세요', title: '차빼줘 문자 호출' },
  from: '684544254587' }
*/ 
export type FCM_RecvData = {
    mType: string;
    qrNo: string;
    callSeq: string;
    msgDesc: string;
    mykey: string;
    membNo: string;
    roomId: string;
    serviceTypeCd: string;
    targetRoomId?: string;
    alarmSoundYn?: string;
    alarmInterval?:string;
    writeMembNo?: string;
    fileImgUrl?: string;
    filePath?: string;
    counterPart?: string;
    image?: string;
    msgTypeCd?: string;
}
export type NoteItem = {
    id: string;
    type: string;
    title: string;
    name: string;
    content: string;
    noteList: NoteItem[];
} 

export interface NotificationData {
    title: string;
    message: string;
    data: FCM_RecvData;
}

export interface NotificationData {
    title: string;
    message: string;
    data: FCM_RecvData;
}

export type ItemOption = {
	code:string;
	value:string;
	selected:boolean;
}

/* API 타입정의 */
export type RegUseQrResponse = {
    code: string,
    message: string,
    regQr: string,
    carInfo: string,
    makerCar: string
}

export type ApiResult = {
    code:string;
    message:string;
    appKey:string;
    status?:number;
    path?:string;
    error?:object;
    isAlert?:string;
    regQr?:string;
    errors?:ApiError[]
}

export type ApiRoom = {
    roomId: string;
    nickNm: string;
}

export type ApiRoomInfo = {
    code: string;
    message: string;
    roomIdList: ApiRoom[]
}

export type ApiError = {
    field:string;
    value:string;
    reason:string;    
}

export type ApiVersionInfo = {
    appKey: string;
    langCd: string;
    storeUrl: string;
    tutoStart: string;
    upRequireInfo: string;
    infoServer: string;
    callServer: string;
}
export type ApiListMenu = {
    appMenuNo: string;
    appMenuNm: string;
    useYn: string;
    viewNum: number;
    filePath: string
}
export type ApiMainMenu = {
    appMenuNo: string;
    appMenuNm: string;
    useYn: string;
    viewNum: number;
    filePath: string;
}
export type ApiRoomIdList = {
    roomId: string;
    nickNm: string;
}
export type ApiMenuInfo = {
    code: string;
    message: string;
    giftYn: string;
    giftUrl: string;
    listMenu: ApiListMenu[];
    mainMenu: ApiMainMenu[];
    roomIdList: ApiRoomIdList[];
}

/* 삭제대상 */
export type ApiTutorialInfo = {
    code:string;
    message:string;
    casMngDataList: ApiCasFields[]
}

export type ApiTutorialImages = {
    code:string;
    message:string;
    tutoDataList: ApiImageFields[]
}

export type ApiCasInfo = {
    code:string;
    message:string;
    casMngDataList: ApiCasFields[]
}

export type ApiImageFields = {
    viewNum: number;
    filePath: string;
    title?:string;
    text?:string;
};

export type ApiCasFields = {
    viewNum: number;
    casNo: string;
    casNm: string;
    casDesc: string;
    requiredYn: string;    
    agreeYn?:boolean|undefined;
    title?:string;
};

export type StackCasFieldsParamList = {
    CasDesc: { data: ApiCasFields }; // CasDesc 스크린에서 받을 데이터 타입 정의
};

export type ApiCasReg = {
    casNo:string;
    selectYn:string;
}
export type ApiCreateSg = {
    newType:string;
    deviTpCd:string;
    deviId:string;
    deviOsVer:string;
    appVer:string;
    nickNm:string;
    pinNo:string;
    appReg:string;
    langCd:string;
    currentDate:string;
    casList: ApiCasReg[];
}
export type ApiCreateSgRes = {
    code:string;
    message:string;
    appKey:string;
    langCd:string;
    membNo:string;
    isAlert?:string;
    status?:string;
    errors?:ApiError[]
}

//메인 호출시 전달 파라메타
export type ApiMainRequest = {
    deviTpCd:string;
    langCd:string;
}
//서비스 홈
export type ApiMainMsgRequest = {
    serviceTypeCd:string;
    qrNo:string;
    deviTpCd:string;
    langCd:string;
}
//서비홈 차빼줘
export type ApiMainCarMsgRequest = {
    serviceTypeCd:string;
    qrNo:string;
    deviTpCd:string;
    langCd:string;
    gridSize:number;
    gridPage:number;
    pagingYn:string;
}
export type RoomFriendLocationRequest = {
    code: string;
    message: string;
    friendLocationList: FriendSearchLocation[];
}
//QR 리스트
export type MyQrRequest = {
    serviceTypeCd: string;
    langCd: string;
}

//닉네임 중복체크
export type QrDupNickNmRequest = {
    serviceTypeCd: string;
    nickNm:string;
    langCd: string;
}

export type DupNickNmRequest = {
    nickNm:string;
    langCd: string;
}

export type QrMembJKJRegRequest = {
    qrNo: string;
    serviceTypeCd:string;
    nickNm:string;
    pinNo:string;
    reUseYn:string;  // 재등록시 Y , 신규등록: N
    introductionInfo:string;
    makerCar:string;
    carInfo:string;
    langCd:string;
    currentDate:string;
}

export type QrDtailMsgListRequest = {
    serviceTypeCd: string;
    qrNo: string;
    langCd:string;
}

export type QrDtaiCarMsgListRequest = {
    serviceTypeCd: string;
    qrNo: string;
    langCd:string;
    gridSize: number;
    searchChatSeq: string;
    pagingYn: string
}

export type QrDtailFriendListRequest = {
    serviceTypeCd:string;
    qrNo: string;
    langCd:string;
}

export type SaveFriendRequest = {
    serviceTypeCd: string;
    qrNo: string;
    friendQrNo: string;
    currentDate: string;
    langCd:string;
}

export type DelMsgRequest = {
    serviceTypeCd: string;
    roomNo: string;
    chatSeq: string
    qrNo: string;
    currentDate: string;
    langCd:string;
}

export type FileUploadRequest = {
    fileType:string;
    currentDate:string;
    langCd:string;
    roomNo:string;
    qrNo?:string;
    multipartFile:ImageAsset;
}

export type SaveMembNickNmRequest = {
    nickNm:string;
    introductionInfo:string;
    currentDate:string;
    langCd:string;
}

export type SearchFriendListRequest = {
    searchNm:string;
    langCd:string;
}

export type InfoProfileFriendRequest = {
    friendNo:string;
    roomNo: string;
    langCd:string;
}

export type RoomChatMsgListRequest = {
    serviceTypeCd:string;
    roomNo: string;
    langCd:string;
    gridSize: number;
    searchChatSeq: string;
    pagingYn: string;
}

export type ChkRoomInfoRequest = {
    scanQrNo:string;
    myQrNo: string;
    langCd: string;
    currentDate: string;
}

export type MembSettingRequest = {
    jobTypeCd:string;
    changeData: string;
    langCd: string;
    currentDate: string;
}

export type ConnectRequest = {
    nickNm:string;
    pinNo: string;
    deviId: string;
    appVer: string;
    deviOsVer: string;
    deviTpCd: string;
    langCd: string;
    currentDate: string;
}

export type QrMembJKJUpdateRequest = {
    qrNo: string;
    serviceTypeCd:string;
    nickNm:string;
    pinNo:string;
    chgPinNo:string;
    reUseYn:string;  // 재등록시 Y , 신규등록: N
    parkText: string;
    introductionInfo:string;
    makerCar:string;
    carInfo:string;
    langCd:string;
    currentDate:string;
}

export type GroupInfoRequest = {
    roomNo: string;
    qrNo:string;
    langCd:string;
}

export type SaveGroupFriendRequest = {
    serviceTypeCd: string;
    roomNo:string;
    roomNm:string;
    qrNo: string;
    currentDate:string;
    langCd:string;
    gridInsertData: FriendList[];
    gridDeleteData: FriendList[];

}

export type GroupFriendInfo = {
    friendNo:string;
    friendqrNo:string;
}

export type MessageRoomInfoRequest = {
    serviceTypeCd:string;
    roomNo: string;
    langCd:string;
}

export type ChangeRoomInfoRequest = {
    serviceTypeCd:string;
    roomNo: string;
    langCd:string;
    currentDate:string;
    gridInsertData: ChatFriendInfo[];
}

export type SaveMsgDataRequest = {
    mType: string;
    mykey: string;
    msgDesc: string;
    langCd: string;
    currentDate: string;
    qrNo: string;
    roomId: string;
    callSeq: string;
    membNo: string;
    writeMembNo: string;
    serviceTypeCd: string;
    fileImgUrl: string;
    filePath: string;
    counterPart: string;
    targetRoomId: string;
    writeNickNm: string;
    writeImgFileUrl: string;
    msgTypeCd: string;
}

export type ChgRoomInfoRequest = {
    roomNo: string;
    langCd:string;
}

export type RemoveDataRequest = {
    removeType: string;  // QR Q, Friend F, Group G
    myQrNo:string;
    serviceTypeCd: string;
    friendQrNo: string;  // 
    friendNo: string;  //친구는 친구번호, 그룹은 room번호
    langCd: string;
}


//====================

export type SaveResponse = {
    code: string;
    message: string;
}

//메인 호출시 수신 데이타 
export type ListService = {
    serviceCd: string;
    serviceNm: string;
    useYn: string;
    viewNum: number;
    filePath: string;
}

export type ListAdView = {
    adCd: string;
    adNm: string;
    useYn: string;
}

export type ListRoomMessage = {
    roomNo: string;
    profileImgFileUrl: string;
    nickNm: string;
    msgDesc: string;
    notReadYn: string;
    notReadCnt: number;
    addDt: string;
    addTime: string;
    msgTypeCd: string;
    roomTypeCd: string;
    chatSeq: string;
    msgReDesc: string;
    callStatCd: string;
    serviceTypeCd: string;
    qrNo: string;
    membNo: string;
    writeMembNo: string;
    sendSubScr?: string;
    targetMembNo?: string;
    mySubScr?: string;
    roomMembCnt?: number;
}
export type InfoSetting = {
    alarmUseYn: string;
    alarmIntervalCd: string;
    alarmIntervalNm: string;
    alarmSoundYn: string;
    alarmSoundNm: string;
    alarmVibYn: string;
    callPhoneYn: string;
    callMsgYn: string;
    hideMsgYn: string;
    locationYn: string;
    langCd: string;
}
export type ListAlert = {
    friendNo: string;
    friendNickNm: string;
    friendQrNo: string;
    friendSubScr: string;
    locationCd: string;
    membQrNo: string;
    membSubScr: string;
    alertMsg: string;
}

export type ListRoom = {
    roomNo: string;
    serviceTypeCd: string;
}

export type ListSubscr = {
    subscr: string;
    serviceTypeCd: string;
}

export type MainResponse = {
    code: string;
    message: string;
    membNo: string;
    nickNm: string;
    introductionInfo: string;
    imgFileUrl: string;
    introImgUrl: string;
    totalNotReadCnt: number;
    totalReadCnt: number;
    colLocationTime: number;
    listService: ListService[];
    listAdView: ListAdView[];
    listRoomMessage: ListRoomMessage[];
    settingInfo: InfoSetting;
    listAlert: ListAlert[];
    listAppMenu: ListAppMenu[];
    listMyQr: ListMyQr[];
    listSubscr: ListSubscr[];
    listFriend: FriendList[];
    listGroup: ListRoomMessage[];
}



export type MainMsgResponse = {
    code: string;
    message: string;
    introImgUrl: string;
    totalNotReadCnt: number;
    totalReadCnt: number;
    listRoomMessage: ListRoomMessage[];
}

export type MainCarMsgResponse = {
    code: string;
    message: string;
    introImgUrl: string;
    totalSize: number;
    listRoomMessage: ListRoomMessage[];
}

export type ListAppMenu = {
    appMenuNo: string;
    appMenuNm: string;
    useYn: string;
    viewNum: string;
    fileUrl: string;
}

export type QrJKJUpdateResponse = {
    code: string;
    message: string;
    addQrInfo: ListMyQr;
}

//myqr리스트 결과
export type MyQrResponse = {
    code: string;
    message: string;
    listMyQr: ListMyQr[];
}

export type QrJKJRegResponse = {
    code: string;
    message: string;
    addQrInfo: ListMyQr;
}

export type RoomListResponse = {
    code: string;
    message: string;
    listSubscr: ListRoom [] ;
}

export type ListMyQr = {
    qrNo: string;
    nickNm: string;
    carInfo: string;
    makerCar: string;
    subScr: string;
    parkText: string;
    introductionInfo: string;
    serviceTypeCd:string;
    qrFileNo: string;
    qrInfo: string;
    imgFileUrl?: string;
    imgFilePath?: string;
    pinNo: string;
}

export type ApiCallHistList = {
    membNo: string;
    callSeq: string;
    nickNm: string;
    qrNo: string;
    callTypeCd: string;
    callTypeNm: string;
    callReqMsg: string;
    callStatCd: string;
    callStatNm: string;
    callStatDt: string;
    newYn: string;
}
export type ApiCallHistInfo = {
    code: string;
    message: string;
    adOutYn: string;
    totalSize: number;
    callHistList: ApiCallHistList[]
}

export type ApiMyQrList = {
    membNo: string;
    qrOwnerCd: string;
    qrOwnerNm: string;
    qrUseCd: string;
    qrUseNm: string;
    carInfo: string;
    qrNo: string;
    nickNm: string;
    makerCar: string;
    filePath: string;
    addDt: string;
    parkText: string;
}


export type NickNmAvailableResponse = {
    code: string;
    message: string;
    availableYn: string;
}

export type CallSeqResponse = {
    code: string;
    message: string;
    callSeq: string;
}


export type ApiMyQrInfo = {
    code: string;
    message: string;
    adOutYn: string;
    giftYn: string;
    giftUrl: string;
    myQrList: ApiMyQrList[];
}

export type ApiSettingInfo = {
    code: string;
    message: string;
    alarmUseYn: string;
    alarmIntervalCd: string;
    alarmIntervalNm: string;
    alarmSoundYn: string;
    alarmSoundNm: string;
    alarmVibYn: string;
    callPhoneYn: string;
    callMsgYn: string;
    allowYn: string;
    alramUrl?: string;
    currentDate?: string;
    langCd?:string;
}

export type ApiFaqList = {
    faqNo: string;
    faqTypeNm: string;
    faqSubject: string;
    faqDesc: string
}
export type ApiFaqInfo = {
    code: string;
    message: string;
    faqInfoList: ApiFaqList[]
}

export type ApiNoticeList = {
    annNo: string;
    annNm: string;
    annDesc: string;
    addDt: string;
}
export type ApiNoticeInfo = {
    code: string;
    message: string;
    totalSize: 0;
    publicList: ApiNoticeList[]
}

export type ApiCarInfo = {
    qrNo: string;
    nickNm: string;
    makerCar: string;
    carInfo: string;
    langCd: string;
    currentDate: string;
}

export type MessageBoxInfo = {
    msgFriend:string;
    chatSeq:number;
	imageUri:string;
	serviceTypeCd:string;
	roomTypeCd:string;
	roomNo:number;
	roomNm:string;
	msgTypeCd:string;
	msgDesc:string;
	msgReDesc:string;
	writeMembNo:string;
	addDt:string;
	addTime:string;
	notReadYn:string;
	nickNm:string;
	notReadCnt:string;
	intro:string;
	locationCd:string;
}

export type ApiQrImgInfo = {
    qr_no: string;
    qrimageUri: string;
    nickNm: string;
}
export type ApiServiceItemInfo = {
    imageUri: string;    // imageUri는 문자열 타입
    label: string;       // label은 문자열 타입
    serviceTypeCd: string; // 서비스타입 Car Find Protect
}

export type QrDtlFriendListResponse = {
    code: string;
    message: string;
    friendCnt: number;
    msgCnt: number;
    friendList: FriendList[];
}

export type FriendList = {
    membNo: string;
    imgFileUrl: string;
    nickNm: string;
    introductionInfo: string;
    membLocationCd: string;
    friendLocationCd: string;
    roomNo: string;
    membLocationNm: string;
    friendLocationNm: string;
    serviceTypeCd: string;
    friendNo: string;
    membQrNo: string;
    friendQrNo: string;
    friendSubScr: string;
}

export type QrDtlMsgListResponse = {
    code: string;
    message: string;
    friendCnt: number;
    msgCnt: number;
    qrMsgList: ListRoomMessage[];
}

export type QrDtlCarMsgListResponse = {
    code: string;
    message: string;
    lastChatSeq: string;
    qrCarCallList: ListRoomMessage[];
}

export type FileResponse = {
    code: string;
    message: string;
    fileNo: string;
    downUrl: string;
    orgFileNm: string;
}

export type SearchFriendListResponse = {
    code: string;
    message: string;
    searchCnt:number;
    friendList: SearchFriendList [];
}

export type SearchFriendList = {
    membNo: string;
    imgFileUrl: string;
    nickNm: string;
    introductionInfo: number;
    membLocationCd: string;
    friendLocationCd: string;
    roomNo: string;
    membLocationNm: string;
    friendLocationNm: string;
    serviceTypeCd: string;
    qrNickNm: string;
    friendNo: string;
    membQrNo: string;
    friendQrNo: string;
}

export type FriendProfileInfoResponse = {
    code: string;
    message: string;
    friendNo: string;
    imgFileUrl: string;
    nickNm: string;
    introductionInfo: string;
    callPhoneYn: string;
    roomNo: string;
    friendQrNo: string;
    friendSubScr:string;
    membQrNo:string;
    membSubScr:string;
    addDt:string;
}

export type RoomChatInitResponse = {
    code: string;
    message: string;
    lastChatSeq: string;
    roomTypeCd: string;
    mySubScr: string;
    qrSubScr: string;
    friendList: ChatFriendInfo[];
    chatMsgList: RoomChatMsgInfo [] ;
}

export type ChatFriendInfo = {
    roomNo: string;
    membNo: string;
    nickNm: string;
    locationCd: string;
    qrNo: string;
    alertYn: string; 
    subScr: string;
    imgFileUrl: string;
}


export type RoomChatMsgListResponse = {
    code: string;
    message: string;
    lastChatSeq: string;
    chatMsgList: RoomChatMsgInfo [] ;
}

export type ChkRoomInfoResponse = {
    code: string;
    message: string;
    roomNo: string;
    profileImgFileUrl: string;
    nickNm: string;
    msgDesc: string;
    notReadYn: string;
    notReadCnt: number;
    addDt: string;
    addTime: string;
    msgTypeCd: string;
    roomTypeCd: string;
    chatSeq: string;
    msgReDesc: string;
    callStatCd: string;
    serviceTypeCd: string;
    qrNo: string;
    writeMembNo: string;
    sendSubScr: string;
    roomMembCnt: number;
    membNo: string;
    mySubScr: string;
}

export type RoomChatMsgInfo = {
    roomNo: string;
    chatSeq: string;
    msgTypeCd: string;
    msgDesc: string;
    profileImgFileUrl: string;
    writeMembNo: string;
    readChatSeq: string;
    myTextYn: string;
    nickNm: string;
    addDt: string;
    addTime: string;
    notReadCnt: number;
    callStatCd: string;
    roomImgUrl: string;
}


export type AddFriendResponse = {
    code: string;
    message: string;
    addMyYn: string;
    addFriendYn: string;
    friendSubScr: string;
    addFriendInfo: FriendList | null;
}

export type AlarmAddFriendResponse = {
    code: string;
    message: string;
    addFriendInfo: FriendList | null;
}

export type ConnectResponse = {
    code: string;
    message: string;
    membNo: string;
    deviId:string;
    appKey: string
}

export type ManualInfo = {
    filePath: string;
    viewNum: number;
}

export type ManualListResponse = {
    code: string;
    message: string;
    manualDataList: ManualInfo[];
}

export type FaqInfo = {
    faqNo: string;
    faqTypeNm: string;
    faqSubject: string;
    faqDesc: string
}

export type FaqListResponse = {
    code: string;
    message: string;
    faqInfoList: FaqInfo[];
}

export type GroupListResponse = {
    code: string;
    message: string;
    listGroup: ListRoomMessage[];
}


export type GroupInfoResponse = {
    code: string;
    message: string;
    roomNo: string;
    roomNm: string;
    qrNo: string;
    serviceTypeCd: string;
    listGroupFriend: FriendList[];
}

export type MessageRoomInfoResponse = {
    code: string;
    message: string;
    imgFileUrl: string;
    roomNm: string;
}

export type ChgRoomInfoResponse = {
    code: string;
    message: string;
    friendList: ChatFriendInfo[];
    listGroup: ListRoomMessage[];
}




//====================================================
export type ImgProps = {
    uri:string;
    imageWidth:number;
}

/* 페이지 매개변수 타입정의 */
export type tutorial03_params = {
    casNo:string;
    casDesc:string;
}

export type Serviceinfo = {
    serviceCd: string;
    serviceNm: string;
    useYn: string;
    viewNum: number;
    filePath: string;
} 


// 튜토리얼에서 App쪽과 연결 
export type TutorialProps = {
    route: RouteProp<RootStackParamList, 'Tutorial'>; // RouteProp으로 타입 정의
    navigation: StackNavigationProp<RootStackParamList, 'Tutorial'>; // StackNavigationProp으로 타입 정의
    callChangeStack: (param: any) => void; // 전달받은 함수 타입 정의
};

export type MainHomeProps = {
    navigation: StackNavigationProp<RootStackParamList>; // StackNavigationProp으로 타입 정의
};


export type BottomTabBarProps = {
	bottonCall: (param: any) => void; // 전달받은 함수 타입 정의callQrAddView
    navigation: StackNavigationProp<RootStackParamList>; 
};


export type ServiceItemProps = {
    navigation: StackNavigationProp<RootStackParamList>; // StackNavigationProp으로 타입 정의
    imageUri: string;    // imageUri는 문자열 타입
    label: string;       // label은 문자열 타입
    serviceTypeCd: string; // 서비스타입 Car Find Protect
    backgroundColor: string;
   // onChangeService: (serviceTypeCd: string) => void; 
}




export type ServiceQrBoxProps = {
    navigation: StackNavigationProp<RootStackParamList>; // StackNavigationProp으로 타입 정의
    serviceCd: string ;
    qrNo: string;
    onAddQR: (serviceTypeCd: string) => void; 
    onEditQR?: (item: any) => void; // ← updateQRInfo때문에 추가
   // onQrDataSearch: (param: any, param1: any) => void;
  };


export type ServiceIntroProps = {
    imageUri: string;    // imageUri는 문자열 타입
  }

// MyProfile
export type MyProfileProps = {
    navigation: StackNavigationProp<RootStackParamList>; // StackNavigationProp으로 타입 정의
};

// MyProfile
export type QrAddViewProps = {
    popVisible: boolean ;
	onQrAddViewClose: (param: any) => void; // 전달받은 함수 타입 정의
};

export type QrSelectViewProps = {
    popVisible: boolean ;
	onQrSelectViewClose: (param: any) => void; // 전달받은 함수 타입 정의
};

export type MessageBoxProps = {
	//navigation: StackNavigationProp<any, any>; // navigation prop 추가
    blDelType: boolean;
    msgItem: ListRoomMessage | null;
    friendItem: FriendList | null;
    groupItem: ListRoomMessage | null;
	callMsgStack: (param: any, param1: ListRoomMessage|null, param2: FriendList|null, param3: ListRoomMessage|null) => void; // 전달받은 함수 타입 정의
}

export type FriendBoxProps = {
	//navigation: StackNavigationProp<any, any>; // navigation prop 추가
    friendItem: FriendList;
	callFriendStack: (param: any, param1: any, param2: any) => void; // 전달받은 함수 타입 정의
}

export type QRCodeScannerPopProps = {
    closeCamera: () => void;
	onQRCodeRead: (param: any) => void; // 전달받은 함수 타입 정의
};

export type CallScannerPopProps = {
    callQrNo: string;
    closeCallScanner: () => void;
	onCallQRRead: (param: any) => void; // 전달받은 함수 타입 정의
};

export type SelectCallMsgPopProps = {
    callQrNo: string;
    targetQrNo: string;
    onSelType: (param: any) => void; // 전달받은 함수 타입 정의 callQrNo, targetQrNo, Call : B, Msg: M, close: C
};




// MyProfile
export type WriteQrInfoPopProps = {
    serviceTypeCd: string ;
    qrNo: string ;
	onQrWriteSet: (param: any) => void; // 전달받은 함수 타입 정의
    onQrWriteClose: () => void;
};

export type UpdateQrInfoPopProps = {
    item: ListMyQr | null;
	onQrUpdateSet: (param: any) => void; // 전달받은 함수 타입 정의
    onClose: () => void;
  };

export type QRFriendScannerPopProps = {
    closeAddFriend: () => void;
	onQRFriendRead: (param: any) => void; // 전달받은 함수 타입 정의
};

export type QRCallScannerPopProps = {
    closeQrCall: () => void;
	onQrCallRead: (param: any) => void; // 전달받은 함수 타입 정의
};



export type WriteMyProfilePopProps = {
    closeWriteProfile: () => void;
};

export type MyQrListPopProps = {
    closeMyQrList: () => void;
};

export type FriendProfilePopProps = {
    roomNo: string;
    friendNo: string;
    closeFriendCall: (param: any, param1: any) => void;
};

export type FriendInfoReq = {
    friendNo: string;
    roomNo: string;
}

export type QRSelectPopupProps = {
    closeSelectQr: () => void;
    onSelectQrRead: (param: any) => void;
};

//=============================================
/* common types */

export type RectEl = {
    x:number;
    y:number;
    width:number;
    height:number;
    pageX:number;
    pageY:number;
}

export const RemoteImage = ({uri, imageWidth}: ImgProps) => {
    const [desiredHeight, setDesiredHeight] = React.useState(0)
    Image.getSize(uri, (width, height) => {
        setDesiredHeight(imageWidth / width * height)
    })
    //console.log("Remote image => ", uri, imageWidth)
    return (
        <Image
            source={{uri}}
            style={{
                borderWidth: 1,
                width: imageWidth,
                height: desiredHeight
            }}
        />
    )
}

// 네비게이션 
export type RootStackParamList = {
    Splash: undefined;             // Splash 스크린은 매개변수가 없음
    Tutorial: { callChangeStack: (param: string) => void };           // Tutorial 스크린은 매개변수가 없음
    CasDesc: { data: ApiCasFields }; // CasDesc 스크린은 ApiCasFields를 받음
    MainHome: undefined;
    Search: undefined;
    MyProfile: undefined;
    MySetting: undefined;
    Chat: {sendTypeData: SendType};  // relNo, etcInfo  relNo: string, etcInfo: string , roomNm: string
    Calling: undefined;  
    Notice: undefined;
    Inquiry: undefined;
    Connect: undefined;
    RegConnectInfo: {casList: ApiCasFields[]};  
    Manual: undefined;
    Faq: undefined;
    Group: {roomNo: string};
    
    
    // 추가 스크린 정의...
};

export type QrPageType = {
    searchChatSeq: string;
    totalSize: number;
    lastChatSeq: string;
    preSearchChatSeq: string;
  }

export type QrClickType = {
    qrNo: string ,
    serviceTypeCd: string,
  }  

  //이미지 파일 업로드시 사용할 타입
export type ImageAsset = {
    uri: string | undefined; // 이미지 URI
    type?: string; // MIME 타입 (선택 사항)
    fileName?: string; // 파일 이름 (선택 사항)
}

// 채팅창이나 통화시 전달하는 구조
export type SendType = {
    msgItem:ListRoomMessage;
    sendMothod: string ; // C  close, B : 통화,  M: 문자
}

// 채팅창이나 통화시 전달하는 구조
export type CallType = {
    serviceTypeCd: string;
    sendSubScr: string;
    receiveSubScr:string;
    roomNo: string;
    targetMembNo: string;
    callTypeCd: string ; // receive : R   call: C
    qrNo:string;
}

export type NetworkType = {
    isConnected: boolean ; // 이미지 URI
    type: string;
}

export type MembLocation = {
    latitude: number ; 
    longitude: number;
}

//공지항,FAQ, 문의사항, 매뉴얼
export type AnnounceListRequest = {
    langCd:string;
    gridSize:number;
    gridPage:number;
    pagingYn:string;
}

export type AskRequest = {
    email: string;
    askSubject: string;
    askDesc: string;
    langCd: string;
    currentDate: string;
}



export type RemoveData = {
    removeType: string;  
    myQrNo:string;
    friendQrNo: string;  
    friendNo: string;  
    friendNm: string;
    friendImgFileUrl: string;
    serviceTypeCd: string;
    
}

//그룹 채팅 방이름 변경경
export type ChgRoomNmRequest ={
  roomNo: string;
  qrNo:string;
  nickNm:string;
  currentDate:string;
  langCd:string;
}
export type ChgRoomNmResponse ={
    code: string;
    message: string;
}

//친구 닉네임 수정
export type ChgFriendNmRequest ={
  serviceTypeCd:string;
  qrNo:string;
  friendNo:string;
  friendQrNo:string;
  nickNm:string;
  currentDate:string;
  langCd:string;
}
export type ChgFriendNmResponse ={
    code: string;
    message: string;
}
