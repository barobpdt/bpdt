import React, {useEffect, useState, useRef, useContext} from 'react';
import { StyleSheet, Alert, Linking, BackHandler, Platform, PermissionsAndroid, Modal, ToastAndroid, AppRegistry } from 'react-native';
//import { useTranslation } from 'react-i18next';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { GlobalData, selectGrobalData, useGlobalStore, CHAT_LIST_TYPE, OPEN_LIST_TYPE, callPost, GetDate } from './src/store/global';
import { NotificationData, RootStackParamList} from './src/types/common';
import { SafeAreaProvider} from 'react-native-safe-area-context';
import { NavigationContainer, NavigationContainerRef} from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import SplashScreen from './src/screens/splash/SplashScreen';
import TutorialScreen from './src/screens/tutorial/TutorialScreen';
import MyProfileScreen from './src/screens/main/MyProfileScreen';
import MySettingScreen from './src/screens/main/MySettingScreen';
import CasDescPop from './src/components/CasDescPop';
import MainHomeScreen from './src/screens/main/MainHomeScreen';
import SearchScreen from './src/screens/main/SearchScreen';
import ChatScreen from './src/screens/main/ChatScreen';
import CallingScreen from './src/screens/main/CallingScreen';
import NoticeScreen from  './src/screens/main/NoticeScreen';
import InquiryScreen from './src/screens/main/InquiryScreen';
import RegConnectInfoScreen from './src/screens/main/RegConnectInfoScreen';
import ConnectScreen from './src/screens/main/ConnectScreen';
import LocationRequestPop from './src/components/LocationRequestPop';
import ManualScreen from './src/screens/main/ManualScreen';
import FAQScreen from './src/screens/main/FAQScreen';
import GroupScreen from './src/screens/main/GroupScreen';

import messaging, { FirebaseMessagingTypes } from '@react-native-firebase/messaging';
import PushNotificationIOS from '@react-native-community/push-notification-ios';
import PushNotification, { ReceivedNotification, Importance } from 'react-native-push-notification';
import BackgroundFetch from 'react-native-background-fetch';
// import { useCameraPermission, useMicrophonePermission } from 'react-native-vision-camera';
import { FCM_RecvData } from './src/types/common';
import { request, check, PERMISSIONS, RESULTS } from 'react-native-permissions';
import { SocketStompContext, SocketStompProvider  } from './src/utils/WebSocketManager';
import ReceiveCallPop from './src/components/ReceiveCallPop';
import CallingPopup from './src/components/CallingPopup';
import CallingCarPopup from './src/components/CallingCarPopup';
import LocationAllowPop from './src/components/LocationAllowPop';
import ScanPopup from './src/components/ScanPopup';
import MyQrListPop from './src/components/MyQrListPop';
import WriteQrInfoPop from './src/components/WriteQrInfoPop';
import LocationRequestListPop from './src/components/LocationRequestListPop';
import DeleteFriend from './src/components/DeleteFriend';
import QRViewPopup from './src/components/QRViewPopup';
import QRSelectPop from './src/components/QRSelectPop';
import UpdateQrInfoPop from './src/components/UpdateQrInfoPop';
import FriendCallProfilePop from './src/components/FriendCallProfilePop';
import NetInfo from '@react-native-community/netinfo';
import Geolocation, { GeoPosition } from 'react-native-geolocation-service';

const Stack = createNativeStackNavigator<RootStackParamList>();

PushNotification.configure({
	onRegister: function (token) {
		console.log("TOKEN:", token);
	},
	onNotification: function (notification: Omit<ReceivedNotification, "userInfo">) {
		console.log("@@ onNotification:", notification);
		// iOS 필요
		notification.finish(PushNotificationIOS.FetchResult.NoData);
	},
	permissions: {
		alert: true,
		badge: true,
		sound: true,
	},
	popInitialNotification: true,
	requestPermissions: true,
});
 
//앱 메인 실행 건
const App: React.FC = () => {
	const navigationRef = useRef<NavigationContainerRef<any>>(null);
	const global = useGlobalStore();
	//디바이스 언어를 가져와 언어 세팅 처리 한다. ==> git jikyeojwo 연결됨
	//const {t, i18n} = useTranslation();
	//화면 이전
	const { 
		versionInfo, 
		getVersion,
		updateFcmToken,
		updateNoorijaToken,
	} = useGlobalStore();
	//소켓 연결 

	const initVersionInfo = async () => {
		console.log("initVersionInfo")
		await selectGrobalData(); // 함수를 호출하여 리턴값을 기다림
		console.log("@@ GlobalData.uniqueId================>", GlobalData);
		if( GlobalData.uniqueId ) {
			await getVersion()
		}
	}
	const closeApp = () => { 
		Alert.alert('앱 종료', '앱을 종료하시겠습니까?', [
			{ text: '취소', onPress: () => null },
			{ text: '확인', onPress: () => BackHandler.exitApp() },
		]);
	}

	useEffect(() => {		
		//권한 체크 : 카메라, 마이크, 사운드 
		global.setProcessScreen("splash")
		initVersionInfo()
		const unsubscribeForeground = messaging().onMessage(async (remoteMessage: FirebaseMessagingTypes.RemoteMessage) => {
			console.log('@@ Received foreground message:', remoteMessage);
			const notificationData: NotificationData = {
				title: remoteMessage.notification?.title ?? '차빼줘 호출',
				message: remoteMessage.notification?.body ?? '새로운 메시지가 도착했습니다.',
				data: remoteMessage.data as FCM_RecvData,
			};
			handlePushNotification(notificationData, false);
		});
		return () => {
			unsubscribeForeground();			
		};
	}, []);

	useEffect(() => {
		if ( versionInfo==null ) {
			return;
		}
		requestPermissions()
		initMessageConfig()	
		initPushNotification()

		GlobalData.infoUrl = versionInfo.infoServer;
		GlobalData.callUrl = versionInfo.callServer;
		// GlobalData.autoConnectYn = 'Y'

		console.log("@@ useEffect versionInfo================>", versionInfo);
		if (versionInfo.upRequireInfo == "10" || versionInfo.upRequireInfo == "40") {
			movePage();
		} else {
			showUpdateAlert(versionInfo.storeUrl, versionInfo.upRequireInfo) ;
		}
		let backPressCount: number = 0;
		let timeoutRef: NodeJS.Timeout | null = null;
		BackHandler.addEventListener('hardwareBackPress', () => {
			const navigation = navigationRef.current;
			console.log("@@ backhandler start");
			if( navigation == null ) return true;			
			const state = useGlobalStore.getState();
			if( state.popupPageId ) {				
				console.log("@@ backhandler state.popupPageId", state.popupPageId);
				global.setPopupPageId('');
				return true;
			}
			console.log("@@ backhandler navigation.canGoBack()", navigation.canGoBack(), backPressCount);
			if( navigation.canGoBack() ) {
				const currentRoute = navigation.getState().routes[navigation.getState().index];
				console.log("@@ backhandler navigation.canGoBack()", currentRoute.name);

				if( currentRoute.name == 'Calling' ) {
					return true;
				}
				
				if( currentRoute.name == 'MainHome' || currentRoute.name == 'Tutorial' || 
					currentRoute.name == 'Connect' || currentRoute.name == 'CasDescPop' ||
					currentRoute.name == 'RegConnectInfo'
				) {
					if( timeoutRef ) {
						clearTimeout(timeoutRef);
						timeoutRef = null;
					}
					if( backPressCount === 0 ) {
						backPressCount += 1;
						ToastAndroid.show('한 번 더 누르면 종료됩니다.', ToastAndroid.SHORT);						
						timeoutRef = setTimeout(() => {
							backPressCount = 0;
						}, 2000); // 2초 안에 다시 누르면 종료
						return true;
					}
					backPressCount = 0;
					closeApp();
					return true;
				}
				global.setProcessScreen('');
				navigation.goBack();
				return true;
			}			
        })
	}, [versionInfo]);

	// 화면 변경처리 
	useEffect(() => {
		console.log("@@ useEffect processScreen : ", global.processScreen);	
		//const state = useGlobalStore.getState();
		if( global.processScreen && navigationRef.current  ) {
			navigationRef.current.navigate(global.processScreen);
		}
	}, [global.processScreen]);

	const movePage = () => {
		if( versionInfo ) {
			if (versionInfo.tutoStart == "Y") {
				global.setProcessScreen("Tutorial");
			} else {
				if (GlobalData.autoConnectYn === 'Y') {
					updateNoorijaToken(versionInfo.appKey);
					global.setProcessScreen("MainHome");    
				} else {
					global.setProcessScreen("Connect");
				}			
			}
		}
	}
		// 버전 업데이트 처리 함수 
	const showUpdateAlert = (updateUrl:string, type:string) => {
		Alert.alert(  // versionInfo.tutoStart
			"앱업데이트",
			"새로운 버전이 출시되었습니다!" + (type=='30'?'\n\n 지켜줘 앱을 종료 하신 후 앱스토어로 이동해서 업그레이드 해주세요':''),[
				{
					text: "다음에",
						style: "cancel",
						onPress: () => {
							//console.log("App Close =====================================")
							type=='30' ?  BackHandler.exitApp() : movePage();   
						}
					}, {
					text: "업데이트",
					onPress: () => {
						//console.log("App Update =====================================")
						Linking.openURL(updateUrl)
						BackHandler.exitApp()
					}
				}
			],
			{ cancelable: false }
		);
	} 

	//화면 Stack변경을 위한 튜토리얼에서 데이타 받기
	const callChangeStack =(tokenData: string) => {
		//updateNoorijaToken(tokenData);
		if (GlobalData.autoConnectYn === 'Y') {
			updateNoorijaToken(tokenData);
			global.setProcessScreen("MainHome");  
		} else {
			global.setProcessScreen("Connect");  
		}
		// setProcessScreen(OPEN_LIST_TYPE.MAIN); // 화면 전환처리됨
	}

	// FCM 초기화 및 토큰 설정
	const initPushNotification = async () => {
		// FCM 권한 요청
		const authorizationStatus = await messaging().requestPermission({
			sound: true,
			announcement: true,
			providesAppNotificationSettings: true
		});

		const enabled =
			authorizationStatus === messaging.AuthorizationStatus.AUTHORIZED ||
			authorizationStatus === messaging.AuthorizationStatus.PROVISIONAL;

		console.log('@@ FCM authorizationStatus:', authorizationStatus, enabled);

		if (enabled) {
			await messaging().registerDeviceForRemoteMessages();
			const token = await messaging().getToken();
			updateFcmToken(token);
			console.log('@@ FCM Token:', token);
			
			messaging().onTokenRefresh(token => {
				updateFcmToken(token);
				console.log('New FCM Token:', token);
			});
			
		}
		messaging().setBackgroundMessageHandler(async (remoteMessage: FirebaseMessagingTypes.RemoteMessage) => {
			console.log('@@ Background message received:', remoteMessage);					
			try {
				const message: NotificationData = {
					title: remoteMessage.notification?.title || '차빼줘 호출',
					message: remoteMessage.notification?.body || '새로운 메시지가 도착했습니다.',
					data: remoteMessage.data as FCM_RecvData
				};
				
				// Android에서 백그라운드 알림 표시
				if (Platform.OS === 'android') {
					console.log('@@ Sending Android notification:', message);
					/*
					await new Promise((resolve) => {
						PushNotification.localNotification({
							channelId: "jkjapp",
							title: message.title,
							message: message.message,
							playSound: true,
							soundName: "default",
							importance: "high",
							vibrate: true,
							userInfo: message.data,
							priority: "high",
							smallIcon: "ic_notification",
							largeIcon: "",
							actions: ["확인"],
							invokeApp: true,
						});
						resolve(true);
					});
					*/
					console.log('@@ Android notification sent successfully');
				}						
				// handlePushNotification(message);
			} catch (error) {
				console.error('@@ Error handling background message:', error);
			}
		});

		// 초기 알림 처리
		PushNotification.popInitialNotification((message) => {            
			if (message && message.data) {
				global.setCurrentFcmRecvData(message.data as FCM_RecvData|null);
			}
		});

		// Android 알림 채널 설정을 먼저 수행
		if( Platform.OS === 'android') { 				
			const channel_id = 'jkjapp';
			PushNotification.channelExists(channel_id, async (exists) => {
				console.log('@@ channelExists :', exists); // true/false
			})
			PushNotification.channelBlocked(channel_id, function (blocked) {
				console.log('@@ channelBlocked :', blocked); // true/false
			})
			PushNotification.createChannel({
				channelId: channel_id,
				channelName: "지켜줘 알림",
				channelDescription: "지켜줘 앱의 알림 채널입니다",
				playSound: true,
				soundName: "protectme.wav",
				importance: Importance.HIGH,
				vibrate: true
			}, (created) => {
				console.log('@@ createChannel returned :', created); 
			});
		}
	};

	// 푸시 알림 메시지 처리 함수
	const handlePushNotification = (message: NotificationData, isBackground: boolean) => {
		const state = useGlobalStore.getState();
		console.log('@@ Handling push notification...', state.isAppActive);
		const data : FCM_RecvData|null = message.data as FCM_RecvData || null
		console.log('@@ Handling push notification.data..',data);
		if( data ) {
			if( GlobalData.messageMap[data.callSeq] ) {
				// 지연된 노티가 왔을때 중복된 메시지라면 무시
				console.log('@@ message data is skip callSeq:', data.callSeq)
				return
			}
			if( !isBackground ) {
				isBackground = !state.isAppActive;
			}
			console.log('@@ handlePushNotification message isBackground:', isBackground)
			if( isBackground ) {
				GlobalData.messageMap[data.callSeq] = data;
				global.updateNotificationData(message);
			}
		}
		if (!message || !navigationRef.current) return;
	};
	// 실시간 위치 가져오기
	const getPosition = (): Promise<GeoPosition> => {
		return new Promise((resolve, reject) => {
			Geolocation.getCurrentPosition(
				(position) => {
					console.log("@@ [BackgroundFetch] Got position:", position);
					resolve(position);
				},
				(error) => {
					console.error("@@ [BackgroundFetch] Location error:", error);
					reject(error);
				},
				{
					enableHighAccuracy: true,
					timeout: 15000,
					maximumAge: 10000,
					forceRequestLocation: true,
					showLocationDialog: false
				}
			);
		});
	};
  	
	const initMessageConfig = async () => {		
		const onBackgroundTimeout = async (taskId) => {
			console.log("@@ [BackgroundFetch] timeout taskId: ", taskId);
			try {
				BackgroundFetch.finish(taskId);
			} catch (error) {
				console.error("@@ [BackgroundFetch] Error in timeout handler:", error);
			}
		}

		const onBackgroundFetch = async (taskId) => {
			console.log("@@ [BackgroundFetch] run taskId: ", taskId);
			try {
				// 위치 권한 확인
				const locationPermission = Platform.select({
					ios: PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
					android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
				});

				if (!locationPermission) {
					console.log("@@ [BackgroundFetch] Location permission not available for platform");
					BackgroundFetch.finish(taskId);
					return;
				}

				const hasLocationPermission = await check(locationPermission);
				if (hasLocationPermission !== RESULTS.GRANTED) {
					console.log("@@ [BackgroundFetch] Location permission not granted");
					BackgroundFetch.finish(taskId);
					return;
				}

				// 네트워크 상태 확인
				const netInfo = await NetInfo.fetch();
				if (!netInfo.isConnected) {
					console.log("@@ [BackgroundFetch] No network connection");
					BackgroundFetch.finish(taskId);
					return;
				}				
				const state = useGlobalStore.getState();
				let latitude = state.infoLocation.latitude;
				let longitude = state.infoLocation.longitude;
				if( latitude==0 || longitude==0 ) {
					const position = await getPosition();
					latitude = position.coords.latitude;
					longitude = position.coords.longitude;
				}
				const params = {
					latitude: latitude,
					longitude: longitude,
					currentDate: GetDate(),
					langCd: GlobalData.langCd,
				};
				/*
				accuracy: position.coords.accuracy,
				speed: position.coords.speed,
				heading: position.coords.heading,
				altitude: position.coords.altitude
				*/
				console.log("@@ [BackgroundFetch] Sending location data:", params);
				const info = await callPost("/api/main/save-location", params);
				console.log("@@ [BackgroundFetch] Location saved successfully:", info);
			} catch (error) {
				console.error("@@ [BackgroundFetch] Error in fetch handler:", error);
			} finally {
				BackgroundFetch.finish(taskId);
			}
		}

		try {
			const backgroundStatus = await BackgroundFetch.configure({
				minimumFetchInterval: 15,     // 15분마다 실행
				stopOnTerminate: false,       // 앱 종료 후에도 계속 실행
				startOnBoot: true,            // 기기 재시작 시 자동 시작
				enableHeadless: true,         // 헤드리스 모드 활성화
				requiredNetworkType: BackgroundFetch.NETWORK_TYPE_ANY,
				requiresBatteryNotLow: false,
				requiresCharging: false,      // 충전 중이 아니어도 실행
				requiresDeviceIdle: false,    // 기기가 idle 상태가 아니어도 실행
				requiresStorageNotLow: false,
				forceAlarmManager: true,      // JobScheduler 대신 AlarmManager 사용
			}, onBackgroundFetch, onBackgroundTimeout);

			console.log('@@ [BackgroundFetch] Configuration status:', backgroundStatus);

			// Background Fetch 상태 모니터링
			BackgroundFetch.status((status) => {
				console.log("@@ [BackgroundFetch] Current status:", status);
				switch(status) {
					case BackgroundFetch.STATUS_RESTRICTED:
						console.log("@@ [BackgroundFetch] Restricted by system");
						break;
					case BackgroundFetch.STATUS_DENIED:
						console.log("@@ [BackgroundFetch] Denied by user");
						break;
					case BackgroundFetch.STATUS_AVAILABLE:
						console.log("@@ [BackgroundFetch] Available and enabled");
						break;
				}
			});

			// Background Fetch 시작
			await BackgroundFetch.start();
			console.log("@@ [BackgroundFetch] Started successfully");

		} catch (error) {
			console.error("@@ [BackgroundFetch] Configuration error:", error);
		}

		AppRegistry.registerHeadlessTask('BackgroundFetch', () => async (taskData) => {
			console.log('[BackgroundFetch HeadlessTask] running with taskData: ', taskData);
			try {
				await onBackgroundFetch(taskData.taskId);
				// BackgroundFetch.finish(taskData.taskId);
			} catch (error) {
				BackgroundFetch.finish(taskData.taskId);
			}
		});

		// 앱이 백그라운드에서 알림을 탭한 경우
		messaging().onNotificationOpenedApp((remoteMessage: FirebaseMessagingTypes.RemoteMessage) => {
			console.log('@@ Background notification tapped:', remoteMessage);
			const message: NotificationData = {
				title: remoteMessage.notification?.title || '차빼줘 호출',
				message: remoteMessage.notification?.body || '새로운 메시지가 도착했습니다.',
				data: remoteMessage.data as FCM_RecvData
			};
			handlePushNotification(message, true);
		});

		// 앱이 종료된 상태에서 알림을 탭한 경우
		messaging().getInitialNotification().then((remoteMessage: FirebaseMessagingTypes.RemoteMessage | null) => {
			if (remoteMessage) {
				console.log('@@ App opened by notification...');
				const message: NotificationData = {
					title: remoteMessage.notification?.title || '알림',
					message: remoteMessage.notification?.body || '새로운 메시지가 도착했습니다.',
					data: remoteMessage.data as FCM_RecvData
				};
				handlePushNotification(message, true);
			}
		});
	}

	const requestPermissions = async () => {
		// Android 13 이상에서 알림 권한 요청
		if (Platform.OS === 'android' && Platform.Version >= 33) {
			try {
				const result = await PermissionsAndroid.request(
					PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS
				);
				console.log('@@ Notification permission result:', result);
				if (result !== PermissionsAndroid.RESULTS.GRANTED) {
					console.log('@@ Notification permission denied');
					return;
				}
			} catch (error) {
				console.error('@@ Error requesting notification permission:', error);
			}
		}

		const permissions = [
			// QR 스캔을 위한 카메라 권한
			Platform.select({
				ios: PERMISSIONS.IOS.CAMERA,
				android: PERMISSIONS.ANDROID.CAMERA,
			}),
			// 이미지 다운로드 및 읽기를 위한 저장소 권한
			Platform.select({
				ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
				android: PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
			}),
			// WebRTC를 위한 오디오 권한
			Platform.select({
				ios: PERMISSIONS.IOS.MICROPHONE,
				android: PERMISSIONS.ANDROID.RECORD_AUDIO,
			}),
			// 로컬 파일 업로드를 위한 저장소 권한
			Platform.select({
				ios: PERMISSIONS.IOS.PHOTO_LIBRARY,
				android: PERMISSIONS.ANDROID.READ_EXTERNAL_STORAGE,
			}),
			// 위치정보 권한 요청
			Platform.select({
				ios: PERMISSIONS.IOS.LOCATION_WHEN_IN_USE,
				android: PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION,
			}),
		];
	
		for (const permission of permissions) {
			if (permission) {
				const result = await check(permission);
				if (result === RESULTS.GRANTED) {
					console.log(`${permission} is already granted.`);
				} 
				else {
					const requestResult = await request(permission);
					if (requestResult === RESULTS.GRANTED) {
						console.log(`${permission} granted.`);
					}
				}
			}
		}

		if( Platform.OS == 'android' ) {
			try {
				const permissions = [
					PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
					PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION,
					PermissionsAndroid.PERMISSIONS.ACCESS_BACKGROUND_LOCATION,
				];
		
				const granted = await PermissionsAndroid.requestMultiple(permissions);
				const locationGranted = granted[PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION] === PermissionsAndroid.RESULTS.GRANTED;
				const coarseLocationGranted = granted[PermissionsAndroid.PERMISSIONS.ACCESS_COARSE_LOCATION] === PermissionsAndroid.RESULTS.GRANTED;
				const backgroundLocationGranted = granted[PermissionsAndroid.PERMISSIONS.ACCESS_BACKGROUND_LOCATION] === PermissionsAndroid.RESULTS.GRANTED;
		
				if (locationGranted && coarseLocationGranted && backgroundLocationGranted) {
					console.log('@@ All location permissions granted');
				} else {
					console.log('@@ One or more location permissions denied');
				}
			} catch (err) {
				console.warn('@@ Permission request error:', err);
			}
		}
	};



	return ( 
		<GestureHandlerRootView style={{ flex: 1 }}>
		<SafeAreaProvider>
			<SocketStompProvider>
				<NavigationContainer  ref={navigationRef}>
					<Stack.Navigator screenOptions={{ headerShown: false }}>
						<Stack.Screen name="Splash" component={SplashScreen} />
						<Stack.Screen name="Tutorial">
						{props => (
								<TutorialScreen {...props} callChangeStack={callChangeStack} />
							)}
						</Stack.Screen>
						<Stack.Screen name="CasDesc" component={CasDescPop} />
						<Stack.Screen name="RegConnectInfo" component={RegConnectInfoScreen} />
						<Stack.Screen name="Connect" component={ConnectScreen} />
						<Stack.Screen name="MainHome" component={MainHomeScreen} /> 
						<Stack.Screen name="MyProfile" component={MyProfileScreen} /> 
						<Stack.Screen name="Search" component={SearchScreen} /> 
						<Stack.Screen name="MySetting" component={MySettingScreen} /> 
						<Stack.Screen name="Chat" component={ChatScreen} /> 
						<Stack.Screen name="Calling" component={CallingScreen} /> 
						<Stack.Screen name="Notice" component={NoticeScreen} /> 
						<Stack.Screen name="Inquiry" component={InquiryScreen} /> 
						<Stack.Screen name="Manual" component={ManualScreen} /> 
						<Stack.Screen name="Faq" component={FAQScreen} /> 
						<Stack.Screen name="Group" component={GroupScreen} /> 
					</Stack.Navigator>
				</NavigationContainer>
				{ global.popupPageId=="ReceiveCallPop" && <ReceiveCallPop />}
				{ global.popupPageId=="LocationAllowPop" && <LocationAllowPop />}
				{ global.popupPageId=="CallingCarPopup" && <CallingCarPopup />}
				{ global.popupPageId=="CallingPopup" && <CallingPopup />}
				{ global.popupPageId=="ScanPopup" && <ScanPopup />}
				{ global.popupPageId=="MyQrListPop" && <MyQrListPop />}
				{ global.popupPageId=="WriteQrInfoPop" && <WriteQrInfoPop /> }
				{ global.popupPageId=="LocationRequestPop" && <LocationRequestPop />}
				{ global.popupPageId=="LocationRequestListPop" && <LocationRequestListPop />}
				{ global.popupPageId=="QRViewPopup" && <QRViewPopup />}
				{ global.popupPageId=="DeleteFriend" && <DeleteFriend />}
				{ global.popupPageId=="QRSelectPop" && <QRSelectPop />}
				{ global.popupPageId=="UpdateQrInfoPop" &&  <UpdateQrInfoPop />	}
				{ global.popupPageId=="FriendCallProfilePop" &&  <FriendCallProfilePop/>	}

			</SocketStompProvider>
		</SafeAreaProvider>
		</GestureHandlerRootView>
	);
};

// 스타일 정의
const styles = StyleSheet.create({
	
	bottomContainer: {
		flex:1, width: '100%', height: '100%', justifyContent: 'flex-end', backgroundColor: '#F7F8FA',
	},
});
export default App;


