module.exports = {
  presets: ['module:@react-native/babel-preset'],
  plugins: ['react-native-reanimated/plugin', 
    [
    'module-resolver', {
      root: ['./src'],
      extensions: [
        '.ios.ts',
        '.android.ts',
        '.ts',
        '.ios.tsx',
        '.android.tsx',
        '.tsx',
        '.jsx',
        '.js',
        '.json',
      ],
      alias: {
        '@': './src',
        '@assets': './src/assets',
        '@components': './src/components',
        '@constants': './src/constants',
        '@types': './src/types',
        '@store': './src/store',
      },
    }
  ]]
};
